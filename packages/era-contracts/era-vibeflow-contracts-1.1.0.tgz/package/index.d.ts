export type JsonPrimitive = string | number | boolean | null;
export type JsonValue =
  | JsonPrimitive
  | readonly JsonValue[]
  | { readonly [key: string]: JsonValue };

export type MacroStoredStat =
  | { readonly kind: "present"; readonly value: JsonValue }
  | { readonly kind: "missing" };

export interface MacroInputs {
  readonly substring: string;
  readonly storedStat: MacroStoredStat;
}

export interface MacroOutputs {
  readonly replacement: string;
}

export type EraTransportArg =
  | { readonly kind: "json"; readonly value: JsonValue }
  | { readonly kind: "undefined" }
  | {
      readonly kind: "host-ref";
      readonly token: string;
      readonly refKind: string;
    };

export interface EraTransportEventV1 {
  readonly schemaVersion: 1;
  readonly eventId: string;
  readonly sequence: number;
  readonly type: string;
  readonly occurredAt: number;
  readonly source: "tavern" | "ui" | "era-api" | "timer";
  readonly args: readonly EraTransportArg[];
  readonly encodedBytes: number;
}

export declare const ERA_COLLECTION_TIMER_EVENT_TYPE: "era.service.collection_timer";

export interface EraServiceConfigV1 {
  readonly max_event_bytes: number;
  readonly max_fifo_events: number;
  readonly max_fifo_bytes: number;
  readonly max_collection_events: number;
  readonly max_collection_bytes: number;
  readonly max_batch_steps: number;
  readonly barrier_watchdog_ms: number;
  readonly max_host_refs_per_event: number;
}

export declare const DEFAULT_ERA_SERVICE_CONFIG_V1: Readonly<EraServiceConfigV1>;

export interface EraServiceStateV1 {
  readonly schemaVersion: 1;
  readonly collection: readonly EraTransportEventV1[];
  readonly collectionBytes: number;
  readonly iteration: number;
  readonly consecutiveProcessingCount: number;
  readonly consecutiveMk: string | null;
  readonly timerToken: string | null;
}

export type EraCollectionRouteV1 = "wait" | "execute";

export interface EraCollectionReductionV1 {
  readonly schemaVersion: 1;
  readonly route: EraCollectionRouteV1;
  readonly nextState: EraServiceStateV1;
  readonly batchEvents: readonly EraTransportEventV1[];
  readonly throughSequence: number | null;
}

export type EraTaskRouteV1 = "initialize" | "sync" | "api" | "update-mk";

export interface EraPlannedStepV1 {
  readonly stepId: string;
  readonly index: number;
  readonly taskRoute: EraTaskRouteV1;
  readonly sourceSequences: readonly number[];
  readonly events: readonly EraTransportEventV1[];
}

export interface EraBatchPlanV1 {
  readonly schemaVersion: 1;
  readonly batchId: string;
  readonly throughSequence: number;
  readonly nextState: EraServiceStateV1;
  readonly events: readonly EraTransportEventV1[];
  readonly sourceSequences: readonly number[];
  readonly steps: readonly EraPlannedStepV1[];
}

export interface EraFailureV1 {
  readonly code: string;
  readonly message: string;
  readonly category: "input" | "domain" | "tavern" | "cancelled";
  readonly retryable: boolean;
  readonly details?: Readonly<Record<string, JsonValue>>;
}

export type EraSettlementV1 =
  | {
      readonly eventId: string;
      readonly sequence: number;
      readonly status: "completed";
      readonly taskId: string;
      readonly relation: "primary" | "combined" | "coalesced";
      readonly value?: JsonValue;
    }
  | {
      readonly eventId: string;
      readonly sequence: number;
      readonly status: "ignored";
      readonly reason: string;
    }
  | {
      readonly eventId: string;
      readonly sequence: number;
      readonly status: "failed";
      readonly error: EraFailureV1;
    }
  | {
      readonly eventId: string;
      readonly sequence: number;
      readonly status: "cancelled";
      readonly reason: string;
    };

export interface EraNotificationV1 {
  readonly type: string;
  readonly args: readonly EraTransportArg[];
}

export interface EraDiagnosticV1 {
  readonly code: string;
  readonly message: string;
  readonly sequence: number | null;
}

export type EraTaskStatusV1 = "committed" | "no-op" | "failed" | "fatal";

export interface EraTaskResultV1 {
  readonly status: EraTaskStatusV1;
  readonly settlements: readonly EraSettlementV1[];
  readonly notifications: readonly EraNotificationV1[];
  readonly diagnostics: readonly EraDiagnosticV1[];
}

export interface EraExecutionSourceV1 {
  readonly eventId: string;
  readonly sequence: number;
}

export interface EraBatchExecutionStateV1 {
  readonly schemaVersion: 1;
  readonly batchId: string;
  readonly throughSequence: number;
  readonly nextState: EraServiceStateV1;
  readonly sources: readonly EraExecutionSourceV1[];
  readonly steps: readonly EraPlannedStepV1[];
  readonly index: number;
  readonly settlements: readonly EraSettlementV1[];
  readonly notifications: readonly EraNotificationV1[];
  readonly diagnostics: readonly EraDiagnosticV1[];
  readonly fatal: boolean;
  readonly coverageError: string | null;
}

export type EraBatchExecutionStateNextV1 = EraBatchExecutionStateV1;
export type EraBatchExecutionStateAfterV1 = EraBatchExecutionStateV1;
export type EraStepRequestV1 = EraPlannedStepV1;
export type EraStepRequestRoutedV1 = EraPlannedStepV1;

export interface EraBatchFinalizationV1 {
  readonly schemaVersion: 1;
  readonly batchId: string;
  readonly throughSequence: number;
  readonly nextState: EraServiceStateV1;
  readonly settlements: readonly EraSettlementV1[];
  readonly notifications: readonly EraNotificationV1[];
  readonly diagnostics: readonly EraDiagnosticV1[];
  readonly fatal: boolean;
}

export type EraCollectionCommandV1 =
  | {
      readonly kind: "schedule";
      readonly token: string;
      readonly dueAt: number;
    }
  | {
      readonly kind: "cancel";
      readonly token: string;
    };

export interface EraCollectionControlV1 {
  readonly schemaVersion: 1;
  readonly frameId: string;
  readonly kind: "collection-control";
  readonly commands: readonly EraCollectionCommandV1[];
}

export interface EraBatchResultV1 {
  readonly schemaVersion: 1;
  readonly frameId: string;
  readonly kind: "batch-result";
  readonly throughSequence: number;
  readonly settlements: readonly EraSettlementV1[];
  readonly notifications: readonly EraNotificationV1[];
  readonly diagnostics: readonly EraDiagnosticV1[];
  readonly fatal: boolean;
}

export declare function isJsonValue(value: unknown): value is JsonValue;
export declare function isPresentMacroStoredStat(
  value: unknown,
): value is Extract<MacroStoredStat, { readonly kind: "present" }>;
export declare function missingMacroStoredStat(): Readonly<{
  kind: "missing";
}>;
export declare function isEraTransportArg(value: unknown): value is EraTransportArg;
export declare function isEraTransportEventV1(value: unknown): value is EraTransportEventV1;
export declare function countEraHostRefs(event: EraTransportEventV1): number;
export declare function isEraServiceConfigV1(value: unknown): value is EraServiceConfigV1;
export declare function isEraServiceStateV1(value: unknown): value is EraServiceStateV1;
export declare function isEraPlannedStepV1(value: unknown): value is EraPlannedStepV1;
export declare function isEraFailureV1(value: unknown): value is EraFailureV1;
export declare function isEraSettlementV1(value: unknown): value is EraSettlementV1;
export declare function isEraNotificationV1(value: unknown): value is EraNotificationV1;
export declare function isEraDiagnosticV1(value: unknown): value is EraDiagnosticV1;
export declare function isEraTaskResultV1(value: unknown): value is EraTaskResultV1;
export declare function isEraCollectionControlV1(value: unknown): value is EraCollectionControlV1;
export declare function isEraBatchResultV1(value: unknown): value is EraBatchResultV1;
