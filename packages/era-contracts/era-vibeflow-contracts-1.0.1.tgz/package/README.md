# `@era/vibeflow-contracts`

该目录是跨 app、Service AOT 和 Macro AOT 的公开 DTO、JSON Schema 与纯
codec 唯一来源。包本身不访问宿主，也不包含工作流调度逻辑。

规则：

- 只包含 JSON 可移植类型、Schema 和无 I/O 的 codec。
- 不导入 Tavern、DOM、Vue、VibeFlow node 或 Host Extension。
- runtime `schemaVersion` 不得写入 ERA 持久化变量。
- 跨边界的 Service/Macro Data Schema 必须与本目录 `schemas/` 中的 canonical
  Schema 结构等价；工作流内部临时数据类型不属于跨边界契约。
- `npm run check:schema-sync` 对两个 root 的公开 descriptor 执行结构等价检查。
- 发布给两个 AOT root 的依赖使用固定版本 tarball，并分别写入 npm lock。
