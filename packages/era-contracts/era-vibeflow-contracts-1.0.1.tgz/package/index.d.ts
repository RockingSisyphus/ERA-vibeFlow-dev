export type JsonPrimitive = string | number | boolean | null;
export type JsonValue =
  | JsonPrimitive
  | readonly JsonValue[]
  | { readonly [key: string]: JsonValue };

export type MacroStoredStat =
  | { readonly kind: "present"; readonly value: JsonValue }
  | { readonly kind: "missing" };

export interface MacroInputs {
  readonly substring: string;
  readonly storedStat: MacroStoredStat;
}

export interface MacroOutputs {
  readonly replacement: string;
}

export type EraTransportArg =
  | { readonly kind: "json"; readonly value: JsonValue }
  | { readonly kind: "undefined" }
  | {
      readonly kind: "host-ref";
      readonly token: string;
      readonly refKind: string;
    };

export interface EraTransportEventV1 {
  readonly schemaVersion: 1;
  readonly eventId: string;
  readonly sequence: number;
  readonly type: string;
  readonly occurredAt: number;
  readonly source: "tavern" | "ui" | "era-api" | "timer";
  readonly args: readonly EraTransportArg[];
  readonly encodedBytes: number;
}

export declare function isJsonValue(value: unknown): value is JsonValue;
export declare function isPresentMacroStoredStat(
  value: unknown,
): value is Extract<MacroStoredStat, { readonly kind: "present" }>;
export declare function missingMacroStoredStat(): Readonly<{
  kind: "missing";
}>;
