/**
 * 判断值是否为可移植 JSON 值。
 *
 * 该 codec 只做结构判断，不克隆、不修改输入，也不访问任何宿主资源。
 */
export function isJsonValue(value) {
  if (
    value === null ||
    typeof value === "string" ||
    typeof value === "boolean"
  ) {
    return true;
  }

  if (typeof value === "number") {
    return Number.isFinite(value);
  }

  if (Array.isArray(value)) {
    return value.every(isJsonValue);
  }

  if (typeof value !== "object") {
    return false;
  }

  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    return false;
  }

  return Object.values(value).every(isJsonValue);
}

/** 判断宏输入是否携带一份存在的已存 ERA 状态。 */
export function isPresentMacroStoredStat(value) {
  return (
    typeof value === "object" &&
    value !== null &&
    value.kind === "present" &&
    Object.prototype.hasOwnProperty.call(value, "value") &&
    isJsonValue(value.value)
  );
}

/** 构造显式的状态缺失标记。 */
export function missingMacroStoredStat() {
  return Object.freeze({ kind: "missing" });
}
