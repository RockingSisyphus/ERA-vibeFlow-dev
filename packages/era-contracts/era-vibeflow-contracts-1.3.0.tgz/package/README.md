# `@era/vibeflow-contracts`

该目录是跨 app、Service AOT 和 Macro AOT 的公开 DTO、JSON Schema 与纯
codec 唯一来源。包本身不访问宿主，也不包含工作流调度逻辑。

规则：

- 只包含 JSON 可移植类型、Schema 和无 I/O 的 codec。
- 不导入 Tavern、DOM、Vue、VibeFlow node 或 Host Extension。
- runtime `schemaVersion` 不得写入 ERA 持久化变量。
- Service 与 Macro Data Schema 必须与本目录 `schemas/` 中的 canonical Schema
  结构等价；Service 的动态步骤、执行状态和收尾状态也在此固定，避免节点、Host
  与出站帧各自猜测字段。
- 1.2 的 `EraPlannedStepV1` 是严格 `execute | ignore` 联合：execute 必须携带
  完整 `EraDomainTaskV1` 与 `EraPlannedSourceV1[]`，ignore 必须携带原始原因；
  `TaskResult.stateUpdate` 只更新易失 Service 连续处理状态。
- 两个内部 UI 初始化事件使用 `EraInitializeTaskV1.operation` 区分
  `resources` 与 `settings-update`，`app_ready` 固定为 `startup`；它们不属于公开
  13 API。
- `npm run check:schema-sync` 对 12 个 Macro descriptor 与 18 个 Service
  descriptor 执行结构等价检查，并核对传输参数、结算、通知、诊断及定时器命令
  在复合 Schema 中的嵌入结构。
- `args` 不限制参数总数；`max_host_refs_per_event` 只限制其中 `host-ref` 标签的数量，
  由 Host 在接受事件前执行。
- `timer` 来源固定使用 `era.service.collection_timer`，并由 workflow 校验 token；
  迟到定时器不得关闭其他事件集。
- 所有 runtime DTO 默认拒绝未知字段；仅错误 `details` 允许保留可移植 JSON 扩展。
- 发布给两个 AOT root 的依赖使用固定版本 tarball，并分别写入 npm lock。
