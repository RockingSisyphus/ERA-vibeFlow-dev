/**
 * 判断值是否为可移植 JSON 值。
 *
 * 该 codec 只做结构判断，不克隆、不修改输入，也不访问任何宿主资源。
 */
export function isJsonValue(value) {
  if (
    value === null ||
    typeof value === "string" ||
    typeof value === "boolean"
  ) {
    return true;
  }

  if (typeof value === "number") {
    return Number.isFinite(value);
  }

  if (Array.isArray(value)) {
    return value.every(isJsonValue);
  }

  if (typeof value !== "object") {
    return false;
  }

  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) {
    return false;
  }

  return Object.values(value).every(isJsonValue);
}

/** 判断宏输入是否携带一份存在的已存 ERA 状态。 */
export function isPresentMacroStoredStat(value) {
  return (
    typeof value === "object" &&
    value !== null &&
    value.kind === "present" &&
    Object.prototype.hasOwnProperty.call(value, "value") &&
    isJsonValue(value.value)
  );
}

/** 构造显式的状态缺失标记。 */
export function missingMacroStoredStat() {
  return Object.freeze({ kind: "missing" });
}

/** ERA Host 合成的收集定时器事件类型。 */
export const ERA_COLLECTION_TIMER_EVENT_TYPE = "era.service.collection_timer";

/** 首版 Service 的锁定资源上限。 */
export const DEFAULT_ERA_SERVICE_CONFIG_V1 = Object.freeze({
  max_event_bytes: 262144,
  max_fifo_events: 256,
  max_fifo_bytes: 8388608,
  max_collection_events: 128,
  max_collection_bytes: 2097152,
  max_batch_steps: 128,
  barrier_watchdog_ms: 5000,
  max_host_refs_per_event: 32,
});

function isRecord(value) {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function hasOnlyKeys(value, requiredKeys, optionalKeys = []) {
  if (!isRecord(value)) {
    return false;
  }
  const allowed = new Set([...requiredKeys, ...optionalKeys]);
  return (
    requiredKeys.every((key) =>
      Object.prototype.hasOwnProperty.call(value, key),
    ) && Object.keys(value).every((key) => allowed.has(key))
  );
}

function isNonEmptyString(value) {
  return typeof value === "string" && value.length > 0;
}

function isSafeIntegerAtLeast(value, minimum) {
  return Number.isSafeInteger(value) && value >= minimum;
}

function isFiniteNumber(value) {
  return typeof value === "number" && Number.isFinite(value);
}

/** 判断一个值是否为无损传输参数标签。 */
export function isEraTransportArg(value) {
  if (!isRecord(value)) {
    return false;
  }
  if (value.kind === "json") {
    return hasOnlyKeys(value, ["kind", "value"]) && isJsonValue(value.value);
  }
  if (value.kind === "undefined") {
    return hasOnlyKeys(value, ["kind"]);
  }
  if (value.kind === "host-ref") {
    return (
      hasOnlyKeys(value, ["kind", "token", "refKind"]) &&
      isNonEmptyString(value.token) &&
      isNonEmptyString(value.refKind)
    );
  }
  return false;
}

/** 判断一个值是否为首版 ERA 传输事件。 */
export function isEraTransportEventV1(value) {
  if (
    !hasOnlyKeys(value, [
      "schemaVersion",
      "eventId",
      "sequence",
      "type",
      "occurredAt",
      "source",
      "args",
      "encodedBytes",
    ])
  ) {
    return false;
  }

  const sourceIsValid = ["tavern", "ui", "era-api", "timer"].includes(
    value.source,
  );
  return (
    value.schemaVersion === 1 &&
    isNonEmptyString(value.eventId) &&
    isSafeIntegerAtLeast(value.sequence, 1) &&
    isNonEmptyString(value.type) &&
    isFiniteNumber(value.occurredAt) &&
    sourceIsValid &&
    (value.source !== "timer" ||
      value.type === ERA_COLLECTION_TIMER_EVENT_TYPE) &&
    Array.isArray(value.args) &&
    value.args.every(isEraTransportArg) &&
    isSafeIntegerAtLeast(value.encodedBytes, 0) &&
    value.encodedBytes <= DEFAULT_ERA_SERVICE_CONFIG_V1.max_event_bytes
  );
}

/** 统计单事件中的宿主引用；32 个上限由 Host 接受事件前应用。 */
export function countEraHostRefs(event) {
  return event.args.reduce(
    (count, arg) => count + (arg.kind === "host-ref" ? 1 : 0),
    0,
  );
}

/** 判断一个值是否为首版 Service 资源上限配置。 */
export function isEraServiceConfigV1(value) {
  if (
    !hasOnlyKeys(value, [
      "max_event_bytes",
      "max_fifo_events",
      "max_fifo_bytes",
      "max_collection_events",
      "max_collection_bytes",
      "max_batch_steps",
      "barrier_watchdog_ms",
      "max_host_refs_per_event",
    ])
  ) {
    return false;
  }
  return (
    isSafeIntegerAtLeast(value.max_event_bytes, 1) &&
    isSafeIntegerAtLeast(value.max_fifo_events, 1) &&
    isSafeIntegerAtLeast(value.max_fifo_bytes, 1) &&
    isSafeIntegerAtLeast(value.max_collection_events, 1) &&
    value.max_collection_events <= 128 &&
    isSafeIntegerAtLeast(value.max_collection_bytes, 1) &&
    isSafeIntegerAtLeast(value.max_batch_steps, 1) &&
    value.max_batch_steps <= 128 &&
    isSafeIntegerAtLeast(value.barrier_watchdog_ms, 0) &&
    isSafeIntegerAtLeast(value.max_host_refs_per_event, 0)
  );
}

/** 判断一个值是否为永久循环携带的有界 Service 状态。 */
export function isEraServiceStateV1(value) {
  if (
    !hasOnlyKeys(value, [
      "schemaVersion",
      "collection",
      "collectionBytes",
      "iteration",
      "consecutiveProcessingCount",
      "consecutiveMk",
      "timerToken",
    ])
  ) {
    return false;
  }
  return (
    value.schemaVersion === 1 &&
    Array.isArray(value.collection) &&
    value.collection.length <= 128 &&
    value.collection.every(isEraTransportEventV1) &&
    isSafeIntegerAtLeast(value.collectionBytes, 0) &&
    value.collectionBytes <=
      DEFAULT_ERA_SERVICE_CONFIG_V1.max_collection_bytes &&
    isSafeIntegerAtLeast(value.iteration, 0) &&
    isSafeIntegerAtLeast(value.consecutiveProcessingCount, 0) &&
    (value.consecutiveMk === null || isNonEmptyString(value.consecutiveMk)) &&
    (value.timerToken === null || isNonEmptyString(value.timerToken))
  );
}

const ERA_EXECUTABLE_TASK_ROUTES = ["initialize", "sync", "api", "update-mk"];
const ERA_EVENT_RELATIONS = ["primary", "combined", "coalesced"];
const ERA_TASK_CONTEXTS = ["none", "latest-message", "latest-message-with-mk"];
const ERA_SYNC_REASONS = [
  "history-changed",
  "edited",
  "swipe-regeneration",
  "manual",
  "api-write",
];

function sameEventIdentity(left, right) {
  return left.eventId === right.eventId && left.sequence === right.sequence;
}

function isBoundedEventArray(value) {
  return (
    Array.isArray(value) &&
    value.length >= 1 &&
    value.length <= 128 &&
    value.every(isEraTransportEventV1)
  );
}

function hasValidDomainTaskBase(value) {
  return (
    isNonEmptyString(value.id) &&
    isBoundedEventArray(value.sourceEvents) &&
    isEraTransportEventV1(value.primaryEvent) &&
    value.sourceEvents.some((event) =>
      sameEventIdentity(event, value.primaryEvent),
    ) &&
    ERA_TASK_CONTEXTS.includes(value.context)
  );
}

function isEraSyncTargetV1(value) {
  if (!isRecord(value)) return false;
  if (value.kind === "auto") return hasOnlyKeys(value, ["kind"]);
  if (value.kind === "message") {
    return (
      hasOnlyKeys(value, ["kind", "messageId", "stopAfterTarget"]) &&
      isSafeIntegerAtLeast(value.messageId, 0) &&
      typeof value.stopAfterTarget === "boolean"
    );
  }
  return (
    value.kind === "previous-of-latest" &&
    hasOnlyKeys(value, ["kind", "stopAfterTarget"]) &&
    value.stopAfterTarget === true
  );
}

/** 判断一个值是否完整携带候选基线领域任务语义。 */
export function isEraDomainTaskV1(value) {
  if (!isRecord(value) || !hasValidDomainTaskBase(value)) return false;
  const baseKeys = ["id", "sourceEvents", "primaryEvent", "context", "kind"];
  if (value.kind === "initialize") {
    return (
      hasOnlyKeys(value, [...baseKeys, "operation", "args"]) &&
      ["startup", "resources", "settings-update"].includes(value.operation) &&
      Array.isArray(value.args) &&
      value.args.every(isEraTransportArg)
    );
  }
  if (value.kind === "update-mk") {
    return hasOnlyKeys(value, baseKeys);
  }
  if (value.kind === "sync") {
    return (
      hasOnlyKeys(value, [...baseKeys, "reason", "target", "fullRebuild"]) &&
      ERA_SYNC_REASONS.includes(value.reason) &&
      isEraSyncTargetV1(value.target) &&
      typeof value.fullRebuild === "boolean"
    );
  }
  if (value.kind === "api") {
    return (
      hasOnlyKeys(value, [...baseKeys, "intent", "eventType", "args"]) &&
      ["query", "message-write", "state-sync"].includes(value.intent) &&
      isNonEmptyString(value.eventType) &&
      Array.isArray(value.args) &&
      value.args.every(isEraTransportArg)
    );
  }
  return false;
}

/** 判断一个值是否为带候选关系的计划来源。 */
export function isEraPlannedSourceV1(value) {
  return (
    hasOnlyKeys(value, ["event", "relation"]) &&
    isEraTransportEventV1(value.event) &&
    ERA_EVENT_RELATIONS.includes(value.relation)
  );
}

function hasValidStepBase(value) {
  return (
    isNonEmptyString(value.stepId) &&
    isSafeIntegerAtLeast(value.index, 0) &&
    value.index <= 127 &&
    Array.isArray(value.sourceSequences) &&
    value.sourceSequences.length >= 1 &&
    value.sourceSequences.length <= 128 &&
    value.sourceSequences.every((sequence) =>
      isSafeIntegerAtLeast(sequence, 1),
    ) &&
    new Set(value.sourceSequences).size === value.sourceSequences.length &&
    isBoundedEventArray(value.events) &&
    value.events.length === value.sourceSequences.length &&
    value.events.every(
      (event, index) => event.sequence === value.sourceSequences[index],
    )
  );
}

/** 判断一个值是否为无损且有界的 execute/ignore 动态步骤。 */
export function isEraPlannedStepV1(value) {
  if (!isRecord(value) || !hasValidStepBase(value)) return false;
  const baseKeys = [
    "kind",
    "stepId",
    "index",
    "taskRoute",
    "sourceSequences",
    "events",
  ];
  if (value.kind === "ignore") {
    return (
      hasOnlyKeys(value, [...baseKeys, "reason"]) &&
      value.taskRoute === "ignore" &&
      isNonEmptyString(value.reason)
    );
  }
  if (value.kind !== "execute") return false;
  if (
    !hasOnlyKeys(value, [...baseKeys, "task", "sources"]) ||
    !ERA_EXECUTABLE_TASK_ROUTES.includes(value.taskRoute) ||
    !isEraDomainTaskV1(value.task) ||
    value.task.kind !== value.taskRoute ||
    !Array.isArray(value.sources) ||
    value.sources.length !== value.events.length ||
    !value.sources.every(isEraPlannedSourceV1) ||
    !value.sources.every((source, index) =>
      sameEventIdentity(source.event, value.events[index]),
    ) ||
    value.task.sourceEvents.length !== value.events.length ||
    !value.task.sourceEvents.every((event, index) =>
      sameEventIdentity(event, value.events[index]),
    )
  ) {
    return false;
  }
  return true;
}

/** 判断一个值是否为稳定的可恢复业务错误。 */
export function isEraFailureV1(value) {
  if (
    !hasOnlyKeys(
      value,
      ["code", "message", "category", "retryable"],
      ["details"],
    )
  ) {
    return false;
  }
  return (
    isNonEmptyString(value.code) &&
    typeof value.message === "string" &&
    ["input", "domain", "tavern", "cancelled"].includes(value.category) &&
    typeof value.retryable === "boolean" &&
    (!Object.prototype.hasOwnProperty.call(value, "details") ||
      (isRecord(value.details) && isJsonValue(value.details)))
  );
}

/** 判断一个值是否为恰好一次事件结算。 */
export function isEraSettlementV1(value) {
  if (
    !isRecord(value) ||
    !isNonEmptyString(value.eventId) ||
    !isSafeIntegerAtLeast(value.sequence, 1)
  ) {
    return false;
  }
  if (value.status === "completed") {
    return (
      hasOnlyKeys(
        value,
        ["eventId", "sequence", "status", "taskId", "relation"],
        ["value"],
      ) &&
      isNonEmptyString(value.taskId) &&
      ["primary", "combined", "coalesced"].includes(value.relation) &&
      (!Object.prototype.hasOwnProperty.call(value, "value") ||
        isJsonValue(value.value))
    );
  }
  if (value.status === "ignored" || value.status === "cancelled") {
    return (
      hasOnlyKeys(value, ["eventId", "sequence", "status", "reason"]) &&
      isNonEmptyString(value.reason)
    );
  }
  if (value.status === "failed") {
    return (
      hasOnlyKeys(value, ["eventId", "sequence", "status", "error"]) &&
      isEraFailureV1(value.error)
    );
  }
  return false;
}

/** 判断一个值是否为锁外通知声明。 */
export function isEraNotificationV1(value) {
  return (
    hasOnlyKeys(value, ["type", "args"]) &&
    isNonEmptyString(value.type) &&
    Array.isArray(value.args) &&
    value.args.every(isEraTransportArg)
  );
}

/** 判断一个值是否为结构化 Service 诊断。 */
export function isEraDiagnosticV1(value) {
  return (
    hasOnlyKeys(value, ["code", "message", "sequence"]) &&
    isNonEmptyString(value.code) &&
    typeof value.message === "string" &&
    (value.sequence === null || isSafeIntegerAtLeast(value.sequence, 1))
  );
}

/** 判断任务携带的易失连续处理状态更新；该值不属于持久化 Schema。 */
export function isEraTaskStateUpdateV1(value) {
  return (
    hasOnlyKeys(value, ["consecutiveMk", "consecutiveProcessingCount"]) &&
    (value.consecutiveMk === null || isNonEmptyString(value.consecutiveMk)) &&
    isSafeIntegerAtLeast(value.consecutiveProcessingCount, 0)
  );
}

/** 判断一个值是否为固定状态的领域任务结果。 */
export function isEraTaskResultV1(value) {
  return (
    hasOnlyKeys(
      value,
      ["status", "settlements", "notifications", "diagnostics"],
      ["stateUpdate"],
    ) &&
    ["committed", "no-op", "failed", "fatal"].includes(value.status) &&
    Array.isArray(value.settlements) &&
    value.settlements.length <= 128 &&
    value.settlements.every(isEraSettlementV1) &&
    Array.isArray(value.notifications) &&
    value.notifications.every(isEraNotificationV1) &&
    Array.isArray(value.diagnostics) &&
    value.diagnostics.every(isEraDiagnosticV1) &&
    (!Object.prototype.hasOwnProperty.call(value, "stateUpdate") ||
      isEraTaskStateUpdateV1(value.stateUpdate))
  );
}

function isEraCollectionCommandV1(value) {
  if (!isRecord(value)) {
    return false;
  }
  if (value.kind === "schedule") {
    return (
      hasOnlyKeys(value, ["kind", "token", "dueAt"]) &&
      isNonEmptyString(value.token) &&
      isFiniteNumber(value.dueAt)
    );
  }
  if (value.kind === "cancel") {
    return (
      hasOnlyKeys(value, ["kind", "token"]) && isNonEmptyString(value.token)
    );
  }
  return false;
}

/** 判断一个值是否为幂等事件集控制帧。 */
export function isEraCollectionControlV1(value) {
  return (
    hasOnlyKeys(value, ["schemaVersion", "frameId", "kind", "commands"]) &&
    value.schemaVersion === 1 &&
    isNonEmptyString(value.frameId) &&
    value.kind === "collection-control" &&
    Array.isArray(value.commands) &&
    value.commands.every(isEraCollectionCommandV1)
  );
}

/** 判断一个值是否为幂等批次结果帧。 */
export function isEraBatchResultV1(value) {
  return (
    hasOnlyKeys(value, [
      "schemaVersion",
      "frameId",
      "kind",
      "throughSequence",
      "settlements",
      "notifications",
      "diagnostics",
      "fatal",
    ]) &&
    value.schemaVersion === 1 &&
    isNonEmptyString(value.frameId) &&
    value.kind === "batch-result" &&
    isSafeIntegerAtLeast(value.throughSequence, 1) &&
    Array.isArray(value.settlements) &&
    value.settlements.length >= 1 &&
    value.settlements.length <= 128 &&
    value.settlements.every(isEraSettlementV1) &&
    Array.isArray(value.notifications) &&
    value.notifications.every(isEraNotificationV1) &&
    Array.isArray(value.diagnostics) &&
    value.diagnostics.every(isEraDiagnosticV1) &&
    typeof value.fatal === "boolean"
  );
}
