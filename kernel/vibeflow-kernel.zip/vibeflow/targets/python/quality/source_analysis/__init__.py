from __future__ import annotations

import ast
from dataclasses import dataclass
from typing import Any

from vibeflow.core.contracts import DataProvider, DataRequirement
from vibeflow.targets.python.project.node import EFFECT_SCOPE_NONE, EFFECT_SCOPE_TRUSTED, NodeContract, NodeInfo, PureNode, effective_effect_scope
from vibeflow.targets.python.quality.source_analysis.ast_rules import import_aliases_from_node, imported_module_roots
from vibeflow.targets.python.quality.source_analysis.helpers import _dedupe_violations, _violation
from vibeflow.targets.python.quality.source_analysis.metrics import _ComplexityCounter, _analyze_internal_call_chain
from vibeflow.targets.python.quality.source_analysis.runtime_dispatch import (
    RuntimeDispatchAnalysis,
    RuntimeDispatchSite,
    analyze_runtime_dispatch,
)
from vibeflow.targets.python.quality.source_analysis.source import _parse_source, _source_info
from vibeflow.targets.python.quality.source_analysis.types import NodeMetrics, PurityPolicy, PurityViolation
from vibeflow.targets.python.quality.source_analysis.validators import (
    _validate_architecture_smells,
    _validate_call_chain_metrics,
    _validate_complexity_metrics,
    _validate_contract,
    _validate_flow_kind_contract,
    _validate_interface,
    _validate_node_info,
    _validate_source_size,
)
from vibeflow.targets.python.quality.source_analysis.visitors import ModulePurityVisitor, NodePurityVisitor


@dataclass(frozen=True)
class _ClassVisitorContext:
    class_tree: object
    contract: object
    policy: PurityPolicy
    source: object
    known_node_modules: tuple[str, ...]
    known_node_class_names: tuple[str, ...]
    effect_scope: str
    module_aliases: dict[str, str]
    imported_roots: set[str]
    module_state_names: set[str]


def validate_node_class(
    node_cls: type[PureNode],
    *,
    policy: PurityPolicy | None = None,
    expected_type: str | None = None,
    known_node_modules: tuple[str, ...] = (),
    known_node_class_names: tuple[str, ...] = (),
    scan_module: bool = False,
    configured_param_count: int = 0,
) -> list[PurityViolation]:
    policy = policy or PurityPolicy()
    source = _source_info(node_cls)
    violations: list[PurityViolation] = []
    info = getattr(node_cls, "NODE_INFO", None)
    contract = getattr(node_cls, "CONTRACT", None)
    effect_scope = effective_effect_scope(info)

    _append_contract_violations(node_cls, info, contract, expected_type, source, violations)

    if effect_scope == EFFECT_SCOPE_TRUSTED:
        return _dedupe_violations(violations)

    if source.class_text is None:
        violations.append(_source_unavailable_violation(source))
        return violations

    violations.extend(_validate_source_size(source.class_text, policy=policy, source=source))
    class_tree = _parse_source(source.class_text, source=source)
    if isinstance(class_tree, PurityViolation):
        violations.append(class_tree)
        return violations
    metrics = collect_node_metrics(node_cls, configured_param_count=configured_param_count)
    violations.extend(_validate_complexity_metrics(metrics, policy=policy, source=source))
    violations.extend(_validate_call_chain_metrics(metrics, policy=policy, source=source))
    if isinstance(info, NodeInfo) and isinstance(contract, NodeContract) and _contract_items_valid(contract):
        violations.extend(_validate_architecture_smells(info, contract, source=source, metrics=metrics))

    module_aliases, imported_roots, module_state_names = _module_import_context(source)
    visitor_context = _ClassVisitorContext(
        class_tree,
        contract,
        policy,
        source,
        known_node_modules,
        known_node_class_names,
        effect_scope,
        module_aliases,
        imported_roots,
        module_state_names,
    )
    _append_class_visitor_violations(visitor_context, violations)

    if effect_scope == EFFECT_SCOPE_NONE:
        analysis = analyze_runtime_dispatch(node_cls)
        if analysis is not None and analysis.detected:
            violations.append(_runtime_dispatch_warning(analysis))

    if scan_module:
        _append_module_violations(node_cls, source, policy, known_node_modules, known_node_class_names, effect_scope, violations)
    return _dedupe_violations(violations)


def _runtime_dispatch_warning(analysis: RuntimeDispatchAnalysis) -> PurityViolation:
    first = analysis.sites[0]
    return PurityViolation(
        code="runtime_dispatch",
        rule_id="NODE.EFFECT.RUNTIME_DISPATCH.UNDECLARED",
        severity="warning",
        source_location={
            "path": first.path,
            "line": first.line,
            "column": first.column,
        },
        failure_layer="implementation",
        message=(
            "node explicitly dispatches through a runtime-provided callable or "
            "object; use flow_kind='global_state' to make this runtime boundary visible"
        ),
        suggested_fix_type="fix_contract",
        details={
            "dispatch_kind": first.dispatch_kind,
            "callee": first.expression,
            "origin": first.origin,
            "site_count": len(analysis.sites),
            "sites": [site.to_dict() for site in analysis.sites],
        },
    )


def _append_contract_violations(node_cls, info, contract, expected_type, source, violations: list[PurityViolation]) -> None:
    violations.extend(_validate_node_info(info, expected_type=expected_type, source=source))
    violations.extend(_validate_contract(contract, source=source))
    violations.extend(_validate_interface(node_cls, source=source))
    if isinstance(info, NodeInfo) and isinstance(contract, NodeContract) and _contract_items_valid(contract):
        violations.extend(_validate_flow_kind_contract(info, contract, source=source))


def _source_unavailable_violation(source) -> PurityViolation:
    return _violation(
        "source_unavailable",
        "node source is unavailable for static purity check",
        source=source,
        suggested_fix_type="fix_node",
    )


def _append_class_visitor_violations(context: _ClassVisitorContext, violations: list[PurityViolation]) -> None:
    contract = context.contract if isinstance(context.contract, NodeContract) and _contract_items_valid(context.contract) else None
    visitor = NodePurityVisitor(
        policy=context.policy,
        source=context.source,
        contract=contract,
        known_node_modules=context.known_node_modules,
        known_node_class_names=context.known_node_class_names,
        line_offset=context.source.class_start_line - 1,
        effect_scope=context.effect_scope,
        initial_aliases=context.module_aliases,
        imported_roots=context.imported_roots,
        module_state_names=context.module_state_names,
    )
    visitor.visit(context.class_tree)
    violations.extend(visitor.violations)


def _module_import_context(source) -> tuple[dict[str, str], set[str], set[str]]:
    if not source.module_text:
        return {}, set(), set()
    module_tree = _parse_source(source.module_text, source=source)
    if not isinstance(module_tree, ast.Module):
        return {}, set(), set()
    aliases: dict[str, str] = {}
    roots: set[str] = set()
    state_names: set[str] = set()
    for statement in module_tree.body:
        if isinstance(statement, (ast.Import, ast.ImportFrom)):
            aliases.update(import_aliases_from_node(statement))
            roots.update(imported_module_roots(statement))
        elif isinstance(statement, ast.Assign):
            for target in statement.targets:
                state_names.update(_bound_names(target))
        elif isinstance(statement, ast.AnnAssign):
            state_names.update(_bound_names(statement.target))
    state_names.difference_update({"BASE_LIB_INFO", "CONTRACT", "NODE_INFO", "PLUGIN_INFO"})
    return aliases, roots, state_names


def _bound_names(target: ast.AST) -> set[str]:
    if isinstance(target, ast.Name):
        return {target.id}
    if isinstance(target, (ast.List, ast.Tuple)):
        names: set[str] = set()
        for item in target.elts:
            names.update(_bound_names(item))
        return names
    return set()


def _contract_items_valid(contract: NodeContract) -> bool:
    return all(isinstance(item, DataRequirement) for item in contract.requires) and all(isinstance(item, DataProvider) for item in contract.provides)


def _append_module_violations(
    node_cls: type[PureNode],
    source,
    policy: PurityPolicy,
    known_node_modules: tuple[str, ...],
    known_node_class_names: tuple[str, ...],
    effect_scope: str,
    violations: list[PurityViolation],
) -> None:
    if not source.module_text:
        return
    module_tree = _parse_source(source.module_text, source=source)
    if isinstance(module_tree, PurityViolation):
        violations.append(module_tree)
        return
    module_visitor = ModulePurityVisitor(
        policy=policy,
        source=source,
        node_class_name=node_cls.__name__,
        known_node_modules=known_node_modules,
        known_node_class_names=known_node_class_names,
        effect_scope=effect_scope,
    )
    module_visitor.visit(module_tree)
    violations.extend(module_visitor.violations)



def collect_node_metrics(
    node_cls: type[Any], *, configured_param_count: int = 0
) -> NodeMetrics:
    source = _source_info(node_cls)
    contract = getattr(node_cls, "CONTRACT", None)
    if source.class_text is None:
        return NodeMetrics()
    tree = _parse_source(source.class_text, source=source)
    if isinstance(tree, PurityViolation):
        return NodeMetrics(source_lines=len(source.class_text.splitlines()), source_bytes=len(source.class_text.encode("utf-8")))
    counter = _ComplexityCounter()
    counter.visit(tree)
    call_chain = _analyze_internal_call_chain(tree)
    requires = getattr(contract, "requires", ()) if isinstance(contract, NodeContract) else ()
    provides = getattr(contract, "provides", ()) if isinstance(contract, NodeContract) else ()
    return NodeMetrics(
        source_lines=len(source.class_text.splitlines()),
        source_bytes=len(source.class_text.encode("utf-8")),
        function_count=counter.function_count,
        branch_count=counter.branch_count,
        max_nesting_depth=counter.max_nesting_depth,
        param_count=configured_param_count,
        requires_count=len(requires),
        provides_count=len(provides),
        contract_key_count=len(requires) + len(provides),
        function_names=tuple(counter.function_names),
        run_pure_fingerprint=counter.run_pure_fingerprint,
        run_pure_shape=counter.run_pure_shape,
        call_chain_length=call_chain.length,
        call_chain_path=call_chain.path,
        recursive_call_chains=call_chain.recursive_paths,
    )


__all__ = [
    "ModulePurityVisitor",
    "NodeMetrics",
    "NodePurityVisitor",
    "PurityPolicy",
    "PurityViolation",
    "RuntimeDispatchAnalysis",
    "RuntimeDispatchSite",
    "analyze_runtime_dispatch",
    "collect_node_metrics",
    "validate_node_class",
]
