"""Adapt a workflow's portable contributions to native Python resources."""

from dataclasses import replace
import inspect
from pathlib import Path
from vibeflow.core.descriptors.json_values import freeze_mapping

from vibeflow.targets.python.project.plugins import PluginRegistry
from vibeflow.tooling.application.python.project.resource_selection import select_python_resources


def contributed_resources(workspace, registry):
    resources, findings = select_python_resources({}, registry=registry)
    return resources, findings


def lifecycle_registry(registry, *, workflow_id, config_path, plugin_types=("compiler", "runtime")):
    """Create instances at the native compile/run boundary, not declaration time."""
    result = PluginRegistry()
    loaded = registry.loaded_plugins
    created = []
    try:
        for selection in loaded.lifecycle_selections:
            if selection.get("status") == "planned":
                continue
            descriptor = loaded.catalogs.plugins.require(selection["id"])
            if descriptor.plugin_type not in plugin_types:
                continue
            factory = registry.direct_bindings.get(("plugin", descriptor.id))
            if factory is None:
                from vibeflow.tooling.application.python.project.declarations import _load_rule_handler, _implementation_path
                root = registry.resource_roots[("plugins", descriptor.id)]
                source = descriptor.implementations[0].source
                factory = _load_rule_handler(_implementation_path(source.kind, source.ref, root.path, registry.source_roots), source.export, root, registry)
            config = freeze_mapping(selection["config"], field_name="plugin.config")
            context = freeze_mapping({"config": config, "workflow_id": workflow_id, "config_path": str(config_path)}, field_name="plugin.context")
            from vibeflow.targets.python.sdk.loading import source_paths
            with source_paths(registry.source_roots):
                instance = factory(context)
            if inspect.isawaitable(instance):
                raise ValueError("Python lifecycle factories must return an instance synchronously")
            if instance is None:
                raise ValueError("lifecycle factory must return an instance")
            created.append(instance)
            result.register(instance, plugin_type=descriptor.plugin_type, name=descriptor.id,
                priority=descriptor.priority, source=descriptor.implementations[0].source.ref,
                class_name=descriptor.implementations[0].source.export or "", config_keys=tuple(config),
                source_path=loaded.catalogs.plugins.source_for(descriptor.id), rulesets=descriptor.rulesets, conflict="error",
                declaration=descriptor)
    except BaseException:
        for instance in reversed(created):
            dispose = getattr(instance, "dispose", None)
            if callable(dispose):
                dispose()
        raise
    return result


def release_plugins(plugin_registry, *, plugin_type):
    instances = plugin_registry.runtime_plugins() if plugin_type == "runtime" else plugin_registry.compiler_plugins()
    for instance in reversed(instances):
        dispose = getattr(instance, "dispose", None)
        if callable(dispose):
            dispose()


def release_runtime_plugins(plugin_registry):
    release_plugins(plugin_registry, plugin_type="runtime")
