"""Load prepared Python workflows without source checks or graph compilation."""
from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
from threading import RLock

from vibeflow.block_compiler import workflow_plan_from_dict, WORKFLOW_ABI_VERSION, map_plan_sources
from vibeflow.core.descriptors.decode import decode_resource
from vibeflow.core.descriptors.models import SourceLocator
from vibeflow.core.findings import HealthFinding, HealthReport
from vibeflow.core.workflows.entries import choose_entry
from vibeflow.targets.python.project.registry import NodeRegistry, load_node_implementation
from vibeflow.targets.python.project.plugins import PluginRegistry, create_lifecycle_plugin
from vibeflow.targets.python.runtime.preparation import PreparedPythonWorkflow, bind_python_workflow
from vibeflow.targets.python.sdk.loading import load_plugin, source_paths
from vibeflow.targets.python.sdk.source_namespace import source_namespace
from vibeflow.tooling.application.python.bundle_snapshot import PYTHON_AOT_FORMAT, decode_snapshot
from vibeflow.tooling.application.python.delegate_contract import apply_delegate_cli_findings


class PythonBundle:
    def __init__(self, path):
        self.path = Path(path).resolve()
        self.metadata = json.loads((self.path / 'vibeflow-build.json').read_text(encoding='utf-8'))
        if self.metadata.get('project_target') != 'python':
            raise ValueError('bundle is not a Python workflow')
        if self.metadata.get('format') != PYTHON_AOT_FORMAT or self.metadata.get('abi_version') != WORKFLOW_ABI_VERSION:
            raise ValueError('unsupported Python AOT format or workflow ABI; rebuild the bundle')
        self.data = json.loads((self.path / self.metadata['target_metadata']['bindings']).read_text(encoding='utf-8'))
        relocate = lambda value: str(self.path / value[len('@bundle/'):]) if isinstance(value,str) and value.startswith('@bundle/') else value
        self.workflow = map_plan_sources(workflow_plan_from_dict(self.data['workflow']),
            lambda source:replace(source,ref=relocate(source.ref)))
        types = self.data['snapshot_types']
        self.prepared = PreparedPythonWorkflow(self.workflow,
            decode_snapshot(self.data['graphs'], types=types, relocate=relocate),
            decode_snapshot(self.data['compiled'], types=types, relocate=relocate),
            decode_snapshot(self.data['globals'], types=types), decode_snapshot(self.data['overrides'], types=types))
        self.roots = tuple(self.path / value for value in self.data['source_roots'])
        # Fixed, relocated declarations belong to the bundle, not each Runtime.
        self._node_records = tuple(self._prepare_node(record) for record in self.data['nodes'])
        self._plugin_records = tuple((self._descriptor(record['descriptor']),
            self._plugin_source(record['plugin']), record) for record in self.data['plugins'])
        self._plugin_bindings = {}
        self._bindings_lock = RLock()
        self._source_namespaces = {}
        for root, visible in self.data["source_import_roots"].items():
            source_namespace(self.path / root, namespaces=self._source_namespaces,
                source_roots=tuple(self.path / value for value in visible))

    @property
    def workflow_descriptor(self):
        return deepcopy(self.data['workflow_descriptor'])

    def _prepare_node(self, record):
        binding = dict(record['binding'])
        binding.update(path=self.path / binding['path'], load_root=self.path / binding['load_root'],
            members=tuple(binding['export'].split('.')))
        return self._descriptor(record['descriptor']), binding, self._path(record['source']), record['source_line']

    def _plugin_source(self, record):
        source = dict(record['source'])
        if source['kind'] == 'file':
            source['ref'] = self._path(source['ref'])
        return self.path / record['root'], SourceLocator(**source)

    def _bindings(self, source):
        with self._bindings_lock:
            if source not in self._plugin_bindings:
                root, locator = source
                definition = load_plugin(locator, root=root, source_roots=self.roots, namespaces=self._source_namespaces)
                self._plugin_bindings[source] = definition.bindings()
            return self._plugin_bindings[source]

    def _registry(self):
        registry = NodeRegistry()
        for descriptor, binding, source, line in self._node_records:
            def resolve(binding=binding, key=descriptor.id):
                def load():
                    with source_paths((binding['load_root'], *self.roots)):
                        root = binding['load_root']
                        value = source_namespace(root, namespaces=self._source_namespaces,
                            source_roots=self.roots).load(binding['path'])
                        for part in binding['members']:
                            value = getattr(value, part)
                        return value
                return load_node_implementation(registry, key, binding['path'], binding['export'], load)
            registry.register(descriptor,loader=resolve,source=source,source_line=line)
        return registry

    def _plugins(self, _owned=None):
        result = PluginRegistry()
        created = [] if _owned is None else _owned
        try:
            for descriptor, source, record in self._plugin_records:
                factory = self._bindings(source).get(('plugin',descriptor.id))
                if factory is None:
                    locator = descriptor.implementations[0].source
                    module = source_namespace(source[0], namespaces=self._source_namespaces, source_roots=self.roots).load(self.path / record['factory_path'])
                    factory = module
                    for part in locator.export.split('.'):
                        factory = getattr(factory,part)
                from vibeflow.core.descriptors.json_values import freeze_mapping
                context = freeze_mapping({'config':record['config'],
                    'workflow_id':str(self.path / self.data['config_path']),
                    'config_path':str(self.path / self.data['config_path'])}, field_name='plugin.context')
                create_lifecycle_plugin(result,descriptor,factory,context,owned_instances=created,
                    source=descriptor.implementations[0].source.ref,
                    class_name=descriptor.implementations[0].source.export or '',
                    config_keys=tuple(record['config']),rulesets=descriptor.rulesets)
        except BaseException as error:
            from vibeflow.targets.python.project.plugins import dispose_instances
            if _owned is None:
                dispose_instances(created, primary=error)
            raise
        return result

    def _blocks(self, plan, block_id):
        from vibeflow.targets.python.runtime.block_compiler import bind_compiled_block
        return tuple(bind_compiled_block(plan, kind=item['kind'], name=item['name'],
            entry=plan.order[0] if item['kind'] == 'graph' else item['entry'],
            exits=tuple(n for n in item['exits'] if n in plan.frames),
            nodes=tuple(n for n in item['nodes'] if n in plan.frames), path=tuple(item['path']))
            for item in self.data['blocks'].get(block_id, ()) if item['kind'] == 'graph' or item['entry'] in plan.frames)

    def create_runtime(self, *, runtime_options=None, workflow_session=None, run_dir=None,
                       node_config_overrides=None, global_config=None, delegate_cli=False, entry=None, workflow_instance_id=None):
        from vibeflow.targets.python.runtime.engine import PipelineRuntime
        effective = self.effective_options(runtime_options)
        registry = self._registry()
        prepared = self.prepared
        if node_config_overrides or global_config is not None:
            prepared = self._bind_config(prepared, registry, node_config_overrides, global_config)
        def bind(instances, plugins=None):
            return bind_python_workflow(prepared, registry=registry, runtime_options=effective,
                plugin_registry=plugins, instantiate=instances, block_loader=self._blocks,
                entry=entry,
                source_hash_for_path=lambda path:self.metadata['files'][path.relative_to(self.path).as_posix()])
        with source_paths(self.roots):
            plan = bind(False)
            runtime = PipelineRuntime(plan.graph, registry=registry,
                run_dir=run_dir, runtime_options=effective, workflow_session=workflow_session,
                workflow_instance_id=workflow_instance_id,
                delegate_cli=delegate_cli, _execution_plan=plan)
        from vibeflow.tooling.application.python.execution import (_checked_runtime_binding)
        runtime._runtime_plugin_descriptors = tuple(item[0] for item in self._plugin_records)
        runtime._runtime_plan_factory = lambda plugins: _checked_runtime_binding(
            lambda: bind(True, plugins), health=self.health, run_dir=runtime._run_dir)
        from vibeflow.tooling.application.python.project.lifecycle import checked_runtime_plugins
        runtime._runtime_plugin_factory = lambda: checked_runtime_plugins(
            self._plugins, config_path=self.path / self.data['config_path'],
            effective_policy=self.data['health']['effective_policy'], run_dir=runtime._run_dir)
        from vibeflow.targets.python.project.plugins import create_plugins_async
        runtime._runtime_plugin_factory_async = lambda: create_plugins_async(lambda owned: checked_runtime_plugins(
            lambda: self._plugins(_owned=owned), config_path=self.path / self.data['config_path'],
            effective_policy=self.data['health']['effective_policy'], run_dir=runtime._run_dir))
        runtime._bundle_source_roots = self.roots
        return runtime

    def _bind_config(self, prepared, registry, overrides, global_config):
        from vibeflow.core.graph_calls import graph_call_subjects
        from vibeflow.core.config.concurrency import business_config, dispatch_limit
        from vibeflow.core.config.scope import ConfigScope, normalize_config_scope, scoped_node_params
        from vibeflow.block_compiler.compiler import _block_id
        from vibeflow.block_compiler.model import freeze_json_object
        root = prepared.graphs[prepared.workflow.entry_block]
        blocks = {block.id:block for block in prepared.workflow.blocks}
        globals_by_block = dict(prepared.globals)
        overrides_by_block = dict(prepared.overrides)
        for subject in graph_call_subjects(root, global_config=global_config if global_config is not None else ConfigScope(values=prepared.globals[prepared.workflow.entry_block]), node_config_overrides=overrides):
            key = _block_id(subject.call_path)
            if subject.declaration_only or key not in blocks:
                continue
            block = blocks[key]
            scope = normalize_config_scope(subject.global_config)
            globals_by_block[key] = scope.values
            overrides_by_block[key] = subject.overrides
            specs = {node.id:node for node in subject.graph.nodes}
            calls = []
            for call in block.nodes:
                spec = specs[call.id]
                if (call.is_loop or call.is_nodeset) and call.status != 'planned':
                    config = {**spec.params, **subject.overrides.get(call.id, {})}
                    calls.append(replace(call, max_concurrency=dispatch_limit(config)))
                    continue
                if call.status == 'planned':
                    params = {**spec.params, **subject.overrides.get(call.id, {})}
                else:
                    config = registry.get_config_spec(call.definition_id)
                    params = scoped_node_params(spec.params,scope,declared_keys=set(config.schema))
                    params = registry.merge_config(call.definition_id,{**params,**subject.overrides.get(call.id,{})})
                calls.append(replace(call, params=freeze_json_object(business_config(params)),
                    max_concurrency=dispatch_limit(params)))
            blocks[key] = replace(block,nodes=tuple(calls))
        return replace(prepared,workflow=replace(prepared.workflow,blocks=tuple(blocks.values())),globals=globals_by_block,overrides=overrides_by_block)

    def effective_options(self, overrides=None):
        from vibeflow.targets.python.runtime.options import merge_runtime_options
        return merge_runtime_options(self.data['runtime_options'], overrides)

    def _run_health(self, *, entry, delegate_cli):
        entries = {item.name: item for item in self.workflow.named_entries}
        selected = choose_entry(entries, self.workflow.default_entry, entry)
        health = self.health
        if not delegate_cli:
            return health
        if selected is None:
            stored = self.data['delegate_findings']
        else:
            stored = self.data['delegate_findings_by_entry'][selected]
        findings = tuple(HealthFinding(**item) for item in deepcopy(stored))
        return apply_delegate_cli_findings(health, findings)

    def run(self, initial=None, *, runtime_options=None, workflow_session=None, run_root=None, run_id=None,
            delegate_cli=False, node_config_overrides=None, global_config=None, _prepared_run_dir=None, entry=None, signal=None, workflow_instance_id=None):
        from vibeflow.tooling.application.python.run_directory import prepare_run_dir as _prepare_run_dir
        from vibeflow.tooling.application.python.execution import (CheckedRunResult, _new_run_id, _write_json, _summarize_run_result, _ensure_trace_files)
        from vibeflow.targets.python.runtime.observation import observe_run
        actual_id = _new_run_id() if run_id is None else run_id
        directory = _prepared_run_dir or _prepare_run_dir(run_root, actual_id)
        effective = self.effective_options(runtime_options)
        with observe_run(directory, effective):
            health = self._run_health(entry=entry, delegate_cli=delegate_cli)
            _write_json(directory / 'health_report.json', health.to_dict())
            _write_json(directory / 'effective_policy.json', health.effective_policy)
            if health.status in {'FAIL','ERROR'}:
                from vibeflow.tooling.application.python.execution import (CheckedRunError)
                raise CheckedRunError('bundle run refused: invalid delegated CLI contract', CheckedRunResult(actual_id,directory,health))
            from vibeflow.targets.python.runtime.summaries import summarize_mapping
            _write_json(directory / 'input_summary.json', summarize_mapping(dict(initial or {})))
            runtime = self.create_runtime(runtime_options=effective, workflow_session=workflow_session,
                workflow_instance_id=workflow_instance_id,
                run_dir=directory, delegate_cli=delegate_cli,
                node_config_overrides=node_config_overrides, global_config=global_config, entry=entry)
            unsubscribe = signal.subscribe(runtime.request_stop) if signal is not None else lambda: None
            try:
                context = runtime.run(initial)
            finally:
                unsubscribe()
                _ensure_trace_files(directory)
            _write_json(directory / 'output_summary.json', _summarize_run_result(context))
            from .execution import checked_result
            return checked_result(actual_id,directory,health,context,runtime.graph)

    async def run_async(self, initial=None, *, runtime_options=None, workflow_session=None, run_root=None, run_id=None, delegate_cli=False, node_config_overrides=None, global_config=None, _prepared_run_dir=None, entry=None, signal=None, workflow_instance_id=None):
        from vibeflow.tooling.application.python.run_directory import prepare_run_dir as _prepare_run_dir
        from vibeflow.tooling.application.python.execution import CheckedRunResult, _new_run_id, _write_json, _summarize_run_result, _ensure_trace_files
        from vibeflow.targets.python.runtime.observation import observe_run
        actual_id = _new_run_id() if run_id is None else run_id
        directory = _prepared_run_dir or _prepare_run_dir(run_root, actual_id)
        effective = self.effective_options(runtime_options)
        with observe_run(directory, effective):
            health = self._run_health(entry=entry, delegate_cli=delegate_cli)
            _write_json(directory / 'health_report.json', health.to_dict())
            _write_json(directory / 'effective_policy.json', health.effective_policy)
            if health.status in {'FAIL', 'ERROR'}:
                from vibeflow.tooling.application.python.execution import CheckedRunError
                raise CheckedRunError('bundle run refused: invalid delegated CLI contract', CheckedRunResult(actual_id, directory, health))
            from vibeflow.targets.python.runtime.summaries import summarize_mapping
            _write_json(directory / 'input_summary.json', summarize_mapping(dict(initial or {})))
            runtime = self.create_runtime(runtime_options=effective, workflow_session=workflow_session, workflow_instance_id=workflow_instance_id, run_dir=directory, delegate_cli=delegate_cli, node_config_overrides=node_config_overrides, global_config=global_config, entry=entry)
            unsubscribe = signal.subscribe(runtime.request_stop) if signal is not None else lambda: None
            try:
                context = await runtime.run_async(initial)
            finally:
                unsubscribe()
                _ensure_trace_files(directory)
            _write_json(directory / 'output_summary.json', _summarize_run_result(context))
            from .execution import checked_result
            return checked_result(actual_id, directory, health, context, runtime.graph)

    @property
    def health(self):
        report = deepcopy(self.data['health'])
        for key in ('errors', 'warnings', 'skipped'):
            report[key] = tuple(HealthFinding(**item) for item in report[key])
        return HealthReport(**report)

    def _path(self, value):
        return str(self.path / value[len('@bundle/'):]) if value.startswith('@bundle/') else value

    def _descriptor(self, value):
        value = deepcopy(value)
        for implementation in value.get('implementations',()):
            for source in (implementation['source'],*implementation.get('implementation_files',())):
                if source['kind'] == 'file':
                    source['ref'] = self._path(source['ref'])
        return decode_resource(value)


def load_bundle(path):
    return PythonBundle(path)
