"""Portable workflow references and node-owned launch declarations."""
from collections.abc import Mapping
from posixpath import normpath


def workflow_node_params(node, descriptor, subject):
    """Use the same declared scope and call override order as execution."""
    from vibeflow.core.config.scope import normalize_config_scope, scoped_node_params
    contract = getattr(descriptor, "contract", None)
    local = scoped_node_params(node.params, normalize_config_scope(subject.global_config),
        declared_keys=set(getattr(contract, "params_schema", {})))
    return {**getattr(contract, "params_defaults", {}), **local, **subject.overrides.get(node.id, {})}


def workflow_reference(value, *, root=""):
    if not isinstance(value, Mapping) or set(value) - {"root", "path", "entry"}:
        raise ValueError("workflow must contain root, path and optional entry")
    path = value.get("path")
    if not isinstance(path, str) or not path.strip() or path.startswith(("/", "\\")):
        raise ValueError("workflow.path must be relative to its root")
    path = normpath(path.replace("\\", "/"))
    if path == ".." or path.startswith("../") or ":" in path:
        raise ValueError("workflow.path must stay within its root")
    result = {"root": value.get("root") or root, "path": path}
    if not isinstance(result["root"], str):
        raise ValueError("workflow.root must be a root id")
    if "entry" in value and value["entry"] is not None:
        if not isinstance(value["entry"], str) or not value["entry"].strip():
            raise ValueError("workflow.entry must name an entry")
        result["entry"] = value["entry"]
    return result


def launch_configuration(value):
    if not isinstance(value, Mapping) or "kind" not in value:
        raise ValueError("launch.kind is required; migrate to process or in_process and rebuild")
    if value["kind"] == "in_process":
        if set(value) != {"kind"}:
            raise ValueError("in_process launch allows only kind; bind the target explicitly")
        return {"kind": "in_process"}
    if value["kind"] != "process" or set(value) - {"kind", "command", "cwd", "env"}:
        raise ValueError("launch.kind must be process or in_process")
    command = value.get("command")
    if not isinstance(command, (list, tuple)) or not command or any(not isinstance(v, str) for v in command) or not command[0]:
        raise ValueError("launch.command must be a non-empty argument array")
    cwd, env = value.get("cwd", "."), value.get("env", {})
    if not isinstance(cwd, str) or not isinstance(env, Mapping) or any(
            not isinstance(k, str) or not k or not isinstance(v, str) for k, v in env.items()):
        raise ValueError("launch.cwd must be a string and launch.env must map strings")
    return {"kind": "process", "command": list(command), "cwd": cwd, "env": dict(env)}


def node_workflow_actions(actions, params, *, root=""):
    """Join evaluated operations with the effective call configuration once."""
    result = []
    for original in actions:
        action = dict(original)
        if action.get("operation") in {"invoke_sync", "call", "wait", "send", "receive", "kill"}:
            if set(action) & {"target", "entry", "workflow", "launch", "expected_workflows"}:
                raise ValueError("workflow action target aliases are removed; configure node.workflow")
            operation = action.get("operation")
            if operation in {"invoke_sync", "call", "kill"}:
                if params.get("workflow") is not None or not action.get("planned"):
                    action["workflow"] = workflow_reference(params.get("workflow"), root=root)
                if operation == "call" and not action.get("planned"):
                    launch_configuration(params.get("launch"))
            if operation in {"send", "receive"}:
                expected = params.get("expected_workflows", ())
                if not isinstance(expected, (list, tuple)):
                    raise ValueError("expected_workflows must be a list")
                action["expected_workflows"] = [workflow_reference(item, root=root) for item in expected]
        result.append(action)
    return result


def action_references(action):
    if action.get("operation") in {"invoke_sync", "call", "kill"}:
        reference = action.get("workflow")
        return (reference,) if reference is not None else ()
    return tuple(action.get("expected_workflows", ()))


def launch_document(launches, *, base=".", workflow=None):
    return {"format":"vibeflow.workflow-launches.v2",
            "workflow":workflow,
            "launches":[{**item, "base":base} for item in launches]}
