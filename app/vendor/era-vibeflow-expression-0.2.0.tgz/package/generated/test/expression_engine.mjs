var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod3) => function __require2() {
  try {
    return mod3 || (0, cb[__getOwnPropNames(cb)[0]])((mod3 = { exports: {} }).exports, mod3), mod3.exports;
  } catch (e3) {
    throw mod3 = 0, e3;
  }
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod3, isNodeMode, target) => (target = mod3 != null ? __create(__getProtoOf(mod3)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod3 || !mod3.__esModule ? __defProp(target, "default", { value: mod3, enumerable: true }) : target,
  mod3
));

// node_modules/@stdlib/math-base-assert-is-nan/lib/main.js
var require_main = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-nan/lib/main.js"(exports, module) {
    "use strict";
    function isnan(x) {
      return x !== x;
    }
    module.exports = isnan;
  }
});

// node_modules/@stdlib/math-base-assert-is-nan/lib/index.js
var require_lib = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-nan/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-floor/lib/main.js
var require_main2 = __commonJS({
  "node_modules/@stdlib/math-base-special-floor/lib/main.js"(exports, module) {
    "use strict";
    var floor3 = Math.floor;
    module.exports = floor3;
  }
});

// node_modules/@stdlib/math-base-special-floor/lib/index.js
var require_lib2 = __commonJS({
  "node_modules/@stdlib/math-base-special-floor/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main2();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-assert-is-integer/lib/main.js
var require_main3 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-integer/lib/main.js"(exports, module) {
    "use strict";
    var floor3 = require_lib2();
    function isInteger4(x) {
      return floor3(x) === x;
    }
    module.exports = isInteger4;
  }
});

// node_modules/@stdlib/math-base-assert-is-integer/lib/index.js
var require_lib3 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-integer/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main3();
    module.exports = main;
  }
});

// node_modules/@stdlib/number-ctor/lib/main.js
var require_main4 = __commonJS({
  "node_modules/@stdlib/number-ctor/lib/main.js"(exports, module) {
    "use strict";
    module.exports = Number;
  }
});

// node_modules/@stdlib/number-ctor/lib/index.js
var require_lib4 = __commonJS({
  "node_modules/@stdlib/number-ctor/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main4();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-ninf/lib/index.js
var require_lib5 = __commonJS({
  "node_modules/@stdlib/constants-float64-ninf/lib/index.js"(exports, module) {
    "use strict";
    var Number2 = require_lib4();
    var FLOAT64_NINF = Number2.NEGATIVE_INFINITY;
    module.exports = FLOAT64_NINF;
  }
});

// node_modules/@stdlib/math-base-assert-is-negative-zero/lib/main.js
var require_main5 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-negative-zero/lib/main.js"(exports, module) {
    "use strict";
    var NINF = require_lib5();
    function isNegativeZero(x) {
      return x === 0 && 1 / x === NINF;
    }
    module.exports = isNegativeZero;
  }
});

// node_modules/@stdlib/math-base-assert-is-negative-zero/lib/index.js
var require_lib6 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-negative-zero/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main5();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-abs/lib/main.js
var require_main6 = __commonJS({
  "node_modules/@stdlib/math-base-special-abs/lib/main.js"(exports, module) {
    "use strict";
    function abs3(x) {
      return Math.abs(x);
    }
    module.exports = abs3;
  }
});

// node_modules/@stdlib/math-base-special-abs/lib/index.js
var require_lib7 = __commonJS({
  "node_modules/@stdlib/math-base-special-abs/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main6();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-high-word-abs-mask/lib/index.js
var require_lib8 = __commonJS({
  "node_modules/@stdlib/constants-float64-high-word-abs-mask/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_HIGH_WORD_ABS_MASK = 2147483647 >>> 0;
    module.exports = FLOAT64_HIGH_WORD_ABS_MASK;
  }
});

// node_modules/@stdlib/constants-float64-high-word-exponent-mask/lib/index.js
var require_lib9 = __commonJS({
  "node_modules/@stdlib/constants-float64-high-word-exponent-mask/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_HIGH_WORD_EXPONENT_MASK = 2146435072;
    module.exports = FLOAT64_HIGH_WORD_EXPONENT_MASK;
  }
});

// node_modules/@stdlib/assert-has-symbol-support/lib/main.js
var require_main7 = __commonJS({
  "node_modules/@stdlib/assert-has-symbol-support/lib/main.js"(exports, module) {
    "use strict";
    function hasSymbolSupport() {
      return typeof Symbol === "function" && typeof /* @__PURE__ */ Symbol("foo") === "symbol";
    }
    module.exports = hasSymbolSupport;
  }
});

// node_modules/@stdlib/assert-has-symbol-support/lib/index.js
var require_lib10 = __commonJS({
  "node_modules/@stdlib/assert-has-symbol-support/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main7();
    module.exports = main;
  }
});

// node_modules/@stdlib/assert-has-tostringtag-support/lib/main.js
var require_main8 = __commonJS({
  "node_modules/@stdlib/assert-has-tostringtag-support/lib/main.js"(exports, module) {
    "use strict";
    var hasSymbols = require_lib10();
    var FLG = hasSymbols();
    function hasToStringTagSupport() {
      return FLG && typeof Symbol.toStringTag === "symbol";
    }
    module.exports = hasToStringTagSupport;
  }
});

// node_modules/@stdlib/assert-has-tostringtag-support/lib/index.js
var require_lib11 = __commonJS({
  "node_modules/@stdlib/assert-has-tostringtag-support/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main8();
    module.exports = main;
  }
});

// node_modules/@stdlib/utils-native-class/lib/tostring.js
var require_tostring = __commonJS({
  "node_modules/@stdlib/utils-native-class/lib/tostring.js"(exports, module) {
    "use strict";
    var toStr = Object.prototype.toString;
    module.exports = toStr;
  }
});

// node_modules/@stdlib/utils-native-class/lib/main.js
var require_main9 = __commonJS({
  "node_modules/@stdlib/utils-native-class/lib/main.js"(exports, module) {
    "use strict";
    var toStr = require_tostring();
    function nativeClass(v) {
      return toStr.call(v);
    }
    module.exports = nativeClass;
  }
});

// node_modules/@stdlib/assert-has-own-property/lib/main.js
var require_main10 = __commonJS({
  "node_modules/@stdlib/assert-has-own-property/lib/main.js"(exports, module) {
    "use strict";
    var has = Object.prototype.hasOwnProperty;
    function hasOwnProp(value, property) {
      if (value === void 0 || value === null) {
        return false;
      }
      return has.call(value, property);
    }
    module.exports = hasOwnProp;
  }
});

// node_modules/@stdlib/assert-has-own-property/lib/index.js
var require_lib12 = __commonJS({
  "node_modules/@stdlib/assert-has-own-property/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main10();
    module.exports = main;
  }
});

// node_modules/@stdlib/symbol-ctor/lib/main.js
var require_main11 = __commonJS({
  "node_modules/@stdlib/symbol-ctor/lib/main.js"(exports, module) {
    "use strict";
    var Sym = typeof Symbol === "function" ? Symbol : void 0;
    module.exports = Sym;
  }
});

// node_modules/@stdlib/symbol-ctor/lib/index.js
var require_lib13 = __commonJS({
  "node_modules/@stdlib/symbol-ctor/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main11();
    module.exports = main;
  }
});

// node_modules/@stdlib/utils-native-class/lib/tostringtag.js
var require_tostringtag = __commonJS({
  "node_modules/@stdlib/utils-native-class/lib/tostringtag.js"(exports, module) {
    "use strict";
    var Symbol2 = require_lib13();
    var toStrTag = typeof Symbol2 === "function" ? Symbol2.toStringTag : "";
    module.exports = toStrTag;
  }
});

// node_modules/@stdlib/utils-native-class/lib/polyfill.js
var require_polyfill = __commonJS({
  "node_modules/@stdlib/utils-native-class/lib/polyfill.js"(exports, module) {
    "use strict";
    var hasOwnProp = require_lib12();
    var toStringTag = require_tostringtag();
    var toStr = require_tostring();
    function nativeClass(v) {
      var isOwn;
      var tag2;
      var out;
      if (v === null || v === void 0) {
        return toStr.call(v);
      }
      tag2 = v[toStringTag];
      isOwn = hasOwnProp(v, toStringTag);
      try {
        v[toStringTag] = void 0;
      } catch (err) {
        return toStr.call(v);
      }
      out = toStr.call(v);
      if (isOwn) {
        v[toStringTag] = tag2;
      } else {
        delete v[toStringTag];
      }
      return out;
    }
    module.exports = nativeClass;
  }
});

// node_modules/@stdlib/utils-native-class/lib/index.js
var require_lib14 = __commonJS({
  "node_modules/@stdlib/utils-native-class/lib/index.js"(exports, module) {
    "use strict";
    var hasToStringTag = require_lib11();
    var builtin = require_main9();
    var polyfill = require_polyfill();
    var main;
    if (hasToStringTag()) {
      main = polyfill;
    } else {
      main = builtin;
    }
    module.exports = main;
  }
});

// node_modules/@stdlib/assert-is-uint32array/lib/main.js
var require_main12 = __commonJS({
  "node_modules/@stdlib/assert-is-uint32array/lib/main.js"(exports, module) {
    "use strict";
    var nativeClass = require_lib14();
    var hasUint32Array = typeof Uint32Array === "function";
    function isUint32Array(value) {
      return hasUint32Array && value instanceof Uint32Array || // eslint-disable-line stdlib/require-globals
      nativeClass(value) === "[object Uint32Array]";
    }
    module.exports = isUint32Array;
  }
});

// node_modules/@stdlib/assert-is-uint32array/lib/index.js
var require_lib15 = __commonJS({
  "node_modules/@stdlib/assert-is-uint32array/lib/index.js"(exports, module) {
    "use strict";
    var isUint32Array = require_main12();
    module.exports = isUint32Array;
  }
});

// node_modules/@stdlib/constants-uint32-max/lib/index.js
var require_lib16 = __commonJS({
  "node_modules/@stdlib/constants-uint32-max/lib/index.js"(exports, module) {
    "use strict";
    var UINT32_MAX = 4294967295;
    module.exports = UINT32_MAX;
  }
});

// node_modules/@stdlib/assert-has-uint32array-support/lib/uint32array.js
var require_uint32array = __commonJS({
  "node_modules/@stdlib/assert-has-uint32array-support/lib/uint32array.js"(exports, module) {
    "use strict";
    var main = typeof Uint32Array === "function" ? Uint32Array : null;
    module.exports = main;
  }
});

// node_modules/@stdlib/assert-has-uint32array-support/lib/main.js
var require_main13 = __commonJS({
  "node_modules/@stdlib/assert-has-uint32array-support/lib/main.js"(exports, module) {
    "use strict";
    var isUint32Array = require_lib15();
    var UINT32_MAX = require_lib16();
    var GlobalUint32Array = require_uint32array();
    function hasUint32ArraySupport() {
      var bool;
      var arr;
      if (typeof GlobalUint32Array !== "function") {
        return false;
      }
      try {
        arr = [1, 3.14, -3.14, UINT32_MAX + 1, UINT32_MAX + 2];
        arr = new GlobalUint32Array(arr);
        bool = isUint32Array(arr) && arr[0] === 1 && arr[1] === 3 && // truncation
        arr[2] === UINT32_MAX - 2 && // truncation and wrap around
        arr[3] === 0 && // wrap around
        arr[4] === 1;
      } catch (err) {
        bool = false;
      }
      return bool;
    }
    module.exports = hasUint32ArraySupport;
  }
});

// node_modules/@stdlib/assert-has-uint32array-support/lib/index.js
var require_lib17 = __commonJS({
  "node_modules/@stdlib/assert-has-uint32array-support/lib/index.js"(exports, module) {
    "use strict";
    var hasUint32ArraySupport = require_main13();
    module.exports = hasUint32ArraySupport;
  }
});

// node_modules/@stdlib/array-uint32/lib/main.js
var require_main14 = __commonJS({
  "node_modules/@stdlib/array-uint32/lib/main.js"(exports, module) {
    "use strict";
    var ctor = typeof Uint32Array === "function" ? Uint32Array : void 0;
    module.exports = ctor;
  }
});

// node_modules/@stdlib/array-uint32/lib/polyfill.js
var require_polyfill2 = __commonJS({
  "node_modules/@stdlib/array-uint32/lib/polyfill.js"(exports, module) {
    "use strict";
    function polyfill() {
      throw new Error("not implemented");
    }
    module.exports = polyfill;
  }
});

// node_modules/@stdlib/array-uint32/lib/index.js
var require_lib18 = __commonJS({
  "node_modules/@stdlib/array-uint32/lib/index.js"(exports, module) {
    "use strict";
    var hasUint32ArraySupport = require_lib17();
    var builtin = require_main14();
    var polyfill = require_polyfill2();
    var ctor;
    if (hasUint32ArraySupport()) {
      ctor = builtin;
    } else {
      ctor = polyfill;
    }
    module.exports = ctor;
  }
});

// node_modules/@stdlib/assert-is-float64array/lib/main.js
var require_main15 = __commonJS({
  "node_modules/@stdlib/assert-is-float64array/lib/main.js"(exports, module) {
    "use strict";
    var nativeClass = require_lib14();
    var hasFloat64Array = typeof Float64Array === "function";
    function isFloat64Array(value) {
      return hasFloat64Array && value instanceof Float64Array || // eslint-disable-line stdlib/require-globals
      nativeClass(value) === "[object Float64Array]";
    }
    module.exports = isFloat64Array;
  }
});

// node_modules/@stdlib/assert-is-float64array/lib/index.js
var require_lib19 = __commonJS({
  "node_modules/@stdlib/assert-is-float64array/lib/index.js"(exports, module) {
    "use strict";
    var isFloat64Array = require_main15();
    module.exports = isFloat64Array;
  }
});

// node_modules/@stdlib/assert-has-float64array-support/lib/float64array.js
var require_float64array = __commonJS({
  "node_modules/@stdlib/assert-has-float64array-support/lib/float64array.js"(exports, module) {
    "use strict";
    var main = typeof Float64Array === "function" ? Float64Array : null;
    module.exports = main;
  }
});

// node_modules/@stdlib/assert-has-float64array-support/lib/main.js
var require_main16 = __commonJS({
  "node_modules/@stdlib/assert-has-float64array-support/lib/main.js"(exports, module) {
    "use strict";
    var isFloat64Array = require_lib19();
    var GlobalFloat64Array = require_float64array();
    function hasFloat64ArraySupport() {
      var bool;
      var arr;
      if (typeof GlobalFloat64Array !== "function") {
        return false;
      }
      try {
        arr = new GlobalFloat64Array([1, 3.14, -3.14, NaN]);
        bool = isFloat64Array(arr) && arr[0] === 1 && arr[1] === 3.14 && arr[2] === -3.14 && arr[3] !== arr[3];
      } catch (err) {
        bool = false;
      }
      return bool;
    }
    module.exports = hasFloat64ArraySupport;
  }
});

// node_modules/@stdlib/assert-has-float64array-support/lib/index.js
var require_lib20 = __commonJS({
  "node_modules/@stdlib/assert-has-float64array-support/lib/index.js"(exports, module) {
    "use strict";
    var hasFloat64ArraySupport = require_main16();
    module.exports = hasFloat64ArraySupport;
  }
});

// node_modules/@stdlib/array-float64/lib/main.js
var require_main17 = __commonJS({
  "node_modules/@stdlib/array-float64/lib/main.js"(exports, module) {
    "use strict";
    var ctor = typeof Float64Array === "function" ? Float64Array : void 0;
    module.exports = ctor;
  }
});

// node_modules/@stdlib/array-float64/lib/polyfill.js
var require_polyfill3 = __commonJS({
  "node_modules/@stdlib/array-float64/lib/polyfill.js"(exports, module) {
    "use strict";
    function polyfill() {
      throw new Error("not implemented");
    }
    module.exports = polyfill;
  }
});

// node_modules/@stdlib/array-float64/lib/index.js
var require_lib21 = __commonJS({
  "node_modules/@stdlib/array-float64/lib/index.js"(exports, module) {
    "use strict";
    var hasFloat64ArraySupport = require_lib20();
    var builtin = require_main17();
    var polyfill = require_polyfill3();
    var ctor;
    if (hasFloat64ArraySupport()) {
      ctor = builtin;
    } else {
      ctor = polyfill;
    }
    module.exports = ctor;
  }
});

// node_modules/@stdlib/assert-is-uint8array/lib/main.js
var require_main18 = __commonJS({
  "node_modules/@stdlib/assert-is-uint8array/lib/main.js"(exports, module) {
    "use strict";
    var nativeClass = require_lib14();
    var hasUint8Array = typeof Uint8Array === "function";
    function isUint8Array(value) {
      return hasUint8Array && value instanceof Uint8Array || // eslint-disable-line stdlib/require-globals
      nativeClass(value) === "[object Uint8Array]";
    }
    module.exports = isUint8Array;
  }
});

// node_modules/@stdlib/assert-is-uint8array/lib/index.js
var require_lib22 = __commonJS({
  "node_modules/@stdlib/assert-is-uint8array/lib/index.js"(exports, module) {
    "use strict";
    var isUint8Array = require_main18();
    module.exports = isUint8Array;
  }
});

// node_modules/@stdlib/constants-uint8-max/lib/index.js
var require_lib23 = __commonJS({
  "node_modules/@stdlib/constants-uint8-max/lib/index.js"(exports, module) {
    "use strict";
    var UINT8_MAX = 255 | 0;
    module.exports = UINT8_MAX;
  }
});

// node_modules/@stdlib/assert-has-uint8array-support/lib/uint8array.js
var require_uint8array = __commonJS({
  "node_modules/@stdlib/assert-has-uint8array-support/lib/uint8array.js"(exports, module) {
    "use strict";
    var main = typeof Uint8Array === "function" ? Uint8Array : null;
    module.exports = main;
  }
});

// node_modules/@stdlib/assert-has-uint8array-support/lib/main.js
var require_main19 = __commonJS({
  "node_modules/@stdlib/assert-has-uint8array-support/lib/main.js"(exports, module) {
    "use strict";
    var isUint8Array = require_lib22();
    var UINT8_MAX = require_lib23();
    var GlobalUint8Array = require_uint8array();
    function hasUint8ArraySupport() {
      var bool;
      var arr;
      if (typeof GlobalUint8Array !== "function") {
        return false;
      }
      try {
        arr = [1, 3.14, -3.14, UINT8_MAX + 1, UINT8_MAX + 2];
        arr = new GlobalUint8Array(arr);
        bool = isUint8Array(arr) && arr[0] === 1 && arr[1] === 3 && // truncation
        arr[2] === UINT8_MAX - 2 && // truncation and wrap around
        arr[3] === 0 && // wrap around
        arr[4] === 1;
      } catch (err) {
        bool = false;
      }
      return bool;
    }
    module.exports = hasUint8ArraySupport;
  }
});

// node_modules/@stdlib/assert-has-uint8array-support/lib/index.js
var require_lib24 = __commonJS({
  "node_modules/@stdlib/assert-has-uint8array-support/lib/index.js"(exports, module) {
    "use strict";
    var hasUint8ArraySupport = require_main19();
    module.exports = hasUint8ArraySupport;
  }
});

// node_modules/@stdlib/array-uint8/lib/main.js
var require_main20 = __commonJS({
  "node_modules/@stdlib/array-uint8/lib/main.js"(exports, module) {
    "use strict";
    var ctor = typeof Uint8Array === "function" ? Uint8Array : void 0;
    module.exports = ctor;
  }
});

// node_modules/@stdlib/array-uint8/lib/polyfill.js
var require_polyfill4 = __commonJS({
  "node_modules/@stdlib/array-uint8/lib/polyfill.js"(exports, module) {
    "use strict";
    function polyfill() {
      throw new Error("not implemented");
    }
    module.exports = polyfill;
  }
});

// node_modules/@stdlib/array-uint8/lib/index.js
var require_lib25 = __commonJS({
  "node_modules/@stdlib/array-uint8/lib/index.js"(exports, module) {
    "use strict";
    var hasUint8ArraySupport = require_lib24();
    var builtin = require_main20();
    var polyfill = require_polyfill4();
    var ctor;
    if (hasUint8ArraySupport()) {
      ctor = builtin;
    } else {
      ctor = polyfill;
    }
    module.exports = ctor;
  }
});

// node_modules/@stdlib/assert-is-uint16array/lib/main.js
var require_main21 = __commonJS({
  "node_modules/@stdlib/assert-is-uint16array/lib/main.js"(exports, module) {
    "use strict";
    var nativeClass = require_lib14();
    var hasUint16Array = typeof Uint16Array === "function";
    function isUint16Array(value) {
      return hasUint16Array && value instanceof Uint16Array || // eslint-disable-line stdlib/require-globals
      nativeClass(value) === "[object Uint16Array]";
    }
    module.exports = isUint16Array;
  }
});

// node_modules/@stdlib/assert-is-uint16array/lib/index.js
var require_lib26 = __commonJS({
  "node_modules/@stdlib/assert-is-uint16array/lib/index.js"(exports, module) {
    "use strict";
    var isUint16Array = require_main21();
    module.exports = isUint16Array;
  }
});

// node_modules/@stdlib/constants-uint16-max/lib/index.js
var require_lib27 = __commonJS({
  "node_modules/@stdlib/constants-uint16-max/lib/index.js"(exports, module) {
    "use strict";
    var UINT16_MAX = 65535 | 0;
    module.exports = UINT16_MAX;
  }
});

// node_modules/@stdlib/assert-has-uint16array-support/lib/uint16array.js
var require_uint16array = __commonJS({
  "node_modules/@stdlib/assert-has-uint16array-support/lib/uint16array.js"(exports, module) {
    "use strict";
    var main = typeof Uint16Array === "function" ? Uint16Array : null;
    module.exports = main;
  }
});

// node_modules/@stdlib/assert-has-uint16array-support/lib/main.js
var require_main22 = __commonJS({
  "node_modules/@stdlib/assert-has-uint16array-support/lib/main.js"(exports, module) {
    "use strict";
    var isUint16Array = require_lib26();
    var UINT16_MAX = require_lib27();
    var GlobalUint16Array = require_uint16array();
    function hasUint16ArraySupport() {
      var bool;
      var arr;
      if (typeof GlobalUint16Array !== "function") {
        return false;
      }
      try {
        arr = [1, 3.14, -3.14, UINT16_MAX + 1, UINT16_MAX + 2];
        arr = new GlobalUint16Array(arr);
        bool = isUint16Array(arr) && arr[0] === 1 && arr[1] === 3 && // truncation
        arr[2] === UINT16_MAX - 2 && // truncation and wrap around
        arr[3] === 0 && // wrap around
        arr[4] === 1;
      } catch (err) {
        bool = false;
      }
      return bool;
    }
    module.exports = hasUint16ArraySupport;
  }
});

// node_modules/@stdlib/assert-has-uint16array-support/lib/index.js
var require_lib28 = __commonJS({
  "node_modules/@stdlib/assert-has-uint16array-support/lib/index.js"(exports, module) {
    "use strict";
    var hasUint16ArraySupport = require_main22();
    module.exports = hasUint16ArraySupport;
  }
});

// node_modules/@stdlib/array-uint16/lib/main.js
var require_main23 = __commonJS({
  "node_modules/@stdlib/array-uint16/lib/main.js"(exports, module) {
    "use strict";
    var ctor = typeof Uint16Array === "function" ? Uint16Array : void 0;
    module.exports = ctor;
  }
});

// node_modules/@stdlib/array-uint16/lib/polyfill.js
var require_polyfill5 = __commonJS({
  "node_modules/@stdlib/array-uint16/lib/polyfill.js"(exports, module) {
    "use strict";
    function polyfill() {
      throw new Error("not implemented");
    }
    module.exports = polyfill;
  }
});

// node_modules/@stdlib/array-uint16/lib/index.js
var require_lib29 = __commonJS({
  "node_modules/@stdlib/array-uint16/lib/index.js"(exports, module) {
    "use strict";
    var hasUint16ArraySupport = require_lib28();
    var builtin = require_main23();
    var polyfill = require_polyfill5();
    var ctor;
    if (hasUint16ArraySupport()) {
      ctor = builtin;
    } else {
      ctor = polyfill;
    }
    module.exports = ctor;
  }
});

// node_modules/@stdlib/assert-is-little-endian/lib/ctors.js
var require_ctors = __commonJS({
  "node_modules/@stdlib/assert-is-little-endian/lib/ctors.js"(exports, module) {
    "use strict";
    var Uint8Array2 = require_lib25();
    var Uint16Array2 = require_lib29();
    var ctors = {
      "uint16": Uint16Array2,
      "uint8": Uint8Array2
    };
    module.exports = ctors;
  }
});

// node_modules/@stdlib/assert-is-little-endian/lib/main.js
var require_main24 = __commonJS({
  "node_modules/@stdlib/assert-is-little-endian/lib/main.js"(exports, module) {
    "use strict";
    var ctors = require_ctors();
    var bool;
    function isLittleEndian() {
      var uint16view;
      var uint8view;
      uint16view = new ctors["uint16"](1);
      uint16view[0] = 4660;
      uint8view = new ctors["uint8"](uint16view.buffer);
      return uint8view[0] === 52;
    }
    bool = isLittleEndian();
    module.exports = bool;
  }
});

// node_modules/@stdlib/assert-is-little-endian/lib/index.js
var require_lib30 = __commonJS({
  "node_modules/@stdlib/assert-is-little-endian/lib/index.js"(exports, module) {
    "use strict";
    var IS_LITTLE_ENDIAN = require_main24();
    module.exports = IS_LITTLE_ENDIAN;
  }
});

// node_modules/@stdlib/number-float64-base-get-high-word/lib/high.js
var require_high = __commonJS({
  "node_modules/@stdlib/number-float64-base-get-high-word/lib/high.js"(exports, module) {
    "use strict";
    var isLittleEndian = require_lib30();
    var HIGH;
    if (isLittleEndian === true) {
      HIGH = 1;
    } else {
      HIGH = 0;
    }
    module.exports = HIGH;
  }
});

// node_modules/@stdlib/number-float64-base-get-high-word/lib/main.js
var require_main25 = __commonJS({
  "node_modules/@stdlib/number-float64-base-get-high-word/lib/main.js"(exports, module) {
    "use strict";
    var Uint32Array2 = require_lib18();
    var Float64Array2 = require_lib21();
    var HIGH = require_high();
    var FLOAT64_VIEW = new Float64Array2(1);
    var UINT32_VIEW = new Uint32Array2(FLOAT64_VIEW.buffer);
    function getHighWord(x) {
      FLOAT64_VIEW[0] = x;
      return UINT32_VIEW[HIGH];
    }
    module.exports = getHighWord;
  }
});

// node_modules/@stdlib/number-float64-base-get-high-word/lib/index.js
var require_lib31 = __commonJS({
  "node_modules/@stdlib/number-float64-base-get-high-word/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main25();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-kernel-cos/lib/polyval_c13.js
var require_polyval_c13 = __commonJS({
  "node_modules/@stdlib/math-base-special-kernel-cos/lib/polyval_c13.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return 0.0416666666666666;
      }
      return 0.0416666666666666 + x * (-0.001388888888887411 + x * 2480158728947673e-20);
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-kernel-cos/lib/polyval_c46.js
var require_polyval_c46 = __commonJS({
  "node_modules/@stdlib/math-base-special-kernel-cos/lib/polyval_c46.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return -27557314351390663e-23;
      }
      return -27557314351390663e-23 + x * (2087572321298175e-24 + x * -11359647557788195e-27);
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-kernel-cos/lib/main.js
var require_main26 = __commonJS({
  "node_modules/@stdlib/math-base-special-kernel-cos/lib/main.js"(exports, module) {
    "use strict";
    var polyval13 = require_polyval_c13();
    var polyval46 = require_polyval_c46();
    function kernelCos(x, y) {
      var hz;
      var r;
      var w;
      var z;
      z = x * x;
      w = z * z;
      r = z * polyval13(z);
      r += w * w * polyval46(z);
      hz = 0.5 * z;
      w = 1 - hz;
      return w + (1 - w - hz + (z * r - x * y));
    }
    module.exports = kernelCos;
  }
});

// node_modules/@stdlib/math-base-special-kernel-cos/lib/index.js
var require_lib32 = __commonJS({
  "node_modules/@stdlib/math-base-special-kernel-cos/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main26();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-kernel-sin/lib/main.js
var require_main27 = __commonJS({
  "node_modules/@stdlib/math-base-special-kernel-sin/lib/main.js"(exports, module) {
    "use strict";
    var S1 = -0.16666666666666632;
    var S2 = 0.00833333333332249;
    var S3 = -1984126982985795e-19;
    var S4 = 27557313707070068e-22;
    var S5 = -25050760253406863e-24;
    var S6 = 158969099521155e-24;
    function kernelSin(x, y) {
      var r;
      var v;
      var w;
      var z;
      z = x * x;
      w = z * z;
      r = S2 + z * (S3 + z * S4) + z * w * (S5 + z * S6);
      v = z * x;
      if (y === 0) {
        return x + v * (S1 + z * r);
      }
      return x - (z * (0.5 * y - v * r) - y - v * S1);
    }
    module.exports = kernelSin;
  }
});

// node_modules/@stdlib/math-base-special-kernel-sin/lib/index.js
var require_lib33 = __commonJS({
  "node_modules/@stdlib/math-base-special-kernel-sin/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main27();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-high-word-significand-mask/lib/index.js
var require_lib34 = __commonJS({
  "node_modules/@stdlib/constants-float64-high-word-significand-mask/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_HIGH_WORD_SIGNIFICAND_MASK = 1048575;
    module.exports = FLOAT64_HIGH_WORD_SIGNIFICAND_MASK;
  }
});

// node_modules/@stdlib/number-float64-base-get-low-word/lib/low.js
var require_low = __commonJS({
  "node_modules/@stdlib/number-float64-base-get-low-word/lib/low.js"(exports, module) {
    "use strict";
    var isLittleEndian = require_lib30();
    var LOW;
    if (isLittleEndian === true) {
      LOW = 0;
    } else {
      LOW = 1;
    }
    module.exports = LOW;
  }
});

// node_modules/@stdlib/number-float64-base-get-low-word/lib/main.js
var require_main28 = __commonJS({
  "node_modules/@stdlib/number-float64-base-get-low-word/lib/main.js"(exports, module) {
    "use strict";
    var Uint32Array2 = require_lib18();
    var Float64Array2 = require_lib21();
    var LOW = require_low();
    var FLOAT64_VIEW = new Float64Array2(1);
    var UINT32_VIEW = new Uint32Array2(FLOAT64_VIEW.buffer);
    function getLowWord(x) {
      FLOAT64_VIEW[0] = x;
      return UINT32_VIEW[LOW];
    }
    module.exports = getLowWord;
  }
});

// node_modules/@stdlib/number-float64-base-get-low-word/lib/index.js
var require_lib35 = __commonJS({
  "node_modules/@stdlib/number-float64-base-get-low-word/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main28();
    module.exports = main;
  }
});

// node_modules/@stdlib/number-float64-base-from-words/lib/indices.js
var require_indices = __commonJS({
  "node_modules/@stdlib/number-float64-base-from-words/lib/indices.js"(exports, module) {
    "use strict";
    var isLittleEndian = require_lib30();
    var indices;
    var HIGH;
    var LOW;
    if (isLittleEndian === true) {
      HIGH = 1;
      LOW = 0;
    } else {
      HIGH = 0;
      LOW = 1;
    }
    indices = {
      "HIGH": HIGH,
      "LOW": LOW
    };
    module.exports = indices;
  }
});

// node_modules/@stdlib/number-float64-base-from-words/lib/main.js
var require_main29 = __commonJS({
  "node_modules/@stdlib/number-float64-base-from-words/lib/main.js"(exports, module) {
    "use strict";
    var Uint32Array2 = require_lib18();
    var Float64Array2 = require_lib21();
    var indices = require_indices();
    var FLOAT64_VIEW = new Float64Array2(1);
    var UINT32_VIEW = new Uint32Array2(FLOAT64_VIEW.buffer);
    var HIGH = indices.HIGH;
    var LOW = indices.LOW;
    function fromWords(high, low) {
      UINT32_VIEW[HIGH] = high;
      UINT32_VIEW[LOW] = low;
      return FLOAT64_VIEW[0];
    }
    module.exports = fromWords;
  }
});

// node_modules/@stdlib/number-float64-base-from-words/lib/index.js
var require_lib36 = __commonJS({
  "node_modules/@stdlib/number-float64-base-from-words/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main29();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-pinf/lib/index.js
var require_lib37 = __commonJS({
  "node_modules/@stdlib/constants-float64-pinf/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_PINF = Number.POSITIVE_INFINITY;
    module.exports = FLOAT64_PINF;
  }
});

// node_modules/@stdlib/constants-float64-exponent-bias/lib/index.js
var require_lib38 = __commonJS({
  "node_modules/@stdlib/constants-float64-exponent-bias/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_EXPONENT_BIAS = 1023 | 0;
    module.exports = FLOAT64_EXPONENT_BIAS;
  }
});

// node_modules/@stdlib/constants-float64-max-base2-exponent/lib/index.js
var require_lib39 = __commonJS({
  "node_modules/@stdlib/constants-float64-max-base2-exponent/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_MAX_BASE2_EXPONENT = 1023 | 0;
    module.exports = FLOAT64_MAX_BASE2_EXPONENT;
  }
});

// node_modules/@stdlib/constants-float64-max-base2-exponent-subnormal/lib/index.js
var require_lib40 = __commonJS({
  "node_modules/@stdlib/constants-float64-max-base2-exponent-subnormal/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_MAX_BASE2_EXPONENT_SUBNORMAL = -1023 | 0;
    module.exports = FLOAT64_MAX_BASE2_EXPONENT_SUBNORMAL;
  }
});

// node_modules/@stdlib/constants-float64-min-base2-exponent-subnormal/lib/index.js
var require_lib41 = __commonJS({
  "node_modules/@stdlib/constants-float64-min-base2-exponent-subnormal/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_MIN_BASE2_EXPONENT_SUBNORMAL = -1074 | 0;
    module.exports = FLOAT64_MIN_BASE2_EXPONENT_SUBNORMAL;
  }
});

// node_modules/@stdlib/math-base-assert-is-infinite/lib/main.js
var require_main30 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-infinite/lib/main.js"(exports, module) {
    "use strict";
    var PINF = require_lib37();
    var NINF = require_lib5();
    function isInfinite(x) {
      return x === PINF || x === NINF;
    }
    module.exports = isInfinite;
  }
});

// node_modules/@stdlib/math-base-assert-is-infinite/lib/index.js
var require_lib42 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-infinite/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main30();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-high-word-sign-mask/lib/index.js
var require_lib43 = __commonJS({
  "node_modules/@stdlib/constants-float64-high-word-sign-mask/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_HIGH_WORD_SIGN_MASK = 2147483648 >>> 0;
    module.exports = FLOAT64_HIGH_WORD_SIGN_MASK;
  }
});

// node_modules/@stdlib/utils-define-property/lib/define_property.js
var require_define_property = __commonJS({
  "node_modules/@stdlib/utils-define-property/lib/define_property.js"(exports, module) {
    "use strict";
    var main = typeof Object.defineProperty === "function" ? Object.defineProperty : null;
    module.exports = main;
  }
});

// node_modules/@stdlib/utils-define-property/lib/has_define_property_support.js
var require_has_define_property_support = __commonJS({
  "node_modules/@stdlib/utils-define-property/lib/has_define_property_support.js"(exports, module) {
    "use strict";
    var defineProperty = require_define_property();
    function hasDefinePropertySupport() {
      try {
        defineProperty({}, "x", {});
        return true;
      } catch (err) {
        return false;
      }
    }
    module.exports = hasDefinePropertySupport;
  }
});

// node_modules/@stdlib/utils-define-property/lib/builtin.js
var require_builtin = __commonJS({
  "node_modules/@stdlib/utils-define-property/lib/builtin.js"(exports, module) {
    "use strict";
    var defineProperty = Object.defineProperty;
    module.exports = defineProperty;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/is_number.js
var require_is_number = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/is_number.js"(exports, module) {
    "use strict";
    function isNumber2(value) {
      return typeof value === "number";
    }
    module.exports = isNumber2;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/zero_pad.js
var require_zero_pad = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/zero_pad.js"(exports, module) {
    "use strict";
    function startsWithMinus(str) {
      return str[0] === "-";
    }
    function zeros2(n) {
      var out = "";
      var i;
      for (i = 0; i < n; i++) {
        out += "0";
      }
      return out;
    }
    function zeroPad(str, width, right) {
      var negative = false;
      var pad = width - str.length;
      if (pad < 0) {
        return str;
      }
      if (startsWithMinus(str)) {
        negative = true;
        str = str.substr(1);
      }
      str = right ? str + zeros2(pad) : zeros2(pad) + str;
      if (negative) {
        str = "-" + str;
      }
      return str;
    }
    module.exports = zeroPad;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/format_integer.js
var require_format_integer = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/format_integer.js"(exports, module) {
    "use strict";
    var isNumber2 = require_is_number();
    var zeroPad = require_zero_pad();
    var lowercase = String.prototype.toLowerCase;
    var uppercase = String.prototype.toUpperCase;
    function formatInteger(token) {
      var base;
      var out;
      var i;
      switch (token.specifier) {
        case "b":
          base = 2;
          break;
        case "o":
          base = 8;
          break;
        case "x":
        case "X":
          base = 16;
          break;
        case "d":
        case "i":
        case "u":
        default:
          base = 10;
          break;
      }
      out = token.arg;
      i = parseInt(out, 10);
      if (!isFinite(i)) {
        if (!isNumber2(out)) {
          throw new Error("invalid integer. Value: " + out);
        }
        i = 0;
      }
      if (i < 0 && (token.specifier === "u" || base !== 10)) {
        i = 4294967295 + i + 1;
      }
      if (i < 0) {
        out = (-i).toString(base);
        if (token.precision) {
          out = zeroPad(out, token.precision, token.padRight);
        }
        out = "-" + out;
      } else {
        out = i.toString(base);
        if (!i && !token.precision) {
          out = "";
        } else if (token.precision) {
          out = zeroPad(out, token.precision, token.padRight);
        }
        if (token.sign) {
          out = token.sign + out;
        }
      }
      if (base === 16) {
        if (token.alternate) {
          out = "0x" + out;
        }
        out = token.specifier === uppercase.call(token.specifier) ? uppercase.call(out) : lowercase.call(out);
      }
      if (base === 8) {
        if (token.alternate && out.charAt(0) !== "0") {
          out = "0" + out;
        }
      }
      return out;
    }
    module.exports = formatInteger;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/is_string.js
var require_is_string = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/is_string.js"(exports, module) {
    "use strict";
    function isString2(value) {
      return typeof value === "string";
    }
    module.exports = isString2;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/format_double.js
var require_format_double = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/format_double.js"(exports, module) {
    "use strict";
    var abs3 = Math.abs;
    var lowercase = String.prototype.toLowerCase;
    var uppercase = String.prototype.toUpperCase;
    var replace = String.prototype.replace;
    var RE_EXP_POS_DIGITS = /e\+(\d)$/;
    var RE_EXP_NEG_DIGITS = /e-(\d)$/;
    var RE_ONLY_DIGITS = /^(\d+)$/;
    var RE_DIGITS_BEFORE_EXP = /^(\d+)e/;
    var RE_TRAILING_PERIOD_ZERO = /\.0$/;
    var RE_PERIOD_ZERO_EXP = /\.0*e/;
    var RE_ZERO_BEFORE_EXP = /(\..*[^0])0*e/;
    function formatDouble(f, token) {
      var digits2;
      var out;
      switch (token.specifier) {
        case "e":
        case "E":
          out = f.toExponential(token.precision);
          break;
        case "f":
        case "F":
          out = f.toFixed(token.precision);
          break;
        case "g":
        case "G":
          if (abs3(f) < 1e-4) {
            digits2 = token.precision;
            if (digits2 > 0) {
              digits2 -= 1;
            }
            out = f.toExponential(digits2);
          } else {
            out = f.toPrecision(token.precision);
          }
          if (!token.alternate) {
            out = replace.call(out, RE_ZERO_BEFORE_EXP, "$1e");
            out = replace.call(out, RE_PERIOD_ZERO_EXP, "e");
            out = replace.call(out, RE_TRAILING_PERIOD_ZERO, "");
          }
          break;
        default:
          throw new Error("invalid double notation. Value: " + token.specifier);
      }
      out = replace.call(out, RE_EXP_POS_DIGITS, "e+0$1");
      out = replace.call(out, RE_EXP_NEG_DIGITS, "e-0$1");
      if (token.alternate) {
        out = replace.call(out, RE_ONLY_DIGITS, "$1.");
        out = replace.call(out, RE_DIGITS_BEFORE_EXP, "$1.e");
      }
      if (f >= 0 && token.sign) {
        out = token.sign + out;
      }
      out = token.specifier === uppercase.call(token.specifier) ? uppercase.call(out) : lowercase.call(out);
      return out;
    }
    module.exports = formatDouble;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/space_pad.js
var require_space_pad = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/space_pad.js"(exports, module) {
    "use strict";
    function spaces(n) {
      var out = "";
      var i;
      for (i = 0; i < n; i++) {
        out += " ";
      }
      return out;
    }
    function spacePad(str, width, right) {
      var pad = width - str.length;
      if (pad < 0) {
        return str;
      }
      str = right ? str + spaces(pad) : spaces(pad) + str;
      return str;
    }
    module.exports = spacePad;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/main.js
var require_main31 = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/main.js"(exports, module) {
    "use strict";
    var formatInteger = require_format_integer();
    var isString2 = require_is_string();
    var isNumber2 = require_is_number();
    var formatDouble = require_format_double();
    var spacePad = require_space_pad();
    var zeroPad = require_zero_pad();
    var fromCharCode = String.fromCharCode;
    var isArray2 = Array.isArray;
    function isnan(value) {
      return value !== value;
    }
    function initialize(token) {
      var out = {};
      out.specifier = token.specifier;
      out.precision = token.precision === void 0 ? 1 : token.precision;
      out.width = token.width;
      out.flags = token.flags || "";
      out.mapping = token.mapping;
      return out;
    }
    function formatInterpolate(tokens) {
      var hasPeriod;
      var flags;
      var token;
      var flag;
      var num;
      var out;
      var pos;
      var f;
      var i;
      var j;
      if (!isArray2(tokens)) {
        throw new TypeError("invalid argument. First argument must be an array. Value: `" + tokens + "`.");
      }
      out = "";
      pos = 1;
      for (i = 0; i < tokens.length; i++) {
        token = tokens[i];
        if (isString2(token)) {
          out += token;
        } else {
          hasPeriod = token.precision !== void 0;
          token = initialize(token);
          if (!token.specifier) {
            throw new TypeError("invalid argument. Token is missing `specifier` property. Index: `" + i + "`. Value: `" + token + "`.");
          }
          if (token.mapping) {
            pos = token.mapping;
          }
          flags = token.flags;
          for (j = 0; j < flags.length; j++) {
            flag = flags.charAt(j);
            switch (flag) {
              case " ":
                token.sign = " ";
                break;
              case "+":
                token.sign = "+";
                break;
              case "-":
                token.padRight = true;
                token.padZeros = false;
                break;
              case "0":
                token.padZeros = flags.indexOf("-") < 0;
                break;
              case "#":
                token.alternate = true;
                break;
              default:
                throw new Error("invalid flag: " + flag);
            }
          }
          if (token.width === "*") {
            token.width = parseInt(arguments[pos], 10);
            pos += 1;
            if (isnan(token.width)) {
              throw new TypeError("the argument for * width at position " + pos + " is not a number. Value: `" + token.width + "`.");
            }
            if (token.width < 0) {
              token.padRight = true;
              token.width = -token.width;
            }
          }
          if (hasPeriod) {
            if (token.precision === "*") {
              token.precision = parseInt(arguments[pos], 10);
              pos += 1;
              if (isnan(token.precision)) {
                throw new TypeError("the argument for * precision at position " + pos + " is not a number. Value: `" + token.precision + "`.");
              }
              if (token.precision < 0) {
                token.precision = 1;
                hasPeriod = false;
              }
            }
          }
          token.arg = arguments[pos];
          switch (token.specifier) {
            case "b":
            case "o":
            case "x":
            case "X":
            case "d":
            case "i":
            case "u":
              if (hasPeriod) {
                token.padZeros = false;
              }
              token.arg = formatInteger(token);
              break;
            case "s":
              token.maxWidth = hasPeriod ? token.precision : -1;
              token.arg = String(token.arg);
              break;
            case "c":
              if (!isnan(token.arg)) {
                num = parseInt(token.arg, 10);
                if (num < 0 || num > 127) {
                  throw new Error("invalid character code. Value: " + token.arg);
                }
                token.arg = isnan(num) ? String(token.arg) : fromCharCode(num);
              }
              break;
            case "e":
            case "E":
            case "f":
            case "F":
            case "g":
            case "G":
              if (!hasPeriod) {
                token.precision = 6;
              }
              f = parseFloat(token.arg);
              if (!isFinite(f)) {
                if (!isNumber2(token.arg)) {
                  throw new Error("invalid floating-point number. Value: " + out);
                }
                f = token.arg;
                token.padZeros = false;
              }
              token.arg = formatDouble(f, token);
              break;
            default:
              throw new Error("invalid specifier: " + token.specifier);
          }
          if (token.maxWidth >= 0 && token.arg.length > token.maxWidth) {
            token.arg = token.arg.substring(0, token.maxWidth);
          }
          if (token.padZeros) {
            token.arg = zeroPad(token.arg, token.width || token.precision, token.padRight);
          } else if (token.width) {
            token.arg = spacePad(token.arg, token.width, token.padRight);
          }
          out += token.arg || "";
          pos += 1;
        }
      }
      return out;
    }
    module.exports = formatInterpolate;
  }
});

// node_modules/@stdlib/string-base-format-interpolate/lib/index.js
var require_lib44 = __commonJS({
  "node_modules/@stdlib/string-base-format-interpolate/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main31();
    module.exports = main;
  }
});

// node_modules/@stdlib/string-base-format-tokenize/lib/main.js
var require_main32 = __commonJS({
  "node_modules/@stdlib/string-base-format-tokenize/lib/main.js"(exports, module) {
    "use strict";
    var RE = /%(?:([1-9]\d*)\$)?([0 +\-#]*)(\*|\d+)?(?:(\.)(\*|\d+)?)?[hlL]?([%A-Za-z])/g;
    function parse2(match) {
      var token = {
        "mapping": match[1] ? parseInt(match[1], 10) : void 0,
        "flags": match[2],
        "width": match[3],
        "precision": match[5],
        "specifier": match[6]
      };
      if (match[4] === "." && match[5] === void 0) {
        token.precision = "1";
      }
      return token;
    }
    function formatTokenize(str) {
      var content;
      var tokens;
      var match;
      var prev;
      tokens = [];
      prev = 0;
      match = RE.exec(str);
      while (match) {
        content = str.slice(prev, RE.lastIndex - match[0].length);
        if (content.length) {
          tokens.push(content);
        }
        if (match[6] === "%") {
          tokens.push("%");
        } else {
          tokens.push(parse2(match));
        }
        prev = RE.lastIndex;
        match = RE.exec(str);
      }
      content = str.slice(prev);
      if (content.length) {
        tokens.push(content);
      }
      return tokens;
    }
    module.exports = formatTokenize;
  }
});

// node_modules/@stdlib/string-base-format-tokenize/lib/index.js
var require_lib45 = __commonJS({
  "node_modules/@stdlib/string-base-format-tokenize/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main32();
    module.exports = main;
  }
});

// node_modules/@stdlib/string-format/lib/is_string.js
var require_is_string2 = __commonJS({
  "node_modules/@stdlib/string-format/lib/is_string.js"(exports, module) {
    "use strict";
    function isString2(value) {
      return typeof value === "string";
    }
    module.exports = isString2;
  }
});

// node_modules/@stdlib/string-format/lib/main.js
var require_main33 = __commonJS({
  "node_modules/@stdlib/string-format/lib/main.js"(exports, module) {
    "use strict";
    var interpolate = require_lib44();
    var tokenize = require_lib45();
    var isString2 = require_is_string2();
    function format5(str) {
      var args;
      var i;
      if (!isString2(str)) {
        throw new TypeError(format5("invalid argument. First argument must be a string. Value: `%s`.", str));
      }
      args = [tokenize(str)];
      for (i = 1; i < arguments.length; i++) {
        args.push(arguments[i]);
      }
      return interpolate.apply(null, args);
    }
    module.exports = format5;
  }
});

// node_modules/@stdlib/string-format/lib/index.js
var require_lib46 = __commonJS({
  "node_modules/@stdlib/string-format/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main33();
    module.exports = main;
  }
});

// node_modules/@stdlib/utils-define-property/lib/polyfill.js
var require_polyfill6 = __commonJS({
  "node_modules/@stdlib/utils-define-property/lib/polyfill.js"(exports, module) {
    "use strict";
    var format5 = require_lib46();
    var objectProtoype = Object.prototype;
    var toStr = objectProtoype.toString;
    var defineGetter = objectProtoype.__defineGetter__;
    var defineSetter = objectProtoype.__defineSetter__;
    var lookupGetter = objectProtoype.__lookupGetter__;
    var lookupSetter = objectProtoype.__lookupSetter__;
    function defineProperty(obj, prop, descriptor) {
      var prototype;
      var hasValue;
      var hasGet;
      var hasSet;
      if (typeof obj !== "object" || obj === null || toStr.call(obj) === "[object Array]") {
        throw new TypeError(format5("invalid argument. First argument must be an object. Value: `%s`.", obj));
      }
      if (typeof descriptor !== "object" || descriptor === null || toStr.call(descriptor) === "[object Array]") {
        throw new TypeError(format5("invalid argument. Property descriptor must be an object. Value: `%s`.", descriptor));
      }
      hasValue = "value" in descriptor;
      if (hasValue) {
        if (lookupGetter.call(obj, prop) || lookupSetter.call(obj, prop)) {
          prototype = obj.__proto__;
          obj.__proto__ = objectProtoype;
          delete obj[prop];
          obj[prop] = descriptor.value;
          obj.__proto__ = prototype;
        } else {
          obj[prop] = descriptor.value;
        }
      }
      hasGet = "get" in descriptor;
      hasSet = "set" in descriptor;
      if (hasValue && (hasGet || hasSet)) {
        throw new Error("invalid argument. Cannot specify one or more accessors and a value or writable attribute in the property descriptor.");
      }
      if (hasGet && defineGetter) {
        defineGetter.call(obj, prop, descriptor.get);
      }
      if (hasSet && defineSetter) {
        defineSetter.call(obj, prop, descriptor.set);
      }
      return obj;
    }
    module.exports = defineProperty;
  }
});

// node_modules/@stdlib/utils-define-property/lib/index.js
var require_lib47 = __commonJS({
  "node_modules/@stdlib/utils-define-property/lib/index.js"(exports, module) {
    "use strict";
    var hasDefinePropertySupport = require_has_define_property_support();
    var builtin = require_builtin();
    var polyfill = require_polyfill6();
    var defineProperty;
    if (hasDefinePropertySupport()) {
      defineProperty = builtin;
    } else {
      defineProperty = polyfill;
    }
    module.exports = defineProperty;
  }
});

// node_modules/@stdlib/utils-define-nonenumerable-read-only-property/lib/main.js
var require_main34 = __commonJS({
  "node_modules/@stdlib/utils-define-nonenumerable-read-only-property/lib/main.js"(exports, module) {
    "use strict";
    var defineProperty = require_lib47();
    function setNonEnumerableReadOnly(obj, prop, value) {
      defineProperty(obj, prop, {
        "configurable": false,
        "enumerable": false,
        "writable": false,
        "value": value
      });
    }
    module.exports = setNonEnumerableReadOnly;
  }
});

// node_modules/@stdlib/utils-define-nonenumerable-read-only-property/lib/index.js
var require_lib48 = __commonJS({
  "node_modules/@stdlib/utils-define-nonenumerable-read-only-property/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main34();
    module.exports = main;
  }
});

// node_modules/@stdlib/number-float64-base-to-words/lib/indices.js
var require_indices2 = __commonJS({
  "node_modules/@stdlib/number-float64-base-to-words/lib/indices.js"(exports, module) {
    "use strict";
    var isLittleEndian = require_lib30();
    var indices;
    var HIGH;
    var LOW;
    if (isLittleEndian === true) {
      HIGH = 1;
      LOW = 0;
    } else {
      HIGH = 0;
      LOW = 1;
    }
    indices = {
      "HIGH": HIGH,
      "LOW": LOW
    };
    module.exports = indices;
  }
});

// node_modules/@stdlib/number-float64-base-to-words/lib/assign.js
var require_assign = __commonJS({
  "node_modules/@stdlib/number-float64-base-to-words/lib/assign.js"(exports, module) {
    "use strict";
    var Uint32Array2 = require_lib18();
    var Float64Array2 = require_lib21();
    var indices = require_indices2();
    var FLOAT64_VIEW = new Float64Array2(1);
    var UINT32_VIEW = new Uint32Array2(FLOAT64_VIEW.buffer);
    var HIGH = indices.HIGH;
    var LOW = indices.LOW;
    function toWords(x, out, stride, offset) {
      FLOAT64_VIEW[0] = x;
      out[offset] = UINT32_VIEW[HIGH];
      out[offset + stride] = UINT32_VIEW[LOW];
      return out;
    }
    module.exports = toWords;
  }
});

// node_modules/@stdlib/number-float64-base-to-words/lib/main.js
var require_main35 = __commonJS({
  "node_modules/@stdlib/number-float64-base-to-words/lib/main.js"(exports, module) {
    "use strict";
    var fcn = require_assign();
    function toWords(x) {
      return fcn(x, [0 >>> 0, 0 >>> 0], 1, 0);
    }
    module.exports = toWords;
  }
});

// node_modules/@stdlib/number-float64-base-to-words/lib/index.js
var require_lib49 = __commonJS({
  "node_modules/@stdlib/number-float64-base-to-words/lib/index.js"(exports, module) {
    "use strict";
    var setReadOnly = require_lib48();
    var main = require_main35();
    var assign = require_assign();
    setReadOnly(main, "assign", assign);
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-copysign/lib/main.js
var require_main36 = __commonJS({
  "node_modules/@stdlib/math-base-special-copysign/lib/main.js"(exports, module) {
    "use strict";
    var SIGN_MASK = require_lib43();
    var ABS_MASK = require_lib8();
    var toWords = require_lib49();
    var getHighWord = require_lib31();
    var fromWords = require_lib36();
    var WORDS = [0, 0];
    function copysign(x, y) {
      var hx;
      var hy;
      toWords.assign(x, WORDS, 1, 0);
      hx = WORDS[0];
      hx &= ABS_MASK;
      hy = getHighWord(y);
      hy &= SIGN_MASK;
      hx |= hy;
      return fromWords(hx, WORDS[1]);
    }
    module.exports = copysign;
  }
});

// node_modules/@stdlib/math-base-special-copysign/lib/index.js
var require_lib50 = __commonJS({
  "node_modules/@stdlib/math-base-special-copysign/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main36();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-smallest-normal/lib/index.js
var require_lib51 = __commonJS({
  "node_modules/@stdlib/constants-float64-smallest-normal/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_SMALLEST_NORMAL = 22250738585072014e-324;
    module.exports = FLOAT64_SMALLEST_NORMAL;
  }
});

// node_modules/@stdlib/number-float64-base-normalize/lib/assign.js
var require_assign2 = __commonJS({
  "node_modules/@stdlib/number-float64-base-normalize/lib/assign.js"(exports, module) {
    "use strict";
    var FLOAT64_SMALLEST_NORMAL = require_lib51();
    var isInfinite = require_lib42();
    var isnan = require_lib();
    var abs3 = require_lib7();
    var SCALAR = 4503599627370496;
    function normalize(x, out, stride, offset) {
      if (isnan(x) || isInfinite(x)) {
        out[offset] = x;
        out[offset + stride] = 0;
        return out;
      }
      if (x !== 0 && abs3(x) < FLOAT64_SMALLEST_NORMAL) {
        out[offset] = x * SCALAR;
        out[offset + stride] = -52;
        return out;
      }
      out[offset] = x;
      out[offset + stride] = 0;
      return out;
    }
    module.exports = normalize;
  }
});

// node_modules/@stdlib/number-float64-base-normalize/lib/main.js
var require_main37 = __commonJS({
  "node_modules/@stdlib/number-float64-base-normalize/lib/main.js"(exports, module) {
    "use strict";
    var fcn = require_assign2();
    function normalize(x) {
      return fcn(x, [0, 0], 1, 0);
    }
    module.exports = normalize;
  }
});

// node_modules/@stdlib/number-float64-base-normalize/lib/index.js
var require_lib52 = __commonJS({
  "node_modules/@stdlib/number-float64-base-normalize/lib/index.js"(exports, module) {
    "use strict";
    var setReadOnly = require_lib48();
    var main = require_main37();
    var assign = require_assign2();
    setReadOnly(main, "assign", assign);
    module.exports = main;
  }
});

// node_modules/@stdlib/number-float64-base-exponent/lib/main.js
var require_main38 = __commonJS({
  "node_modules/@stdlib/number-float64-base-exponent/lib/main.js"(exports, module) {
    "use strict";
    var getHighWord = require_lib31();
    var EXP_MASK = require_lib9();
    var BIAS = require_lib38();
    function exponent(x) {
      var high = getHighWord(x);
      high = (high & EXP_MASK) >>> 20;
      return high - BIAS | 0;
    }
    module.exports = exponent;
  }
});

// node_modules/@stdlib/number-float64-base-exponent/lib/index.js
var require_lib53 = __commonJS({
  "node_modules/@stdlib/number-float64-base-exponent/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main38();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-ldexp/lib/main.js
var require_main39 = __commonJS({
  "node_modules/@stdlib/math-base-special-ldexp/lib/main.js"(exports, module) {
    "use strict";
    var PINF = require_lib37();
    var NINF = require_lib5();
    var BIAS = require_lib38();
    var MAX_EXPONENT = require_lib39();
    var MAX_SUBNORMAL_EXPONENT = require_lib40();
    var MIN_SUBNORMAL_EXPONENT = require_lib41();
    var isnan = require_lib();
    var isInfinite = require_lib42();
    var copysign = require_lib50();
    var normalize = require_lib52().assign;
    var floatExp = require_lib53();
    var toWords = require_lib49();
    var fromWords = require_lib36();
    var TWO52_INV = 2220446049250313e-31;
    var CLEAR_EXP_MASK = 2148532223 >>> 0;
    var FRAC = [0, 0];
    var WORDS = [0, 0];
    function ldexp(frac, exp3) {
      var high;
      var m;
      if (exp3 === 0 || frac === 0 || // handles +-0
      isnan(frac) || isInfinite(frac)) {
        return frac;
      }
      normalize(frac, FRAC, 1, 0);
      frac = FRAC[0];
      exp3 += FRAC[1];
      exp3 += floatExp(frac);
      if (exp3 < MIN_SUBNORMAL_EXPONENT) {
        return copysign(0, frac);
      }
      if (exp3 > MAX_EXPONENT) {
        if (frac < 0) {
          return NINF;
        }
        return PINF;
      }
      if (exp3 <= MAX_SUBNORMAL_EXPONENT) {
        exp3 += 52;
        m = TWO52_INV;
      } else {
        m = 1;
      }
      toWords.assign(frac, WORDS, 1, 0);
      high = WORDS[0];
      high &= CLEAR_EXP_MASK;
      high |= exp3 + BIAS << 20;
      return m * fromWords(high, WORDS[1]);
    }
    module.exports = ldexp;
  }
});

// node_modules/@stdlib/math-base-special-ldexp/lib/index.js
var require_lib54 = __commonJS({
  "node_modules/@stdlib/math-base-special-ldexp/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main39();
    module.exports = main;
  }
});

// node_modules/@stdlib/array-base-filled/lib/main.js
var require_main40 = __commonJS({
  "node_modules/@stdlib/array-base-filled/lib/main.js"(exports, module) {
    "use strict";
    function filled(value, len) {
      var arr;
      var i;
      arr = [];
      for (i = 0; i < len; i++) {
        arr.push(value);
      }
      return arr;
    }
    module.exports = filled;
  }
});

// node_modules/@stdlib/array-base-filled/lib/index.js
var require_lib55 = __commonJS({
  "node_modules/@stdlib/array-base-filled/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main40();
    module.exports = main;
  }
});

// node_modules/@stdlib/array-base-zeros/lib/main.js
var require_main41 = __commonJS({
  "node_modules/@stdlib/array-base-zeros/lib/main.js"(exports, module) {
    "use strict";
    var filled = require_lib55();
    function zeros2(len) {
      return filled(0, len);
    }
    module.exports = zeros2;
  }
});

// node_modules/@stdlib/array-base-zeros/lib/index.js
var require_lib56 = __commonJS({
  "node_modules/@stdlib/array-base-zeros/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main41();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-rempio2/lib/kernel_rempio2.js
var require_kernel_rempio2 = __commonJS({
  "node_modules/@stdlib/math-base-special-rempio2/lib/kernel_rempio2.js"(exports, module) {
    "use strict";
    var floor3 = require_lib2();
    var ldexp = require_lib54();
    var zeros2 = require_lib56();
    var IPIO2 = [
      10680707,
      7228996,
      1387004,
      2578385,
      16069853,
      12639074,
      9804092,
      4427841,
      16666979,
      11263675,
      12935607,
      2387514,
      4345298,
      14681673,
      3074569,
      13734428,
      16653803,
      1880361,
      10960616,
      8533493,
      3062596,
      8710556,
      7349940,
      6258241,
      3772886,
      3769171,
      3798172,
      8675211,
      12450088,
      3874808,
      9961438,
      366607,
      15675153,
      9132554,
      7151469,
      3571407,
      2607881,
      12013382,
      4155038,
      6285869,
      7677882,
      13102053,
      15825725,
      473591,
      9065106,
      15363067,
      6271263,
      9264392,
      5636912,
      4652155,
      7056368,
      13614112,
      10155062,
      1944035,
      9527646,
      15080200,
      6658437,
      6231200,
      6832269,
      16767104,
      5075751,
      3212806,
      1398474,
      7579849,
      6349435,
      12618859
    ];
    var PIO2 = [
      1.570796251296997,
      // 0x3FF921FB, 0x40000000
      7549789415861596e-23,
      // 0x3E74442D, 0x00000000
      5390302529957765e-30,
      // 0x3CF84698, 0x80000000
      3282003415807913e-37,
      // 0x3B78CC51, 0x60000000
      1270655753080676e-44,
      // 0x39F01B83, 0x80000000
      12293330898111133e-52,
      // 0x387A2520, 0x40000000
      27337005381646456e-60,
      // 0x36E38222, 0x80000000
      21674168387780482e-67
      // 0x3569F31D, 0x00000000
    ];
    var TWO24 = 16777216;
    var TWON24 = 5960464477539063e-23;
    var F = zeros2(20);
    var Q2 = zeros2(20);
    var FQ = zeros2(20);
    var IQ = zeros2(20);
    function compute(x, y, jz, q, q0, jk, jv, jx, f) {
      var carry;
      var fw;
      var ih;
      var jp;
      var i;
      var k;
      var n;
      var j;
      var z;
      jp = jk;
      z = q[jz];
      j = jz;
      for (i = 0; j > 0; i++) {
        fw = TWON24 * z | 0;
        IQ[i] = z - TWO24 * fw | 0;
        z = q[j - 1] + fw;
        j -= 1;
      }
      z = ldexp(z, q0);
      z -= 8 * floor3(z * 0.125);
      n = z | 0;
      z -= n;
      ih = 0;
      if (q0 > 0) {
        i = IQ[jz - 1] >> 24 - q0;
        n += i;
        IQ[jz - 1] -= i << 24 - q0;
        ih = IQ[jz - 1] >> 23 - q0;
      } else if (q0 === 0) {
        ih = IQ[jz - 1] >> 23;
      } else if (z >= 0.5) {
        ih = 2;
      }
      if (ih > 0) {
        n += 1;
        carry = 0;
        for (i = 0; i < jz; i++) {
          j = IQ[i];
          if (carry === 0) {
            if (j !== 0) {
              carry = 1;
              IQ[i] = 16777216 - j;
            }
          } else {
            IQ[i] = 16777215 - j;
          }
        }
        if (q0 > 0) {
          switch (q0) {
            // eslint-disable-line default-case
            case 1:
              IQ[jz - 1] &= 8388607;
              break;
            case 2:
              IQ[jz - 1] &= 4194303;
              break;
          }
        }
        if (ih === 2) {
          z = 1 - z;
          if (carry !== 0) {
            z -= ldexp(1, q0);
          }
        }
      }
      if (z === 0) {
        j = 0;
        for (i = jz - 1; i >= jk; i--) {
          j |= IQ[i];
        }
        if (j === 0) {
          for (k = 1; IQ[jk - k] === 0; k++) {
          }
          for (i = jz + 1; i <= jz + k; i++) {
            f[jx + i] = IPIO2[jv + i];
            fw = 0;
            for (j = 0; j <= jx; j++) {
              fw += x[j] * f[jx + (i - j)];
            }
            q[i] = fw;
          }
          jz += k;
          return compute(x, y, jz, q, q0, jk, jv, jx, f);
        }
        jz -= 1;
        q0 -= 24;
        while (IQ[jz] === 0) {
          jz -= 1;
          q0 -= 24;
        }
      } else {
        z = ldexp(z, -q0);
        if (z >= TWO24) {
          fw = TWON24 * z | 0;
          IQ[jz] = z - TWO24 * fw | 0;
          jz += 1;
          q0 += 24;
          IQ[jz] = fw;
        } else {
          IQ[jz] = z | 0;
        }
      }
      fw = ldexp(1, q0);
      for (i = jz; i >= 0; i--) {
        q[i] = fw * IQ[i];
        fw *= TWON24;
      }
      for (i = jz; i >= 0; i--) {
        fw = 0;
        for (k = 0; k <= jp && k <= jz - i; k++) {
          fw += PIO2[k] * q[i + k];
        }
        FQ[jz - i] = fw;
      }
      fw = 0;
      for (i = jz; i >= 0; i--) {
        fw += FQ[i];
      }
      if (ih === 0) {
        y[0] = fw;
      } else {
        y[0] = -fw;
      }
      fw = FQ[0] - fw;
      for (i = 1; i <= jz; i++) {
        fw += FQ[i];
      }
      if (ih === 0) {
        y[1] = fw;
      } else {
        y[1] = -fw;
      }
      return n & 7;
    }
    function kernelRempio2(x, y, e0, nx) {
      var fw;
      var jk;
      var jv;
      var jx;
      var jz;
      var q0;
      var i;
      var j;
      var m;
      jk = 4;
      jx = nx - 1;
      jv = (e0 - 3) / 24 | 0;
      if (jv < 0) {
        jv = 0;
      }
      q0 = e0 - 24 * (jv + 1);
      j = jv - jx;
      m = jx + jk;
      for (i = 0; i <= m; i++) {
        if (j < 0) {
          F[i] = 0;
        } else {
          F[i] = IPIO2[j];
        }
        j += 1;
      }
      for (i = 0; i <= jk; i++) {
        fw = 0;
        for (j = 0; j <= jx; j++) {
          fw += x[j] * F[jx + (i - j)];
        }
        Q2[i] = fw;
      }
      jz = jk;
      return compute(x, y, jz, Q2, q0, jk, jv, jx, F);
    }
    module.exports = kernelRempio2;
  }
});

// node_modules/@stdlib/math-base-special-round/lib/main.js
var require_main42 = __commonJS({
  "node_modules/@stdlib/math-base-special-round/lib/main.js"(exports, module) {
    "use strict";
    var round3 = Math.round;
    module.exports = round3;
  }
});

// node_modules/@stdlib/math-base-special-round/lib/index.js
var require_lib57 = __commonJS({
  "node_modules/@stdlib/math-base-special-round/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main42();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-rempio2/lib/rempio2_medium.js
var require_rempio2_medium = __commonJS({
  "node_modules/@stdlib/math-base-special-rempio2/lib/rempio2_medium.js"(exports, module) {
    "use strict";
    var round3 = require_lib57();
    var getHighWord = require_lib31();
    var INVPIO2 = 0.6366197723675814;
    var PIO2_1 = 1.5707963267341256;
    var PIO2_1T = 6077100506506192e-26;
    var PIO2_2 = 6077100506303966e-26;
    var PIO2_2T = 20222662487959506e-37;
    var PIO2_3 = 20222662487111665e-37;
    var PIO2_3T = 84784276603689e-45;
    var EXPONENT_MASK = 2047 | 0;
    function rempio2Medium(x, ix, y) {
      var high;
      var n;
      var t;
      var r;
      var w;
      var i;
      var j;
      n = round3(x * INVPIO2);
      r = x - n * PIO2_1;
      w = n * PIO2_1T;
      j = ix >> 20 | 0;
      y[0] = r - w;
      high = getHighWord(y[0]);
      i = j - (high >> 20 & EXPONENT_MASK);
      if (i > 16) {
        t = r;
        w = n * PIO2_2;
        r = t - w;
        w = n * PIO2_2T - (t - r - w);
        y[0] = r - w;
        high = getHighWord(y[0]);
        i = j - (high >> 20 & EXPONENT_MASK);
        if (i > 49) {
          t = r;
          w = n * PIO2_3;
          r = t - w;
          w = n * PIO2_3T - (t - r - w);
          y[0] = r - w;
        }
      }
      y[1] = r - y[0] - w;
      return n;
    }
    module.exports = rempio2Medium;
  }
});

// node_modules/@stdlib/math-base-special-rempio2/lib/main.js
var require_main43 = __commonJS({
  "node_modules/@stdlib/math-base-special-rempio2/lib/main.js"(exports, module) {
    "use strict";
    var ABS_MASK = require_lib8();
    var EXPONENT_MASK = require_lib9();
    var SIGNIFICAND_MASK = require_lib34();
    var getHighWord = require_lib31();
    var getLowWord = require_lib35();
    var fromWords = require_lib36();
    var rempio2Kernel = require_kernel_rempio2();
    var rempio2Medium = require_rempio2_medium();
    var ZERO = 0;
    var TWO24 = 16777216;
    var PIO2_1 = 1.5707963267341256;
    var PIO2_1T = 6077100506506192e-26;
    var TWO_PIO2_1T = 2 * PIO2_1T;
    var THREE_PIO2_1T = 3 * PIO2_1T;
    var FOUR_PIO2_1T = 4 * PIO2_1T;
    var PI_HIGH_WORD_SIGNIFICAND = 598523 | 0;
    var PIO4_HIGH_WORD = 1072243195 | 0;
    var THREE_PIO4_HIGH_WORD = 1073928572 | 0;
    var FIVE_PIO4_HIGH_WORD = 1074752122 | 0;
    var THREE_PIO2_HIGH_WORD = 1074977148 | 0;
    var SEVEN_PIO4_HIGH_WORD = 1075183036 | 0;
    var TWO_PI_HIGH_WORD = 1075388923 | 0;
    var NINE_PIO4_HIGH_WORD = 1075594811 | 0;
    var MEDIUM = 1094263291 | 0;
    var TX = [0, 0, 0];
    var TY = [0, 0];
    function rempio2(x, y) {
      var low;
      var e0;
      var hx;
      var ix;
      var nx;
      var i;
      var n;
      var z;
      hx = getHighWord(x) | 0;
      ix = hx & ABS_MASK | 0;
      if (ix <= PIO4_HIGH_WORD) {
        y[0] = x;
        y[1] = 0;
        return 0;
      }
      if (ix <= FIVE_PIO4_HIGH_WORD) {
        if ((ix & SIGNIFICAND_MASK) === PI_HIGH_WORD_SIGNIFICAND) {
          return rempio2Medium(x, ix, y);
        }
        if (ix <= THREE_PIO4_HIGH_WORD) {
          if (hx > 0) {
            z = x - PIO2_1;
            y[0] = z - PIO2_1T;
            y[1] = z - y[0] - PIO2_1T;
            return 1;
          }
          z = x + PIO2_1;
          y[0] = z + PIO2_1T;
          y[1] = z - y[0] + PIO2_1T;
          return -1;
        }
        if (hx > 0) {
          z = x - 2 * PIO2_1;
          y[0] = z - TWO_PIO2_1T;
          y[1] = z - y[0] - TWO_PIO2_1T;
          return 2;
        }
        z = x + 2 * PIO2_1;
        y[0] = z + TWO_PIO2_1T;
        y[1] = z - y[0] + TWO_PIO2_1T;
        return -2;
      }
      if (ix <= NINE_PIO4_HIGH_WORD) {
        if (ix <= SEVEN_PIO4_HIGH_WORD) {
          if (ix === THREE_PIO2_HIGH_WORD) {
            return rempio2Medium(x, ix, y);
          }
          if (hx > 0) {
            z = x - 3 * PIO2_1;
            y[0] = z - THREE_PIO2_1T;
            y[1] = z - y[0] - THREE_PIO2_1T;
            return 3;
          }
          z = x + 3 * PIO2_1;
          y[0] = z + THREE_PIO2_1T;
          y[1] = z - y[0] + THREE_PIO2_1T;
          return -3;
        }
        if (ix === TWO_PI_HIGH_WORD) {
          return rempio2Medium(x, ix, y);
        }
        if (hx > 0) {
          z = x - 4 * PIO2_1;
          y[0] = z - FOUR_PIO2_1T;
          y[1] = z - y[0] - FOUR_PIO2_1T;
          return 4;
        }
        z = x + 4 * PIO2_1;
        y[0] = z + FOUR_PIO2_1T;
        y[1] = z - y[0] + FOUR_PIO2_1T;
        return -4;
      }
      if (ix < MEDIUM) {
        return rempio2Medium(x, ix, y);
      }
      if (ix >= EXPONENT_MASK) {
        y[0] = NaN;
        y[1] = NaN;
        return 0;
      }
      low = getLowWord(x);
      e0 = (ix >> 20) - 1046;
      z = fromWords(ix - (e0 << 20 | 0), low);
      for (i = 0; i < 2; i++) {
        TX[i] = z | 0;
        z = (z - TX[i]) * TWO24;
      }
      TX[2] = z;
      nx = 3;
      while (TX[nx - 1] === ZERO) {
        nx -= 1;
      }
      n = rempio2Kernel(TX, TY, e0, nx, 1);
      if (hx < 0) {
        y[0] = -TY[0];
        y[1] = -TY[1];
        return -n;
      }
      y[0] = TY[0];
      y[1] = TY[1];
      return n;
    }
    module.exports = rempio2;
  }
});

// node_modules/@stdlib/math-base-special-rempio2/lib/index.js
var require_lib58 = __commonJS({
  "node_modules/@stdlib/math-base-special-rempio2/lib/index.js"(exports, module) {
    "use strict";
    var rempio2 = require_main43();
    module.exports = rempio2;
  }
});

// node_modules/@stdlib/math-base-special-sin/lib/main.js
var require_main44 = __commonJS({
  "node_modules/@stdlib/math-base-special-sin/lib/main.js"(exports, module) {
    "use strict";
    var HIGH_WORD_ABS_MASK = require_lib8();
    var HIGH_WORD_EXPONENT_MASK = require_lib9();
    var getHighWord = require_lib31();
    var kernelCos = require_lib32();
    var kernelSin = require_lib33();
    var rempio2 = require_lib58();
    var PIO4_HIGH_WORD = 1072243195 | 0;
    var SMALL_HIGH_WORD = 1045430272 | 0;
    var Y = [0, 0];
    function sin3(x) {
      var ix;
      var n;
      ix = getHighWord(x);
      ix &= HIGH_WORD_ABS_MASK;
      if (ix <= PIO4_HIGH_WORD) {
        if (ix < SMALL_HIGH_WORD) {
          return x;
        }
        return kernelSin(x, 0);
      }
      if (ix >= HIGH_WORD_EXPONENT_MASK) {
        return NaN;
      }
      n = rempio2(x, Y);
      switch (n & 3) {
        case 0:
          return kernelSin(Y[0], Y[1]);
        case 1:
          return kernelCos(Y[0], Y[1]);
        case 2:
          return -kernelSin(Y[0], Y[1]);
        default:
          return -kernelCos(Y[0], Y[1]);
      }
    }
    module.exports = sin3;
  }
});

// node_modules/@stdlib/math-base-special-sin/lib/index.js
var require_lib59 = __commonJS({
  "node_modules/@stdlib/math-base-special-sin/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main44();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-pi/lib/index.js
var require_lib60 = __commonJS({
  "node_modules/@stdlib/constants-float64-pi/lib/index.js"(exports, module) {
    "use strict";
    var PI2 = 3.141592653589793;
    module.exports = PI2;
  }
});

// node_modules/@stdlib/constants-float64-sqrt-two-pi/lib/index.js
var require_lib61 = __commonJS({
  "node_modules/@stdlib/constants-float64-sqrt-two-pi/lib/index.js"(exports, module) {
    "use strict";
    var SQRT_TWO_PI = 2.5066282746310007;
    module.exports = SQRT_TWO_PI;
  }
});

// node_modules/@stdlib/math-base-assert-is-even/lib/main.js
var require_main45 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-even/lib/main.js"(exports, module) {
    "use strict";
    var isInteger4 = require_lib3();
    function isEven(x) {
      return isInteger4(x / 2);
    }
    module.exports = isEven;
  }
});

// node_modules/@stdlib/math-base-assert-is-even/lib/index.js
var require_lib62 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-even/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main45();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-assert-is-odd/lib/main.js
var require_main46 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-odd/lib/main.js"(exports, module) {
    "use strict";
    var isEven = require_lib62();
    function isOdd2(x) {
      if (x > 0) {
        return isEven(x - 1);
      }
      return isEven(x + 1);
    }
    module.exports = isOdd2;
  }
});

// node_modules/@stdlib/math-base-assert-is-odd/lib/index.js
var require_lib63 = __commonJS({
  "node_modules/@stdlib/math-base-assert-is-odd/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main46();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-sqrt/lib/main.js
var require_main47 = __commonJS({
  "node_modules/@stdlib/math-base-special-sqrt/lib/main.js"(exports, module) {
    "use strict";
    var sqrt3 = Math.sqrt;
    module.exports = sqrt3;
  }
});

// node_modules/@stdlib/math-base-special-sqrt/lib/index.js
var require_lib64 = __commonJS({
  "node_modules/@stdlib/math-base-special-sqrt/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main47();
    module.exports = main;
  }
});

// node_modules/@stdlib/number-float64-base-set-low-word/lib/low.js
var require_low2 = __commonJS({
  "node_modules/@stdlib/number-float64-base-set-low-word/lib/low.js"(exports, module) {
    "use strict";
    var isLittleEndian = require_lib30();
    var LOW;
    if (isLittleEndian === true) {
      LOW = 0;
    } else {
      LOW = 1;
    }
    module.exports = LOW;
  }
});

// node_modules/@stdlib/number-float64-base-set-low-word/lib/main.js
var require_main48 = __commonJS({
  "node_modules/@stdlib/number-float64-base-set-low-word/lib/main.js"(exports, module) {
    "use strict";
    var Uint32Array2 = require_lib18();
    var Float64Array2 = require_lib21();
    var LOW = require_low2();
    var FLOAT64_VIEW = new Float64Array2(1);
    var UINT32_VIEW = new Uint32Array2(FLOAT64_VIEW.buffer);
    function setLowWord(x, low) {
      FLOAT64_VIEW[0] = x;
      UINT32_VIEW[LOW] = low >>> 0;
      return FLOAT64_VIEW[0];
    }
    module.exports = setLowWord;
  }
});

// node_modules/@stdlib/number-float64-base-set-low-word/lib/index.js
var require_lib65 = __commonJS({
  "node_modules/@stdlib/number-float64-base-set-low-word/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main48();
    module.exports = main;
  }
});

// node_modules/@stdlib/number-uint32-base-to-int32/lib/main.js
var require_main49 = __commonJS({
  "node_modules/@stdlib/number-uint32-base-to-int32/lib/main.js"(exports, module) {
    "use strict";
    function uint32ToInt32(x) {
      return x | 0;
    }
    module.exports = uint32ToInt32;
  }
});

// node_modules/@stdlib/number-uint32-base-to-int32/lib/index.js
var require_lib66 = __commonJS({
  "node_modules/@stdlib/number-uint32-base-to-int32/lib/index.js"(exports, module) {
    "use strict";
    var uint32ToInt32 = require_main49();
    module.exports = uint32ToInt32;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/x_is_zero.js
var require_x_is_zero = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/x_is_zero.js"(exports, module) {
    "use strict";
    var isOdd2 = require_lib63();
    var copysign = require_lib50();
    var NINF = require_lib5();
    var PINF = require_lib37();
    function pow3(x, y) {
      if (y === NINF) {
        return PINF;
      }
      if (y === PINF) {
        return 0;
      }
      if (y > 0) {
        if (isOdd2(y)) {
          return x;
        }
        return 0;
      }
      if (isOdd2(y)) {
        return copysign(PINF, x);
      }
      return PINF;
    }
    module.exports = pow3;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/y_is_huge.js
var require_y_is_huge = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/y_is_huge.js"(exports, module) {
    "use strict";
    var ABS_MASK = require_lib8();
    var getHighWord = require_lib31();
    var HIGH_MAX_NEAR_UNITY = 1072693247 | 0;
    var HUGE = 1e300;
    var TINY = 1e-300;
    function pow3(x, y) {
      var ahx;
      var hx;
      hx = getHighWord(x);
      ahx = hx & ABS_MASK;
      if (ahx <= HIGH_MAX_NEAR_UNITY) {
        if (y < 0) {
          return HUGE * HUGE;
        }
        return TINY * TINY;
      }
      if (y > 0) {
        return HUGE * HUGE;
      }
      return TINY * TINY;
    }
    module.exports = pow3;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/y_is_infinite.js
var require_y_is_infinite = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/y_is_infinite.js"(exports, module) {
    "use strict";
    var abs3 = require_lib7();
    var PINF = require_lib37();
    function pow3(x, y) {
      if (x === -1) {
        return (x - x) / (x - x);
      }
      if (x === 1) {
        return 1;
      }
      if (abs3(x) < 1 === (y === PINF)) {
        return 0;
      }
      return PINF;
    }
    module.exports = pow3;
  }
});

// node_modules/@stdlib/number-float64-base-set-high-word/lib/high.js
var require_high2 = __commonJS({
  "node_modules/@stdlib/number-float64-base-set-high-word/lib/high.js"(exports, module) {
    "use strict";
    var isLittleEndian = require_lib30();
    var HIGH;
    if (isLittleEndian === true) {
      HIGH = 1;
    } else {
      HIGH = 0;
    }
    module.exports = HIGH;
  }
});

// node_modules/@stdlib/number-float64-base-set-high-word/lib/main.js
var require_main50 = __commonJS({
  "node_modules/@stdlib/number-float64-base-set-high-word/lib/main.js"(exports, module) {
    "use strict";
    var Uint32Array2 = require_lib18();
    var Float64Array2 = require_lib21();
    var HIGH = require_high2();
    var FLOAT64_VIEW = new Float64Array2(1);
    var UINT32_VIEW = new Uint32Array2(FLOAT64_VIEW.buffer);
    function setHighWord(x, high) {
      FLOAT64_VIEW[0] = x;
      UINT32_VIEW[HIGH] = high >>> 0;
      return FLOAT64_VIEW[0];
    }
    module.exports = setHighWord;
  }
});

// node_modules/@stdlib/number-float64-base-set-high-word/lib/index.js
var require_lib67 = __commonJS({
  "node_modules/@stdlib/number-float64-base-set-high-word/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main50();
    module.exports = main;
  }
});

// node_modules/@stdlib/constants-float64-num-high-word-significand-bits/lib/index.js
var require_lib68 = __commonJS({
  "node_modules/@stdlib/constants-float64-num-high-word-significand-bits/lib/index.js"(exports, module) {
    "use strict";
    var FLOAT64_NUM_HIGH_WORD_SIGNIFICAND_BITS = 20 | 0;
    module.exports = FLOAT64_NUM_HIGH_WORD_SIGNIFICAND_BITS;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/polyval_l.js
var require_polyval_l = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/polyval_l.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return 0.5999999999999946;
      }
      return 0.5999999999999946 + x * (0.4285714285785502 + x * (0.33333332981837743 + x * (0.272728123808534 + x * (0.23066074577556175 + x * 0.20697501780033842))));
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/log2ax.js
var require_log2ax = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/log2ax.js"(exports, module) {
    "use strict";
    var getHighWord = require_lib31();
    var setLowWord = require_lib65();
    var setHighWord = require_lib67();
    var BIAS = require_lib38();
    var HIGH_NUM_SIGNIFICAND_BITS = require_lib68();
    var polyvalL = require_polyval_l();
    var HIGH_SIGNIFICAND_MASK = 1048575 | 0;
    var HIGH_MIN_NORMAL_EXP = 1048576 | 0;
    var HIGH_BIASED_EXP_0 = 1072693248 | 0;
    var HIGH_BIASED_EXP_NEG_512 = 536870912 | 0;
    var HIGH_SIGNIFICAND_HALF = 524288 | 0;
    var TWO53 = 9007199254740992;
    var CP = 0.9617966939259756;
    var CP_HI = 0.9617967009544373;
    var CP_LO = -7028461650952758e-24;
    var BP = [
      1,
      1.5
    ];
    var DP_HI = [
      0,
      0.5849624872207642
      // 0x3FE2B803, 0x40000000
    ];
    var DP_LO = [
      0,
      1350039202129749e-23
      // 0x3E4CFDEB, 0x43CFD006
    ];
    function log2ax(out, ax, ahx) {
      var tmp;
      var ss;
      var s2;
      var hs;
      var ls;
      var ht;
      var lt;
      var bp;
      var dp;
      var hp;
      var lp;
      var hz;
      var lz;
      var t1;
      var t2;
      var t;
      var r;
      var u;
      var v;
      var n;
      var j;
      var k;
      n = 0 | 0;
      if (ahx < HIGH_MIN_NORMAL_EXP) {
        ax *= TWO53;
        n -= 53 | 0;
        ahx = getHighWord(ax);
      }
      n += (ahx >> HIGH_NUM_SIGNIFICAND_BITS) - BIAS | 0;
      j = ahx & HIGH_SIGNIFICAND_MASK | 0;
      ahx = j | HIGH_BIASED_EXP_0 | 0;
      if (j <= 235662) {
        k = 0;
      } else if (j < 767610) {
        k = 1;
      } else {
        k = 0;
        n += 1 | 0;
        ahx -= HIGH_MIN_NORMAL_EXP;
      }
      ax = setHighWord(ax, ahx);
      bp = BP[k];
      u = ax - bp;
      v = 1 / (ax + bp);
      ss = u * v;
      hs = setLowWord(ss, 0);
      tmp = (ahx >> 1 | HIGH_BIASED_EXP_NEG_512) + HIGH_SIGNIFICAND_HALF;
      tmp += k << 18;
      ht = setHighWord(0, tmp);
      lt = ax - (ht - bp);
      ls = v * (u - hs * ht - hs * lt);
      s2 = ss * ss;
      r = s2 * s2 * polyvalL(s2);
      r += ls * (hs + ss);
      s2 = hs * hs;
      ht = 3 + s2 + r;
      ht = setLowWord(ht, 0);
      lt = r - (ht - 3 - s2);
      u = hs * ht;
      v = ls * ht + lt * ss;
      hp = u + v;
      hp = setLowWord(hp, 0);
      lp = v - (hp - u);
      hz = CP_HI * hp;
      lz = CP_LO * hp + lp * CP + DP_LO[k];
      dp = DP_HI[k];
      t = n;
      t1 = hz + lz + dp + t;
      t1 = setLowWord(t1, 0);
      t2 = lz - (t1 - t - dp - hz);
      out[0] = t1;
      out[1] = t2;
      return out;
    }
    module.exports = log2ax;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/polyval_w.js
var require_polyval_w = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/polyval_w.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return 0.5;
      }
      return 0.5 + x * (-0.3333333333333333 + x * 0.25);
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/logx.js
var require_logx = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/logx.js"(exports, module) {
    "use strict";
    var setLowWord = require_lib65();
    var polyvalW = require_polyval_w();
    var INV_LN2 = 1.4426950408889634;
    var INV_LN2_HI = 1.4426950216293335;
    var INV_LN2_LO = 19259629911266175e-24;
    function logx(out, ax) {
      var t2;
      var t1;
      var t;
      var w;
      var u;
      var v;
      t = ax - 1;
      w = t * t * polyvalW(t);
      u = INV_LN2_HI * t;
      v = t * INV_LN2_LO - w * INV_LN2;
      t1 = u + v;
      t1 = setLowWord(t1, 0);
      t2 = v - (t1 - u);
      out[0] = t1;
      out[1] = t2;
      return out;
    }
    module.exports = logx;
  }
});

// node_modules/@stdlib/constants-float64-ln-two/lib/index.js
var require_lib69 = __commonJS({
  "node_modules/@stdlib/constants-float64-ln-two/lib/index.js"(exports, module) {
    "use strict";
    var LN22 = 0.6931471805599453;
    module.exports = LN22;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/polyval_p.js
var require_polyval_p = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/polyval_p.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return 0.16666666666666602;
      }
      return 0.16666666666666602 + x * (-0.0027777777777015593 + x * (6613756321437934e-20 + x * (-16533902205465252e-22 + x * 41381367970572385e-24)));
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/pow2.js
var require_pow2 = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/pow2.js"(exports, module) {
    "use strict";
    var getHighWord = require_lib31();
    var setHighWord = require_lib67();
    var setLowWord = require_lib65();
    var uint32ToInt32 = require_lib66();
    var ldexp = require_lib54();
    var LN22 = require_lib69();
    var BIAS = require_lib38();
    var ABS_MASK = require_lib8();
    var HIGH_SIGNIFICAND_MASK = require_lib34();
    var HIGH_NUM_SIGNIFICAND_BITS = require_lib68();
    var polyvalP = require_polyval_p();
    var HIGH_MIN_NORMAL_EXP = 1048576 | 0;
    var HIGH_BIASED_EXP_NEG_1 = 1071644672 | 0;
    var LN2_HI = 0.6931471824645996;
    var LN2_LO = -1904654299957768e-24;
    function pow22(j, hp, lp) {
      var tmp;
      var t1;
      var t;
      var r;
      var u;
      var v;
      var w;
      var z;
      var n;
      var i;
      var k;
      i = j & ABS_MASK | 0;
      k = (i >> HIGH_NUM_SIGNIFICAND_BITS) - BIAS | 0;
      n = 0;
      if (i > HIGH_BIASED_EXP_NEG_1) {
        n = j + (HIGH_MIN_NORMAL_EXP >> k + 1) >>> 0;
        k = ((n & ABS_MASK) >> HIGH_NUM_SIGNIFICAND_BITS) - BIAS | 0;
        tmp = (n & ~(HIGH_SIGNIFICAND_MASK >> k)) >>> 0;
        t = setHighWord(0, tmp);
        n = (n & HIGH_SIGNIFICAND_MASK | HIGH_MIN_NORMAL_EXP) >> HIGH_NUM_SIGNIFICAND_BITS - k >>> 0;
        if (j < 0) {
          n = -n;
        }
        hp -= t;
      }
      t = lp + hp;
      t = setLowWord(t, 0);
      u = t * LN2_HI;
      v = (lp - (t - hp)) * LN22 + t * LN2_LO;
      z = u + v;
      w = v - (z - u);
      t = z * z;
      t1 = z - t * polyvalP(t);
      r = z * t1 / (t1 - 2) - (w + z * w);
      z = 1 - (r - z);
      j = getHighWord(z);
      j = uint32ToInt32(j);
      j += n << HIGH_NUM_SIGNIFICAND_BITS >>> 0;
      if (j >> HIGH_NUM_SIGNIFICAND_BITS <= 0) {
        z = ldexp(z, n);
      } else {
        z = setHighWord(z, j);
      }
      return z;
    }
    module.exports = pow22;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/main.js
var require_main51 = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/main.js"(exports, module) {
    "use strict";
    var isnan = require_lib();
    var isOdd2 = require_lib63();
    var isInfinite = require_lib42();
    var isInteger4 = require_lib3();
    var sqrt3 = require_lib64();
    var abs3 = require_lib7();
    var toWords = require_lib49();
    var setLowWord = require_lib65();
    var uint32ToInt32 = require_lib66();
    var NINF = require_lib5();
    var PINF = require_lib37();
    var ABS_MASK = require_lib8();
    var xIsZero = require_x_is_zero();
    var yIsHuge = require_y_is_huge();
    var yIsInfinite = require_y_is_infinite();
    var log2ax = require_log2ax();
    var logx = require_logx();
    var pow22 = require_pow2();
    var HIGH_MAX_NEAR_UNITY = 1072693247 | 0;
    var HIGH_BIASED_EXP_31 = 1105199104 | 0;
    var HIGH_BIASED_EXP_64 = 1139802112 | 0;
    var HIGH_BIASED_EXP_10 = 1083179008 | 0;
    var HIGH_BIASED_EXP_0 = 1072693248 | 0;
    var HIGH_1075 = 1083231232 | 0;
    var HIGH_NEG_1075 = 3230714880 >>> 0;
    var HIGH_NUM_NONSIGN_BITS = 31 | 0;
    var HUGE = 1e300;
    var TINY = 1e-300;
    var OVT = 8008566259537294e-32;
    var WORDS = [0 | 0, 0 | 0];
    var LOG_WORKSPACE = [0, 0];
    function pow3(x, y) {
      var ahx;
      var ahy;
      var ax;
      var hx;
      var lx;
      var hy;
      var ly;
      var sx;
      var sy;
      var y1;
      var hp;
      var lp;
      var t;
      var z;
      var j;
      var i;
      if (isnan(x) || isnan(y)) {
        return NaN;
      }
      toWords.assign(y, WORDS, 1, 0);
      hy = WORDS[0];
      ly = WORDS[1];
      if (ly === 0) {
        if (y === 0) {
          return 1;
        }
        if (y === 1) {
          return x;
        }
        if (y === -1) {
          return 1 / x;
        }
        if (y === 0.5) {
          return sqrt3(x);
        }
        if (y === -0.5) {
          return 1 / sqrt3(x);
        }
        if (y === 2) {
          return x * x;
        }
        if (y === 3) {
          return x * x * x;
        }
        if (y === 4) {
          x *= x;
          return x * x;
        }
        if (isInfinite(y)) {
          return yIsInfinite(x, y);
        }
      }
      toWords.assign(x, WORDS, 1, 0);
      hx = WORDS[0];
      lx = WORDS[1];
      if (lx === 0) {
        if (hx === 0) {
          return xIsZero(x, y);
        }
        if (x === 1) {
          return 1;
        }
        if (x === -1 && isOdd2(y)) {
          return -1;
        }
        if (isInfinite(x)) {
          if (x === NINF) {
            return pow3(-0, -y);
          }
          if (y < 0) {
            return 0;
          }
          return PINF;
        }
      }
      if (x < 0 && isInteger4(y) === false) {
        return (x - x) / (x - x);
      }
      ax = abs3(x);
      ahx = hx & ABS_MASK | 0;
      ahy = hy & ABS_MASK | 0;
      sx = hx >>> HIGH_NUM_NONSIGN_BITS | 0;
      sy = hy >>> HIGH_NUM_NONSIGN_BITS | 0;
      if (sx && isOdd2(y)) {
        sx = -1;
      } else {
        sx = 1;
      }
      if (ahy > HIGH_BIASED_EXP_31) {
        if (ahy > HIGH_BIASED_EXP_64) {
          return yIsHuge(x, y);
        }
        if (ahx < HIGH_MAX_NEAR_UNITY) {
          if (sy === 1) {
            return sx * HUGE * HUGE;
          }
          return sx * TINY * TINY;
        }
        if (ahx > HIGH_BIASED_EXP_0) {
          if (sy === 0) {
            return sx * HUGE * HUGE;
          }
          return sx * TINY * TINY;
        }
        t = logx(LOG_WORKSPACE, ax);
      } else {
        t = log2ax(LOG_WORKSPACE, ax, ahx);
      }
      y1 = setLowWord(y, 0);
      lp = (y - y1) * t[0] + y * t[1];
      hp = y1 * t[0];
      z = lp + hp;
      toWords.assign(z, WORDS, 1, 0);
      j = uint32ToInt32(WORDS[0]);
      i = uint32ToInt32(WORDS[1]);
      if (j >= HIGH_BIASED_EXP_10) {
        if ((j - HIGH_BIASED_EXP_10 | i) !== 0) {
          return sx * HUGE * HUGE;
        }
        if (lp + OVT > z - hp) {
          return sx * HUGE * HUGE;
        }
      } else if ((j & ABS_MASK) >= HIGH_1075) {
        if ((j - HIGH_NEG_1075 | i) !== 0) {
          return sx * TINY * TINY;
        }
        if (lp <= z - hp) {
          return sx * TINY * TINY;
        }
      }
      z = pow22(j, hp, lp);
      return sx * z;
    }
    module.exports = pow3;
  }
});

// node_modules/@stdlib/math-base-special-pow/lib/index.js
var require_lib70 = __commonJS({
  "node_modules/@stdlib/math-base-special-pow/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main51();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-ceil/lib/main.js
var require_main52 = __commonJS({
  "node_modules/@stdlib/math-base-special-ceil/lib/main.js"(exports, module) {
    "use strict";
    var ceil3 = Math.ceil;
    module.exports = ceil3;
  }
});

// node_modules/@stdlib/math-base-special-ceil/lib/index.js
var require_lib71 = __commonJS({
  "node_modules/@stdlib/math-base-special-ceil/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main52();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-trunc/lib/main.js
var require_main53 = __commonJS({
  "node_modules/@stdlib/math-base-special-trunc/lib/main.js"(exports, module) {
    "use strict";
    var floor3 = require_lib2();
    var ceil3 = require_lib71();
    function trunc2(x) {
      if (x < 0) {
        return ceil3(x);
      }
      return floor3(x);
    }
    module.exports = trunc2;
  }
});

// node_modules/@stdlib/math-base-special-trunc/lib/index.js
var require_lib72 = __commonJS({
  "node_modules/@stdlib/math-base-special-trunc/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main53();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-exp/lib/polyval_p.js
var require_polyval_p2 = __commonJS({
  "node_modules/@stdlib/math-base-special-exp/lib/polyval_p.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return 0.16666666666666602;
      }
      return 0.16666666666666602 + x * (-0.0027777777777015593 + x * (6613756321437934e-20 + x * (-16533902205465252e-22 + x * 41381367970572385e-24)));
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-exp/lib/expmulti.js
var require_expmulti = __commonJS({
  "node_modules/@stdlib/math-base-special-exp/lib/expmulti.js"(exports, module) {
    "use strict";
    var ldexp = require_lib54();
    var polyvalP = require_polyval_p2();
    function expmulti(hi, lo, k) {
      var r;
      var t;
      var c;
      var y;
      r = hi - lo;
      t = r * r;
      c = r - t * polyvalP(t);
      y = 1 - (lo - r * c / (2 - c) - hi);
      return ldexp(y, k);
    }
    module.exports = expmulti;
  }
});

// node_modules/@stdlib/math-base-special-exp/lib/main.js
var require_main54 = __commonJS({
  "node_modules/@stdlib/math-base-special-exp/lib/main.js"(exports, module) {
    "use strict";
    var isnan = require_lib();
    var trunc2 = require_lib72();
    var NINF = require_lib5();
    var PINF = require_lib37();
    var expmulti = require_expmulti();
    var LN2_HI = 0.6931471803691238;
    var LN2_LO = 19082149292705877e-26;
    var LOG2_E = 1.4426950408889634;
    var OVERFLOW = 709.782712893384;
    var UNDERFLOW = -745.1332191019411;
    var NEARZERO = 1 / (1 << 28);
    var NEG_NEARZERO = -NEARZERO;
    function exp3(x) {
      var hi;
      var lo;
      var k;
      if (isnan(x) || x === PINF) {
        return x;
      }
      if (x === NINF) {
        return 0;
      }
      if (x > OVERFLOW) {
        return PINF;
      }
      if (x < UNDERFLOW) {
        return 0;
      }
      if (x > NEG_NEARZERO && x < NEARZERO) {
        return 1 + x;
      }
      if (x < 0) {
        k = trunc2(LOG2_E * x - 0.5);
      } else {
        k = trunc2(LOG2_E * x + 0.5);
      }
      hi = x - k * LN2_HI;
      lo = k * LN2_LO;
      return expmulti(hi, lo, k);
    }
    module.exports = exp3;
  }
});

// node_modules/@stdlib/math-base-special-exp/lib/index.js
var require_lib73 = __commonJS({
  "node_modules/@stdlib/math-base-special-exp/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main54();
    module.exports = main;
  }
});

// node_modules/@stdlib/math-base-special-gamma/lib/polyval_s.js
var require_polyval_s = __commonJS({
  "node_modules/@stdlib/math-base-special-gamma/lib/polyval_s.js"(exports, module) {
    "use strict";
    function evalpoly(x) {
      if (x === 0) {
        return 0.08333333333334822;
      }
      return 0.08333333333334822 + x * (0.0034722222160545866 + x * (-0.0026813261780578124 + x * (-22954996161337813e-20 + x * 7873113957930937e-19)));
    }
    module.exports = evalpoly;
  }
});

// node_modules/@stdlib/math-base-special-gamma/lib/stirling_approximation.js
var require_stirling_approximation = __commonJS({
  "node_modules/@stdlib/math-base-special-gamma/lib/stirling_approximation.js"(exports, module) {
    "use strict";
    var SQRT_TWO_PI = require_lib61();
    var pow3 = require_lib70();
    var exp3 = require_lib73();
    var polyval = require_polyval_s();
    var MAX_STIRLING = 143.01608;
    function gamma3(x) {
      var w;
      var y;
      var v;
      w = 1 / x;
      w = 1 + w * polyval(w);
      y = exp3(x);
      if (x > MAX_STIRLING) {
        v = pow3(x, 0.5 * x - 0.25);
        y = v * (v / y);
      } else {
        y = pow3(x, x - 0.5) / y;
      }
      return SQRT_TWO_PI * y * w;
    }
    module.exports = gamma3;
  }
});

// node_modules/@stdlib/constants-float64-eulergamma/lib/index.js
var require_lib74 = __commonJS({
  "node_modules/@stdlib/constants-float64-eulergamma/lib/index.js"(exports, module) {
    "use strict";
    var EULERGAMMA = 0.5772156649015329;
    module.exports = EULERGAMMA;
  }
});

// node_modules/@stdlib/math-base-special-gamma/lib/small_approximation.js
var require_small_approximation = __commonJS({
  "node_modules/@stdlib/math-base-special-gamma/lib/small_approximation.js"(exports, module) {
    "use strict";
    var EULER = require_lib74();
    function gamma3(x, z) {
      return z / ((1 + EULER * x) * x);
    }
    module.exports = gamma3;
  }
});

// node_modules/@stdlib/math-base-special-gamma/lib/rational_pq.js
var require_rational_pq = __commonJS({
  "node_modules/@stdlib/math-base-special-gamma/lib/rational_pq.js"(exports, module) {
    "use strict";
    function evalrational(x) {
      var ax;
      var s1;
      var s2;
      if (x === 0) {
        return 1;
      }
      if (x < 0) {
        ax = -x;
      } else {
        ax = x;
      }
      if (ax <= 1) {
        s1 = 1 + x * (0.4942148268014971 + x * (0.20744822764843598 + x * (0.04763678004571372 + x * (0.010421379756176158 + x * (0.0011913514700658638 + x * (16011952247675185e-20 + x * 0))))));
        s2 = 1 + x * (0.0714304917030273 + x * (-0.23459179571824335 + x * (0.035823639860549865 + x * (0.011813978522206043 + x * (-0.004456419138517973 + x * (5396055804933034e-19 + x * -23158187332412014e-21))))));
      } else {
        x = 1 / x;
        s1 = 0 + x * (16011952247675185e-20 + x * (0.0011913514700658638 + x * (0.010421379756176158 + x * (0.04763678004571372 + x * (0.20744822764843598 + x * (0.4942148268014971 + x * 1))))));
        s2 = -23158187332412014e-21 + x * (5396055804933034e-19 + x * (-0.004456419138517973 + x * (0.011813978522206043 + x * (0.035823639860549865 + x * (-0.23459179571824335 + x * (0.0714304917030273 + x * 1))))));
      }
      return s1 / s2;
    }
    module.exports = evalrational;
  }
});

// node_modules/@stdlib/math-base-special-gamma/lib/main.js
var require_main55 = __commonJS({
  "node_modules/@stdlib/math-base-special-gamma/lib/main.js"(exports, module) {
    "use strict";
    var isnan = require_lib();
    var isInteger4 = require_lib3();
    var isNegativeZero = require_lib6();
    var abs3 = require_lib7();
    var floor3 = require_lib2();
    var sin3 = require_lib59();
    var PINF = require_lib37();
    var NINF = require_lib5();
    var PI2 = require_lib60();
    var stirlingApprox = require_stirling_approximation();
    var smallApprox = require_small_approximation();
    var rateval = require_rational_pq();
    function gamma3(x) {
      var sign4;
      var q;
      var p;
      var z;
      if (isInteger4(x) && x < 0 || x === NINF || isnan(x)) {
        return NaN;
      }
      if (x === 0) {
        if (isNegativeZero(x)) {
          return NINF;
        }
        return PINF;
      }
      if (x > 171.61447887182297) {
        return PINF;
      }
      if (x < -170.5674972726612) {
        return 0;
      }
      q = abs3(x);
      if (q > 33) {
        if (x >= 0) {
          return stirlingApprox(x);
        }
        p = floor3(q);
        if ((p & 1) === 0) {
          sign4 = -1;
        } else {
          sign4 = 1;
        }
        z = q - p;
        if (z > 0.5) {
          p += 1;
          z = q - p;
        }
        z = q * sin3(PI2 * z);
        return sign4 * PI2 / (abs3(z) * stirlingApprox(q));
      }
      z = 1;
      while (x >= 3) {
        x -= 1;
        z *= x;
      }
      while (x < 0) {
        if (x > -1e-9) {
          return smallApprox(x, z);
        }
        z /= x;
        x += 1;
      }
      while (x < 2) {
        if (x < 1e-9) {
          return smallApprox(x, z);
        }
        z /= x;
        x += 1;
      }
      if (x === 2) {
        return z;
      }
      x -= 2;
      return z * rateval(x);
    }
    module.exports = gamma3;
  }
});

// node_modules/@stdlib/math-base-special-gamma/lib/index.js
var require_lib75 = __commonJS({
  "node_modules/@stdlib/math-base-special-gamma/lib/index.js"(exports, module) {
    "use strict";
    var main = require_main55();
    module.exports = main;
  }
});

// node_modules/@babel/runtime/helpers/extends.js
var require_extends = __commonJS({
  "node_modules/@babel/runtime/helpers/extends.js"(exports, module) {
    function _extends5() {
      return module.exports = _extends5 = Object.assign ? Object.assign.bind() : function(n) {
        for (var e3 = 1; e3 < arguments.length; e3++) {
          var t = arguments[e3];
          for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
        }
        return n;
      }, module.exports.__esModule = true, module.exports["default"] = module.exports, _extends5.apply(null, arguments);
    }
    module.exports = _extends5, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
});

// node_modules/typed-function/lib/umd/typed-function.js
var require_typed_function = __commonJS({
  "node_modules/typed-function/lib/umd/typed-function.js"(exports, module) {
    (function(global, factory2) {
      typeof exports === "object" && typeof module !== "undefined" ? module.exports = factory2() : typeof define === "function" && define.amd ? define(factory2) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, global.typed = factory2());
    })(exports, (function() {
      "use strict";
      function ok() {
        return true;
      }
      function notOk() {
        return false;
      }
      function undef() {
        return void 0;
      }
      const NOT_TYPED_FUNCTION = "Argument is not a typed-function.";
      function create() {
        function isPlainObject2(x) {
          return typeof x === "object" && x !== null && x.constructor === Object;
        }
        const _types = [{
          name: "number",
          test: function(x) {
            return typeof x === "number";
          }
        }, {
          name: "string",
          test: function(x) {
            return typeof x === "string";
          }
        }, {
          name: "boolean",
          test: function(x) {
            return typeof x === "boolean";
          }
        }, {
          name: "Function",
          test: function(x) {
            return typeof x === "function";
          }
        }, {
          name: "Array",
          test: Array.isArray
        }, {
          name: "Date",
          test: function(x) {
            return x instanceof Date;
          }
        }, {
          name: "RegExp",
          test: function(x) {
            return x instanceof RegExp;
          }
        }, {
          name: "Object",
          test: isPlainObject2
        }, {
          name: "null",
          test: function(x) {
            return x === null;
          }
        }, {
          name: "undefined",
          test: function(x) {
            return x === void 0;
          }
        }];
        const anyType = {
          name: "any",
          test: ok,
          isAny: true
        };
        let typeMap;
        let typeList;
        let nConversions = 0;
        let typed3 = {
          createCount: 0
        };
        function findType(typeName) {
          const type = typeMap.get(typeName);
          if (type) {
            return type;
          }
          let message = 'Unknown type "' + typeName + '"';
          const name114 = typeName.toLowerCase();
          let otherName;
          for (otherName of typeList) {
            if (otherName.toLowerCase() === name114) {
              message += '. Did you mean "' + otherName + '" ?';
              break;
            }
          }
          throw new TypeError(message);
        }
        function addTypes(types) {
          let beforeSpec = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "any";
          const beforeIndex = beforeSpec ? findType(beforeSpec).index : typeList.length;
          const newTypes = [];
          for (let i = 0; i < types.length; ++i) {
            if (!types[i] || typeof types[i].name !== "string" || typeof types[i].test !== "function") {
              throw new TypeError("Object with properties {name: string, test: function} expected");
            }
            const typeName = types[i].name;
            if (typeMap.has(typeName)) {
              throw new TypeError('Duplicate type name "' + typeName + '"');
            }
            newTypes.push(typeName);
            typeMap.set(typeName, {
              name: typeName,
              test: types[i].test,
              isAny: types[i].isAny,
              index: beforeIndex + i,
              conversionsTo: []
              // Newly added type can't have any conversions to it
            });
          }
          const affectedTypes = typeList.slice(beforeIndex);
          typeList = typeList.slice(0, beforeIndex).concat(newTypes).concat(affectedTypes);
          for (let i = beforeIndex + newTypes.length; i < typeList.length; ++i) {
            typeMap.get(typeList[i]).index = i;
          }
        }
        function clear() {
          typeMap = /* @__PURE__ */ new Map();
          typeList = [];
          nConversions = 0;
          addTypes([anyType], false);
        }
        clear();
        addTypes(_types);
        function clearConversions() {
          let typeName;
          for (typeName of typeList) {
            typeMap.get(typeName).conversionsTo = [];
          }
          nConversions = 0;
        }
        function findTypeNames(value) {
          const matches = typeList.filter((name114) => {
            const type = typeMap.get(name114);
            return !type.isAny && type.test(value);
          });
          if (matches.length) {
            return matches;
          }
          return ["any"];
        }
        function isTypedFunction(entity) {
          return entity && typeof entity === "function" && "_typedFunctionData" in entity;
        }
        function findSignature(fn, signature, options) {
          if (!isTypedFunction(fn)) {
            throw new TypeError(NOT_TYPED_FUNCTION);
          }
          const exact = options && options.exact;
          const stringSignature = Array.isArray(signature) ? signature.join(",") : signature;
          const params = parseSignature(stringSignature);
          const canonicalSignature = stringifyParams(params);
          if (!exact || canonicalSignature in fn.signatures) {
            const match = fn._typedFunctionData.signatureMap.get(canonicalSignature);
            if (match) {
              return match;
            }
          }
          const nParams = params.length;
          let remainingSignatures;
          if (exact) {
            remainingSignatures = [];
            let name114;
            for (name114 in fn.signatures) {
              remainingSignatures.push(fn._typedFunctionData.signatureMap.get(name114));
            }
          } else {
            remainingSignatures = fn._typedFunctionData.signatures;
          }
          for (let i = 0; i < nParams; ++i) {
            const want = params[i];
            const filteredSignatures = [];
            let possibility;
            for (possibility of remainingSignatures) {
              const have = getParamAtIndex(possibility.params, i);
              if (!have || want.restParam && !have.restParam) {
                continue;
              }
              if (!have.hasAny) {
                const haveTypes = paramTypeSet(have);
                if (want.types.some((wtype) => !haveTypes.has(wtype.name))) {
                  continue;
                }
              }
              filteredSignatures.push(possibility);
            }
            remainingSignatures = filteredSignatures;
            if (remainingSignatures.length === 0) break;
          }
          let candidate;
          for (candidate of remainingSignatures) {
            if (candidate.params.length <= nParams) {
              return candidate;
            }
          }
          throw new TypeError("Signature not found (signature: " + (fn.name || "unnamed") + "(" + stringifyParams(params, ", ") + "))");
        }
        function find(fn, signature, options) {
          return findSignature(fn, signature, options).implementation;
        }
        function convert(value, typeName) {
          const type = findType(typeName);
          if (type.test(value)) {
            return value;
          }
          const conversions = type.conversionsTo;
          if (conversions.length === 0) {
            throw new Error("There are no conversions to " + typeName + " defined.");
          }
          for (let i = 0; i < conversions.length; i++) {
            const fromType = findType(conversions[i].from);
            if (fromType.test(value)) {
              return conversions[i].convert(value);
            }
          }
          throw new Error("Cannot convert " + value + " to " + typeName);
        }
        function stringifyParams(params) {
          let separator = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ",";
          return params.map((p) => p.name).join(separator);
        }
        function parseParam(param) {
          const restParam = param.indexOf("...") === 0;
          const types = !restParam ? param : param.length > 3 ? param.slice(3) : "any";
          const typeDefs = types.split("|").map((s) => findType(s.trim()));
          let hasAny = false;
          let paramName = restParam ? "..." : "";
          const exactTypes = typeDefs.map(function(type) {
            hasAny = type.isAny || hasAny;
            paramName += type.name + "|";
            return {
              name: type.name,
              typeIndex: type.index,
              test: type.test,
              isAny: type.isAny,
              conversion: null,
              conversionIndex: -1
            };
          });
          return {
            types: exactTypes,
            name: paramName.slice(0, -1),
            // remove trailing '|' from above
            hasAny,
            hasConversion: false,
            restParam
          };
        }
        function expandParam(param) {
          const typeNames = param.types.map((t) => t.name);
          const matchingConversions = availableConversions(typeNames);
          let hasAny = param.hasAny;
          let newName = param.name;
          const convertibleTypes = matchingConversions.map(function(conversion) {
            const type = findType(conversion.from);
            hasAny = type.isAny || hasAny;
            newName += "|" + conversion.from;
            return {
              name: conversion.from,
              typeIndex: type.index,
              test: type.test,
              isAny: type.isAny,
              conversion,
              conversionIndex: conversion.index
            };
          });
          return {
            types: param.types.concat(convertibleTypes),
            name: newName,
            hasAny,
            hasConversion: convertibleTypes.length > 0,
            restParam: param.restParam
          };
        }
        function paramTypeSet(param) {
          if (!param.typeSet) {
            param.typeSet = /* @__PURE__ */ new Set();
            param.types.forEach((type) => param.typeSet.add(type.name));
          }
          return param.typeSet;
        }
        function parseSignature(rawSignature) {
          const params = [];
          if (typeof rawSignature !== "string") {
            throw new TypeError("Signatures must be strings");
          }
          const signature = rawSignature.trim();
          if (signature === "") {
            return params;
          }
          const rawParams = signature.split(",");
          for (let i = 0; i < rawParams.length; ++i) {
            const parsedParam = parseParam(rawParams[i].trim());
            if (parsedParam.restParam && i !== rawParams.length - 1) {
              throw new SyntaxError('Unexpected rest parameter "' + rawParams[i] + '": only allowed for the last parameter');
            }
            if (parsedParam.types.length === 0) {
              return null;
            }
            params.push(parsedParam);
          }
          return params;
        }
        function hasRestParam(params) {
          const param = last(params);
          return param ? param.restParam : false;
        }
        function compileTest(param) {
          if (!param || param.types.length === 0) {
            return ok;
          } else if (param.types.length === 1) {
            return findType(param.types[0].name).test;
          } else if (param.types.length === 2) {
            const test0 = findType(param.types[0].name).test;
            const test1 = findType(param.types[1].name).test;
            return function or2(x) {
              return test0(x) || test1(x);
            };
          } else {
            const tests = param.types.map(function(type) {
              return findType(type.name).test;
            });
            return function or2(x) {
              for (let i = 0; i < tests.length; i++) {
                if (tests[i](x)) {
                  return true;
                }
              }
              return false;
            };
          }
        }
        function compileTests(params) {
          let tests, test0, test1;
          if (hasRestParam(params)) {
            tests = initial(params).map(compileTest);
            const varIndex = tests.length;
            const lastTest = compileTest(last(params));
            const testRestParam = function(args) {
              for (let i = varIndex; i < args.length; i++) {
                if (!lastTest(args[i])) {
                  return false;
                }
              }
              return true;
            };
            return function testArgs(args) {
              for (let i = 0; i < tests.length; i++) {
                if (!tests[i](args[i])) {
                  return false;
                }
              }
              return testRestParam(args) && args.length >= varIndex + 1;
            };
          } else {
            if (params.length === 0) {
              return function testArgs(args) {
                return args.length === 0;
              };
            } else if (params.length === 1) {
              test0 = compileTest(params[0]);
              return function testArgs(args) {
                return test0(args[0]) && args.length === 1;
              };
            } else if (params.length === 2) {
              test0 = compileTest(params[0]);
              test1 = compileTest(params[1]);
              return function testArgs(args) {
                return test0(args[0]) && test1(args[1]) && args.length === 2;
              };
            } else {
              tests = params.map(compileTest);
              return function testArgs(args) {
                for (let i = 0; i < tests.length; i++) {
                  if (!tests[i](args[i])) {
                    return false;
                  }
                }
                return args.length === tests.length;
              };
            }
          }
        }
        function getParamAtIndex(params, index2) {
          return index2 < params.length ? params[index2] : hasRestParam(params) ? last(params) : null;
        }
        function getTypeSetAtIndex(params, index2) {
          const param = getParamAtIndex(params, index2);
          if (!param) {
            return /* @__PURE__ */ new Set();
          }
          return paramTypeSet(param);
        }
        function isExactType(type) {
          return type.conversion === null || type.conversion === void 0;
        }
        function mergeExpectedParams(signatures, index2) {
          const typeSet = /* @__PURE__ */ new Set();
          signatures.forEach((signature) => {
            const paramSet = getTypeSetAtIndex(signature.params, index2);
            let name114;
            for (name114 of paramSet) {
              typeSet.add(name114);
            }
          });
          return typeSet.has("any") ? ["any"] : Array.from(typeSet);
        }
        function createError(name114, args, signatures) {
          let err, expected;
          const _name = name114 || "unnamed";
          let matchingSignatures = signatures;
          let index2;
          for (index2 = 0; index2 < args.length; index2++) {
            const nextMatchingDefs = [];
            matchingSignatures.forEach((signature) => {
              const param = getParamAtIndex(signature.params, index2);
              const test = compileTest(param);
              if ((index2 < signature.params.length || hasRestParam(signature.params)) && test(args[index2])) {
                nextMatchingDefs.push(signature);
              }
            });
            if (nextMatchingDefs.length === 0) {
              expected = mergeExpectedParams(matchingSignatures, index2);
              if (expected.length > 0) {
                const actualTypes = findTypeNames(args[index2]);
                err = new TypeError("Unexpected type of argument in function " + _name + " (expected: " + expected.join(" or ") + ", actual: " + actualTypes.join(" | ") + ", index: " + index2 + ")");
                err.data = {
                  category: "wrongType",
                  fn: _name,
                  index: index2,
                  actual: actualTypes,
                  expected
                };
                return err;
              }
            } else {
              matchingSignatures = nextMatchingDefs;
            }
          }
          const lengths = matchingSignatures.map(function(signature) {
            return hasRestParam(signature.params) ? Infinity : signature.params.length;
          });
          if (args.length < Math.min.apply(null, lengths)) {
            expected = mergeExpectedParams(matchingSignatures, index2);
            err = new TypeError("Too few arguments in function " + _name + " (expected: " + expected.join(" or ") + ", index: " + args.length + ")");
            err.data = {
              category: "tooFewArgs",
              fn: _name,
              index: args.length,
              expected
            };
            return err;
          }
          const maxLength = Math.max.apply(null, lengths);
          if (args.length > maxLength) {
            err = new TypeError("Too many arguments in function " + _name + " (expected: " + maxLength + ", actual: " + args.length + ")");
            err.data = {
              category: "tooManyArgs",
              fn: _name,
              index: args.length,
              expectedLength: maxLength
            };
            return err;
          }
          const argTypes = [];
          for (let i = 0; i < args.length; ++i) {
            argTypes.push(findTypeNames(args[i]).join("|"));
          }
          err = new TypeError('Arguments of type "' + argTypes.join(", ") + '" do not match any of the defined signatures of function ' + _name + ".");
          err.data = {
            category: "mismatch",
            actual: argTypes
          };
          return err;
        }
        function getLowestTypeIndex(param) {
          let min3 = typeList.length + 1;
          for (let i = 0; i < param.types.length; i++) {
            min3 = Math.min(min3, param.types[i].typeIndex);
          }
          return min3;
        }
        function getLowestConversionIndex(param) {
          let min3 = nConversions + 1;
          for (let i = 0; i < param.types.length; i++) {
            if (!isExactType(param.types[i])) {
              min3 = Math.min(min3, param.types[i].conversionIndex);
            }
          }
          return min3;
        }
        function compareParams(param1, param2) {
          if (param1.hasAny) {
            if (!param2.hasAny) {
              return 0.1;
            }
          } else if (param2.hasAny) {
            return -0.1;
          }
          if (param1.restParam) {
            if (!param2.restParam) {
              return 0.01;
            }
          } else if (param2.restParam) {
            return -0.01;
          }
          const typeDiff = getLowestTypeIndex(param1) - getLowestTypeIndex(param2);
          if (typeDiff < 0) {
            return -1e-3;
          }
          if (typeDiff > 0) {
            return 1e-3;
          }
          const conv1 = getLowestConversionIndex(param1);
          const conv2 = getLowestConversionIndex(param2);
          if (param1.hasConversion) {
            if (!param2.hasConversion) {
              return (1 + conv1) * 1e-6;
            }
          } else if (param2.hasConversion) {
            return -(1 + conv2) * 1e-6;
          }
          const convDiff = conv1 - conv2;
          if (convDiff < 0) {
            return -1e-7;
          }
          if (convDiff > 0) {
            return 1e-7;
          }
          return 0;
        }
        function compareSignatures(signature1, signature2) {
          const pars1 = signature1.params;
          const pars2 = signature2.params;
          const last1 = last(pars1);
          const last2 = last(pars2);
          const hasRest1 = hasRestParam(pars1);
          const hasRest2 = hasRestParam(pars2);
          if (hasRest1 && last1.hasAny) {
            if (!hasRest2 || !last2.hasAny) {
              return 1e7;
            }
          } else if (hasRest2 && last2.hasAny) {
            return -1e7;
          }
          let any1 = 0;
          let conv1 = 0;
          let par;
          for (par of pars1) {
            if (par.hasAny) ++any1;
            if (par.hasConversion) ++conv1;
          }
          let any2 = 0;
          let conv2 = 0;
          for (par of pars2) {
            if (par.hasAny) ++any2;
            if (par.hasConversion) ++conv2;
          }
          if (any1 !== any2) {
            return (any1 - any2) * 1e6;
          }
          if (hasRest1 && last1.hasConversion) {
            if (!hasRest2 || !last2.hasConversion) {
              return 1e5;
            }
          } else if (hasRest2 && last2.hasConversion) {
            return -1e5;
          }
          if (conv1 !== conv2) {
            return (conv1 - conv2) * 1e4;
          }
          if (hasRest1) {
            if (!hasRest2) {
              return 1e3;
            }
          } else if (hasRest2) {
            return -1e3;
          }
          const lengthCriterion = (pars1.length - pars2.length) * (hasRest1 ? -100 : 100);
          if (lengthCriterion !== 0) {
            return lengthCriterion;
          }
          const comparisons = [];
          let tc = 0;
          for (let i = 0; i < pars1.length; ++i) {
            const thisComparison = compareParams(pars1[i], pars2[i]);
            comparisons.push(thisComparison);
            tc += thisComparison;
          }
          if (tc !== 0) {
            return (tc < 0 ? -10 : 10) + tc;
          }
          let c;
          let bonus = 9;
          const decrement = bonus / (comparisons.length + 1);
          for (c of comparisons) {
            if (c !== 0) {
              return (c < 0 ? -bonus : bonus) + c;
            }
            bonus -= decrement;
          }
          return 0;
        }
        function availableConversions(typeNames) {
          if (typeNames.length === 0) {
            return [];
          }
          const types = typeNames.map(findType);
          if (typeNames.length === 1) return types[0].conversionsTo;
          const knownTypes = new Set(typeNames);
          const convertibleTypes = /* @__PURE__ */ new Set();
          for (let i = 0; i < types.length; ++i) {
            for (const match of types[i].conversionsTo) {
              if (!knownTypes.has(match.from)) convertibleTypes.add(match.from);
            }
          }
          const matches = [];
          for (const typeName of convertibleTypes) {
            let bestIndex = nConversions + 1;
            let bestConversion = null;
            for (let i = 0; i < types.length; ++i) {
              for (const match of types[i].conversionsTo) {
                if (match.from === typeName && match.index < bestIndex) {
                  bestIndex = match.index;
                  bestConversion = match;
                }
              }
            }
            matches.push(bestConversion);
          }
          return matches;
        }
        function compileArgsPreprocessing(params, fn) {
          let fnConvert = fn;
          let name114 = "";
          if (params.some((p) => p.hasConversion)) {
            const restParam = hasRestParam(params);
            const compiledConversions = params.map(compileArgConversion);
            name114 = compiledConversions.map((conv) => conv.name).join(";");
            fnConvert = function convertArgs() {
              const args = [];
              const last2 = restParam ? arguments.length - 1 : arguments.length;
              for (let i = 0; i < last2; i++) {
                args[i] = compiledConversions[i](arguments[i]);
              }
              if (restParam) {
                args[last2] = arguments[last2].map(compiledConversions[last2]);
              }
              return fn.apply(this, args);
            };
          }
          let fnPreprocess = fnConvert;
          if (hasRestParam(params)) {
            const offset = params.length - 1;
            fnPreprocess = function preprocessRestParams() {
              return fnConvert.apply(this, slice(arguments, 0, offset).concat([slice(arguments, offset)]));
            };
          }
          if (name114) Object.defineProperty(fnPreprocess, "name", {
            value: name114
          });
          return fnPreprocess;
        }
        function compileArgConversion(param) {
          let test0, test1, conversion0, conversion1;
          const tests = [];
          const conversions = [];
          let name114 = "";
          param.types.forEach(function(type) {
            if (type.conversion) {
              name114 += type.conversion.from + "~>" + type.conversion.to + ",";
              tests.push(findType(type.conversion.from).test);
              conversions.push(type.conversion.convert);
            }
          });
          if (name114) name114 = name114.slice(0, -1);
          else name114 = "pass";
          let convertor = (arg) => arg;
          switch (conversions.length) {
            case 0:
              break;
            case 1:
              test0 = tests[0];
              conversion0 = conversions[0];
              convertor = function convertArg(arg) {
                if (test0(arg)) {
                  return conversion0(arg);
                }
                return arg;
              };
              break;
            case 2:
              test0 = tests[0];
              test1 = tests[1];
              conversion0 = conversions[0];
              conversion1 = conversions[1];
              convertor = function convertArg(arg) {
                if (test0(arg)) {
                  return conversion0(arg);
                }
                if (test1(arg)) {
                  return conversion1(arg);
                }
                return arg;
              };
              break;
            default:
              convertor = function convertArg(arg) {
                for (let i = 0; i < conversions.length; i++) {
                  if (tests[i](arg)) {
                    return conversions[i](arg);
                  }
                }
                return arg;
              };
          }
          Object.defineProperty(convertor, "name", {
            value: name114
          });
          return convertor;
        }
        function splitParams(params) {
          function _splitParams(params2, index2, paramsSoFar) {
            if (index2 < params2.length) {
              const param = params2[index2];
              let resultingParams = [];
              if (param.restParam) {
                const exactTypes = param.types.filter(isExactType);
                if (exactTypes.length < param.types.length) {
                  resultingParams.push({
                    types: exactTypes,
                    name: "..." + exactTypes.map((t) => t.name).join("|"),
                    hasAny: exactTypes.some((t) => t.isAny),
                    hasConversion: false,
                    restParam: true
                  });
                }
                resultingParams.push(param);
              } else {
                resultingParams = param.types.map(function(type) {
                  return {
                    types: [type],
                    name: type.name,
                    hasAny: type.isAny,
                    hasConversion: type.conversion,
                    restParam: false
                  };
                });
              }
              return flatMap(resultingParams, function(nextParam) {
                return _splitParams(params2, index2 + 1, paramsSoFar.concat([nextParam]));
              });
            } else {
              return [paramsSoFar];
            }
          }
          return _splitParams(params, 0, []);
        }
        function conflicting(params1, params2) {
          const ii = Math.max(params1.length, params2.length);
          for (let i = 0; i < ii; i++) {
            const typeSet1 = getTypeSetAtIndex(params1, i);
            const typeSet2 = getTypeSetAtIndex(params2, i);
            let overlap = false;
            let name114;
            for (name114 of typeSet2) {
              if (typeSet1.has(name114)) {
                overlap = true;
                break;
              }
            }
            if (!overlap) {
              return false;
            }
          }
          const len1 = params1.length;
          const len2 = params2.length;
          const restParam1 = hasRestParam(params1);
          const restParam2 = hasRestParam(params2);
          return restParam1 ? restParam2 ? len1 === len2 : len2 >= len1 : restParam2 ? len1 >= len2 : len1 === len2;
        }
        function clearResolutions(functionList) {
          return functionList.map((fn) => {
            if (isReferToSelf(fn)) {
              return referToSelf(fn.referToSelf.callback);
            }
            if (isReferTo(fn)) {
              return makeReferTo(fn.referTo.references, fn.referTo.callback);
            }
            return fn;
          });
        }
        function collectResolutions(references, functionList, signatureMap) {
          const resolvedReferences = [];
          let reference;
          for (reference of references) {
            let resolution = signatureMap[reference];
            if (typeof resolution !== "number") {
              throw new TypeError('No definition for referenced signature "' + reference + '"');
            }
            resolution = functionList[resolution];
            if (typeof resolution !== "function") {
              return false;
            }
            resolvedReferences.push(resolution);
          }
          return resolvedReferences;
        }
        function resolveReferences(functionList, signatureMap, self2) {
          const resolvedFunctions = clearResolutions(functionList);
          const isResolved = new Array(resolvedFunctions.length).fill(false);
          let leftUnresolved = true;
          while (leftUnresolved) {
            leftUnresolved = false;
            let nothingResolved = true;
            for (let i = 0; i < resolvedFunctions.length; ++i) {
              if (isResolved[i]) continue;
              const fn = resolvedFunctions[i];
              if (isReferToSelf(fn)) {
                resolvedFunctions[i] = fn.referToSelf.callback(self2);
                resolvedFunctions[i].referToSelf = fn.referToSelf;
                isResolved[i] = true;
                nothingResolved = false;
              } else if (isReferTo(fn)) {
                const resolvedReferences = collectResolutions(fn.referTo.references, resolvedFunctions, signatureMap);
                if (resolvedReferences) {
                  resolvedFunctions[i] = fn.referTo.callback.apply(this, resolvedReferences);
                  resolvedFunctions[i].referTo = fn.referTo;
                  isResolved[i] = true;
                  nothingResolved = false;
                } else {
                  leftUnresolved = true;
                }
              }
            }
            if (nothingResolved && leftUnresolved) {
              throw new SyntaxError("Circular reference detected in resolving typed.referTo");
            }
          }
          return resolvedFunctions;
        }
        function validateDeprecatedThis(signaturesMap) {
          const deprecatedThisRegex = /\bthis(\(|\.signatures\b)/;
          Object.keys(signaturesMap).forEach((signature) => {
            const fn = signaturesMap[signature];
            if (deprecatedThisRegex.test(fn.toString())) {
              throw new SyntaxError("Using `this` to self-reference a function is deprecated since typed-function@3. Use typed.referTo and typed.referToSelf instead.");
            }
          });
        }
        function createTypedFunction(name114, rawSignaturesMap) {
          typed3.createCount++;
          if (Object.keys(rawSignaturesMap).length === 0) {
            throw new SyntaxError("No signatures provided");
          }
          if (typed3.warnAgainstDeprecatedThis) {
            validateDeprecatedThis(rawSignaturesMap);
          }
          const parsedParams = [];
          const originalFunctions = [];
          const signaturesMap = {};
          const preliminarySignatures = [];
          let signature;
          for (signature in rawSignaturesMap) {
            if (!Object.prototype.hasOwnProperty.call(rawSignaturesMap, signature)) {
              continue;
            }
            const params = parseSignature(signature);
            if (!params) continue;
            parsedParams.forEach(function(pp) {
              if (conflicting(pp, params)) {
                throw new TypeError('Conflicting signatures "' + stringifyParams(pp) + '" and "' + stringifyParams(params) + '".');
              }
            });
            parsedParams.push(params);
            const functionIndex = originalFunctions.length;
            originalFunctions.push(rawSignaturesMap[signature]);
            const conversionParams = params.map(expandParam);
            let sp;
            for (sp of splitParams(conversionParams)) {
              const spName = stringifyParams(sp);
              preliminarySignatures.push({
                params: sp,
                name: spName,
                fn: functionIndex
              });
              if (sp.every((p) => !p.hasConversion)) {
                signaturesMap[spName] = functionIndex;
              }
            }
          }
          preliminarySignatures.sort(compareSignatures);
          const resolvedFunctions = resolveReferences(originalFunctions, signaturesMap, theTypedFn);
          let s;
          for (s in signaturesMap) {
            if (Object.prototype.hasOwnProperty.call(signaturesMap, s)) {
              signaturesMap[s] = resolvedFunctions[signaturesMap[s]];
            }
          }
          const signatures = [];
          const internalSignatureMap = /* @__PURE__ */ new Map();
          for (s of preliminarySignatures) {
            if (!internalSignatureMap.has(s.name)) {
              s.fn = resolvedFunctions[s.fn];
              signatures.push(s);
              internalSignatureMap.set(s.name, s);
            }
          }
          const ok0 = signatures[0] && signatures[0].params.length <= 2 && !hasRestParam(signatures[0].params);
          const ok1 = signatures[1] && signatures[1].params.length <= 2 && !hasRestParam(signatures[1].params);
          const ok2 = signatures[2] && signatures[2].params.length <= 2 && !hasRestParam(signatures[2].params);
          const ok3 = signatures[3] && signatures[3].params.length <= 2 && !hasRestParam(signatures[3].params);
          const ok4 = signatures[4] && signatures[4].params.length <= 2 && !hasRestParam(signatures[4].params);
          const ok5 = signatures[5] && signatures[5].params.length <= 2 && !hasRestParam(signatures[5].params);
          const allOk = ok0 && ok1 && ok2 && ok3 && ok4 && ok5;
          for (let i = 0; i < signatures.length; ++i) {
            signatures[i].test = compileTests(signatures[i].params);
          }
          const test00 = ok0 ? compileTest(signatures[0].params[0]) : notOk;
          const test10 = ok1 ? compileTest(signatures[1].params[0]) : notOk;
          const test20 = ok2 ? compileTest(signatures[2].params[0]) : notOk;
          const test30 = ok3 ? compileTest(signatures[3].params[0]) : notOk;
          const test40 = ok4 ? compileTest(signatures[4].params[0]) : notOk;
          const test50 = ok5 ? compileTest(signatures[5].params[0]) : notOk;
          const test01 = ok0 ? compileTest(signatures[0].params[1]) : notOk;
          const test11 = ok1 ? compileTest(signatures[1].params[1]) : notOk;
          const test21 = ok2 ? compileTest(signatures[2].params[1]) : notOk;
          const test31 = ok3 ? compileTest(signatures[3].params[1]) : notOk;
          const test41 = ok4 ? compileTest(signatures[4].params[1]) : notOk;
          const test51 = ok5 ? compileTest(signatures[5].params[1]) : notOk;
          for (let i = 0; i < signatures.length; ++i) {
            signatures[i].implementation = compileArgsPreprocessing(signatures[i].params, signatures[i].fn);
          }
          const fn0 = ok0 ? signatures[0].implementation : undef;
          const fn1 = ok1 ? signatures[1].implementation : undef;
          const fn2 = ok2 ? signatures[2].implementation : undef;
          const fn3 = ok3 ? signatures[3].implementation : undef;
          const fn4 = ok4 ? signatures[4].implementation : undef;
          const fn5 = ok5 ? signatures[5].implementation : undef;
          const len0 = ok0 ? signatures[0].params.length : -1;
          const len1 = ok1 ? signatures[1].params.length : -1;
          const len2 = ok2 ? signatures[2].params.length : -1;
          const len3 = ok3 ? signatures[3].params.length : -1;
          const len4 = ok4 ? signatures[4].params.length : -1;
          const len5 = ok5 ? signatures[5].params.length : -1;
          const iStart = allOk ? 6 : 0;
          const iEnd = signatures.length;
          const tests = signatures.map((s2) => s2.test);
          const fns = signatures.map((s2) => s2.implementation);
          const generic = function generic2() {
            for (let i = iStart; i < iEnd; i++) {
              if (tests[i](arguments)) {
                return fns[i].apply(this, arguments);
              }
            }
            return typed3.onMismatch(name114, arguments, signatures);
          };
          function theTypedFn(arg0, arg1) {
            if (arguments.length === len0 && test00(arg0) && test01(arg1)) {
              return fn0.apply(this, arguments);
            }
            if (arguments.length === len1 && test10(arg0) && test11(arg1)) {
              return fn1.apply(this, arguments);
            }
            if (arguments.length === len2 && test20(arg0) && test21(arg1)) {
              return fn2.apply(this, arguments);
            }
            if (arguments.length === len3 && test30(arg0) && test31(arg1)) {
              return fn3.apply(this, arguments);
            }
            if (arguments.length === len4 && test40(arg0) && test41(arg1)) {
              return fn4.apply(this, arguments);
            }
            if (arguments.length === len5 && test50(arg0) && test51(arg1)) {
              return fn5.apply(this, arguments);
            }
            return generic.apply(this, arguments);
          }
          try {
            Object.defineProperty(theTypedFn, "name", {
              value: name114
            });
          } catch (err) {
          }
          theTypedFn.signatures = signaturesMap;
          theTypedFn._typedFunctionData = {
            signatures,
            signatureMap: internalSignatureMap
          };
          return theTypedFn;
        }
        function _onMismatch(name114, args, signatures) {
          throw createError(name114, args, signatures);
        }
        function initial(arr) {
          return slice(arr, 0, arr.length - 1);
        }
        function last(arr) {
          return arr[arr.length - 1];
        }
        function slice(arr, start, end) {
          return Array.prototype.slice.call(arr, start, end);
        }
        function findInArray(arr, test) {
          for (let i = 0; i < arr.length; i++) {
            if (test(arr[i])) {
              return arr[i];
            }
          }
          return void 0;
        }
        function flatMap(arr, callback) {
          return Array.prototype.concat.apply([], arr.map(callback));
        }
        function referTo() {
          const references = initial(arguments).map((s) => stringifyParams(parseSignature(s)));
          const callback = last(arguments);
          if (typeof callback !== "function") {
            throw new TypeError("Callback function expected as last argument");
          }
          return makeReferTo(references, callback);
        }
        function makeReferTo(references, callback) {
          return {
            referTo: {
              references,
              callback
            }
          };
        }
        function referToSelf(callback) {
          if (typeof callback !== "function") {
            throw new TypeError("Callback function expected as first argument");
          }
          return {
            referToSelf: {
              callback
            }
          };
        }
        function isReferTo(objectOrFn) {
          return objectOrFn && typeof objectOrFn.referTo === "object" && Array.isArray(objectOrFn.referTo.references) && typeof objectOrFn.referTo.callback === "function";
        }
        function isReferToSelf(objectOrFn) {
          return objectOrFn && typeof objectOrFn.referToSelf === "object" && typeof objectOrFn.referToSelf.callback === "function";
        }
        function checkName(nameSoFar, newName) {
          if (!nameSoFar) {
            return newName;
          }
          if (newName && newName !== nameSoFar) {
            const err = new Error("Function names do not match (expected: " + nameSoFar + ", actual: " + newName + ")");
            err.data = {
              actual: newName,
              expected: nameSoFar
            };
            throw err;
          }
          return nameSoFar;
        }
        function getObjectName(obj) {
          let name114;
          for (const key in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, key) && (isTypedFunction(obj[key]) || typeof obj[key].signature === "string")) {
              name114 = checkName(name114, obj[key].name);
            }
          }
          return name114;
        }
        function mergeSignatures(dest, source) {
          let key;
          for (key in source) {
            if (Object.prototype.hasOwnProperty.call(source, key)) {
              if (key in dest) {
                if (source[key] !== dest[key]) {
                  const err = new Error('Signature "' + key + '" is defined twice');
                  err.data = {
                    signature: key,
                    sourceFunction: source[key],
                    destFunction: dest[key]
                  };
                  throw err;
                }
              }
              dest[key] = source[key];
            }
          }
        }
        const saveTyped = typed3;
        typed3 = function(maybeName) {
          const named = typeof maybeName === "string";
          const start = named ? 1 : 0;
          let name114 = named ? maybeName : "";
          const allSignatures = {};
          for (let i = start; i < arguments.length; ++i) {
            const item = arguments[i];
            let theseSignatures = {};
            let thisName;
            if (typeof item === "function") {
              thisName = item.name;
              if (typeof item.signature === "string") {
                theseSignatures[item.signature] = item;
              } else if (isTypedFunction(item)) {
                theseSignatures = item.signatures;
              }
            } else if (isPlainObject2(item)) {
              theseSignatures = item;
              if (!named) {
                thisName = getObjectName(item);
              }
            }
            if (Object.keys(theseSignatures).length === 0) {
              const err = new TypeError("Argument to 'typed' at index " + i + " is not a (typed) function, nor an object with signatures as keys and functions as values.");
              err.data = {
                index: i,
                argument: item
              };
              throw err;
            }
            if (!named) {
              name114 = checkName(name114, thisName);
            }
            mergeSignatures(allSignatures, theseSignatures);
          }
          return createTypedFunction(name114 || "", allSignatures);
        };
        typed3.create = create;
        typed3.createCount = saveTyped.createCount;
        typed3.onMismatch = _onMismatch;
        typed3.throwMismatchError = _onMismatch;
        typed3.createError = createError;
        typed3.clear = clear;
        typed3.clearConversions = clearConversions;
        typed3.addTypes = addTypes;
        typed3._findType = findType;
        typed3.referTo = referTo;
        typed3.referToSelf = referToSelf;
        typed3.convert = convert;
        typed3.findSignature = findSignature;
        typed3.find = find;
        typed3.isTypedFunction = isTypedFunction;
        typed3.warnAgainstDeprecatedThis = true;
        typed3.addType = function(type, beforeObjectTest) {
          let before = "any";
          if (beforeObjectTest !== false && typeMap.has("Object")) {
            before = "Object";
          }
          typed3.addTypes([type], before);
        };
        function _validateConversion(conversion) {
          if (!conversion || typeof conversion.from !== "string" || typeof conversion.to !== "string" || typeof conversion.convert !== "function") {
            throw new TypeError("Object with properties {from: string, to: string, convert: function} expected");
          }
          if (conversion.to === conversion.from) {
            throw new SyntaxError('Illegal to define conversion from "' + conversion.from + '" to itself.');
          }
        }
        typed3.addConversion = function(conversion) {
          let options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {
            override: false
          };
          _validateConversion(conversion);
          const to = findType(conversion.to);
          const existing = to.conversionsTo.find((other) => other.from === conversion.from);
          if (existing) {
            if (options && options.override) {
              typed3.removeConversion({
                from: existing.from,
                to: conversion.to,
                convert: existing.convert
              });
            } else {
              throw new Error('There is already a conversion from "' + conversion.from + '" to "' + to.name + '"');
            }
          }
          to.conversionsTo.push({
            from: conversion.from,
            to: to.name,
            convert: conversion.convert,
            index: nConversions++
          });
        };
        typed3.addConversions = function(conversions, options) {
          conversions.forEach((conversion) => typed3.addConversion(conversion, options));
        };
        typed3.removeConversion = function(conversion) {
          _validateConversion(conversion);
          const to = findType(conversion.to);
          const existingConversion = findInArray(to.conversionsTo, (c) => c.from === conversion.from);
          if (!existingConversion) {
            throw new Error("Attempt to remove nonexistent conversion from " + conversion.from + " to " + conversion.to);
          }
          if (existingConversion.convert !== conversion.convert) {
            throw new Error("Conversion to remove does not match existing conversion");
          }
          const index2 = to.conversionsTo.indexOf(existingConversion);
          to.conversionsTo.splice(index2, 1);
        };
        typed3.resolve = function(tf, argList) {
          if (!isTypedFunction(tf)) {
            throw new TypeError(NOT_TYPED_FUNCTION);
          }
          const sigs = tf._typedFunctionData.signatures;
          for (let i = 0; i < sigs.length; ++i) {
            if (sigs[i].test(argList)) {
              return sigs[i];
            }
          }
          return null;
        };
        return typed3;
      }
      var typedFunction2 = create();
      return typedFunction2;
    }));
  }
});

// node_modules/@babel/runtime/helpers/typeof.js
var require_typeof = __commonJS({
  "node_modules/@babel/runtime/helpers/typeof.js"(exports, module) {
    function _typeof(o) {
      "@babel/helpers - typeof";
      return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o2) {
        return typeof o2;
      } : function(o2) {
        return o2 && "function" == typeof Symbol && o2.constructor === Symbol && o2 !== Symbol.prototype ? "symbol" : typeof o2;
      }, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
    }
    module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
});

// node_modules/@babel/runtime/helpers/toPrimitive.js
var require_toPrimitive = __commonJS({
  "node_modules/@babel/runtime/helpers/toPrimitive.js"(exports, module) {
    var _typeof = require_typeof()["default"];
    function toPrimitive(t, r) {
      if ("object" != _typeof(t) || !t) return t;
      var e3 = t[Symbol.toPrimitive];
      if (void 0 !== e3) {
        var i = e3.call(t, r || "default");
        if ("object" != _typeof(i)) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === r ? String : Number)(t);
    }
    module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
});

// node_modules/@babel/runtime/helpers/toPropertyKey.js
var require_toPropertyKey = __commonJS({
  "node_modules/@babel/runtime/helpers/toPropertyKey.js"(exports, module) {
    var _typeof = require_typeof()["default"];
    var toPrimitive = require_toPrimitive();
    function toPropertyKey(t) {
      var i = toPrimitive(t, "string");
      return "symbol" == _typeof(i) ? i : i + "";
    }
    module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
});

// node_modules/@babel/runtime/helpers/defineProperty.js
var require_defineProperty = __commonJS({
  "node_modules/@babel/runtime/helpers/defineProperty.js"(exports, module) {
    var toPropertyKey = require_toPropertyKey();
    function _defineProperty17(e3, r, t) {
      return (r = toPropertyKey(r)) in e3 ? Object.defineProperty(e3, r, {
        value: t,
        enumerable: true,
        configurable: true,
        writable: true
      }) : e3[r] = t, e3;
    }
    module.exports = _defineProperty17, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
});

// node_modules/escape-latex/dist/index.js
var require_dist = __commonJS({
  "node_modules/escape-latex/dist/index.js"(exports, module) {
    "use strict";
    var _extends5 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var defaultEscapes = {
      "{": "\\{",
      "}": "\\}",
      "\\": "\\textbackslash{}",
      "#": "\\#",
      $: "\\$",
      "%": "\\%",
      "&": "\\&",
      "^": "\\textasciicircum{}",
      _: "\\_",
      "~": "\\textasciitilde{}"
    };
    var formatEscapes = {
      "\u2013": "\\--",
      "\u2014": "\\---",
      " ": "~",
      "	": "\\qquad{}",
      "\r\n": "\\newline{}",
      "\n": "\\newline{}"
    };
    var defaultEscapeMapFn = function defaultEscapeMapFn2(defaultEscapes2, formatEscapes2) {
      return _extends5({}, defaultEscapes2, formatEscapes2);
    };
    module.exports = function(str) {
      var _ref = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, _ref$preserveFormatti = _ref.preserveFormatting, preserveFormatting = _ref$preserveFormatti === void 0 ? false : _ref$preserveFormatti, _ref$escapeMapFn = _ref.escapeMapFn, escapeMapFn = _ref$escapeMapFn === void 0 ? defaultEscapeMapFn : _ref$escapeMapFn;
      var runningStr = String(str);
      var result = "";
      var escapes = escapeMapFn(_extends5({}, defaultEscapes), preserveFormatting ? _extends5({}, formatEscapes) : {});
      var escapeKeys = Object.keys(escapes);
      var _loop = function _loop2() {
        var specialCharFound = false;
        escapeKeys.forEach(function(key, index2) {
          if (specialCharFound) {
            return;
          }
          if (runningStr.length >= key.length && runningStr.slice(0, key.length) === key) {
            result += escapes[escapeKeys[index2]];
            runningStr = runningStr.slice(key.length, runningStr.length);
            specialCharFound = true;
          }
        });
        if (!specialCharFound) {
          result += runningStr.slice(0, 1);
          runningStr = runningStr.slice(1, runningStr.length);
        }
      };
      while (runningStr) {
        _loop();
      }
      return result;
    };
  }
});

// node_modules/seedrandom/lib/alea.js
var require_alea = __commonJS({
  "node_modules/seedrandom/lib/alea.js"(exports, module) {
    (function(global, module2, define2) {
      function Alea(seed) {
        var me = this, mash = Mash();
        me.next = function() {
          var t = 2091639 * me.s0 + me.c * 23283064365386963e-26;
          me.s0 = me.s1;
          me.s1 = me.s2;
          return me.s2 = t - (me.c = t | 0);
        };
        me.c = 1;
        me.s0 = mash(" ");
        me.s1 = mash(" ");
        me.s2 = mash(" ");
        me.s0 -= mash(seed);
        if (me.s0 < 0) {
          me.s0 += 1;
        }
        me.s1 -= mash(seed);
        if (me.s1 < 0) {
          me.s1 += 1;
        }
        me.s2 -= mash(seed);
        if (me.s2 < 0) {
          me.s2 += 1;
        }
        mash = null;
      }
      function copy(f, t) {
        t.c = f.c;
        t.s0 = f.s0;
        t.s1 = f.s1;
        t.s2 = f.s2;
        return t;
      }
      function impl(seed, opts) {
        var xg = new Alea(seed), state = opts && opts.state, prng = xg.next;
        prng.int32 = function() {
          return xg.next() * 4294967296 | 0;
        };
        prng.double = function() {
          return prng() + (prng() * 2097152 | 0) * 11102230246251565e-32;
        };
        prng.quick = prng;
        if (state) {
          if (typeof state == "object") copy(state, xg);
          prng.state = function() {
            return copy(xg, {});
          };
        }
        return prng;
      }
      function Mash() {
        var n = 4022871197;
        var mash = function(data) {
          data = String(data);
          for (var i = 0; i < data.length; i++) {
            n += data.charCodeAt(i);
            var h = 0.02519603282416938 * n;
            n = h >>> 0;
            h -= n;
            h *= n;
            n = h >>> 0;
            h -= n;
            n += h * 4294967296;
          }
          return (n >>> 0) * 23283064365386963e-26;
        };
        return mash;
      }
      if (module2 && module2.exports) {
        module2.exports = impl;
      } else if (define2 && define2.amd) {
        define2(function() {
          return impl;
        });
      } else {
        this.alea = impl;
      }
    })(
      exports,
      typeof module == "object" && module,
      // present in node.js
      typeof define == "function" && define
      // present with an AMD loader
    );
  }
});

// node_modules/seedrandom/lib/xor128.js
var require_xor128 = __commonJS({
  "node_modules/seedrandom/lib/xor128.js"(exports, module) {
    (function(global, module2, define2) {
      function XorGen(seed) {
        var me = this, strseed = "";
        me.x = 0;
        me.y = 0;
        me.z = 0;
        me.w = 0;
        me.next = function() {
          var t = me.x ^ me.x << 11;
          me.x = me.y;
          me.y = me.z;
          me.z = me.w;
          return me.w ^= me.w >>> 19 ^ t ^ t >>> 8;
        };
        if (seed === (seed | 0)) {
          me.x = seed;
        } else {
          strseed += seed;
        }
        for (var k = 0; k < strseed.length + 64; k++) {
          me.x ^= strseed.charCodeAt(k) | 0;
          me.next();
        }
      }
      function copy(f, t) {
        t.x = f.x;
        t.y = f.y;
        t.z = f.z;
        t.w = f.w;
        return t;
      }
      function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
          return (xg.next() >>> 0) / 4294967296;
        };
        prng.double = function() {
          do {
            var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 4294967296, result = (top + bot) / (1 << 21);
          } while (result === 0);
          return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
          if (typeof state == "object") copy(state, xg);
          prng.state = function() {
            return copy(xg, {});
          };
        }
        return prng;
      }
      if (module2 && module2.exports) {
        module2.exports = impl;
      } else if (define2 && define2.amd) {
        define2(function() {
          return impl;
        });
      } else {
        this.xor128 = impl;
      }
    })(
      exports,
      typeof module == "object" && module,
      // present in node.js
      typeof define == "function" && define
      // present with an AMD loader
    );
  }
});

// node_modules/seedrandom/lib/xorwow.js
var require_xorwow = __commonJS({
  "node_modules/seedrandom/lib/xorwow.js"(exports, module) {
    (function(global, module2, define2) {
      function XorGen(seed) {
        var me = this, strseed = "";
        me.next = function() {
          var t = me.x ^ me.x >>> 2;
          me.x = me.y;
          me.y = me.z;
          me.z = me.w;
          me.w = me.v;
          return (me.d = me.d + 362437 | 0) + (me.v = me.v ^ me.v << 4 ^ (t ^ t << 1)) | 0;
        };
        me.x = 0;
        me.y = 0;
        me.z = 0;
        me.w = 0;
        me.v = 0;
        if (seed === (seed | 0)) {
          me.x = seed;
        } else {
          strseed += seed;
        }
        for (var k = 0; k < strseed.length + 64; k++) {
          me.x ^= strseed.charCodeAt(k) | 0;
          if (k == strseed.length) {
            me.d = me.x << 10 ^ me.x >>> 4;
          }
          me.next();
        }
      }
      function copy(f, t) {
        t.x = f.x;
        t.y = f.y;
        t.z = f.z;
        t.w = f.w;
        t.v = f.v;
        t.d = f.d;
        return t;
      }
      function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
          return (xg.next() >>> 0) / 4294967296;
        };
        prng.double = function() {
          do {
            var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 4294967296, result = (top + bot) / (1 << 21);
          } while (result === 0);
          return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
          if (typeof state == "object") copy(state, xg);
          prng.state = function() {
            return copy(xg, {});
          };
        }
        return prng;
      }
      if (module2 && module2.exports) {
        module2.exports = impl;
      } else if (define2 && define2.amd) {
        define2(function() {
          return impl;
        });
      } else {
        this.xorwow = impl;
      }
    })(
      exports,
      typeof module == "object" && module,
      // present in node.js
      typeof define == "function" && define
      // present with an AMD loader
    );
  }
});

// node_modules/seedrandom/lib/xorshift7.js
var require_xorshift7 = __commonJS({
  "node_modules/seedrandom/lib/xorshift7.js"(exports, module) {
    (function(global, module2, define2) {
      function XorGen(seed) {
        var me = this;
        me.next = function() {
          var X = me.x, i = me.i, t, v, w;
          t = X[i];
          t ^= t >>> 7;
          v = t ^ t << 24;
          t = X[i + 1 & 7];
          v ^= t ^ t >>> 10;
          t = X[i + 3 & 7];
          v ^= t ^ t >>> 3;
          t = X[i + 4 & 7];
          v ^= t ^ t << 7;
          t = X[i + 7 & 7];
          t = t ^ t << 13;
          v ^= t ^ t << 9;
          X[i] = v;
          me.i = i + 1 & 7;
          return v;
        };
        function init(me2, seed2) {
          var j, w, X = [];
          if (seed2 === (seed2 | 0)) {
            w = X[0] = seed2;
          } else {
            seed2 = "" + seed2;
            for (j = 0; j < seed2.length; ++j) {
              X[j & 7] = X[j & 7] << 15 ^ seed2.charCodeAt(j) + X[j + 1 & 7] << 13;
            }
          }
          while (X.length < 8) X.push(0);
          for (j = 0; j < 8 && X[j] === 0; ++j) ;
          if (j == 8) w = X[7] = -1;
          else w = X[j];
          me2.x = X;
          me2.i = 0;
          for (j = 256; j > 0; --j) {
            me2.next();
          }
        }
        init(me, seed);
      }
      function copy(f, t) {
        t.x = f.x.slice();
        t.i = f.i;
        return t;
      }
      function impl(seed, opts) {
        if (seed == null) seed = +/* @__PURE__ */ new Date();
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
          return (xg.next() >>> 0) / 4294967296;
        };
        prng.double = function() {
          do {
            var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 4294967296, result = (top + bot) / (1 << 21);
          } while (result === 0);
          return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
          if (state.x) copy(state, xg);
          prng.state = function() {
            return copy(xg, {});
          };
        }
        return prng;
      }
      if (module2 && module2.exports) {
        module2.exports = impl;
      } else if (define2 && define2.amd) {
        define2(function() {
          return impl;
        });
      } else {
        this.xorshift7 = impl;
      }
    })(
      exports,
      typeof module == "object" && module,
      // present in node.js
      typeof define == "function" && define
      // present with an AMD loader
    );
  }
});

// node_modules/seedrandom/lib/xor4096.js
var require_xor4096 = __commonJS({
  "node_modules/seedrandom/lib/xor4096.js"(exports, module) {
    (function(global, module2, define2) {
      function XorGen(seed) {
        var me = this;
        me.next = function() {
          var w = me.w, X = me.X, i = me.i, t, v;
          me.w = w = w + 1640531527 | 0;
          v = X[i + 34 & 127];
          t = X[i = i + 1 & 127];
          v ^= v << 13;
          t ^= t << 17;
          v ^= v >>> 15;
          t ^= t >>> 12;
          v = X[i] = v ^ t;
          me.i = i;
          return v + (w ^ w >>> 16) | 0;
        };
        function init(me2, seed2) {
          var t, v, i, j, w, X = [], limit = 128;
          if (seed2 === (seed2 | 0)) {
            v = seed2;
            seed2 = null;
          } else {
            seed2 = seed2 + "\0";
            v = 0;
            limit = Math.max(limit, seed2.length);
          }
          for (i = 0, j = -32; j < limit; ++j) {
            if (seed2) v ^= seed2.charCodeAt((j + 32) % seed2.length);
            if (j === 0) w = v;
            v ^= v << 10;
            v ^= v >>> 15;
            v ^= v << 4;
            v ^= v >>> 13;
            if (j >= 0) {
              w = w + 1640531527 | 0;
              t = X[j & 127] ^= v + w;
              i = 0 == t ? i + 1 : 0;
            }
          }
          if (i >= 128) {
            X[(seed2 && seed2.length || 0) & 127] = -1;
          }
          i = 127;
          for (j = 4 * 128; j > 0; --j) {
            v = X[i + 34 & 127];
            t = X[i = i + 1 & 127];
            v ^= v << 13;
            t ^= t << 17;
            v ^= v >>> 15;
            t ^= t >>> 12;
            X[i] = v ^ t;
          }
          me2.w = w;
          me2.X = X;
          me2.i = i;
        }
        init(me, seed);
      }
      function copy(f, t) {
        t.i = f.i;
        t.w = f.w;
        t.X = f.X.slice();
        return t;
      }
      ;
      function impl(seed, opts) {
        if (seed == null) seed = +/* @__PURE__ */ new Date();
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
          return (xg.next() >>> 0) / 4294967296;
        };
        prng.double = function() {
          do {
            var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 4294967296, result = (top + bot) / (1 << 21);
          } while (result === 0);
          return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
          if (state.X) copy(state, xg);
          prng.state = function() {
            return copy(xg, {});
          };
        }
        return prng;
      }
      if (module2 && module2.exports) {
        module2.exports = impl;
      } else if (define2 && define2.amd) {
        define2(function() {
          return impl;
        });
      } else {
        this.xor4096 = impl;
      }
    })(
      exports,
      // window object or global
      typeof module == "object" && module,
      // present in node.js
      typeof define == "function" && define
      // present with an AMD loader
    );
  }
});

// node_modules/seedrandom/lib/tychei.js
var require_tychei = __commonJS({
  "node_modules/seedrandom/lib/tychei.js"(exports, module) {
    (function(global, module2, define2) {
      function XorGen(seed) {
        var me = this, strseed = "";
        me.next = function() {
          var b = me.b, c = me.c, d = me.d, a = me.a;
          b = b << 25 ^ b >>> 7 ^ c;
          c = c - d | 0;
          d = d << 24 ^ d >>> 8 ^ a;
          a = a - b | 0;
          me.b = b = b << 20 ^ b >>> 12 ^ c;
          me.c = c = c - d | 0;
          me.d = d << 16 ^ c >>> 16 ^ a;
          return me.a = a - b | 0;
        };
        me.a = 0;
        me.b = 0;
        me.c = 2654435769 | 0;
        me.d = 1367130551;
        if (seed === Math.floor(seed)) {
          me.a = seed / 4294967296 | 0;
          me.b = seed | 0;
        } else {
          strseed += seed;
        }
        for (var k = 0; k < strseed.length + 20; k++) {
          me.b ^= strseed.charCodeAt(k) | 0;
          me.next();
        }
      }
      function copy(f, t) {
        t.a = f.a;
        t.b = f.b;
        t.c = f.c;
        t.d = f.d;
        return t;
      }
      ;
      function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
          return (xg.next() >>> 0) / 4294967296;
        };
        prng.double = function() {
          do {
            var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 4294967296, result = (top + bot) / (1 << 21);
          } while (result === 0);
          return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
          if (typeof state == "object") copy(state, xg);
          prng.state = function() {
            return copy(xg, {});
          };
        }
        return prng;
      }
      if (module2 && module2.exports) {
        module2.exports = impl;
      } else if (define2 && define2.amd) {
        define2(function() {
          return impl;
        });
      } else {
        this.tychei = impl;
      }
    })(
      exports,
      typeof module == "object" && module,
      // present in node.js
      typeof define == "function" && define
      // present with an AMD loader
    );
  }
});

// node_modules/seedrandom/seedrandom.js
var require_seedrandom = __commonJS({
  "node_modules/seedrandom/seedrandom.js"(exports, module) {
    (function(global, pool, math2) {
      var width = 256, chunks = 6, digits2 = 52, rngname = "random", startdenom = math2.pow(width, chunks), significance = math2.pow(2, digits2), overflow = significance * 2, mask = width - 1, nodecrypto;
      function seedrandom2(seed, options, callback) {
        var key = [];
        options = options == true ? { entropy: true } : options || {};
        var shortseed = mixkey(flatten2(
          options.entropy ? [seed, tostring(pool)] : seed == null ? autoseed() : seed,
          3
        ), key);
        var arc4 = new ARC4(key);
        var prng = function() {
          var n = arc4.g(chunks), d = startdenom, x = 0;
          while (n < significance) {
            n = (n + x) * width;
            d *= width;
            x = arc4.g(1);
          }
          while (n >= overflow) {
            n /= 2;
            d /= 2;
            x >>>= 1;
          }
          return (n + x) / d;
        };
        prng.int32 = function() {
          return arc4.g(4) | 0;
        };
        prng.quick = function() {
          return arc4.g(4) / 4294967296;
        };
        prng.double = prng;
        mixkey(tostring(arc4.S), pool);
        return (options.pass || callback || function(prng2, seed2, is_math_call, state) {
          if (state) {
            if (state.S) {
              copy(state, arc4);
            }
            prng2.state = function() {
              return copy(arc4, {});
            };
          }
          if (is_math_call) {
            math2[rngname] = prng2;
            return seed2;
          } else return prng2;
        })(
          prng,
          shortseed,
          "global" in options ? options.global : this == math2,
          options.state
        );
      }
      function ARC4(key) {
        var t, keylen = key.length, me = this, i = 0, j = me.i = me.j = 0, s = me.S = [];
        if (!keylen) {
          key = [keylen++];
        }
        while (i < width) {
          s[i] = i++;
        }
        for (i = 0; i < width; i++) {
          s[i] = s[j = mask & j + key[i % keylen] + (t = s[i])];
          s[j] = t;
        }
        (me.g = function(count) {
          var t2, r = 0, i2 = me.i, j2 = me.j, s2 = me.S;
          while (count--) {
            t2 = s2[i2 = mask & i2 + 1];
            r = r * width + s2[mask & (s2[i2] = s2[j2 = mask & j2 + t2]) + (s2[j2] = t2)];
          }
          me.i = i2;
          me.j = j2;
          return r;
        })(width);
      }
      function copy(f, t) {
        t.i = f.i;
        t.j = f.j;
        t.S = f.S.slice();
        return t;
      }
      ;
      function flatten2(obj, depth) {
        var result = [], typ = typeof obj, prop;
        if (depth && typ == "object") {
          for (prop in obj) {
            try {
              result.push(flatten2(obj[prop], depth - 1));
            } catch (e3) {
            }
          }
        }
        return result.length ? result : typ == "string" ? obj : obj + "\0";
      }
      function mixkey(seed, key) {
        var stringseed = seed + "", smear, j = 0;
        while (j < stringseed.length) {
          key[mask & j] = mask & (smear ^= key[mask & j] * 19) + stringseed.charCodeAt(j++);
        }
        return tostring(key);
      }
      function autoseed() {
        try {
          var out;
          if (nodecrypto && (out = nodecrypto.randomBytes)) {
            out = out(width);
          } else {
            out = new Uint8Array(width);
            (global.crypto || global.msCrypto).getRandomValues(out);
          }
          return tostring(out);
        } catch (e3) {
          var browser = global.navigator, plugins = browser && browser.plugins;
          return [+/* @__PURE__ */ new Date(), global, plugins, global.screen, tostring(pool)];
        }
      }
      function tostring(a) {
        return String.fromCharCode.apply(0, a);
      }
      mixkey(math2.random(), pool);
      if (typeof module == "object" && module.exports) {
        module.exports = seedrandom2;
        try {
          nodecrypto = __require("crypto");
        } catch (ex) {
        }
      } else if (typeof define == "function" && define.amd) {
        define(function() {
          return seedrandom2;
        });
      } else {
        math2["seed" + rngname] = seedrandom2;
      }
    })(
      // global: `self` in browsers (including strict mode and web workers),
      // otherwise `this` in Node and other environments
      typeof self !== "undefined" ? self : exports,
      [],
      // pool: entropy pool starts empty
      Math
      // math: package containing random, pow, and seedrandom
    );
  }
});

// node_modules/seedrandom/index.js
var require_seedrandom2 = __commonJS({
  "node_modules/seedrandom/index.js"(exports, module) {
    var alea = require_alea();
    var xor128 = require_xor128();
    var xorwow = require_xorwow();
    var xorshift7 = require_xorshift7();
    var xor4096 = require_xor4096();
    var tychei = require_tychei();
    var sr = require_seedrandom();
    sr.alea = alea;
    sr.xor128 = xor128;
    sr.xorwow = xorwow;
    sr.xorshift7 = xorshift7;
    sr.xor4096 = xor4096;
    sr.tychei = tychei;
    module.exports = sr;
  }
});

// node_modules/javascript-natural-sort/naturalSort.js
var require_naturalSort = __commonJS({
  "node_modules/javascript-natural-sort/naturalSort.js"(exports, module) {
    module.exports = function naturalSort2(a, b) {
      "use strict";
      var re = /(^([+\-]?(?:0|[1-9]\d*)(?:\.\d*)?(?:[eE][+\-]?\d+)?)?$|^0x[0-9a-f]+$|\d+)/gi, sre = /(^[ ]*|[ ]*$)/g, dre = /(^([\w ]+,?[\w ]+)?[\w ]+,?[\w ]+\d+:\d+(:\d+)?[\w ]?|^\d{1,4}[\/\-]\d{1,4}[\/\-]\d{1,4}|^\w+, \w+ \d+, \d{4})/, hre = /^0x[0-9a-f]+$/i, ore = /^0/, i = function(s) {
        return naturalSort2.insensitive && ("" + s).toLowerCase() || "" + s;
      }, x = i(a).replace(sre, "") || "", y = i(b).replace(sre, "") || "", xN = x.replace(re, "\0$1\0").replace(/\0$/, "").replace(/^\0/, "").split("\0"), yN = y.replace(re, "\0$1\0").replace(/\0$/, "").replace(/^\0/, "").split("\0"), xD = parseInt(x.match(hre), 16) || xN.length !== 1 && x.match(dre) && Date.parse(x), yD = parseInt(y.match(hre), 16) || xD && y.match(dre) && Date.parse(y) || null, oFxNcL, oFyNcL;
      if (yD) {
        if (xD < yD) {
          return -1;
        } else if (xD > yD) {
          return 1;
        }
      }
      for (var cLoc = 0, numS = Math.max(xN.length, yN.length); cLoc < numS; cLoc++) {
        oFxNcL = !(xN[cLoc] || "").match(ore) && parseFloat(xN[cLoc]) || xN[cLoc] || 0;
        oFyNcL = !(yN[cLoc] || "").match(ore) && parseFloat(yN[cLoc]) || yN[cLoc] || 0;
        if (isNaN(oFxNcL) !== isNaN(oFyNcL)) {
          return isNaN(oFxNcL) ? 1 : -1;
        } else if (typeof oFxNcL !== typeof oFyNcL) {
          oFxNcL += "";
          oFyNcL += "";
        }
        if (oFxNcL < oFyNcL) {
          return -1;
        }
        if (oFxNcL > oFyNcL) {
          return 1;
        }
      }
      return 0;
    };
  }
});

// base_lib/expression_engine.ts
var import_math_base_special_gamma = __toESM(require_lib75(), 1);

// node_modules/mathjs/lib/esm/entry/configReadonly.js
var import_extends = __toESM(require_extends(), 1);

// node_modules/mathjs/lib/esm/core/config.js
var DEFAULT_CONFIG = {
  // minimum relative difference between two compared values,
  // used by all comparison functions
  relTol: 1e-12,
  // minimum absolute difference between two compared values,
  // used by all comparison functions
  absTol: 1e-15,
  // type of default matrix output. Choose 'matrix' (default) or 'array'
  matrix: "Matrix",
  // type of default number output. Choose 'number' (default) 'BigNumber', 'bigint', or 'Fraction'
  number: "number",
  // type of fallback used for config { number: 'bigint' } when a value cannot be represented
  // in the configured numeric type. Choose 'number' (default) or 'BigNumber'.
  numberFallback: "number",
  // number of significant digits in BigNumbers
  precision: 64,
  // predictable output type of functions. When true, output type depends only
  // on the input types. When false (default), output type can vary depending
  // on input values. For example `math.sqrt(-4)` returns `complex('2i')` when
  // predictable is false, and returns `NaN` when true.
  predictable: false,
  // random seed for seeded pseudo random number generation
  // null = randomly seed
  randomSeed: null,
  // legacy behavior for matrix subset. When true, the subset function
  // returns a matrix or array with the same size as the index (except for scalars).
  // When false, it returns a matrix or array with a size depending on the type of index.
  legacySubset: false
};

// node_modules/mathjs/lib/esm/utils/customs.js
function getSafeProperty(object, prop) {
  if (isSafeObjectProperty(object, prop) || isSafeArrayProperty(object, prop)) {
    return object[prop];
  }
  if (isSafeMethod(object, prop)) {
    throw new Error('Cannot access method "'.concat(prop, '" as a property'));
  }
  if (object === null || object === void 0) {
    throw new TypeError('Cannot access property "'.concat(prop, '": object is ').concat(object));
  }
  throw new Error('No access to property "' + prop + '"');
}
function setSafeProperty(object, prop, value) {
  if (isSafeObjectProperty(object, prop) || isSafeArrayProperty(object, prop)) {
    object[prop] = value;
    return value;
  }
  throw new Error('No access to property "'.concat(prop, '"'));
}
function isSafeObjectProperty(object, prop) {
  if (!isPlainObject(object)) {
    return false;
  }
  return !(prop in Object.prototype);
}
function isSafeArrayProperty(array, prop) {
  if (!Array.isArray(array)) {
    return false;
  }
  return typeof prop === "number" || typeof prop === "string" && isInteger(prop) || prop === "length";
}
function isInteger(prop) {
  return /^\d+$/.test(prop);
}
function getSafeMethod(object, method) {
  if (!isSafeMethod(object, method)) {
    throw new Error('No access to method "' + method + '"');
  }
  return object[method];
}
function isSafeMethod(object, method) {
  if (object === null || object === void 0 || typeof object[method] !== "function") {
    return false;
  }
  if (hasOwnProperty(object, method) && Object.getPrototypeOf && method in Object.getPrototypeOf(object)) {
    return false;
  }
  if (safeNativeMethods.has(method)) {
    return true;
  }
  if (method in Object.prototype) {
    return false;
  }
  if (method in Function.prototype) {
    return false;
  }
  return true;
}
function isPlainObject(object) {
  return typeof object === "object" && object && object.constructor === Object;
}
var safeNativeMethods = /* @__PURE__ */ new Set(["toString", "valueOf", "toLocaleString"]);

// node_modules/mathjs/lib/esm/utils/map.js
var ObjectWrappingMap = class {
  constructor(object) {
    this.wrappedObject = object;
    this[Symbol.iterator] = this.entries;
  }
  keys() {
    return Object.keys(this.wrappedObject).filter((key) => this.has(key)).values();
  }
  get(key) {
    return getSafeProperty(this.wrappedObject, key);
  }
  set(key, value) {
    setSafeProperty(this.wrappedObject, key, value);
    return this;
  }
  has(key) {
    return isSafeObjectProperty(this.wrappedObject, key) && key in this.wrappedObject;
  }
  entries() {
    return mapIterator(this.keys(), (key) => [key, this.get(key)]);
  }
  forEach(callback) {
    for (var key of this.keys()) {
      callback(this.get(key), key, this);
    }
  }
  delete(key) {
    if (isSafeObjectProperty(this.wrappedObject, key)) {
      delete this.wrappedObject[key];
    }
  }
  clear() {
    for (var key of this.keys()) {
      this.delete(key);
    }
  }
  get size() {
    return Object.keys(this.wrappedObject).length;
  }
};
var PartitionedMap = class {
  /**
   * @param {Map} a
   * @param {Map} b
   * @param {Set} bKeys
   */
  constructor(a, b, bKeys) {
    this.a = a;
    this.b = b;
    this.bKeys = bKeys;
    this[Symbol.iterator] = this.entries;
  }
  get(key) {
    return this.bKeys.has(key) ? this.b.get(key) : this.a.get(key);
  }
  set(key, value) {
    if (this.bKeys.has(key)) {
      this.b.set(key, value);
    } else {
      this.a.set(key, value);
    }
    return this;
  }
  has(key) {
    return this.b.has(key) || this.a.has(key);
  }
  keys() {
    return (/* @__PURE__ */ new Set([...this.a.keys(), ...this.b.keys()]))[Symbol.iterator]();
  }
  entries() {
    return mapIterator(this.keys(), (key) => [key, this.get(key)]);
  }
  forEach(callback) {
    for (var key of this.keys()) {
      callback(this.get(key), key, this);
    }
  }
  delete(key) {
    return this.bKeys.has(key) ? this.b.delete(key) : this.a.delete(key);
  }
  clear() {
    this.a.clear();
    this.b.clear();
  }
  get size() {
    return [...this.keys()].length;
  }
};
function mapIterator(it, callback) {
  return {
    next: () => {
      var n = it.next();
      return n.done ? n : {
        value: callback(n.value),
        done: false
      };
    }
  };
}
function createEmptyMap() {
  return /* @__PURE__ */ new Map();
}
function createMap(mapOrObject) {
  if (!mapOrObject) {
    return createEmptyMap();
  }
  if (isMap(mapOrObject)) {
    return mapOrObject;
  }
  if (isObject(mapOrObject)) {
    return new ObjectWrappingMap(mapOrObject);
  }
  throw new Error("createMap can create maps from objects or Maps");
}
function toObject(map3) {
  if (map3 instanceof ObjectWrappingMap) {
    return map3.wrappedObject;
  }
  var object = {};
  for (var key of map3.keys()) {
    var value = map3.get(key);
    setSafeProperty(object, key, value);
  }
  return object;
}

// node_modules/mathjs/lib/esm/utils/is.js
function isNumber(x) {
  return typeof x === "number";
}
function isBigNumber(x) {
  if (!x || typeof x !== "object" || typeof x.constructor !== "function") {
    return false;
  }
  if (x.isBigNumber === true && typeof x.constructor.prototype === "object" && x.constructor.prototype.isBigNumber === true) {
    return true;
  }
  if (typeof x.constructor.isDecimal === "function" && x.constructor.isDecimal(x) === true) {
    return true;
  }
  return false;
}
function isBigInt(x) {
  return typeof x === "bigint";
}
function isComplex(x) {
  return x && typeof x === "object" && Object.getPrototypeOf(x).isComplex === true || false;
}
function isFraction(x) {
  return x && typeof x === "object" && Object.getPrototypeOf(x).isFraction === true || false;
}
function isUnit(x) {
  return x && x.constructor.prototype.isUnit === true || false;
}
function isString(x) {
  return typeof x === "string";
}
var isArray = Array.isArray;
function isMatrix(x) {
  return x && x.constructor.prototype.isMatrix === true || false;
}
function isCollection(x) {
  return Array.isArray(x) || isMatrix(x);
}
function isDenseMatrix(x) {
  return x && x.isDenseMatrix && x.constructor.prototype.isMatrix === true || false;
}
function isSparseMatrix(x) {
  return x && x.isSparseMatrix && x.constructor.prototype.isMatrix === true || false;
}
function isRange(x) {
  return x && x.constructor.prototype.isRange === true || false;
}
function isIndex(x) {
  return x && x.constructor.prototype.isIndex === true || false;
}
function isBoolean(x) {
  return typeof x === "boolean";
}
function isResultSet(x) {
  return x && x.constructor.prototype.isResultSet === true || false;
}
function isHelp(x) {
  return x && x.constructor.prototype.isHelp === true || false;
}
function isFunction(x) {
  return typeof x === "function";
}
function isDate(x) {
  return x instanceof Date;
}
function isRegExp(x) {
  return x instanceof RegExp;
}
function isObject(x) {
  return !!(x && typeof x === "object" && x.constructor === Object && !isComplex(x) && !isFraction(x));
}
function isMap(object) {
  if (!object) {
    return false;
  }
  return object instanceof Map || object instanceof ObjectWrappingMap || typeof object.set === "function" && typeof object.get === "function" && typeof object.keys === "function" && typeof object.has === "function";
}
function isNull(x) {
  return x === null;
}
function isUndefined(x) {
  return x === void 0;
}
function isAccessorNode(x) {
  return x && x.isAccessorNode === true && x.constructor.prototype.isNode === true || false;
}
function isArrayNode(x) {
  return x && x.isArrayNode === true && x.constructor.prototype.isNode === true || false;
}
function isAssignmentNode(x) {
  return x && x.isAssignmentNode === true && x.constructor.prototype.isNode === true || false;
}
function isBlockNode(x) {
  return x && x.isBlockNode === true && x.constructor.prototype.isNode === true || false;
}
function isConditionalNode(x) {
  return x && x.isConditionalNode === true && x.constructor.prototype.isNode === true || false;
}
function isConstantNode(x) {
  return x && x.isConstantNode === true && x.constructor.prototype.isNode === true || false;
}
function rule2Node(node) {
  return isConstantNode(node) || isOperatorNode(node) && node.args.length === 1 && isConstantNode(node.args[0]) && "-+~".includes(node.op);
}
function isFunctionAssignmentNode(x) {
  return x && x.isFunctionAssignmentNode === true && x.constructor.prototype.isNode === true || false;
}
function isFunctionNode(x) {
  return x && x.isFunctionNode === true && x.constructor.prototype.isNode === true || false;
}
function isIndexNode(x) {
  return x && x.isIndexNode === true && x.constructor.prototype.isNode === true || false;
}
function isNode(x) {
  return x && x.isNode === true && x.constructor.prototype.isNode === true || false;
}
function isObjectNode(x) {
  return x && x.isObjectNode === true && x.constructor.prototype.isNode === true || false;
}
function isOperatorNode(x) {
  return x && x.isOperatorNode === true && x.constructor.prototype.isNode === true || false;
}
function isParenthesisNode(x) {
  return x && x.isParenthesisNode === true && x.constructor.prototype.isNode === true || false;
}
function isRangeNode(x) {
  return x && x.isRangeNode === true && x.constructor.prototype.isNode === true || false;
}
function isRelationalNode(x) {
  return x && x.isRelationalNode === true && x.constructor.prototype.isNode === true || false;
}
function isSymbolNode(x) {
  return x && x.isSymbolNode === true && x.constructor.prototype.isNode === true || false;
}
function isChain(x) {
  return x && x.constructor.prototype.isChain === true || false;
}
function typeOf(x) {
  var t = typeof x;
  if (t === "object") {
    if (x === null) return "null";
    if (isBigNumber(x)) return "BigNumber";
    if (x.constructor && x.constructor.name) return x.constructor.name;
    return "Object";
  }
  return t;
}

// node_modules/mathjs/lib/esm/utils/object.js
function clone(x) {
  var type = typeof x;
  if (type === "number" || type === "bigint" || type === "string" || type === "boolean" || x === null || x === void 0) {
    return x;
  }
  if (typeof x.clone === "function") {
    return x.clone();
  }
  if (Array.isArray(x)) {
    return x.map(function(value) {
      return clone(value);
    });
  }
  if (x instanceof Date) return new Date(x.valueOf());
  if (isBigNumber(x)) return x;
  if (isObject(x)) {
    return mapObject(x, clone);
  }
  if (type === "function") {
    return x;
  }
  throw new TypeError("Cannot clone: unknown type of value (value: ".concat(x, ")"));
}
function mapObject(object, callback) {
  var clone6 = {};
  for (var key in object) {
    if (hasOwnProperty(object, key)) {
      clone6[key] = callback(object[key]);
    }
  }
  return clone6;
}
function deepStrictEqual(a, b) {
  var prop, i, len;
  if (Array.isArray(a)) {
    if (!Array.isArray(b)) {
      return false;
    }
    if (a.length !== b.length) {
      return false;
    }
    for (i = 0, len = a.length; i < len; i++) {
      if (!deepStrictEqual(a[i], b[i])) {
        return false;
      }
    }
    return true;
  } else if (typeof a === "function") {
    return a === b;
  } else if (a instanceof Object) {
    if (Array.isArray(b) || !(b instanceof Object)) {
      return false;
    }
    for (prop in a) {
      if (!(prop in b) || !deepStrictEqual(a[prop], b[prop])) {
        return false;
      }
    }
    for (prop in b) {
      if (!(prop in a)) {
        return false;
      }
    }
    return true;
  } else {
    return a === b;
  }
}
function lazy(object, prop, valueResolver) {
  var _uninitialized = true;
  var _value;
  Object.defineProperty(object, prop, {
    get: function get2() {
      if (_uninitialized) {
        _value = valueResolver();
        _uninitialized = false;
      }
      return _value;
    },
    set: function set(value) {
      _value = value;
      _uninitialized = false;
    },
    configurable: true,
    enumerable: true
  });
}
function hasOwnProperty(object, property) {
  return object && Object.hasOwnProperty.call(object, property);
}
function pickShallow(object, properties2) {
  var copy = {};
  for (var i = 0; i < properties2.length; i++) {
    var key = properties2[i];
    var value = object[key];
    if (value !== void 0) {
      copy[key] = value;
    }
  }
  return copy;
}

// node_modules/mathjs/lib/esm/core/function/config.js
var MATRIX_OPTIONS = ["Matrix", "Array"];
var NUMBER_OPTIONS = ["number", "BigNumber", "bigint", "Fraction"];

// node_modules/mathjs/lib/esm/entry/configReadonly.js
var config = function config2(options) {
  if (options) {
    throw new Error("The global config is readonly. \nPlease create a mathjs instance if you want to change the default configuration. \nExample:\n\n  import { create, all } from 'mathjs';\n  const mathjs = create(all);\n  mathjs.config({ number: 'BigNumber' });\n");
  }
  return Object.freeze(DEFAULT_CONFIG);
};
(0, import_extends.default)(config, DEFAULT_CONFIG, {
  MATRIX_OPTIONS,
  NUMBER_OPTIONS
});

// node_modules/mathjs/lib/esm/utils/number.js
function isInteger2(value) {
  if (typeof value === "boolean") {
    return true;
  }
  return Number.isFinite(value) ? value === Math.round(value) : false;
}
function safeNumberType(numberStr, config4) {
  if (config4.number === "bigint") {
    try {
      BigInt(numberStr);
    } catch (_unused) {
      return config4.numberFallback;
    }
  }
  return config4.number;
}
var sign = Math.sign || function(x) {
  if (x > 0) {
    return 1;
  } else if (x < 0) {
    return -1;
  } else {
    return 0;
  }
};
var log2 = Math.log2 || function log22(x) {
  return Math.log(x) / Math.LN2;
};
var log10 = Math.log10 || function log102(x) {
  return Math.log(x) / Math.LN10;
};
var log1p = Math.log1p || function(x) {
  return Math.log(x + 1);
};
var cbrt = Math.cbrt || function cbrt2(x) {
  if (x === 0) {
    return x;
  }
  var negate = x < 0;
  var result;
  if (negate) {
    x = -x;
  }
  if (Number.isFinite(x)) {
    result = Math.exp(Math.log(x) / 3);
    result = (x / (result * result) + 2 * result) / 3;
  } else {
    result = x;
  }
  return negate ? -result : result;
};
var expm1 = Math.expm1 || function expm12(x) {
  return x >= 2e-4 || x <= -2e-4 ? Math.exp(x) - 1 : x + x * x / 2 + x * x * x / 6;
};
function formatNumberToBase(n, base, size2) {
  var prefixes = {
    2: "0b",
    8: "0o",
    16: "0x"
  };
  var prefix = prefixes[base];
  var suffix = "";
  if (size2) {
    if (size2 < 1) {
      throw new Error("size must be in greater than 0");
    }
    if (!isInteger2(size2)) {
      throw new Error("size must be an integer");
    }
    if (n > 2 ** (size2 - 1) - 1 || n < -(2 ** (size2 - 1))) {
      throw new Error("Value must be in range [-2^".concat(size2 - 1, ", 2^").concat(size2 - 1, "-1]"));
    }
    if (!isInteger2(n)) {
      throw new Error("Value must be an integer");
    }
    if (n < 0) {
      n = n + 2 ** size2;
    }
    suffix = "i".concat(size2);
  }
  var sign4 = "";
  if (n < 0) {
    n = -n;
    sign4 = "-";
  }
  return "".concat(sign4).concat(prefix).concat(n.toString(base)).concat(suffix);
}
function format(value, options) {
  if (typeof options === "function") {
    return options(value);
  }
  if (value === Infinity) {
    return "Infinity";
  } else if (value === -Infinity) {
    return "-Infinity";
  } else if (isNaN(value)) {
    return "NaN";
  }
  var {
    notation,
    precision,
    wordSize
  } = normalizeFormatOptions(options);
  switch (notation) {
    case "fixed":
      return toFixed(value, precision);
    case "exponential":
      return toExponential(value, precision);
    case "engineering":
      return toEngineering(value, precision);
    case "bin":
      return formatNumberToBase(value, 2, wordSize);
    case "oct":
      return formatNumberToBase(value, 8, wordSize);
    case "hex":
      return formatNumberToBase(value, 16, wordSize);
    case "auto":
      return toPrecision(value, precision, options).replace(/((\.\d*?)(0+))($|e)/, function() {
        var digits2 = arguments[2];
        var e3 = arguments[4];
        return digits2 !== "." ? digits2 + e3 : e3;
      });
    default:
      throw new Error('Unknown notation "' + notation + '". Choose "auto", "exponential", "fixed", "bin", "oct", or "hex.');
  }
}
function normalizeFormatOptions(options) {
  var notation = "auto";
  var precision;
  var wordSize;
  if (options !== void 0) {
    if (isNumber(options)) {
      precision = options;
    } else if (isBigNumber(options)) {
      precision = options.toNumber();
    } else if (isObject(options)) {
      if (options.precision !== void 0) {
        precision = _toNumberOrThrow(options.precision, () => {
          throw new Error('Option "precision" must be a number or BigNumber');
        });
      }
      if (options.wordSize !== void 0) {
        wordSize = _toNumberOrThrow(options.wordSize, () => {
          throw new Error('Option "wordSize" must be a number or BigNumber');
        });
      }
      if (options.notation) {
        notation = options.notation;
      }
    } else {
      throw new Error("Unsupported type of options, number, BigNumber, or object expected");
    }
  }
  return {
    notation,
    precision,
    wordSize
  };
}
function splitNumber(value) {
  var match = String(value).toLowerCase().match(/^(-?)(\d+\.?\d*)(e([+-]?\d+))?$/);
  if (!match) {
    throw new SyntaxError("Invalid number " + value);
  }
  var sign4 = match[1];
  var digits2 = match[2];
  var exponent = parseFloat(match[4] || "0");
  var dot = digits2.indexOf(".");
  exponent += dot !== -1 ? dot - 1 : digits2.length - 1;
  var coefficients = digits2.replace(".", "").replace(/^0*/, function(zeros2) {
    exponent -= zeros2.length;
    return "";
  }).replace(/0*$/, "").split("").map(function(d) {
    return parseInt(d);
  });
  if (coefficients.length === 0) {
    coefficients.push(0);
    exponent++;
  }
  return {
    sign: sign4,
    coefficients,
    exponent
  };
}
function toEngineering(value, precision) {
  if (isNaN(value) || !Number.isFinite(value)) {
    return String(value);
  }
  var split = splitNumber(value);
  var rounded = roundDigits(split, precision);
  var e3 = rounded.exponent;
  var c = rounded.coefficients;
  var newExp = e3 % 3 === 0 ? e3 : e3 < 0 ? e3 - 3 - e3 % 3 : e3 - e3 % 3;
  if (isNumber(precision)) {
    while (precision > c.length || e3 - newExp + 1 > c.length) {
      c.push(0);
    }
  } else {
    var missingZeros = Math.abs(e3 - newExp) - (c.length - 1);
    for (var i = 0; i < missingZeros; i++) {
      c.push(0);
    }
  }
  var expDiff = Math.abs(e3 - newExp);
  var decimalIdx = 1;
  while (expDiff > 0) {
    decimalIdx++;
    expDiff--;
  }
  var decimals = c.slice(decimalIdx).join("");
  var decimalVal = isNumber(precision) && decimals.length || decimals.match(/[1-9]/) ? "." + decimals : "";
  var str = c.slice(0, decimalIdx).join("") + decimalVal + "e" + (e3 >= 0 ? "+" : "") + newExp.toString();
  return rounded.sign + str;
}
function toFixed(value, precision) {
  if (isNaN(value) || !Number.isFinite(value)) {
    return String(value);
  }
  var splitValue = splitNumber(value);
  var rounded = typeof precision === "number" ? roundDigits(splitValue, splitValue.exponent + 1 + precision) : splitValue;
  var c = rounded.coefficients;
  var p = rounded.exponent + 1;
  var pp = p + (precision || 0);
  if (c.length < pp) {
    c = c.concat(zeros(pp - c.length));
  }
  if (p < 0) {
    c = zeros(-p + 1).concat(c);
    p = 1;
  }
  if (p < c.length) {
    c.splice(p, 0, p === 0 ? "0." : ".");
  }
  return rounded.sign + c.join("");
}
function toExponential(value, precision) {
  if (isNaN(value) || !Number.isFinite(Number(value))) {
    return String(value);
  }
  var split = splitNumber(value);
  var rounded = precision ? roundDigits(split, precision) : split;
  var c = rounded.coefficients;
  var e3 = rounded.exponent;
  if (c.length < precision) {
    c = c.concat(zeros(precision - c.length));
  }
  var first = c.shift();
  return rounded.sign + first + (c.length > 0 ? "." + c.join("") : "") + "e" + (e3 >= 0 ? "+" : "") + e3;
}
function toPrecision(value, precision, options) {
  if (isNaN(value) || !Number.isFinite(value)) {
    return String(value);
  }
  var lowerExp = _toNumberOrDefault(options === null || options === void 0 ? void 0 : options.lowerExp, -3);
  var upperExp = _toNumberOrDefault(options === null || options === void 0 ? void 0 : options.upperExp, 5);
  var split = splitNumber(value);
  var rounded = precision ? roundDigits(split, precision) : split;
  if (rounded.exponent < lowerExp || rounded.exponent >= upperExp) {
    return toExponential(value, precision);
  } else {
    var c = rounded.coefficients;
    var e3 = rounded.exponent;
    if (c.length < precision) {
      c = c.concat(zeros(precision - c.length));
    }
    c = c.concat(zeros(e3 - c.length + 1 + (c.length < precision ? precision - c.length : 0)));
    c = zeros(-e3).concat(c);
    var dot = e3 > 0 ? e3 : 0;
    if (dot < c.length - 1) {
      c.splice(dot + 1, 0, ".");
    }
    return rounded.sign + c.join("");
  }
}
function roundDigits(split, precision) {
  var rounded = {
    sign: split.sign,
    coefficients: split.coefficients,
    exponent: split.exponent
  };
  var c = rounded.coefficients;
  while (precision <= 0) {
    c.unshift(0);
    rounded.exponent++;
    precision++;
  }
  if (c.length > precision) {
    var removed = c.splice(precision, c.length - precision);
    if (removed[0] >= 5) {
      var i = precision - 1;
      c[i]++;
      while (c[i] === 10) {
        c.pop();
        if (i === 0) {
          c.unshift(0);
          rounded.exponent++;
          i++;
        }
        i--;
        c[i]++;
      }
    }
  }
  return rounded;
}
function zeros(length) {
  var arr = [];
  for (var i = 0; i < length; i++) {
    arr.push(0);
  }
  return arr;
}
function digits(value) {
  return value.toExponential().replace(/e.*$/, "").replace(/^0\.?0*|\./, "").length;
}
function nearlyEqual(a, b) {
  var relTol = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1e-8;
  var absTol = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0;
  if (relTol <= 0) {
    throw new Error("Relative tolerance must be greater than 0");
  }
  if (absTol < 0) {
    throw new Error("Absolute tolerance must be at least 0");
  }
  if (isNaN(a) || isNaN(b)) {
    return false;
  }
  if (!Number.isFinite(a) || !Number.isFinite(b)) {
    return a === b;
  }
  if (a === b) {
    return true;
  }
  return Math.abs(a - b) <= Math.max(relTol * Math.max(Math.abs(a), Math.abs(b)), absTol);
}
var acosh = Math.acosh || function(x) {
  return Math.log(Math.sqrt(x * x - 1) + x);
};
var asinh = Math.asinh || function(x) {
  return Math.log(Math.sqrt(x * x + 1) + x);
};
var atanh = Math.atanh || function(x) {
  return Math.log((1 + x) / (1 - x)) / 2;
};
var cosh = Math.cosh || function(x) {
  return (Math.exp(x) + Math.exp(-x)) / 2;
};
var sinh = Math.sinh || function(x) {
  return (Math.exp(x) - Math.exp(-x)) / 2;
};
var tanh = Math.tanh || function(x) {
  var e3 = Math.exp(2 * x);
  return (e3 - 1) / (e3 + 1);
};
function _toNumberOrThrow(value, onError) {
  if (isNumber(value)) {
    return value;
  } else if (isBigNumber(value)) {
    return value.toNumber();
  } else {
    onError();
  }
}
function _toNumberOrDefault(value, defaultValue) {
  if (isNumber(value)) {
    return value;
  } else if (isBigNumber(value)) {
    return value.toNumber();
  } else {
    return defaultValue;
  }
}

// node_modules/mathjs/lib/esm/plain/number/arithmetic.js
var n1 = "number";
var n2 = "number, number";
function absNumber(a) {
  return Math.abs(a);
}
absNumber.signature = n1;
function addNumber(a, b) {
  return a + b;
}
addNumber.signature = n2;
function subtractNumber(a, b) {
  return a - b;
}
subtractNumber.signature = n2;
function multiplyNumber(a, b) {
  return a * b;
}
multiplyNumber.signature = n2;
function divideNumber(a, b) {
  return a / b;
}
divideNumber.signature = n2;
function unaryMinusNumber(x) {
  return -x;
}
unaryMinusNumber.signature = n1;
function unaryPlusNumber(x) {
  return x;
}
unaryPlusNumber.signature = n1;
function cbrtNumber(x) {
  return cbrt(x);
}
cbrtNumber.signature = n1;
function cubeNumber(x) {
  return x * x * x;
}
cubeNumber.signature = n1;
function expNumber(x) {
  return Math.exp(x);
}
expNumber.signature = n1;
function expm1Number(x) {
  return expm1(x);
}
expm1Number.signature = n1;
function gcdNumber(a, b) {
  if (!isInteger2(a) || !isInteger2(b)) {
    throw new Error("Parameters in function gcd must be integer numbers");
  }
  var r;
  while (b !== 0) {
    r = a % b;
    a = b;
    b = r;
  }
  return a < 0 ? -a : a;
}
gcdNumber.signature = n2;
function lcmNumber(a, b) {
  if (!isInteger2(a) || !isInteger2(b)) {
    throw new Error("Parameters in function lcm must be integer numbers");
  }
  if (a === 0 || b === 0) {
    return 0;
  }
  var t;
  var prod2 = a * b;
  while (b !== 0) {
    t = b;
    b = a % t;
    a = t;
  }
  return Math.abs(prod2 / a);
}
lcmNumber.signature = n2;
function logNumber(x, y) {
  if (y) {
    return Math.log(x) / Math.log(y);
  }
  return Math.log(x);
}
function log10Number(x) {
  return log10(x);
}
log10Number.signature = n1;
function log2Number(x) {
  return log2(x);
}
log2Number.signature = n1;
function log1pNumber(x) {
  return log1p(x);
}
log1pNumber.signature = n1;
function modNumber(x, y) {
  return y === 0 ? x : x - y * Math.floor(x / y);
}
modNumber.signature = n2;
function nthRootNumber(a) {
  var root = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 2;
  var inv = root < 0;
  if (inv) {
    root = -root;
  }
  if (root === 0) {
    throw new Error("Root must be non-zero");
  }
  if (a < 0 && Math.abs(root) % 2 !== 1) {
    throw new Error("Root must be odd when a is negative.");
  }
  if (a === 0) {
    return inv ? Infinity : 0;
  }
  if (!isFinite(a)) {
    return inv ? 0 : a;
  }
  var x = Math.pow(Math.abs(a), 1 / root);
  x = a < 0 ? -x : x;
  return inv ? 1 / x : x;
}
function signNumber(x) {
  return sign(x);
}
signNumber.signature = n1;
function sqrtNumber(x) {
  return Math.sqrt(x);
}
sqrtNumber.signature = n1;
function squareNumber(x) {
  return x * x;
}
squareNumber.signature = n1;
function xgcdNumber(a, b) {
  var t;
  var q;
  var r;
  var x = 0;
  var lastx = 1;
  var y = 1;
  var lasty = 0;
  if (!isInteger2(a) || !isInteger2(b)) {
    throw new Error("Parameters in function xgcd must be integer numbers");
  }
  while (b) {
    q = Math.floor(a / b);
    r = a - q * b;
    t = x;
    x = lastx - q * x;
    lastx = t;
    t = y;
    y = lasty - q * y;
    lasty = t;
    a = b;
    b = r;
  }
  var res;
  if (a < 0) {
    res = [-a, -lastx, -lasty];
  } else {
    res = [a, a ? lastx : 0, lasty];
  }
  return res;
}
xgcdNumber.signature = n2;
function powNumber(x, y) {
  if (x * x < 1 && y === Infinity || x * x > 1 && y === -Infinity) {
    return 0;
  }
  return Math.pow(x, y);
}
powNumber.signature = n2;
function roundNumber(value) {
  var decimals = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  if (!isInteger2(decimals) || decimals < 0 || decimals > 15) {
    throw new Error("Number of decimals in function round must be an integer from 0 to 15 inclusive");
  }
  return parseFloat(toFixed(value, decimals));
}
function normNumber(x) {
  return Math.abs(x);
}
normNumber.signature = n1;

// node_modules/mathjs/lib/esm/plain/number/bitwise.js
var n12 = "number";
var n22 = "number, number";
function bitAndNumber(x, y) {
  if (!isInteger2(x) || !isInteger2(y)) {
    throw new Error("Integers expected in function bitAnd");
  }
  return x & y;
}
bitAndNumber.signature = n22;
function bitNotNumber(x) {
  if (!isInteger2(x)) {
    throw new Error("Integer expected in function bitNot");
  }
  return ~x;
}
bitNotNumber.signature = n12;
function bitOrNumber(x, y) {
  if (!isInteger2(x) || !isInteger2(y)) {
    throw new Error("Integers expected in function bitOr");
  }
  return x | y;
}
bitOrNumber.signature = n22;
function bitXorNumber(x, y) {
  if (!isInteger2(x) || !isInteger2(y)) {
    throw new Error("Integers expected in function bitXor");
  }
  return x ^ y;
}
bitXorNumber.signature = n22;
function leftShiftNumber(x, y) {
  if (!isInteger2(x) || !isInteger2(y)) {
    throw new Error("Integers expected in function leftShift");
  }
  return x << y;
}
leftShiftNumber.signature = n22;
function rightArithShiftNumber(x, y) {
  if (!isInteger2(x) || !isInteger2(y)) {
    throw new Error("Integers expected in function rightArithShift");
  }
  return x >> y;
}
rightArithShiftNumber.signature = n22;
function rightLogShiftNumber(x, y) {
  if (!isInteger2(x) || !isInteger2(y)) {
    throw new Error("Integers expected in function rightLogShift");
  }
  return x >>> y;
}
rightLogShiftNumber.signature = n22;

// node_modules/mathjs/lib/esm/utils/product.js
function product(i, n) {
  if (n < i) {
    return 1;
  }
  if (n === i) {
    return n;
  }
  var half = n + i >> 1;
  return product(i, half) * product(half + 1, n);
}

// node_modules/mathjs/lib/esm/plain/number/combinations.js
function combinationsNumber(n, k) {
  if (!isInteger2(n) || n < 0) {
    throw new TypeError("Positive integer value expected in function combinations");
  }
  if (!isInteger2(k) || k < 0) {
    throw new TypeError("Positive integer value expected in function combinations");
  }
  if (k > n) {
    throw new TypeError("k must be less than or equal to n");
  }
  var nMinusk = n - k;
  var answer = 1;
  var firstnumerator = k < nMinusk ? nMinusk + 1 : k + 1;
  var nextdivisor = 2;
  var lastdivisor = k < nMinusk ? k : nMinusk;
  for (var nextnumerator = firstnumerator; nextnumerator <= n; ++nextnumerator) {
    answer *= nextnumerator;
    while (nextdivisor <= lastdivisor && answer % nextdivisor === 0) {
      answer /= nextdivisor;
      ++nextdivisor;
    }
  }
  if (nextdivisor <= lastdivisor) {
    answer /= product(nextdivisor, lastdivisor);
  }
  return answer;
}
combinationsNumber.signature = "number, number";

// node_modules/mathjs/lib/esm/plain/number/constants.js
var pi = Math.PI;
var tau = 2 * Math.PI;
var e = Math.E;
var phi = 1.618033988749895;

// node_modules/mathjs/lib/esm/plain/number/logical.js
var n13 = "number";
var n23 = "number, number";
function notNumber(x) {
  return !x;
}
notNumber.signature = n13;
function orNumber(x, y) {
  return !!(x || y);
}
orNumber.signature = n23;
function xorNumber(x, y) {
  return !!x !== !!y;
}
xorNumber.signature = n23;
function andNumber(x, y) {
  return !!(x && y);
}
andNumber.signature = n23;

// node_modules/mathjs/lib/esm/plain/number/probability.js
function gammaNumber(n) {
  var x;
  if (isInteger2(n)) {
    if (n <= 0) {
      return Number.isFinite(n) ? Infinity : NaN;
    }
    if (n > 171) {
      return Infinity;
    }
    return product(1, n - 1);
  }
  if (n < 0.5) {
    return Math.PI / (Math.sin(Math.PI * n) * gammaNumber(1 - n));
  }
  if (n >= 171.35) {
    return Infinity;
  }
  if (n > 85) {
    var twoN = n * n;
    var threeN = twoN * n;
    var fourN = threeN * n;
    var fiveN = fourN * n;
    return Math.sqrt(2 * Math.PI / n) * Math.pow(n / Math.E, n) * (1 + 1 / (12 * n) + 1 / (288 * twoN) - 139 / (51840 * threeN) - 571 / (2488320 * fourN) + 163879 / (209018880 * fiveN) + 5246819 / (75246796800 * fiveN * n));
  }
  --n;
  x = gammaP[0];
  for (var i = 1; i < gammaP.length; ++i) {
    x += gammaP[i] / (n + i);
  }
  var t = n + gammaG + 0.5;
  return Math.sqrt(2 * Math.PI) * Math.pow(t, n + 0.5) * Math.exp(-t) * x;
}
gammaNumber.signature = "number";
var gammaG = 4.7421875;
var gammaP = [0.9999999999999971, 57.15623566586292, -59.59796035547549, 14.136097974741746, -0.4919138160976202, 3399464998481189e-20, 4652362892704858e-20, -9837447530487956e-20, 1580887032249125e-19, -21026444172410488e-20, 21743961811521265e-20, -1643181065367639e-19, 8441822398385275e-20, -26190838401581408e-21, 36899182659531625e-22];
var lnSqrt2PI = 0.9189385332046728;
var lgammaG = 5;
var lgammaN = 7;
var lgammaSeries = [1.000000000190015, 76.18009172947146, -86.50532032941678, 24.01409824083091, -1.231739572450155, 0.001208650973866179, -5395239384953e-18];
function lgammaNumber(n) {
  if (n < 0) return NaN;
  if (n === 0) return Infinity;
  if (!Number.isFinite(n)) return n;
  if (n < 0.5) {
    return Math.log(Math.PI / Math.sin(Math.PI * n)) - lgammaNumber(1 - n);
  }
  n = n - 1;
  var base = n + lgammaG + 0.5;
  var sum3 = lgammaSeries[0];
  for (var i = lgammaN - 1; i >= 1; i--) {
    sum3 += lgammaSeries[i] / (n + i);
  }
  return lnSqrt2PI + (n + 0.5) * Math.log(base) - base + Math.log(sum3);
}
lgammaNumber.signature = "number";

// node_modules/mathjs/lib/esm/plain/number/trigonometry.js
var n14 = "number";
var n24 = "number, number";
function acosNumber(x) {
  return Math.acos(x);
}
acosNumber.signature = n14;
function acoshNumber(x) {
  return acosh(x);
}
acoshNumber.signature = n14;
function acotNumber(x) {
  return Math.atan(1 / x);
}
acotNumber.signature = n14;
function acothNumber(x) {
  return Number.isFinite(x) ? (Math.log((x + 1) / x) + Math.log(x / (x - 1))) / 2 : 0;
}
acothNumber.signature = n14;
function acscNumber(x) {
  return Math.asin(1 / x);
}
acscNumber.signature = n14;
function acschNumber(x) {
  var xInv = 1 / x;
  return Math.log(xInv + Math.sqrt(xInv * xInv + 1));
}
acschNumber.signature = n14;
function asecNumber(x) {
  return Math.acos(1 / x);
}
asecNumber.signature = n14;
function asechNumber(x) {
  var xInv = 1 / x;
  var ret = Math.sqrt(xInv * xInv - 1);
  return Math.log(ret + xInv);
}
asechNumber.signature = n14;
function asinNumber(x) {
  return Math.asin(x);
}
asinNumber.signature = n14;
function asinhNumber(x) {
  return asinh(x);
}
asinhNumber.signature = n14;
function atanNumber(x) {
  return Math.atan(x);
}
atanNumber.signature = n14;
function atan2Number(y, x) {
  return Math.atan2(y, x);
}
atan2Number.signature = n24;
function atanhNumber(x) {
  return atanh(x);
}
atanhNumber.signature = n14;
function cosNumber(x) {
  return Math.cos(x);
}
cosNumber.signature = n14;
function coshNumber(x) {
  return cosh(x);
}
coshNumber.signature = n14;
function cotNumber(x) {
  return 1 / Math.tan(x);
}
cotNumber.signature = n14;
function cothNumber(x) {
  var e3 = Math.exp(2 * x);
  return (e3 + 1) / (e3 - 1);
}
cothNumber.signature = n14;
function cscNumber(x) {
  return 1 / Math.sin(x);
}
cscNumber.signature = n14;
function cschNumber(x) {
  if (x === 0) {
    return Number.POSITIVE_INFINITY;
  } else {
    return Math.abs(2 / (Math.exp(x) - Math.exp(-x))) * sign(x);
  }
}
cschNumber.signature = n14;
function secNumber(x) {
  return 1 / Math.cos(x);
}
secNumber.signature = n14;
function sechNumber(x) {
  return 2 / (Math.exp(x) + Math.exp(-x));
}
sechNumber.signature = n14;
function sinNumber(x) {
  return Math.sin(x);
}
sinNumber.signature = n14;
function sinhNumber(x) {
  return sinh(x);
}
sinhNumber.signature = n14;
function tanNumber(x) {
  return Math.tan(x);
}
tanNumber.signature = n14;
function tanhNumber(x) {
  return tanh(x);
}
tanhNumber.signature = n14;

// node_modules/mathjs/lib/esm/plain/number/utils.js
var n15 = "number";
function isIntegerNumber(x) {
  return isInteger2(x);
}
isIntegerNumber.signature = n15;
function isNegativeNumber(x) {
  return x < 0;
}
isNegativeNumber.signature = n15;
function isPositiveNumber(x) {
  return x > 0;
}
isPositiveNumber.signature = n15;
function isZeroNumber(x) {
  return x === 0;
}
isZeroNumber.signature = n15;
function isNaNNumber(x) {
  return Number.isNaN(x);
}
isNaNNumber.signature = n15;

// node_modules/mathjs/lib/esm/utils/factory.js
function factory(name114, dependencies102, create, meta) {
  function assertAndCreate(scope) {
    var deps = pickShallow(scope, dependencies102.map(stripOptionalNotation));
    assertDependencies(name114, dependencies102, scope);
    return create(deps);
  }
  assertAndCreate.isFactory = true;
  assertAndCreate.fn = name114;
  assertAndCreate.dependencies = dependencies102.slice().sort();
  if (meta) {
    assertAndCreate.meta = meta;
  }
  return assertAndCreate;
}
function assertDependencies(name114, dependencies102, scope) {
  var allDefined = dependencies102.filter((dependency) => !isOptionalDependency(dependency)).every((dependency) => scope[dependency] !== void 0);
  if (!allDefined) {
    var missingDependencies = dependencies102.filter((dependency) => scope[dependency] === void 0);
    throw new Error('Cannot create function "'.concat(name114, '", ') + "some dependencies are missing: ".concat(missingDependencies.map((d) => '"'.concat(d, '"')).join(", "), "."));
  }
}
function isOptionalDependency(dependency) {
  return dependency && dependency[0] === "?";
}
function stripOptionalNotation(dependency) {
  return dependency && dependency[0] === "?" ? dependency.slice(1) : dependency;
}

// node_modules/mathjs/lib/esm/utils/noop.js
function noBignumber() {
  throw new Error('No "bignumber" implementation available');
}
function noFraction() {
  throw new Error('No "fraction" implementation available');
}
function noMatrix() {
  throw new Error('No "matrix" implementation available');
}
function noIndex() {
  throw new Error('No "index" implementation available');
}
function noSubset() {
  throw new Error('No "matrix" implementation available');
}

// node_modules/mathjs/lib/esm/core/function/typed.js
var import_typed_function = __toESM(require_typed_function(), 1);
var _createTyped2 = function _createTyped() {
  _createTyped2 = import_typed_function.default.create;
  return import_typed_function.default;
};
var dependencies = ["?BigNumber", "?Complex", "?DenseMatrix", "?Fraction"];
var createTyped = /* @__PURE__ */ factory("typed", dependencies, function createTyped2(_ref) {
  var {
    BigNumber,
    Complex,
    DenseMatrix,
    Fraction
  } = _ref;
  var typed3 = _createTyped2();
  typed3.clear();
  typed3.addTypes([
    {
      name: "number",
      test: isNumber
    },
    {
      name: "Complex",
      test: isComplex
    },
    {
      name: "BigNumber",
      test: isBigNumber
    },
    {
      name: "bigint",
      test: isBigInt
    },
    {
      name: "Fraction",
      test: isFraction
    },
    {
      name: "Unit",
      test: isUnit
    },
    // The following type matches a valid variable name, i.e., an alphanumeric
    // string starting with an alphabetic character. It is used (at least)
    // in the definition of the derivative() function, as the argument telling
    // what to differentiate over must (currently) be a variable.
    // TODO: deprecate the identifier type (it's not used anymore, see https://github.com/josdejong/mathjs/issues/3253)
    {
      name: "identifier",
      test: (s) => isString && /^(?:[A-Za-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DC\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDDC0-\uDDF3\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD40-\uDD59\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDD4A-\uDD65\uDD6F-\uDD85\uDE80-\uDEA9\uDEB0\uDEB1\uDEC2-\uDEC7\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61\uDF80-\uDF89\uDF8B\uDF8E\uDF90-\uDFB5\uDFB7\uDFD1\uDFD3]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8\uDFC0-\uDFE0]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDDB0-\uDDDB\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD80E\uD80F\uD81C-\uD822\uD840-\uD868\uD86A-\uD86D\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD88C][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46\uDC60-\uDFFF]|\uD810[\uDC00-\uDFFA]|\uD811[\uDC00-\uDE46]|\uD818[\uDD00-\uDD1D]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDD40-\uDD6C\uDE40-\uDE7F\uDEA0-\uDEB8\uDEBB-\uDED3\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3\uDFF2\uDFF3]|\uD823[\uDC00-\uDCD5\uDCFF-\uDD1E\uDD80-\uDDF2]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDDD0-\uDDED\uDDF0\uDEC0-\uDEDE\uDEE0-\uDEE2\uDEE4\uDEE5\uDEE7-\uDEED\uDEF0-\uDEF4\uDEFE\uDEFF\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEAD\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD88D[\uDC00-\uDC79])(?:[0-9A-Za-z\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088F\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5C\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDC-\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16F1-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u1884\u1887-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C8A\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA7DC\uA7F1-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]|\uD800[\uDC00-\uDC0B\uDC0D-\uDC26\uDC28-\uDC3A\uDC3C\uDC3D\uDC3F-\uDC4D\uDC50-\uDC5D\uDC80-\uDCFA\uDE80-\uDE9C\uDEA0-\uDED0\uDF00-\uDF1F\uDF2D-\uDF40\uDF42-\uDF49\uDF50-\uDF75\uDF80-\uDF9D\uDFA0-\uDFC3\uDFC8-\uDFCF]|\uD801[\uDC00-\uDC9D\uDCB0-\uDCD3\uDCD8-\uDCFB\uDD00-\uDD27\uDD30-\uDD63\uDD70-\uDD7A\uDD7C-\uDD8A\uDD8C-\uDD92\uDD94\uDD95\uDD97-\uDDA1\uDDA3-\uDDB1\uDDB3-\uDDB9\uDDBB\uDDBC\uDDC0-\uDDF3\uDE00-\uDF36\uDF40-\uDF55\uDF60-\uDF67\uDF80-\uDF85\uDF87-\uDFB0\uDFB2-\uDFBA]|\uD802[\uDC00-\uDC05\uDC08\uDC0A-\uDC35\uDC37\uDC38\uDC3C\uDC3F-\uDC55\uDC60-\uDC76\uDC80-\uDC9E\uDCE0-\uDCF2\uDCF4\uDCF5\uDD00-\uDD15\uDD20-\uDD39\uDD40-\uDD59\uDD80-\uDDB7\uDDBE\uDDBF\uDE00\uDE10-\uDE13\uDE15-\uDE17\uDE19-\uDE35\uDE60-\uDE7C\uDE80-\uDE9C\uDEC0-\uDEC7\uDEC9-\uDEE4\uDF00-\uDF35\uDF40-\uDF55\uDF60-\uDF72\uDF80-\uDF91]|\uD803[\uDC00-\uDC48\uDC80-\uDCB2\uDCC0-\uDCF2\uDD00-\uDD23\uDD4A-\uDD65\uDD6F-\uDD85\uDE80-\uDEA9\uDEB0\uDEB1\uDEC2-\uDEC7\uDF00-\uDF1C\uDF27\uDF30-\uDF45\uDF70-\uDF81\uDFB0-\uDFC4\uDFE0-\uDFF6]|\uD804[\uDC03-\uDC37\uDC71\uDC72\uDC75\uDC83-\uDCAF\uDCD0-\uDCE8\uDD03-\uDD26\uDD44\uDD47\uDD50-\uDD72\uDD76\uDD83-\uDDB2\uDDC1-\uDDC4\uDDDA\uDDDC\uDE00-\uDE11\uDE13-\uDE2B\uDE3F\uDE40\uDE80-\uDE86\uDE88\uDE8A-\uDE8D\uDE8F-\uDE9D\uDE9F-\uDEA8\uDEB0-\uDEDE\uDF05-\uDF0C\uDF0F\uDF10\uDF13-\uDF28\uDF2A-\uDF30\uDF32\uDF33\uDF35-\uDF39\uDF3D\uDF50\uDF5D-\uDF61\uDF80-\uDF89\uDF8B\uDF8E\uDF90-\uDFB5\uDFB7\uDFD1\uDFD3]|\uD805[\uDC00-\uDC34\uDC47-\uDC4A\uDC5F-\uDC61\uDC80-\uDCAF\uDCC4\uDCC5\uDCC7\uDD80-\uDDAE\uDDD8-\uDDDB\uDE00-\uDE2F\uDE44\uDE80-\uDEAA\uDEB8\uDF00-\uDF1A\uDF40-\uDF46]|\uD806[\uDC00-\uDC2B\uDCA0-\uDCDF\uDCFF-\uDD06\uDD09\uDD0C-\uDD13\uDD15\uDD16\uDD18-\uDD2F\uDD3F\uDD41\uDDA0-\uDDA7\uDDAA-\uDDD0\uDDE1\uDDE3\uDE00\uDE0B-\uDE32\uDE3A\uDE50\uDE5C-\uDE89\uDE9D\uDEB0-\uDEF8\uDFC0-\uDFE0]|\uD807[\uDC00-\uDC08\uDC0A-\uDC2E\uDC40\uDC72-\uDC8F\uDD00-\uDD06\uDD08\uDD09\uDD0B-\uDD30\uDD46\uDD60-\uDD65\uDD67\uDD68\uDD6A-\uDD89\uDD98\uDDB0-\uDDDB\uDEE0-\uDEF2\uDF02\uDF04-\uDF10\uDF12-\uDF33\uDFB0]|\uD808[\uDC00-\uDF99]|\uD809[\uDC80-\uDD43]|\uD80B[\uDF90-\uDFF0]|[\uD80C\uD80E\uD80F\uD81C-\uD822\uD840-\uD868\uD86A-\uD86D\uD86F-\uD872\uD874-\uD879\uD880-\uD883\uD885-\uD88C][\uDC00-\uDFFF]|\uD80D[\uDC00-\uDC2F\uDC41-\uDC46\uDC60-\uDFFF]|\uD810[\uDC00-\uDFFA]|\uD811[\uDC00-\uDE46]|\uD818[\uDD00-\uDD1D]|\uD81A[\uDC00-\uDE38\uDE40-\uDE5E\uDE70-\uDEBE\uDED0-\uDEED\uDF00-\uDF2F\uDF40-\uDF43\uDF63-\uDF77\uDF7D-\uDF8F]|\uD81B[\uDD40-\uDD6C\uDE40-\uDE7F\uDEA0-\uDEB8\uDEBB-\uDED3\uDF00-\uDF4A\uDF50\uDF93-\uDF9F\uDFE0\uDFE1\uDFE3\uDFF2\uDFF3]|\uD823[\uDC00-\uDCD5\uDCFF-\uDD1E\uDD80-\uDDF2]|\uD82B[\uDFF0-\uDFF3\uDFF5-\uDFFB\uDFFD\uDFFE]|\uD82C[\uDC00-\uDD22\uDD32\uDD50-\uDD52\uDD55\uDD64-\uDD67\uDD70-\uDEFB]|\uD82F[\uDC00-\uDC6A\uDC70-\uDC7C\uDC80-\uDC88\uDC90-\uDC99]|\uD835[\uDC00-\uDC54\uDC56-\uDC9C\uDC9E\uDC9F\uDCA2\uDCA5\uDCA6\uDCA9-\uDCAC\uDCAE-\uDCB9\uDCBB\uDCBD-\uDCC3\uDCC5-\uDD05\uDD07-\uDD0A\uDD0D-\uDD14\uDD16-\uDD1C\uDD1E-\uDD39\uDD3B-\uDD3E\uDD40-\uDD44\uDD46\uDD4A-\uDD50\uDD52-\uDEA5\uDEA8-\uDEC0\uDEC2-\uDEDA\uDEDC-\uDEFA\uDEFC-\uDF14\uDF16-\uDF34\uDF36-\uDF4E\uDF50-\uDF6E\uDF70-\uDF88\uDF8A-\uDFA8\uDFAA-\uDFC2\uDFC4-\uDFCB]|\uD837[\uDF00-\uDF1E\uDF25-\uDF2A]|\uD838[\uDC30-\uDC6D\uDD00-\uDD2C\uDD37-\uDD3D\uDD4E\uDE90-\uDEAD\uDEC0-\uDEEB]|\uD839[\uDCD0-\uDCEB\uDDD0-\uDDED\uDDF0\uDEC0-\uDEDE\uDEE0-\uDEE2\uDEE4\uDEE5\uDEE7-\uDEED\uDEF0-\uDEF4\uDEFE\uDEFF\uDFE0-\uDFE6\uDFE8-\uDFEB\uDFED\uDFEE\uDFF0-\uDFFE]|\uD83A[\uDC00-\uDCC4\uDD00-\uDD43\uDD4B]|\uD83B[\uDE00-\uDE03\uDE05-\uDE1F\uDE21\uDE22\uDE24\uDE27\uDE29-\uDE32\uDE34-\uDE37\uDE39\uDE3B\uDE42\uDE47\uDE49\uDE4B\uDE4D-\uDE4F\uDE51\uDE52\uDE54\uDE57\uDE59\uDE5B\uDE5D\uDE5F\uDE61\uDE62\uDE64\uDE67-\uDE6A\uDE6C-\uDE72\uDE74-\uDE77\uDE79-\uDE7C\uDE7E\uDE80-\uDE89\uDE8B-\uDE9B\uDEA1-\uDEA3\uDEA5-\uDEA9\uDEAB-\uDEBB]|\uD869[\uDC00-\uDEDF\uDF00-\uDFFF]|\uD86E[\uDC00-\uDC1D\uDC20-\uDFFF]|\uD873[\uDC00-\uDEAD\uDEB0-\uDFFF]|\uD87A[\uDC00-\uDFE0\uDFF0-\uDFFF]|\uD87B[\uDC00-\uDE5D]|\uD87E[\uDC00-\uDE1D]|\uD884[\uDC00-\uDF4A\uDF50-\uDFFF]|\uD88D[\uDC00-\uDC79])*$/.test(s)
    },
    {
      name: "string",
      test: isString
    },
    {
      name: "Chain",
      test: isChain
    },
    {
      name: "Array",
      test: isArray
    },
    {
      name: "Matrix",
      test: isMatrix
    },
    {
      name: "DenseMatrix",
      test: isDenseMatrix
    },
    {
      name: "SparseMatrix",
      test: isSparseMatrix
    },
    {
      name: "Range",
      test: isRange
    },
    {
      name: "Index",
      test: isIndex
    },
    {
      name: "boolean",
      test: isBoolean
    },
    {
      name: "ResultSet",
      test: isResultSet
    },
    {
      name: "Help",
      test: isHelp
    },
    {
      name: "function",
      test: isFunction
    },
    {
      name: "Date",
      test: isDate
    },
    {
      name: "RegExp",
      test: isRegExp
    },
    {
      name: "null",
      test: isNull
    },
    {
      name: "undefined",
      test: isUndefined
    },
    {
      name: "AccessorNode",
      test: isAccessorNode
    },
    {
      name: "ArrayNode",
      test: isArrayNode
    },
    {
      name: "AssignmentNode",
      test: isAssignmentNode
    },
    {
      name: "BlockNode",
      test: isBlockNode
    },
    {
      name: "ConditionalNode",
      test: isConditionalNode
    },
    {
      name: "ConstantNode",
      test: isConstantNode
    },
    {
      name: "FunctionNode",
      test: isFunctionNode
    },
    {
      name: "FunctionAssignmentNode",
      test: isFunctionAssignmentNode
    },
    {
      name: "IndexNode",
      test: isIndexNode
    },
    {
      name: "Node",
      test: isNode
    },
    {
      name: "ObjectNode",
      test: isObjectNode
    },
    {
      name: "OperatorNode",
      test: isOperatorNode
    },
    {
      name: "ParenthesisNode",
      test: isParenthesisNode
    },
    {
      name: "RangeNode",
      test: isRangeNode
    },
    {
      name: "RelationalNode",
      test: isRelationalNode
    },
    {
      name: "SymbolNode",
      test: isSymbolNode
    },
    {
      name: "Map",
      test: isMap
    },
    {
      name: "Object",
      test: isObject
    }
    // order 'Object' last, it matches on other classes too
  ]);
  typed3.addConversions([{
    from: "number",
    to: "BigNumber",
    convert: function convert(x) {
      if (!BigNumber) {
        throwNoBignumber(x);
      }
      if (digits(x) > 15) {
        throw new TypeError("Cannot implicitly convert a number with >15 significant digits to BigNumber (value: " + x + "). Use function bignumber(x) to convert to BigNumber.");
      }
      return new BigNumber(x);
    }
  }, {
    from: "number",
    to: "Complex",
    convert: function convert(x) {
      if (!Complex) {
        throwNoComplex(x);
      }
      return new Complex(x, 0);
    }
  }, {
    from: "BigNumber",
    to: "Complex",
    convert: function convert(x) {
      if (!Complex) {
        throwNoComplex(x);
      }
      return new Complex(x.toNumber(), 0);
    }
  }, {
    from: "bigint",
    to: "number",
    convert: function convert(x) {
      if (x > Number.MAX_SAFE_INTEGER) {
        throw new TypeError("Cannot implicitly convert bigint to number: value exceeds the max safe integer value (value: " + x + ")");
      }
      return Number(x);
    }
  }, {
    from: "bigint",
    to: "BigNumber",
    convert: function convert(x) {
      if (!BigNumber) {
        throwNoBignumber(x);
      }
      return new BigNumber(x.toString());
    }
  }, {
    from: "bigint",
    to: "Fraction",
    convert: function convert(x) {
      if (!Fraction) {
        throwNoFraction(x);
      }
      return new Fraction(x);
    }
  }, {
    from: "Fraction",
    to: "BigNumber",
    convert: function convert(x) {
      throw new TypeError("Cannot implicitly convert a Fraction to BigNumber or vice versa. Use function bignumber(x) to convert to BigNumber or fraction(x) to convert to Fraction.");
    }
  }, {
    from: "Fraction",
    to: "Complex",
    convert: function convert(x) {
      if (!Complex) {
        throwNoComplex(x);
      }
      return new Complex(x.valueOf(), 0);
    }
  }, {
    from: "number",
    to: "Fraction",
    convert: function convert(x) {
      if (!Fraction) {
        throwNoFraction(x);
      }
      var f = new Fraction(x);
      if (f.valueOf() !== x) {
        throw new TypeError("Cannot implicitly convert a number to a Fraction when there will be a loss of precision (value: " + x + "). Use function fraction(x) to convert to Fraction.");
      }
      return f;
    }
  }, {
    // FIXME: add conversion from Fraction to number, for example for `sqrt(fraction(1,3))`
    //  from: 'Fraction',
    //  to: 'number',
    //  convert: function (x) {
    //    return x.valueOf()
    //  }
    // }, {
    from: "string",
    to: "number",
    convert: function convert(x) {
      var n = Number(x);
      if (isNaN(n)) {
        throw new Error('Cannot convert "' + x + '" to a number');
      }
      return n;
    }
  }, {
    from: "string",
    to: "BigNumber",
    convert: function convert(x) {
      if (!BigNumber) {
        throwNoBignumber(x);
      }
      try {
        return new BigNumber(x);
      } catch (err) {
        throw new Error('Cannot convert "' + x + '" to BigNumber');
      }
    }
  }, {
    from: "string",
    to: "bigint",
    convert: function convert(x) {
      try {
        return BigInt(x);
      } catch (err) {
        throw new Error('Cannot convert "' + x + '" to BigInt');
      }
    }
  }, {
    from: "string",
    to: "Fraction",
    convert: function convert(x) {
      if (!Fraction) {
        throwNoFraction(x);
      }
      try {
        return new Fraction(x);
      } catch (err) {
        throw new Error('Cannot convert "' + x + '" to Fraction');
      }
    }
  }, {
    from: "string",
    to: "Complex",
    convert: function convert(x) {
      if (!Complex) {
        throwNoComplex(x);
      }
      try {
        return new Complex(x);
      } catch (err) {
        throw new Error('Cannot convert "' + x + '" to Complex');
      }
    }
  }, {
    from: "boolean",
    to: "number",
    convert: function convert(x) {
      return +x;
    }
  }, {
    from: "boolean",
    to: "BigNumber",
    convert: function convert(x) {
      if (!BigNumber) {
        throwNoBignumber(x);
      }
      return new BigNumber(+x);
    }
  }, {
    from: "boolean",
    to: "bigint",
    convert: function convert(x) {
      return BigInt(+x);
    }
  }, {
    from: "boolean",
    to: "Fraction",
    convert: function convert(x) {
      if (!Fraction) {
        throwNoFraction(x);
      }
      return new Fraction(+x);
    }
  }, {
    from: "boolean",
    to: "string",
    convert: function convert(x) {
      return String(x);
    }
  }, {
    from: "Array",
    to: "Matrix",
    convert: function convert(array) {
      if (!DenseMatrix) {
        throwNoMatrix();
      }
      return new DenseMatrix(array);
    }
  }, {
    from: "Matrix",
    to: "Array",
    convert: function convert(matrix2) {
      return matrix2.valueOf();
    }
  }]);
  typed3.onMismatch = (name114, args, signatures) => {
    var usualError = typed3.createError(name114, args, signatures);
    if (["wrongType", "mismatch"].includes(usualError.data.category) && args.length === 1 && isCollection(args[0]) && // check if the function can be unary:
    signatures.some((sig) => !sig.params.includes(","))) {
      var err = new TypeError("Function '".concat(name114, "' doesn't apply to matrices. To call it ") + "elementwise on a matrix 'M', try 'map(M, ".concat(name114, ")'."));
      err.data = usualError.data;
      throw err;
    }
    throw usualError;
  };
  typed3.onMismatch = (name114, args, signatures) => {
    var usualError = typed3.createError(name114, args, signatures);
    if (["wrongType", "mismatch"].includes(usualError.data.category) && args.length === 1 && isCollection(args[0]) && // check if the function can be unary:
    signatures.some((sig) => !sig.params.includes(","))) {
      var err = new TypeError("Function '".concat(name114, "' doesn't apply to matrices. To call it ") + "elementwise on a matrix 'M', try 'map(M, ".concat(name114, ")'."));
      err.data = usualError.data;
      throw err;
    }
    throw usualError;
  };
  return typed3;
});
function throwNoBignumber(x) {
  throw new Error("Cannot convert value ".concat(x, " into a BigNumber: no class 'BigNumber' provided"));
}
function throwNoComplex(x) {
  throw new Error("Cannot convert value ".concat(x, " into a Complex number: no class 'Complex' provided"));
}
function throwNoMatrix() {
  throw new Error("Cannot convert array into a Matrix: no class 'DenseMatrix' provided");
}
function throwNoFraction(x) {
  throw new Error("Cannot convert value ".concat(x, " into a Fraction, no class 'Fraction' provided."));
}

// node_modules/mathjs/lib/esm/type/resultset/ResultSet.js
var name = "ResultSet";
var dependencies2 = [];
var createResultSet = /* @__PURE__ */ factory(name, dependencies2, () => {
  function ResultSet2(entries) {
    if (!(this instanceof ResultSet2)) {
      throw new SyntaxError("Constructor must be called with the new operator");
    }
    this.entries = entries || [];
  }
  ResultSet2.prototype.type = "ResultSet";
  ResultSet2.prototype.isResultSet = true;
  ResultSet2.prototype.valueOf = function() {
    return this.entries;
  };
  ResultSet2.prototype.toString = function() {
    return "[" + this.entries.map(String).join(", ") + "]";
  };
  ResultSet2.prototype.toJSON = function() {
    return {
      mathjs: "ResultSet",
      entries: this.entries
    };
  };
  ResultSet2.fromJSON = function(json) {
    return new ResultSet2(json.entries);
  };
  return ResultSet2;
}, {
  isClass: true
});

// node_modules/mathjs/lib/esm/type/matrix/Range.js
var name2 = "Range";
var dependencies3 = [];
var createRangeClass = /* @__PURE__ */ factory(name2, dependencies3, () => {
  function Range2(start, end, step) {
    if (!(this instanceof Range2)) {
      throw new SyntaxError("Constructor must be called with the new operator");
    }
    var hasStart = start !== null && start !== void 0;
    var hasEnd = end !== null && end !== void 0;
    var hasStep = step !== null && step !== void 0;
    if (hasStart) {
      if (isBigNumber(start)) {
        start = start.toNumber();
      } else if (typeof start !== "number" && !isBigInt(start)) {
        throw new TypeError("Parameter start must be a number or bigint");
      }
    }
    if (hasEnd) {
      if (isBigNumber(end)) {
        end = end.toNumber();
      } else if (typeof end !== "number" && !isBigInt(end)) {
        throw new TypeError("Parameter end must be a number or bigint");
      }
    }
    if (hasStep) {
      if (isBigNumber(step)) {
        step = step.toNumber();
      } else if (typeof step !== "number" && !isBigInt(step)) {
        throw new TypeError("Parameter step must be a number or bigint");
      }
    }
    this.start = hasStart ? parseFloat(start) : 0;
    this.end = hasEnd ? parseFloat(end) : 0;
    this.step = hasStep ? parseFloat(step) : 1;
    if (hasStep && nearlyEqual(this.step, 0)) {
      throw new Error("Step must not be zero");
    }
  }
  Range2.prototype.type = "Range";
  Range2.prototype.isRange = true;
  Range2.parse = function(str) {
    if (typeof str !== "string") {
      return null;
    }
    var args = str.split(":");
    var nums = args.map(function(arg) {
      return parseFloat(arg);
    });
    var invalid = nums.some(function(num) {
      return isNaN(num);
    });
    if (invalid) {
      return null;
    }
    switch (nums.length) {
      case 2:
        return new Range2(nums[0], nums[1]);
      case 3:
        return new Range2(nums[0], nums[2], nums[1]);
      default:
        return null;
    }
  };
  Range2.prototype.clone = function() {
    return new Range2(this.start, this.end, this.step);
  };
  Range2.prototype.size = function() {
    var len = 0;
    var start = this.start;
    var step = this.step;
    var end = this.end;
    var diff = end - start;
    if (sign(step) === sign(diff)) {
      len = Math.ceil(diff / step);
    } else if (diff === 0) {
      len = 0;
    }
    if (isNaN(len)) {
      len = 0;
    }
    return [len];
  };
  Range2.prototype.min = function() {
    var size2 = this.size()[0];
    if (size2 > 0) {
      if (this.step > 0) {
        return this.start;
      } else {
        return this.start + (size2 - 1) * this.step;
      }
    } else {
      return void 0;
    }
  };
  Range2.prototype.max = function() {
    var size2 = this.size()[0];
    if (size2 > 0) {
      if (this.step > 0) {
        return this.start + (size2 - 1) * this.step;
      } else {
        return this.start;
      }
    } else {
      return void 0;
    }
  };
  Range2.prototype.forEach = function(callback) {
    var x = this.start;
    var step = this.step;
    var end = this.end;
    var i = 0;
    if (step > 0) {
      while (x < end) {
        callback(x, [i], this);
        x += step;
        i++;
      }
    } else if (step < 0) {
      while (x > end) {
        callback(x, [i], this);
        x += step;
        i++;
      }
    }
  };
  Range2.prototype.map = function(callback) {
    var array = [];
    this.forEach(function(value, index2, obj) {
      array[index2[0]] = callback(value, index2, obj);
    });
    return array;
  };
  Range2.prototype.toArray = function() {
    var array = [];
    this.forEach(function(value, index2) {
      array[index2[0]] = value;
    });
    return array;
  };
  Range2.prototype.valueOf = function() {
    return this.toArray();
  };
  Range2.prototype.format = function(options) {
    var str = format(this.start, options);
    if (this.step !== 1) {
      str += ":" + format(this.step, options);
    }
    str += ":" + format(this.end, options);
    return str;
  };
  Range2.prototype.toString = function() {
    return this.format();
  };
  Range2.prototype.toJSON = function() {
    return {
      mathjs: "Range",
      start: this.start,
      end: this.end,
      step: this.step
    };
  };
  Range2.fromJSON = function(json) {
    return new Range2(json.start, json.end, json.step);
  };
  return Range2;
}, {
  isClass: true
});

// node_modules/mathjs/lib/esm/utils/bignumber/formatter.js
function formatBigNumberToBase(n, base, size2) {
  var BigNumberCtor = n.constructor;
  var big2 = new BigNumberCtor(2);
  var suffix = "";
  if (size2) {
    if (size2 < 1) {
      throw new Error("size must be in greater than 0");
    }
    if (!isInteger2(size2)) {
      throw new Error("size must be an integer");
    }
    if (n.greaterThan(big2.pow(size2 - 1).sub(1)) || n.lessThan(big2.pow(size2 - 1).mul(-1))) {
      throw new Error("Value must be in range [-2^".concat(size2 - 1, ", 2^").concat(size2 - 1, "-1]"));
    }
    if (!n.isInteger()) {
      throw new Error("Value must be an integer");
    }
    if (n.lessThan(0)) {
      n = n.add(big2.pow(size2));
    }
    suffix = "i".concat(size2);
  }
  switch (base) {
    case 2:
      return "".concat(n.toBinary()).concat(suffix);
    case 8:
      return "".concat(n.toOctal()).concat(suffix);
    case 16:
      return "".concat(n.toHexadecimal()).concat(suffix);
    default:
      throw new Error("Base ".concat(base, " not supported "));
  }
}
function format2(value, options) {
  if (typeof options === "function") {
    return options(value);
  }
  if (!value.isFinite()) {
    return value.isNaN() ? "NaN" : value.gt(0) ? "Infinity" : "-Infinity";
  }
  var {
    notation,
    precision,
    wordSize
  } = normalizeFormatOptions(options);
  switch (notation) {
    case "fixed":
      return toFixed2(value, precision);
    case "exponential":
      return toExponential2(value, precision);
    case "engineering":
      return toEngineering2(value, precision);
    case "bin":
      return formatBigNumberToBase(value, 2, wordSize);
    case "oct":
      return formatBigNumberToBase(value, 8, wordSize);
    case "hex":
      return formatBigNumberToBase(value, 16, wordSize);
    case "auto": {
      var lowerExp = _toNumberOrDefault2(options === null || options === void 0 ? void 0 : options.lowerExp, -3);
      var upperExp = _toNumberOrDefault2(options === null || options === void 0 ? void 0 : options.upperExp, 5);
      if (value.isZero()) return "0";
      var str;
      var rounded = value.toSignificantDigits(precision);
      var exp3 = rounded.e;
      if (exp3 >= lowerExp && exp3 < upperExp) {
        str = rounded.toFixed();
      } else {
        str = toExponential2(value, precision);
      }
      return str.replace(/((\.\d*?)(0+))($|e)/, function() {
        var digits2 = arguments[2];
        var e3 = arguments[4];
        return digits2 !== "." ? digits2 + e3 : e3;
      });
    }
    default:
      throw new Error('Unknown notation "' + notation + '". Choose "auto", "exponential", "fixed", "bin", "oct", or "hex.');
  }
}
function toEngineering2(value, precision) {
  var e3 = value.e;
  var newExp = e3 % 3 === 0 ? e3 : e3 < 0 ? e3 - 3 - e3 % 3 : e3 - e3 % 3;
  var valueWithoutExp = value.mul(Math.pow(10, -newExp));
  var valueStr = valueWithoutExp.toPrecision(precision);
  if (valueStr.includes("e")) {
    var BigNumber = value.constructor;
    valueStr = new BigNumber(valueStr).toFixed();
  }
  return valueStr + "e" + (e3 >= 0 ? "+" : "") + newExp.toString();
}
function toExponential2(value, precision) {
  if (precision !== void 0) {
    return value.toExponential(precision - 1);
  } else {
    return value.toExponential();
  }
}
function toFixed2(value, precision) {
  return value.toFixed(precision);
}
function _toNumberOrDefault2(value, defaultValue) {
  if (isNumber(value)) {
    return value;
  } else if (isBigNumber(value)) {
    return value.toNumber();
  } else {
    return defaultValue;
  }
}

// node_modules/mathjs/lib/esm/utils/string.js
function format3(value, options) {
  var result = _format(value, options);
  if (options && typeof options === "object" && "truncate" in options && result.length > options.truncate) {
    return result.substring(0, options.truncate - 3) + "...";
  }
  return result;
}
function _format(value, options) {
  if (typeof value === "number") {
    return format(value, options);
  }
  if (isBigNumber(value)) {
    return format2(value, options);
  }
  if (looksLikeFraction(value)) {
    if (!options || options.fraction !== "decimal") {
      return "".concat(value.s * value.n, "/").concat(value.d);
    } else {
      return value.toString();
    }
  }
  if (Array.isArray(value)) {
    return formatArray(value, options);
  }
  if (isString(value)) {
    return stringify(value);
  }
  if (typeof value === "function") {
    return value.syntax ? String(value.syntax) : "function";
  }
  if (value && typeof value === "object") {
    if (typeof value.format === "function") {
      return value.format(options);
    } else if (value && value.toString(options) !== {}.toString()) {
      return value.toString(options);
    } else {
      var entries = Object.keys(value).map((key) => {
        return stringify(key) + ": " + format3(value[key], options);
      });
      return "{" + entries.join(", ") + "}";
    }
  }
  return String(value);
}
function stringify(value) {
  var text = String(value);
  var escaped = "";
  var i = 0;
  while (i < text.length) {
    var c = text.charAt(i);
    escaped += c in controlCharacters ? controlCharacters[c] : c;
    i++;
  }
  return '"' + escaped + '"';
}
var controlCharacters = {
  '"': '\\"',
  "\\": "\\\\",
  "\b": "\\b",
  "\f": "\\f",
  "\n": "\\n",
  "\r": "\\r",
  "	": "\\t"
};
function escape(value) {
  var text = String(value);
  text = text.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return text;
}
function formatArray(array, options) {
  if (Array.isArray(array)) {
    var str = "[";
    var len = array.length;
    for (var i = 0; i < len; i++) {
      if (i !== 0) {
        str += ", ";
      }
      str += formatArray(array[i], options);
    }
    str += "]";
    return str;
  } else {
    return format3(array, options);
  }
}
function looksLikeFraction(value) {
  return value && typeof value === "object" && typeof value.s === "bigint" && typeof value.n === "bigint" && typeof value.d === "bigint" || false;
}
function compareText(x, y) {
  if (!isString(x)) {
    throw new TypeError("Unexpected type of argument in function compareText (expected: string or Array or Matrix, actual: " + typeOf(x) + ", index: 0)");
  }
  if (!isString(y)) {
    throw new TypeError("Unexpected type of argument in function compareText (expected: string or Array or Matrix, actual: " + typeOf(y) + ", index: 1)");
  }
  return x === y ? 0 : x > y ? 1 : -1;
}

// node_modules/mathjs/lib/esm/expression/Help.js
var name3 = "Help";
var dependencies4 = ["evaluate"];
var createHelpClass = /* @__PURE__ */ factory(name3, dependencies4, (_ref) => {
  var {
    evaluate: evaluate2
  } = _ref;
  function Help2(doc) {
    if (!(this instanceof Help2)) {
      throw new SyntaxError("Constructor must be called with the new operator");
    }
    if (!doc) throw new Error('Argument "doc" missing');
    this.doc = doc;
  }
  Help2.prototype.type = "Help";
  Help2.prototype.isHelp = true;
  Help2.prototype.toString = function() {
    var doc = this.doc || {};
    var desc = "\n";
    if (doc.name) {
      desc += "Name: " + doc.name + "\n\n";
    }
    if (doc.category) {
      desc += "Category: " + doc.category + "\n\n";
    }
    if (doc.description) {
      desc += "Description:\n    " + doc.description + "\n\n";
    }
    if (doc.syntax) {
      desc += "Syntax:\n    " + doc.syntax.join("\n    ") + "\n\n";
    }
    if (doc.examples) {
      desc += "Examples:\n";
      var configChanged = false;
      var originalConfig = evaluate2("config()");
      var scope = {
        config: (newConfig) => {
          configChanged = true;
          return evaluate2("config(newConfig)", {
            newConfig
          });
        }
      };
      for (var i = 0; i < doc.examples.length; i++) {
        var expr = doc.examples[i];
        desc += "    " + expr + "\n";
        var res = void 0;
        try {
          res = evaluate2(expr, scope);
        } catch (e3) {
          res = e3;
        }
        if (res !== void 0 && !isHelp(res)) {
          desc += "        " + format3(res, {
            precision: 14
          }) + "\n";
        }
      }
      desc += "\n";
      if (configChanged) {
        evaluate2("config(originalConfig)", {
          originalConfig
        });
      }
    }
    if (doc.mayThrow && doc.mayThrow.length) {
      desc += "Throws: " + doc.mayThrow.join(", ") + "\n\n";
    }
    if (doc.seealso && doc.seealso.length) {
      desc += "See also: " + doc.seealso.join(", ") + "\n";
    }
    return desc;
  };
  Help2.prototype.toJSON = function() {
    var obj = clone(this.doc);
    obj.mathjs = "Help";
    return obj;
  };
  Help2.fromJSON = function(json) {
    var doc = {};
    Object.keys(json).filter((prop) => prop !== "mathjs").forEach((prop) => {
      doc[prop] = json[prop];
    });
    return new Help2(doc);
  };
  Help2.prototype.valueOf = Help2.prototype.toString;
  return Help2;
}, {
  isClass: true
});

// node_modules/mathjs/lib/esm/type/chain/Chain.js
var name4 = "Chain";
var dependencies5 = ["?on", "math", "typed"];
var createChainClass = /* @__PURE__ */ factory(name4, dependencies5, (_ref) => {
  var {
    on,
    math: math2,
    typed: typed3
  } = _ref;
  function Chain2(value) {
    if (!(this instanceof Chain2)) {
      throw new SyntaxError("Constructor must be called with the new operator");
    }
    if (isChain(value)) {
      this.value = value.value;
    } else {
      this.value = value;
    }
  }
  Chain2.prototype.type = "Chain";
  Chain2.prototype.isChain = true;
  Chain2.prototype.done = function() {
    return this.value;
  };
  Chain2.prototype.valueOf = function() {
    return this.value;
  };
  Chain2.prototype.toString = function() {
    return format3(this.value);
  };
  Chain2.prototype.toJSON = function() {
    return {
      mathjs: "Chain",
      value: this.value
    };
  };
  Chain2.fromJSON = function(json) {
    return new Chain2(json.value);
  };
  function createProxy(name114, fn) {
    if (typeof fn === "function") {
      Chain2.prototype[name114] = chainify(fn);
    }
  }
  function createLazyProxy(name114, resolver) {
    lazy(Chain2.prototype, name114, function outerResolver() {
      var fn = resolver();
      if (typeof fn === "function") {
        return chainify(fn);
      }
      return void 0;
    });
  }
  function chainify(fn) {
    return function() {
      if (arguments.length === 0) {
        return new Chain2(fn(this.value));
      }
      var args = [this.value];
      for (var i = 0; i < arguments.length; i++) {
        args[i + 1] = arguments[i];
      }
      if (typed3.isTypedFunction(fn)) {
        var sigObject = typed3.resolve(fn, args);
        if (sigObject.params.length === 1) {
          throw new Error("chain function " + fn.name + " cannot match rest parameter between chain value and additional arguments.");
        }
        return new Chain2(sigObject.implementation.apply(fn, args));
      }
      return new Chain2(fn.apply(fn, args));
    };
  }
  Chain2.createProxy = function(arg0, arg1) {
    if (typeof arg0 === "string") {
      createProxy(arg0, arg1);
    } else {
      var _loop = function _loop2(_name2) {
        if (hasOwnProperty(arg0, _name2) && excludedNames[_name2] === void 0) {
          createLazyProxy(_name2, () => arg0[_name2]);
        }
      };
      for (var _name in arg0) {
        _loop(_name);
      }
    }
  };
  var excludedNames = {
    expression: true,
    docs: true,
    type: true,
    classes: true,
    json: true,
    error: true,
    isChain: true
    // conflicts with the property isChain of a Chain instance
  };
  Chain2.createProxy(math2);
  if (on) {
    on("import", function(name114, resolver, path) {
      if (!path) {
        createLazyProxy(name114, resolver);
      }
    });
  }
  return Chain2;
}, {
  isClass: true
});

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/e.js
var eDocs = {
  name: "e",
  category: "Constants",
  syntax: ["e"],
  description: "Euler's number, the base of the natural logarithm. Approximately equal to 2.71828",
  examples: ["e", "e ^ 2", "exp(2)", "log(e)"],
  seealso: ["exp"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/false.js
var falseDocs = {
  name: "false",
  category: "Constants",
  syntax: ["false"],
  description: "Boolean value false",
  examples: ["false"],
  seealso: ["true"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/i.js
var iDocs = {
  name: "i",
  category: "Constants",
  syntax: ["i"],
  description: "Imaginary unit, defined as i*i=-1. A complex number is described as a + b*i, where a is the real part, and b is the imaginary part.",
  examples: ["i", "i * i", "sqrt(-1)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/Infinity.js
var InfinityDocs = {
  name: "Infinity",
  category: "Constants",
  syntax: ["Infinity"],
  description: "Infinity, a number which is larger than the maximum number that can be handled by a floating point number.",
  examples: ["Infinity", "1 / 0"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/LN10.js
var LN10Docs = {
  name: "LN10",
  category: "Constants",
  syntax: ["LN10"],
  description: "Returns the natural logarithm of 10, approximately equal to 2.302",
  examples: ["LN10", "log(10)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/LN2.js
var LN2Docs = {
  name: "LN2",
  category: "Constants",
  syntax: ["LN2"],
  description: "Returns the natural logarithm of 2, approximately equal to 0.693",
  examples: ["LN2", "log(2)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/LOG10E.js
var LOG10EDocs = {
  name: "LOG10E",
  category: "Constants",
  syntax: ["LOG10E"],
  description: "Returns the base-10 logarithm of E, approximately equal to 0.434",
  examples: ["LOG10E", "log(e, 10)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/LOG2E.js
var LOG2EDocs = {
  name: "LOG2E",
  category: "Constants",
  syntax: ["LOG2E"],
  description: "Returns the base-2 logarithm of E, approximately equal to 1.442",
  examples: ["LOG2E", "log(e, 2)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/NaN.js
var NaNDocs = {
  name: "NaN",
  category: "Constants",
  syntax: ["NaN"],
  description: "Not a number",
  examples: ["NaN", "0 / 0"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/null.js
var nullDocs = {
  name: "null",
  category: "Constants",
  syntax: ["null"],
  description: "Value null",
  examples: ["null"],
  seealso: ["true", "false"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/phi.js
var phiDocs = {
  name: "phi",
  category: "Constants",
  syntax: ["phi"],
  description: "Phi is the golden ratio. Two quantities are in the golden ratio if their ratio is the same as the ratio of their sum to the larger of the two quantities. Phi is defined as `(1 + sqrt(5)) / 2` and is approximately 1.618034...",
  examples: ["phi"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/pi.js
var piDocs = {
  name: "pi",
  category: "Constants",
  syntax: ["pi"],
  description: "The number pi is a mathematical constant that is the ratio of a circle's circumference to its diameter, and is approximately equal to 3.14159",
  examples: ["pi", "sin(pi/2)"],
  seealso: ["tau"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/SQRT1_2.js
var SQRT12Docs = {
  name: "SQRT1_2",
  category: "Constants",
  syntax: ["SQRT1_2"],
  description: "Returns the square root of 1/2, approximately equal to 0.707",
  examples: ["SQRT1_2", "sqrt(1/2)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/SQRT2.js
var SQRT2Docs = {
  name: "SQRT2",
  category: "Constants",
  syntax: ["SQRT2"],
  description: "Returns the square root of 2, approximately equal to 1.414",
  examples: ["SQRT2", "sqrt(2)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/tau.js
var tauDocs = {
  name: "tau",
  category: "Constants",
  syntax: ["tau"],
  description: "Tau is the ratio constant of a circle's circumference to radius, equal to 2 * pi, approximately 6.2832.",
  examples: ["tau", "2 * pi"],
  seealso: ["pi"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/true.js
var trueDocs = {
  name: "true",
  category: "Constants",
  syntax: ["true"],
  description: "Boolean value true",
  examples: ["true"],
  seealso: ["false"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/constants/version.js
var versionDocs = {
  name: "version",
  category: "Constants",
  syntax: ["version"],
  description: "A string with the version number of math.js",
  examples: ["version"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/bignumber.js
var bignumberDocs = {
  name: "bignumber",
  category: "Construction",
  syntax: ["bignumber(x)"],
  description: "Create a big number from a number or string.",
  examples: ["0.1 + 0.2", "bignumber(0.1) + bignumber(0.2)", 'bignumber("7.2")', 'bignumber("7.2e500")', "bignumber([0.1, 0.2, 0.3])"],
  seealso: ["boolean", "bigint", "complex", "fraction", "index", "matrix", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/bigint.js
var bigintDocs = {
  name: "bigint",
  category: "Construction",
  syntax: ["bigint(x)"],
  description: "Create a bigint, an integer with an arbitrary number of digits, from a number or string.",
  examples: ["123123123123123123 # a large number will lose digits", 'bigint("123123123123123123")', 'bignumber(["1", "3", "5"])'],
  seealso: ["boolean", "bignumber", "number", "complex", "fraction", "index", "matrix", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/boolean.js
var booleanDocs = {
  name: "boolean",
  category: "Construction",
  syntax: ["x", "boolean(x)"],
  description: "Convert a string or number into a boolean.",
  examples: ["boolean(0)", "boolean(1)", "boolean(3)", 'boolean("true")', 'boolean("false")', "boolean([1, 0, 1, 1])"],
  seealso: ["bignumber", "complex", "index", "matrix", "number", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/complex.js
var complexDocs = {
  name: "complex",
  category: "Construction",
  syntax: ["complex()", "complex(re, im)", "complex(string)"],
  description: "Create a complex number.",
  examples: ["complex()", "complex(2, 3)", 'complex("7 - 2i")'],
  seealso: ["bignumber", "boolean", "index", "matrix", "number", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/createUnit.js
var createUnitDocs = {
  name: "createUnit",
  category: "Construction",
  syntax: ["createUnit(definitions)", "createUnit(name, definition)"],
  description: "Create a user-defined unit and register it with the Unit type.",
  examples: ['createUnit("foo")', 'createUnit("knot", {definition: "0.514444444 m/s", aliases: ["knots", "kt", "kts"]})', 'createUnit("mph", "1 mile/hour")'],
  seealso: ["unit", "splitUnit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/fraction.js
var fractionDocs = {
  name: "fraction",
  category: "Construction",
  syntax: ["fraction(num)", "fraction(matrix)", "fraction(num,den)", "fraction({n: num, d: den})"],
  description: "Create a fraction from a number or from integer numerator and denominator.",
  examples: ["fraction(0.125)", "fraction(1, 3) + fraction(2, 5)", "fraction({n: 333, d: 53})", "fraction([sqrt(9), sqrt(10), sqrt(11)])"],
  seealso: ["bignumber", "boolean", "complex", "index", "matrix", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/index.js
var indexDocs = {
  name: "index",
  category: "Construction",
  syntax: ["[start]", "[start:end]", "[start:step:end]", "[start1, start 2, ...]", "[start1:end1, start2:end2, ...]", "[start1:step1:end1, start2:step2:end2, ...]"],
  description: "Create an index to get or replace a subset of a matrix",
  examples: ["A = [1, 2, 3; 4, 5, 6]", "A[1, :]", "A[1, 2] = 50", "A[1:2, 1:2] = 1", "B = [1, 2, 3]", "B[B>1 and B<3]"],
  seealso: ["bignumber", "boolean", "complex", "matrix", "number", "range", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/matrix.js
var matrixDocs = {
  name: "matrix",
  category: "Construction",
  syntax: ["[]", "[a1, b1, ...; a2, b2, ...]", "matrix()", 'matrix("dense")', "matrix([...])"],
  description: "Create a matrix.",
  examples: ["[]", "[1, 2, 3]", "[1, 2, 3; 4, 5, 6]", "matrix()", "matrix([3, 4])", 'matrix([3, 4; 5, 6], "sparse")', 'matrix([3, 4; 5, 6], "sparse", "number")'],
  seealso: ["bignumber", "boolean", "complex", "index", "number", "string", "unit", "sparse"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/number.js
var numberDocs = {
  name: "number",
  category: "Construction",
  syntax: ["x", "number(x)", "number(unit, valuelessUnit)"],
  description: "Create a number or convert a string or boolean into a number.",
  examples: ["2", "2e3", "4.05", "number(2)", 'number("7.2")', "number(true)", "number([true, false, true, true])", 'number(unit("52cm"), "m")'],
  seealso: ["bignumber", "bigint", "boolean", "complex", "fraction", "index", "matrix", "string", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/sparse.js
var sparseDocs = {
  name: "sparse",
  category: "Construction",
  syntax: ["sparse()", "sparse([a1, b1, ...; a1, b2, ...])", 'sparse([a1, b1, ...; a1, b2, ...], "number")'],
  description: "Create a sparse matrix.",
  examples: ["sparse()", "sparse([3, 4; 5, 6])", 'sparse([3, 0; 5, 0], "number")'],
  seealso: ["bignumber", "boolean", "complex", "index", "number", "string", "unit", "matrix"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/splitUnit.js
var splitUnitDocs = {
  name: "splitUnit",
  category: "Construction",
  syntax: ["splitUnit(unit: Unit, parts: Unit[])"],
  description: "Split a unit in an array of units whose sum is equal to the original unit.",
  examples: ['splitUnit(1 m, ["feet", "inch"])'],
  seealso: ["unit", "createUnit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/string.js
var stringDocs = {
  name: "string",
  category: "Construction",
  syntax: ['"text"', "string(x)"],
  description: "Create a string or convert a value to a string",
  examples: ['"Hello World!"', "string(4.2)", "string(3 + 2i)"],
  seealso: ["bignumber", "boolean", "complex", "index", "matrix", "number", "unit"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/construction/unit.js
var unitDocs = {
  name: "unit",
  category: "Construction",
  syntax: ["value unit", "unit(value, unit)", "unit(string)"],
  description: "Create a unit.",
  examples: ["5.5 mm", "3 inch", 'unit(7.1, "kilogram")', 'unit("23 deg")'],
  seealso: ["bignumber", "boolean", "complex", "index", "matrix", "number", "string"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/core/config.js
var configDocs = {
  name: "config",
  category: "Core",
  syntax: ["config()", "config(options)"],
  description: "Get configuration or change configuration.",
  examples: ["config()", "1/3 + 1/4", 'config({number: "Fraction"})', "1/3 + 1/4"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/core/import.js
var importDocs = {
  name: "import",
  category: "Core",
  syntax: ["import(functions)", "import(functions, options)"],
  description: "Import functions or constants from an object.",
  examples: ["import({myFn: f(x)=x^2, myConstant: 32 })", "myFn(2)", "myConstant"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/core/typed.js
var typedDocs = {
  name: "typed",
  category: "Core",
  syntax: ["typed(signatures)", "typed(name, signatures)"],
  description: "Create a typed function.",
  examples: ['double = typed({ "number": f(x)=x+x, "string": f(x)=concat(x,x) })', "double(2)", 'double("hello")'],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/derivative.js
var derivativeDocs = {
  name: "derivative",
  category: "Algebra",
  syntax: ["derivative(expr, variable)", "derivative(expr, variable, {simplify: boolean})"],
  description: "Takes the derivative of an expression expressed in parser Nodes. The derivative will be taken over the supplied variable in the second parameter. If there are multiple variables in the expression, it will return a partial derivative.",
  examples: ['derivative("2x^3", "x")', 'derivative("2x^3", "x", {simplify: false})', 'derivative("2x^2 + 3x + 4", "x")', 'derivative("sin(2x)", "x")', 'f = parse("x^2 + x")', 'x = parse("x")', "df = derivative(f, x)", "df.evaluate({x: 3})"],
  seealso: ["simplify", "parse", "evaluate"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/leafCount.js
var leafCountDocs = {
  name: "leafCount",
  category: "Algebra",
  syntax: ["leafCount(expr)"],
  description: "Computes the number of leaves in the parse tree of the given expression",
  examples: ['leafCount("e^(i*pi)-1")', 'leafCount(parse("{a: 22/7, b: 10^(1/2)}"))'],
  seealso: ["simplify"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/lsolve.js
var lsolveDocs = {
  name: "lsolve",
  category: "Algebra",
  syntax: ["x=lsolve(L, b)"],
  description: "Finds one solution of the linear system L * x = b where L is an [n x n] lower triangular matrix and b is a [n] column vector.",
  examples: ["a = [-2, 3; 2, 1]", "b = [11, 9]", "x = lsolve(a, b)"],
  seealso: ["lsolveAll", "lup", "lusolve", "usolve", "matrix", "sparse"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/lsolveAll.js
var lsolveAllDocs = {
  name: "lsolveAll",
  category: "Algebra",
  syntax: ["x=lsolveAll(L, b)"],
  description: "Finds all solutions of the linear system L * x = b where L is an [n x n] lower triangular matrix and b is a [n] column vector.",
  examples: ["a = [-2, 3; 2, 1]", "b = [11, 9]", "x = lsolve(a, b)"],
  seealso: ["lsolve", "lup", "lusolve", "usolve", "matrix", "sparse"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/lup.js
var lupDocs = {
  name: "lup",
  category: "Algebra",
  syntax: ["lup(m)"],
  description: "Calculate the Matrix LU decomposition with partial pivoting. Matrix A is decomposed in three matrices (L, U, P) where P * A = L * U",
  examples: ["lup([[2, 1], [1, 4]])", "lup(matrix([[2, 1], [1, 4]]))", "lup(sparse([[2, 1], [1, 4]]))"],
  seealso: ["lusolve", "lsolve", "usolve", "matrix", "sparse", "slu", "qr"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/lusolve.js
var lusolveDocs = {
  name: "lusolve",
  category: "Algebra",
  syntax: ["x=lusolve(A, b)", "x=lusolve(lu, b)"],
  description: "Solves the linear system A * x = b where A is an [n x n] matrix and b is a [n] column vector.",
  examples: ["a = [-2, 3; 2, 1]", "b = [11, 9]", "x = lusolve(a, b)"],
  seealso: ["lup", "slu", "lsolve", "usolve", "matrix", "sparse"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/polynomialRoot.js
var polynomialRootDocs = {
  name: "polynomialRoot",
  category: "Algebra",
  syntax: ["x=polynomialRoot(-6, 3)", "x=polynomialRoot(4, -4, 1)", "x=polynomialRoot(-8, 12, -6, 1)"],
  description: "Finds the roots of a univariate polynomial given by its coefficients starting from constant, linear, and so on, increasing in degree.",
  examples: ["a = polynomialRoot(-6, 11, -6, 1)"],
  seealso: ["cbrt", "sqrt"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/qr.js
var qrDocs = {
  name: "qr",
  category: "Algebra",
  syntax: ["qr(A)"],
  description: "Calculates the Matrix QR decomposition. Matrix `A` is decomposed in two matrices (`Q`, `R`) where `Q` is an orthogonal matrix and `R` is an upper triangular matrix.",
  examples: ["qr([[1, -1,  4], [1,  4, -2], [1,  4,  2], [1,  -1, 0]])"],
  seealso: ["lup", "slu", "matrix"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/rationalize.js
var rationalizeDocs = {
  name: "rationalize",
  category: "Algebra",
  syntax: ["rationalize(expr)", "rationalize(expr, scope)", "rationalize(expr, scope, detailed)"],
  description: "Transform a rationalizable expression in a rational fraction. If rational fraction is one variable polynomial then converts the numerator and denominator in canonical form, with decreasing exponents, returning the coefficients of numerator.",
  examples: ['rationalize("2x/y - y/(x+1)")', 'rationalize("2x/y - y/(x+1)", true)'],
  seealso: ["simplify"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/resolve.js
var resolveDocs = {
  name: "resolve",
  category: "Algebra",
  syntax: ["resolve(node, scope)"],
  description: "Recursively substitute variables in an expression tree.",
  examples: ['resolve(parse("1 + x"), { x: 7 })', 'resolve(parse("size(text)"), { text: "Hello World" })', 'resolve(parse("x + y"), { x: parse("3z") })', 'resolve(parse("3x"), { x: parse("y+z"), z: parse("w^y") })'],
  seealso: ["simplify", "evaluate"],
  mayThrow: ["ReferenceError"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/simplify.js
var simplifyDocs = {
  name: "simplify",
  category: "Algebra",
  syntax: ["simplify(expr)", "simplify(expr, rules)"],
  description: "Simplify an expression tree.",
  examples: ['simplify("3 + 2 / 4")', 'simplify("2x + x")', 'f = parse("x * (x + 2 + x)")', "simplified = simplify(f)", "simplified.evaluate({x: 2})"],
  seealso: ["simplifyCore", "derivative", "evaluate", "parse", "rationalize", "resolve"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/simplifyConstant.js
var simplifyConstantDocs = {
  name: "simplifyConstant",
  category: "Algebra",
  syntax: ["simplifyConstant(expr)", "simplifyConstant(expr, options)"],
  description: "Replace constant subexpressions of node with their values.",
  examples: ['simplifyConstant("(3-3)*x")', 'simplifyConstant(parse("z-cos(tau/8)"))'],
  seealso: ["simplify", "simplifyCore", "evaluate"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/simplifyCore.js
var simplifyCoreDocs = {
  name: "simplifyCore",
  category: "Algebra",
  syntax: ["simplifyCore(node)"],
  description: "Perform simple one-pass simplifications on an expression tree.",
  examples: ['simplifyCore(parse("0*x"))', 'simplifyCore(parse("(x+0)*2"))'],
  seealso: ["simplify", "simplifyConstant", "evaluate"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/slu.js
var sluDocs = {
  name: "slu",
  category: "Algebra",
  syntax: ["slu(A, order, threshold)"],
  description: "Calculate the Matrix LU decomposition with full pivoting. Matrix A is decomposed in two matrices (L, U) and two permutation vectors (pinv, q) where P * A * Q = L * U",
  examples: ["slu(sparse([4.5, 0, 3.2, 0; 3.1, 2.9, 0, 0.9; 0, 1.7, 3, 0; 3.5, 0.4, 0, 1]), 1, 0.001)"],
  seealso: ["lusolve", "lsolve", "usolve", "matrix", "sparse", "lup", "qr"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/symbolicEqual.js
var symbolicEqualDocs = {
  name: "symbolicEqual",
  category: "Algebra",
  syntax: ["symbolicEqual(expr1, expr2)", "symbolicEqual(expr1, expr2, options)"],
  description: "Returns true if the difference of the expressions simplifies to 0",
  examples: ['symbolicEqual("x*y","y*x")', 'symbolicEqual("abs(x^2)", "x^2")', 'symbolicEqual("abs(x)", "x", {context: {abs: {trivial: true}}})'],
  seealso: ["simplify", "evaluate"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/usolve.js
var usolveDocs = {
  name: "usolve",
  category: "Algebra",
  syntax: ["x=usolve(U, b)"],
  description: "Finds one solution of the linear system U * x = b where U is an [n x n] upper triangular matrix and b is a [n] column vector.",
  examples: ["x=usolve(sparse([1, 1, 1, 1; 0, 1, 1, 1; 0, 0, 1, 1; 0, 0, 0, 1]), [1; 2; 3; 4])"],
  seealso: ["usolveAll", "lup", "lusolve", "lsolve", "matrix", "sparse"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/usolveAll.js
var usolveAllDocs = {
  name: "usolveAll",
  category: "Algebra",
  syntax: ["x=usolve(U, b)"],
  description: "Finds all solutions of the linear system U * x = b where U is an [n x n] upper triangular matrix and b is a [n] column vector.",
  examples: ["x=usolve(sparse([1, 1, 1, 1; 0, 1, 1, 1; 0, 0, 1, 1; 0, 0, 0, 1]), [1; 2; 3; 4])"],
  seealso: ["usolve", "lup", "lusolve", "lsolve", "matrix", "sparse"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/abs.js
var absDocs = {
  name: "abs",
  category: "Arithmetic",
  syntax: ["abs(x)"],
  description: "Compute the absolute value.",
  examples: ["abs(3.5)", "abs(-4.2)"],
  seealso: ["sign"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/add.js
var addDocs = {
  name: "add",
  category: "Operators",
  syntax: ["x + y", "add(x, y)"],
  description: "Add two values.",
  examples: ["a = 2.1 + 3.6", "a - 3.6", "3 + 2i", "3 cm + 2 inch", '"2.3" + "4"'],
  seealso: ["subtract"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/cbrt.js
var cbrtDocs = {
  name: "cbrt",
  category: "Arithmetic",
  syntax: ["cbrt(x)", "cbrt(x, allRoots)"],
  description: "Compute the cubic root value. If x = y * y * y, then y is the cubic root of x. When `x` is a number or complex number, an optional second argument `allRoots` can be provided to return all three cubic roots. If not provided, the principal root is returned",
  examples: ["cbrt(64)", "cube(4)", "cbrt(-8)", "cbrt(2 + 3i)", "cbrt(8i)", "cbrt(8i, true)", "cbrt(27 m^3)"],
  seealso: ["square", "sqrt", "cube", "multiply"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/ceil.js
var ceilDocs = {
  name: "ceil",
  category: "Arithmetic",
  syntax: ["ceil(x)", "ceil(x, n)", "ceil(unit, valuelessUnit)", "ceil(unit, n, valuelessUnit)"],
  description: "Round a value towards plus infinity. If x is complex, both real and imaginary part are rounded towards plus infinity.",
  examples: ["ceil(3.2)", "ceil(3.8)", "ceil(-4.2)", "ceil(3.241cm, cm)", "ceil(3.241cm, 2, cm)"],
  seealso: ["floor", "fix", "round"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/cube.js
var cubeDocs = {
  name: "cube",
  category: "Arithmetic",
  syntax: ["cube(x)"],
  description: "Compute the cube of a value. The cube of x is x * x * x.",
  examples: ["cube(2)", "2^3", "2 * 2 * 2"],
  seealso: ["multiply", "square", "pow"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/divide.js
var divideDocs = {
  name: "divide",
  category: "Operators",
  syntax: ["x / y", "divide(x, y)"],
  description: "Divide two values.",
  examples: ["a = 2 / 3", "a * 3", "4.5 / 2", "3 + 4 / 2", "(3 + 4) / 2", "18 km / 4.5"],
  seealso: ["multiply"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/dotDivide.js
var dotDivideDocs = {
  name: "dotDivide",
  category: "Operators",
  syntax: ["x ./ y", "dotDivide(x, y)"],
  description: "Divide two values element wise.",
  examples: ["a = [1, 2, 3; 4, 5, 6]", "b = [2, 1, 1; 3, 2, 5]", "a ./ b"],
  seealso: ["multiply", "dotMultiply", "divide"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/dotMultiply.js
var dotMultiplyDocs = {
  name: "dotMultiply",
  category: "Operators",
  syntax: ["x .* y", "dotMultiply(x, y)"],
  description: "Multiply two values element wise.",
  examples: ["a = [1, 2, 3; 4, 5, 6]", "b = [2, 1, 1; 3, 2, 5]", "a .* b"],
  seealso: ["multiply", "divide", "dotDivide"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/dotPow.js
var dotPowDocs = {
  name: "dotPow",
  category: "Operators",
  syntax: ["x .^ y", "dotPow(x, y)"],
  description: "Calculates the power of x to y element wise.",
  examples: ["a = [1, 2, 3; 4, 5, 6]", "a .^ 2"],
  seealso: ["pow"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/exp.js
var expDocs = {
  name: "exp",
  category: "Arithmetic",
  syntax: ["exp(x)"],
  description: "Calculate the exponent of a value.",
  examples: ["exp(1.3)", "e ^ 1.3", "log(exp(1.3))", "x = 2.4", "(exp(i*x) == cos(x) + i*sin(x))   # Euler's formula"],
  seealso: ["expm", "expm1", "pow", "log"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/expm.js
var expmDocs = {
  name: "expm",
  category: "Arithmetic",
  syntax: ["exp(x)"],
  description: "Compute the matrix exponential, expm(A) = e^A. The matrix must be square. Not to be confused with exp(a), which performs element-wise exponentiation.",
  examples: ["expm([[0,2],[0,0]])"],
  seealso: ["exp"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/expm1.js
var expm1Docs = {
  name: "expm1",
  category: "Arithmetic",
  syntax: ["expm1(x)"],
  description: "Calculate the value of subtracting 1 from the exponential value.",
  examples: ["expm1(2)", "pow(e, 2) - 1", "log(expm1(2) + 1)"],
  seealso: ["exp", "pow", "log"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/fix.js
var fixDocs = {
  name: "fix",
  category: "Arithmetic",
  syntax: ["fix(x)", "fix(x, n)", "fix(unit, valuelessUnit)", "fix(unit, n, valuelessUnit)"],
  description: "Round a value towards zero. If x is complex, both real and imaginary part are rounded towards zero.",
  examples: ["fix(3.2)", "fix(3.8)", "fix(-4.2)", "fix(-4.8)", "fix(3.241cm, cm)", "fix(3.241cm, 2, cm)"],
  seealso: ["ceil", "floor", "round"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/floor.js
var floorDocs = {
  name: "floor",
  category: "Arithmetic",
  syntax: ["floor(x)", "floor(x, n)", "floor(unit, valuelessUnit)", "floor(unit, n, valuelessUnit)"],
  description: "Round a value towards minus infinity.If x is complex, both real and imaginary part are rounded towards minus infinity.",
  examples: ["floor(3.2)", "floor(3.8)", "floor(-4.2)", "floor(3.241cm, cm)", "floor(3.241cm, 2, cm)"],
  seealso: ["ceil", "fix", "round"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/gcd.js
var gcdDocs = {
  name: "gcd",
  category: "Arithmetic",
  syntax: ["gcd(a, b)", "gcd(a, b, c, ...)"],
  description: "Compute the greatest common divisor.",
  examples: ["gcd(8, 12)", "gcd(-4, 6)", "gcd(25, 15, -10)"],
  seealso: ["lcm", "xgcd"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/hypot.js
var hypotDocs = {
  name: "hypot",
  category: "Arithmetic",
  syntax: ["hypot(a, b, c, ...)", "hypot([a, b, c, ...])"],
  description: "Calculate the hypotenuse of a list with values.",
  examples: ["hypot(3, 4)", "sqrt(3^2 + 4^2)", "hypot(-2)", "hypot([3, 4, 5])"],
  seealso: ["abs", "norm"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/invmod.js
var invmodDocs = {
  name: "invmod",
  category: "Arithmetic",
  syntax: ["invmod(a, b)"],
  description: "Calculate the (modular) multiplicative inverse of a modulo b. Solution to the equation ax \u2263 1 (mod b)",
  examples: ["invmod(8, 12)", "invmod(7, 13)", "invmod(15151, 15122)"],
  seealso: ["gcd", "xgcd"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/lcm.js
var lcmDocs = {
  name: "lcm",
  category: "Arithmetic",
  syntax: ["lcm(x, y)"],
  description: "Compute the least common multiple.",
  examples: ["lcm(4, 6)", "lcm(6, 21)", "lcm(6, 21, 5)"],
  seealso: ["gcd"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/log.js
var logDocs = {
  name: "log",
  category: "Arithmetic",
  syntax: ["log(x)", "log(x, base)"],
  description: "Compute the logarithm of a value. If no base is provided, the natural logarithm of x is calculated. If base if provided, the logarithm is calculated for the specified base. log(x, base) is defined as log(x) / log(base).",
  examples: ["log(3.5)", "a = log(2.4)", "exp(a)", "10 ^ 4", "log(10000, 10)", "log(10000) / log(10)", "b = log(1024, 2)", "2 ^ b"],
  seealso: ["exp", "log1p", "log2", "log10"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/log10.js
var log10Docs = {
  name: "log10",
  category: "Arithmetic",
  syntax: ["log10(x)"],
  description: "Compute the 10-base logarithm of a value.",
  examples: ["log10(0.00001)", "log10(10000)", "10 ^ 4", "log(10000) / log(10)", "log(10000, 10)"],
  seealso: ["exp", "log"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/log1p.js
var log1pDocs = {
  name: "log1p",
  category: "Arithmetic",
  syntax: ["log1p(x)", "log1p(x, base)"],
  description: "Calculate the logarithm of a `value+1`",
  examples: ["log1p(2.5)", "exp(log1p(1.4))", "pow(10, 4)", "log1p(9999, 10)", "log1p(9999) / log(10)"],
  seealso: ["exp", "log", "log2", "log10"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/log2.js
var log2Docs = {
  name: "log2",
  category: "Arithmetic",
  syntax: ["log2(x)"],
  description: "Calculate the 2-base of a value. This is the same as calculating `log(x, 2)`.",
  examples: ["log2(0.03125)", "log2(16)", "log2(16) / log2(2)", "pow(2, 4)"],
  seealso: ["exp", "log1p", "log", "log10"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/mod.js
var modDocs = {
  name: "mod",
  category: "Operators",
  syntax: ["x % y", "x mod y", "mod(x, y)"],
  description: "Calculates the modulus, the remainder of an integer division.",
  examples: ["7 % 3", "11 % 2", "10 mod 4", "isOdd(x) = x % 2", "isOdd(2)", "isOdd(3)"],
  seealso: ["divide"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/multiply.js
var multiplyDocs = {
  name: "multiply",
  category: "Operators",
  syntax: ["x * y", "multiply(x, y)"],
  description: "multiply two values.",
  examples: ["a = 2.1 * 3.4", "a / 3.4", "2 * 3 + 4", "2 * (3 + 4)", "3 * 2.1 km"],
  seealso: ["divide"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/norm.js
var normDocs = {
  name: "norm",
  category: "Arithmetic",
  syntax: ["norm(x)", "norm(x, p)"],
  description: "Calculate the norm of a number, vector or matrix.",
  examples: ["abs(-3.5)", "norm(-3.5)", "norm(3 - 4i)", "norm([1, 2, -3], Infinity)", "norm([1, 2, -3], -Infinity)", "norm([3, 4], 2)", "norm([[1, 2], [3, 4]], 1)", 'norm([[1, 2], [3, 4]], "inf")', 'norm([[1, 2], [3, 4]], "fro")']
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/nthRoot.js
var nthRootDocs = {
  name: "nthRoot",
  category: "Arithmetic",
  syntax: ["nthRoot(a)", "nthRoot(a, root)"],
  description: 'Calculate the nth root of a value. The principal nth root of a positive real number A, is the positive real solution of the equation "x^root = A".',
  examples: ["4 ^ 3", "nthRoot(64, 3)", "nthRoot(9, 2)", "sqrt(9)"],
  seealso: ["nthRoots", "pow", "sqrt"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/nthRoots.js
var nthRootsDocs = {
  name: "nthRoots",
  category: "Arithmetic",
  syntax: ["nthRoots(A)", "nthRoots(A, root)"],
  description: 'Calculate the nth roots of a value. An nth root of a positive real number A, is a positive real solution of the equation "x^root = A". This function returns an array of complex values.',
  examples: ["nthRoots(1)", "nthRoots(1, 3)"],
  seealso: ["sqrt", "pow", "nthRoot"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/pow.js
var powDocs = {
  name: "pow",
  category: "Operators",
  syntax: ["x ^ y", "pow(x, y)"],
  description: "Calculates the power of x to y, x^y.",
  examples: ["2^3", "2*2*2", "1 + e ^ (pi * i)", "pow([[1, 2], [4, 3]], 2)", "pow([[1, 2], [4, 3]], -1)"],
  seealso: ["multiply", "nthRoot", "nthRoots", "sqrt"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/round.js
var roundDocs = {
  name: "round",
  category: "Arithmetic",
  syntax: ["round(x)", "round(x, n)", "round(unit, valuelessUnit)", "round(unit, n, valuelessUnit)"],
  description: "round a value towards the nearest integer.If x is complex, both real and imaginary part are rounded towards the nearest integer. When n is specified, the value is rounded to n decimals.",
  examples: ["round(3.2)", "round(3.8)", "round(-4.2)", "round(-4.8)", "round(pi, 3)", "round(123.45678, 2)", "round(3.241cm, 2, cm)", "round([3.2, 3.8, -4.7])"],
  seealso: ["ceil", "floor", "fix"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/sign.js
var signDocs = {
  name: "sign",
  category: "Arithmetic",
  syntax: ["sign(x)"],
  description: "Compute the sign of a value. The sign of a value x is 1 when x>0, -1 when x<0, and 0 when x=0.",
  examples: ["sign(3.5)", "sign(-4.2)", "sign(0)"],
  seealso: ["abs"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/sqrt.js
var sqrtDocs = {
  name: "sqrt",
  category: "Arithmetic",
  syntax: ["sqrt(x)"],
  description: "Compute the square root value. If x = y * y, then y is the square root of x.",
  examples: ["sqrt(25)", "5 * 5", "sqrt(-1)"],
  seealso: ["square", "sqrtm", "multiply", "nthRoot", "nthRoots", "pow"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/sqrtm.js
var sqrtmDocs = {
  name: "sqrtm",
  category: "Arithmetic",
  syntax: ["sqrtm(x)"],
  description: "Calculate the principal square root of a square matrix. The principal square root matrix `X` of another matrix `A` is such that `X * X = A`.",
  examples: ["sqrtm([[33, 24], [48, 57]])"],
  seealso: ["sqrt", "abs", "square", "multiply"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/sylvester.js
var sylvesterDocs = {
  name: "sylvester",
  category: "Algebra",
  syntax: ["sylvester(A,B,C)"],
  description: "Solves the real-valued Sylvester equation AX+XB=C for X",
  examples: ["sylvester([[-1, -2], [1, 1]], [[-2, 1], [-1, 2]], [[-3, 2], [3, 0]])", "A = [[-1, -2], [1, 1]]; B = [[2, -1], [1, -2]]; C = [[-3, 2], [3, 0]]", "sylvester(A, B, C)"],
  seealso: ["schur", "lyap"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/schur.js
var schurDocs = {
  name: "schur",
  category: "Algebra",
  syntax: ["schur(A)"],
  description: "Performs a real Schur decomposition of the real matrix A = UTU'",
  examples: ["schur([[1, 0], [-4, 3]])", "A = [[1, 0], [-4, 3]]", "schur(A)"],
  seealso: ["lyap", "sylvester"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/algebra/lyap.js
var lyapDocs = {
  name: "lyap",
  category: "Algebra",
  syntax: ["lyap(A,Q)"],
  description: "Solves the Continuous-time Lyapunov equation AP+PA'+Q=0 for P",
  examples: ["lyap([[-2, 0], [1, -4]], [[3, 1], [1, 3]])", "A = [[-2, 0], [1, -4]]", "Q = [[3, 1], [1, 3]]", "lyap(A,Q)"],
  seealso: ["schur", "sylvester"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/square.js
var squareDocs = {
  name: "square",
  category: "Arithmetic",
  syntax: ["square(x)"],
  description: "Compute the square of a value. The square of x is x * x.",
  examples: ["square(3)", "sqrt(9)", "3^2", "3 * 3"],
  seealso: ["multiply", "pow", "sqrt", "cube"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/subtract.js
var subtractDocs = {
  name: "subtract",
  category: "Operators",
  syntax: ["x - y", "subtract(x, y)"],
  description: "subtract two values.",
  examples: ["a = 5.3 - 2", "a + 2", "2/3 - 1/6", "2 * 3 - 3", "2.1 km - 500m"],
  seealso: ["add"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/unaryMinus.js
var unaryMinusDocs = {
  name: "unaryMinus",
  category: "Operators",
  syntax: ["-x", "unaryMinus(x)"],
  description: "Inverse the sign of a value. Converts booleans and strings to numbers.",
  examples: ["-4.5", "-(-5.6)", '-"22"'],
  seealso: ["add", "subtract", "unaryPlus"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/unaryPlus.js
var unaryPlusDocs = {
  name: "unaryPlus",
  category: "Operators",
  syntax: ["+x", "unaryPlus(x)"],
  description: "Converts booleans and strings to numbers.",
  examples: ["+true", '+"2"'],
  seealso: ["add", "subtract", "unaryMinus"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/arithmetic/xgcd.js
var xgcdDocs = {
  name: "xgcd",
  category: "Arithmetic",
  syntax: ["xgcd(a, b)"],
  description: "Calculate the extended greatest common divisor for two values. The result is an array [d, x, y] with 3 entries, where d is the greatest common divisor, and d = x * a + y * b.",
  examples: ["xgcd(8, 12)", "gcd(8, 12)", "xgcd(36163, 21199)"],
  seealso: ["gcd", "lcm"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/fraction/num.js
var numDocs = {
  name: "num",
  category: "Fraction",
  syntax: ["num(x)"],
  description: "Get the numerator of a fraction.",
  examples: ["num(fraction(2, 3))", "num(fraction(5, 8))"],
  seealso: ["den", "fraction"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/fraction/den.js
var denDocs = {
  name: "den",
  category: "Fraction",
  syntax: ["den(x)"],
  description: "Get the denominator of a fraction.",
  examples: ["den(fraction(2, 3))", "den(fraction(5, 8))"],
  seealso: ["num", "fraction"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/bitAnd.js
var bitAndDocs = {
  name: "bitAnd",
  category: "Bitwise",
  syntax: ["x & y", "bitAnd(x, y)"],
  description: "Bitwise AND operation. Performs the logical AND operation on each pair of the corresponding bits of the two given values by multiplying them. If both bits in the compared position are 1, the bit in the resulting binary representation is 1, otherwise, the result is 0",
  examples: ["5 & 3", "bitAnd(53, 131)", "[1, 12, 31] & 42"],
  seealso: ["bitNot", "bitOr", "bitXor", "leftShift", "rightArithShift", "rightLogShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/bitNot.js
var bitNotDocs = {
  name: "bitNot",
  category: "Bitwise",
  syntax: ["~x", "bitNot(x)"],
  description: "Bitwise NOT operation. Performs a logical negation on each bit of the given value. Bits that are 0 become 1, and those that are 1 become 0.",
  examples: ["~1", "~2", "bitNot([2, -3, 4])"],
  seealso: ["bitAnd", "bitOr", "bitXor", "leftShift", "rightArithShift", "rightLogShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/bitOr.js
var bitOrDocs = {
  name: "bitOr",
  category: "Bitwise",
  syntax: ["x | y", "bitOr(x, y)"],
  description: "Bitwise OR operation. Performs the logical inclusive OR operation on each pair of corresponding bits of the two given values. The result in each position is 1 if the first bit is 1 or the second bit is 1 or both bits are 1, otherwise, the result is 0.",
  examples: ["5 | 3", "bitOr([1, 2, 3], 4)"],
  seealso: ["bitAnd", "bitNot", "bitXor", "leftShift", "rightArithShift", "rightLogShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/bitXor.js
var bitXorDocs = {
  name: "bitXor",
  category: "Bitwise",
  syntax: ["bitXor(x, y)"],
  description: "Bitwise XOR operation, exclusive OR. Performs the logical exclusive OR operation on each pair of corresponding bits of the two given values. The result in each position is 1 if only the first bit is 1 or only the second bit is 1, but will be 0 if both are 0 or both are 1.",
  examples: ["bitOr(1, 2)", "bitXor([2, 3, 4], 4)"],
  seealso: ["bitAnd", "bitNot", "bitOr", "leftShift", "rightArithShift", "rightLogShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/leftShift.js
var leftShiftDocs = {
  name: "leftShift",
  category: "Bitwise",
  syntax: ["x << y", "leftShift(x, y)"],
  description: "Bitwise left logical shift of a value x by y number of bits.",
  examples: ["4 << 1", "8 >> 1"],
  seealso: ["bitAnd", "bitNot", "bitOr", "bitXor", "rightArithShift", "rightLogShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/rightArithShift.js
var rightArithShiftDocs = {
  name: "rightArithShift",
  category: "Bitwise",
  syntax: ["x >> y", "rightArithShift(x, y)"],
  description: "Bitwise right arithmetic shift of a value x by y number of bits.",
  examples: ["8 >> 1", "4 << 1", "-12 >> 2"],
  seealso: ["bitAnd", "bitNot", "bitOr", "bitXor", "leftShift", "rightLogShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/bitwise/rightLogShift.js
var rightLogShiftDocs = {
  name: "rightLogShift",
  category: "Bitwise",
  syntax: ["x >>> y", "rightLogShift(x, y)"],
  description: "Bitwise right logical shift of a value x by y number of bits.",
  examples: ["8 >>> 1", "4 << 1", "-12 >>> 2"],
  seealso: ["bitAnd", "bitNot", "bitOr", "bitXor", "leftShift", "rightArithShift"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/combinatorics/bellNumbers.js
var bellNumbersDocs = {
  name: "bellNumbers",
  category: "Combinatorics",
  syntax: ["bellNumbers(n)"],
  description: "The Bell Numbers count the number of partitions of a set. A partition is a pairwise disjoint subset of S whose union is S. `bellNumbers` only takes integer arguments. The following condition must be enforced: n >= 0.",
  examples: ["bellNumbers(3)", "bellNumbers(8)"],
  seealso: ["stirlingS2"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/combinatorics/catalan.js
var catalanDocs = {
  name: "catalan",
  category: "Combinatorics",
  syntax: ["catalan(n)"],
  description: "The Catalan Numbers enumerate combinatorial structures of many different types. catalan only takes integer arguments. The following condition must be enforced: n >= 0.",
  examples: ["catalan(3)", "catalan(8)"],
  seealso: ["bellNumbers"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/combinatorics/composition.js
var compositionDocs = {
  name: "composition",
  category: "Combinatorics",
  syntax: ["composition(n, k)"],
  description: "The composition counts of n into k parts. composition only takes integer arguments. The following condition must be enforced: k <= n.",
  examples: ["composition(5, 3)"],
  seealso: ["combinations"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/combinatorics/stirlingS2.js
var stirlingS2Docs = {
  name: "stirlingS2",
  category: "Combinatorics",
  syntax: ["stirlingS2(n, k)"],
  description: "The Stirling numbers of the second kind, counts the number of ways to partition a set of n labelled objects into k nonempty unlabelled subsets. `stirlingS2` only takes integer arguments. The following condition must be enforced: k <= n. If n = k or k = 1, then s(n,k) = 1.",
  examples: ["stirlingS2(5, 3)"],
  seealso: ["bellNumbers", "bernoulli"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/complex/arg.js
var argDocs = {
  name: "arg",
  category: "Complex",
  syntax: ["arg(x)"],
  description: "Compute the argument of a complex value. If x = a+bi, the argument is computed as atan2(b, a).",
  examples: ["arg(2 + 2i)", "atan2(3, 2)", "arg(2 + 3i)"],
  seealso: ["re", "im", "conj", "abs"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/complex/conj.js
var conjDocs = {
  name: "conj",
  category: "Complex",
  syntax: ["conj(x)"],
  description: "Compute the complex conjugate of a complex value. If x = a+bi, the complex conjugate is a-bi.",
  examples: ["conj(2 + 3i)", "conj(2 - 3i)", "conj(-5.2i)"],
  seealso: ["re", "im", "abs", "arg"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/complex/im.js
var imDocs = {
  name: "im",
  category: "Complex",
  syntax: ["im(x)"],
  description: "Get the imaginary part of a complex number.",
  examples: ["im(2 + 3i)", "re(2 + 3i)", "im(-5.2i)", "im(2.4)"],
  seealso: ["re", "conj", "abs", "arg"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/complex/re.js
var reDocs = {
  name: "re",
  category: "Complex",
  syntax: ["re(x)"],
  description: "Get the real part of a complex number.",
  examples: ["re(2 + 3i)", "im(2 + 3i)", "re(-5.2i)", "re(2.4)"],
  seealso: ["im", "conj", "abs", "arg"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/expression/evaluate.js
var evaluateDocs = {
  name: "evaluate",
  category: "Expression",
  syntax: ["evaluate(expression)", "evaluate(expression, scope)", "evaluate([expr1, expr2, expr3, ...])", "evaluate([expr1, expr2, expr3, ...], scope)"],
  description: "Evaluate an expression or an array with expressions.",
  examples: ['evaluate("2 + 3")', 'evaluate("sqrt(16)")', 'evaluate("2 inch to cm")', 'evaluate("sin(x * pi)", { "x": 1/2 })', 'evaluate(["width=2", "height=4","width*height"])'],
  seealso: ["parser", "parse", "compile"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/expression/parser.js
var parserDocs = {
  name: "parser",
  category: "Expression",
  syntax: ["parser()"],
  description: "Create a parser object that keeps a context of variables and their values, allowing the evaluation of expressions in that context.",
  examples: ["myParser = parser()", 'myParser.evaluate("sqrt(3^2 + 4^2)")', 'myParser.set("x", 3)', 'myParser.evaluate("y = x + 3")', 'myParser.evaluate(["y = x + 3", "y = y + 1"])', 'myParser.get("y")'],
  seealso: ["evaluate", "parse", "compile"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/expression/parse.js
var parseDocs = {
  name: "parse",
  category: "Expression",
  syntax: ["parse(expr)", "parse(expr, options)", "parse([expr1, expr2, expr3, ...])", "parse([expr1, expr2, expr3, ...], options)"],
  description: "Parse an expression. Returns a node tree, which can be evaluated by invoking node.evaluate() or transformed into a functional object via node.compile().",
  examples: ['node1 = parse("sqrt(3^2 + 4^2)")', "node1.evaluate()", "code1 = node1.compile()", "code1.evaluate()", "scope = {a: 3, b: 4}", 'node2 = parse("a * b")', "node2.evaluate(scope)", "code2 = node2.compile()", "code2.evaluate(scope)"],
  seealso: ["parser", "evaluate", "compile"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/expression/compile.js
var compileDocs = {
  name: "compile",
  category: "Expression",
  syntax: ["compile(expr) ", "compile([expr1, expr2, expr3, ...])"],
  description: "Parse and compile an expression. Returns a an object with a function evaluate([scope]) to evaluate the compiled expression.",
  examples: ['code1 = compile("sqrt(3^2 + 4^2)")', "code1.evaluate() ", 'code2 = compile("a * b")', "code2.evaluate({a: 3, b: 4})"],
  seealso: ["parser", "parse", "evaluate"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/expression/help.js
var helpDocs = {
  name: "help",
  category: "Expression",
  syntax: ["help(object)", "help(string)"],
  description: "Display documentation on a function or data type.",
  examples: ["help(sqrt)", 'help("complex")'],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/geometry/distance.js
var distanceDocs = {
  name: "distance",
  category: "Geometry",
  syntax: ["distance([x1, y1], [x2, y2])", "distance([[x1, y1], [x2, y2]])"],
  description: "Calculates the Euclidean distance between two points.",
  examples: ["distance([0,0], [4,4])", "distance([[0,0], [4,4]])"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/geometry/intersect.js
var intersectDocs = {
  name: "intersect",
  category: "Geometry",
  syntax: ["intersect(expr1, expr2, expr3, expr4)", "intersect(expr1, expr2, expr3)"],
  description: "Computes the intersection point of lines and/or planes.",
  examples: ["intersect([0, 0], [10, 10], [10, 0], [0, 10])", "intersect([1, 0, 1],  [4, -2, 2], [1, 1, 1, 6])"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/logical/and.js
var andDocs = {
  name: "and",
  category: "Logical",
  syntax: ["x and y", "and(x, y)"],
  description: "Logical and. Test whether two values are both defined with a nonzero/nonempty value.",
  examples: ["true and false", "true and true", "2 and 4"],
  seealso: ["not", "or", "xor"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/logical/not.js
var notDocs = {
  name: "not",
  category: "Logical",
  syntax: ["not x", "not(x)"],
  description: "Logical not. Flips the boolean value of given argument.",
  examples: ["not true", "not false", "not 2", "not 0"],
  seealso: ["and", "or", "xor"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/logical/nullish.js
var nullishDocs = {
  name: "nullish",
  category: "Logical",
  syntax: ["x ?? y", "nullish(x, y)"],
  description: "Nullish coalescing operator. Returns the right-hand operand when the left-hand operand is null or undefined, and otherwise returns the left-hand operand.",
  examples: ["null ?? 42", "undefined ?? 42", "0 ?? 42", "false ?? 42", "null ?? undefined ?? 42"],
  seealso: ["and", "or", "not"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/logical/or.js
var orDocs = {
  name: "or",
  category: "Logical",
  syntax: ["x or y", "or(x, y)"],
  description: "Logical or. Test if at least one value is defined with a nonzero/nonempty value.",
  examples: ["true or false", "false or false", "0 or 4"],
  seealso: ["not", "and", "xor"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/logical/xor.js
var xorDocs = {
  name: "xor",
  category: "Logical",
  syntax: ["x xor y", "xor(x, y)"],
  description: "Logical exclusive or, xor. Test whether one and only one value is defined with a nonzero/nonempty value.",
  examples: ["true xor false", "false xor false", "true xor true", "0 xor 4"],
  seealso: ["not", "and", "or"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/mapSlices.js
var mapSlicesDocs = {
  name: "mapSlices",
  category: "Matrix",
  syntax: ["mapSlices(A, dim, callback)"],
  description: "Generate a matrix one dimension less than A by applying callback to each slice of A along dimension dim.",
  examples: [
    "A = [[1, 2], [3, 4]]",
    "mapSlices(A, 1, sum)",
    // returns [4, 6]
    "mapSlices(A, 2, prod)"
    // returns [2, 12]
  ],
  seealso: ["map", "forEach"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/column.js
var columnDocs = {
  name: "column",
  category: "Matrix",
  syntax: ["column(x, index)"],
  description: "Return a column from a matrix or array.",
  examples: ["A = [[1, 2], [3, 4]]", "column(A, 1)", "column(A, 2)"],
  seealso: ["row", "matrixFromColumns"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/concat.js
var concatDocs = {
  name: "concat",
  category: "Matrix",
  syntax: ["concat(A, B, C, ...)", "concat(A, B, C, ..., dim)"],
  description: "Concatenate matrices. By default, the matrices are concatenated by the last dimension. The dimension on which to concatenate can be provided as last argument.",
  examples: ["A = [1, 2; 5, 6]", "B = [3, 4; 7, 8]", "concat(A, B)", "concat(A, B, 1)", "concat(A, B, 2)"],
  seealso: ["det", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/count.js
var countDocs = {
  name: "count",
  category: "Matrix",
  syntax: ["count(x)"],
  description: "Count the number of elements of a matrix, array or string.",
  examples: ["a = [1, 2; 3, 4; 5, 6]", "count(a)", "size(a)", 'count("hello world")'],
  seealso: ["size"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/cross.js
var crossDocs = {
  name: "cross",
  category: "Matrix",
  syntax: ["cross(A, B)"],
  description: "Calculate the cross product for two vectors in three dimensional space.",
  examples: ["cross([1, 1, 0],  [0, 1, 1])", "cross([3, -3, 1], [4, 9, 2])", "cross([2, 3, 4],  [5, 6, 7])"],
  seealso: ["multiply", "dot"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/ctranspose.js
var ctransposeDocs = {
  name: "ctranspose",
  category: "Matrix",
  syntax: ["x'", "ctranspose(x)"],
  description: "Complex Conjugate and Transpose a matrix",
  examples: ["a = [1, 2, 3; 4, 5, 6]", "a'", "ctranspose(a)"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/det.js
var detDocs = {
  name: "det",
  category: "Matrix",
  syntax: ["det(x)"],
  description: "Calculate the determinant of a matrix",
  examples: ["det([1, 2; 3, 4])", "det([-2, 2, 3; -1, 1, 3; 2, 0, -1])"],
  seealso: ["concat", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/diag.js
var diagDocs = {
  name: "diag",
  category: "Matrix",
  syntax: ["diag(x)", "diag(x, k)"],
  description: "Create a diagonal matrix or retrieve the diagonal of a matrix. When x is a vector, a matrix with the vector values on the diagonal will be returned. When x is a matrix, a vector with the diagonal values of the matrix is returned. When k is provided, the k-th diagonal will be filled in or retrieved, if k is positive, the values are placed on the super diagonal. When k is negative, the values are placed on the sub diagonal.",
  examples: ["diag(1:3)", "diag(1:3, 1)", "a = [1, 2, 3; 4, 5, 6; 7, 8, 9]", "diag(a)"],
  seealso: ["concat", "det", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/diff.js
var diffDocs = {
  name: "diff",
  category: "Matrix",
  syntax: ["diff(arr)", "diff(arr, dim)"],
  description: ["Create a new matrix or array with the difference of the passed matrix or array.", "Dim parameter is optional and used to indicate the dimension of the array/matrix to apply the difference", "If no dimension parameter is passed it is assumed as dimension 0", "Dimension is zero-based in javascript and one-based in the parser", "Arrays must be 'rectangular' meaning arrays like [1, 2]", "If something is passed as a matrix it will be returned as a matrix but other than that all matrices are converted to arrays"],
  examples: ["A = [1, 2, 4, 7, 0]", "diff(A)", "diff(A, 1)", "B = [[1, 2], [3, 4]]", "diff(B)", "diff(B, 1)", "diff(B, 2)", "diff(B, bignumber(2))", "diff([[1, 2], matrix([3, 4])], 2)"],
  seealso: ["subtract", "partitionSelect"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/dot.js
var dotDocs = {
  name: "dot",
  category: "Matrix",
  syntax: ["dot(A, B)", "A * B"],
  description: "Calculate the dot product of two vectors. The dot product of A = [a1, a2, a3, ..., an] and B = [b1, b2, b3, ..., bn] is defined as dot(A, B) = a1 * b1 + a2 * b2 + a3 * b3 + ... + an * bn",
  examples: ["dot([2, 4, 1], [2, 2, 3])", "[2, 4, 1] * [2, 2, 3]"],
  seealso: ["multiply", "cross"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/eigs.js
var eigsDocs = {
  name: "eigs",
  category: "Matrix",
  syntax: ["eigs(x)"],
  description: "Calculate the eigenvalues and optionally eigenvectors of a square matrix",
  examples: ["eigs([[5, 2.3], [2.3, 1]])", "eigs([[1, 2, 3], [4, 5, 6], [7, 8, 9]], { precision: 1e-6, eigenvectors: false })"],
  seealso: ["inv"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/filter.js
var filterDocs = {
  name: "filter",
  category: "Matrix",
  syntax: ["filter(x, test)"],
  description: "Filter items in a matrix.",
  examples: ["isPositive(x) = x > 0", "filter([6, -2, -1, 4, 3], isPositive)", "filter([6, -2, 0, 1, 0], x != 0)"],
  seealso: ["sort", "map", "forEach"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/flatten.js
var flattenDocs = {
  name: "flatten",
  category: "Matrix",
  syntax: ["flatten(x)"],
  description: "Flatten a multi dimensional matrix into a single dimensional matrix.",
  examples: ["a = [1, 2, 3; 4, 5, 6]", "size(a)", "b = flatten(a)", "size(b)"],
  seealso: ["concat", "resize", "size", "squeeze"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/forEach.js
var forEachDocs = {
  name: "forEach",
  category: "Matrix",
  syntax: ["forEach(x, callback)"],
  description: "Iterates over all elements of a matrix/array, and executes the given callback function.",
  examples: ["numberOfPets = {}", "addPet(n) = numberOfPets[n] = (numberOfPets[n] ? numberOfPets[n]:0 ) + 1;", 'forEach(["Dog","Cat","Cat"], addPet)', "numberOfPets"],
  seealso: ["map", "sort", "filter"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/getMatrixDataType.js
var getMatrixDataTypeDocs = {
  name: "getMatrixDataType",
  category: "Matrix",
  syntax: ["getMatrixDataType(x)"],
  description: 'Find the data type of all elements in a matrix or array, for example "number" if all items are a number and "Complex" if all values are complex numbers. If a matrix contains more than one data type, it will return "mixed".',
  examples: ["getMatrixDataType([1, 2, 3])", "getMatrixDataType([[5 cm], [2 inch]])", 'getMatrixDataType([1, "text"])', "getMatrixDataType([1, bignumber(4)])"],
  seealso: ["matrix", "sparse", "typeOf"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/identity.js
var identityDocs = {
  name: "identity",
  category: "Matrix",
  syntax: ["identity(n)", "identity(m, n)", "identity([m, n])"],
  description: "Returns the identity matrix with size m-by-n. The matrix has ones on the diagonal and zeros elsewhere.",
  examples: ["identity(3)", "identity(3, 5)", "a = [1, 2, 3; 4, 5, 6]", "identity(size(a))"],
  seealso: ["concat", "det", "diag", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/inv.js
var invDocs = {
  name: "inv",
  category: "Matrix",
  syntax: ["inv(x)"],
  description: "Calculate the inverse of a matrix",
  examples: ["inv([1, 2; 3, 4])", "inv(4)", "1 / 4"],
  seealso: ["concat", "det", "diag", "identity", "ones", "range", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/pinv.js
var pinvDocs = {
  name: "pinv",
  category: "Matrix",
  syntax: ["pinv(x)"],
  description: "Calculate the Moore\u2013Penrose inverse of a matrix",
  examples: ["pinv([1, 2; 3, 4])", "pinv([[1, 0], [0, 1], [0, 1]])", "pinv(4)"],
  seealso: ["inv"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/kron.js
var kronDocs = {
  name: "kron",
  category: "Matrix",
  syntax: ["kron(x, y)"],
  description: "Calculates the Kronecker product of 2 matrices or vectors.",
  examples: ["kron([[1, 0], [0, 1]], [[1, 2], [3, 4]])", "kron([1,1], [2,3,4])"],
  seealso: ["multiply", "dot", "cross"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/map.js
var mapDocs = {
  name: "map",
  category: "Matrix",
  syntax: ["map(x, callback)", "map(x, y, ..., callback)"],
  description: "Create a new matrix or array with the results of the callback function executed on each entry of the matrix/array or the matrices/arrays.",
  examples: ["map([1, 2, 3], square)", "map([1, 2], [3, 4], f(a,b) = a + b)"],
  seealso: ["filter", "forEach"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/matrixFromColumns.js
var matrixFromColumnsDocs = {
  name: "matrixFromColumns",
  category: "Matrix",
  syntax: ["matrixFromColumns(...arr)", "matrixFromColumns(row1, row2)", "matrixFromColumns(row1, row2, row3)"],
  description: "Create a dense matrix from vectors as individual columns.",
  examples: ["matrixFromColumns([1, 2, 3], [[4],[5],[6]])"],
  seealso: ["matrix", "matrixFromRows", "matrixFromFunction", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/matrixFromFunction.js
var matrixFromFunctionDocs = {
  name: "matrixFromFunction",
  category: "Matrix",
  syntax: ["matrixFromFunction(size, fn)", "matrixFromFunction(size, fn, format)", "matrixFromFunction(size, fn, format, datatype)", "matrixFromFunction(size, format, fn)", "matrixFromFunction(size, format, datatype, fn)"],
  description: "Create a matrix by evaluating a generating function at each index.",
  examples: ["f(I) = I[1] - I[2]", "matrixFromFunction([3,3], f)", "g(I) = I[1] - I[2] == 1 ? 4 : 0", 'matrixFromFunction([100, 100], "sparse", g)', "matrixFromFunction([5], random)"],
  seealso: ["matrix", "matrixFromRows", "matrixFromColumns", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/matrixFromRows.js
var matrixFromRowsDocs = {
  name: "matrixFromRows",
  category: "Matrix",
  syntax: ["matrixFromRows(...arr)", "matrixFromRows(row1, row2)", "matrixFromRows(row1, row2, row3)"],
  description: "Create a dense matrix from vectors as individual rows.",
  examples: ["matrixFromRows([1, 2, 3], [[4],[5],[6]])"],
  seealso: ["matrix", "matrixFromColumns", "matrixFromFunction", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/ones.js
var onesDocs = {
  name: "ones",
  category: "Matrix",
  syntax: ["ones(m)", "ones(m, n)", "ones(m, n, p, ...)", "ones([m])", "ones([m, n])", "ones([m, n, p, ...])"],
  description: "Create a matrix containing ones.",
  examples: ["ones(3)", "ones(3, 5)", "ones([2,3]) * 4.5", "a = [1, 2, 3; 4, 5, 6]", "ones(size(a))"],
  seealso: ["concat", "det", "diag", "identity", "inv", "range", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/partitionSelect.js
var partitionSelectDocs = {
  name: "partitionSelect",
  category: "Matrix",
  syntax: ["partitionSelect(x, k)", "partitionSelect(x, k, compare)"],
  description: "Partition-based selection of an array or 1D matrix. Will find the kth smallest value, and mutates the input array. Uses Quickselect.",
  examples: ["partitionSelect([5, 10, 1], 2)", 'partitionSelect(["C", "B", "A", "D"], 1, compareText)', "arr = [5, 2, 1]", "partitionSelect(arr, 0) # returns 1, arr is now: [1, 2, 5]", "arr", "partitionSelect(arr, 1, 'desc') # returns 2, arr is now: [5, 2, 1]", "arr"],
  seealso: ["sort"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/range.js
var rangeDocs = {
  name: "range",
  category: "Type",
  syntax: ["start:end", "start:step:end", "range(start, end)", "range(start, end, step)", "range(string)"],
  description: "Create a range. Lower bound of the range is included, upper bound is excluded.",
  examples: ["1:5", "3:-1:-3", "range(3, 7)", "range(0, 12, 2)", 'range("4:10")', "range(1m, 1m, 3m)", "a = [1, 2, 3, 4; 5, 6, 7, 8]", "a[1:2, 1:2]"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "size", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/reshape.js
var reshapeDocs = {
  name: "reshape",
  category: "Matrix",
  syntax: ["reshape(x, sizes)"],
  description: "Reshape a multi dimensional array to fit the specified dimensions.",
  examples: ["reshape([1, 2, 3, 4, 5, 6], [2, 3])", "reshape([[1, 2], [3, 4]], [1, 4])", "reshape([[1, 2], [3, 4]], [4])", "reshape([1, 2, 3, 4], [-1, 2])"],
  seealso: ["size", "squeeze", "resize"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/resize.js
var resizeDocs = {
  name: "resize",
  category: "Matrix",
  syntax: ["resize(x, size)", "resize(x, size, defaultValue)"],
  description: "Resize a matrix.",
  examples: ["resize([1,2,3,4,5], [3])", "resize([1,2,3], [5])", "resize([1,2,3], [5], -1)", "resize(2, [2, 3])", 'resize("hello", [8], "!")'],
  seealso: ["size", "subset", "squeeze", "reshape"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/rotate.js
var rotateDocs = {
  name: "rotate",
  category: "Matrix",
  syntax: ["rotate(w, theta)", "rotate(w, theta, v)"],
  description: "Returns a 2-D rotation matrix (2x2) for a given angle (in radians). Returns a 2-D rotation matrix (3x3) of a given angle (in radians) around given axis.",
  examples: ["rotate([1, 0], pi / 2)", 'rotate(matrix([1, 0]), unit("35deg"))', 'rotate([1, 0, 0], unit("90deg"), [0, 0, 1])', 'rotate(matrix([1, 0, 0]), unit("90deg"), matrix([0, 0, 1]))'],
  seealso: ["matrix", "rotationMatrix"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/rotationMatrix.js
var rotationMatrixDocs = {
  name: "rotationMatrix",
  category: "Matrix",
  syntax: ["rotationMatrix(theta)", "rotationMatrix(theta, v)", "rotationMatrix(theta, v, format)"],
  description: "Returns a 2-D rotation matrix (2x2) for a given angle (in radians). Returns a 2-D rotation matrix (3x3) of a given angle (in radians) around given axis.",
  examples: ["rotationMatrix(pi / 2)", 'rotationMatrix(unit("45deg"), [0, 0, 1])', 'rotationMatrix(1, matrix([0, 0, 1]), "sparse")'],
  seealso: ["cos", "sin"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/row.js
var rowDocs = {
  name: "row",
  category: "Matrix",
  syntax: ["row(x, index)"],
  description: "Return a row from a matrix or array.",
  examples: ["A = [[1, 2], [3, 4]]", "row(A, 1)", "row(A, 2)"],
  seealso: ["column", "matrixFromRows"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/size.js
var sizeDocs = {
  name: "size",
  category: "Matrix",
  syntax: ["size(x)"],
  description: "Calculate the size of a matrix.",
  examples: ["size(2.3)", 'size("hello world")', "a = [1, 2; 3, 4; 5, 6]", "size(a)", "size(1:6)"],
  seealso: ["concat", "count", "det", "diag", "identity", "inv", "ones", "range", "squeeze", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/sort.js
var sortDocs = {
  name: "sort",
  category: "Matrix",
  syntax: ["sort(x)", "sort(x, compare)"],
  description: 'Sort the items in a matrix. Compare can be a string "asc", "desc", "natural", or a custom sort function.',
  examples: ["sort([5, 10, 1])", 'sort(["C", "B", "A", "D"], "natural")', "sortByLength(a, b) = size(a)[1] - size(b)[1]", 'sort(["Langdon", "Tom", "Sara"], sortByLength)', 'sort(["10", "1", "2"], "natural")'],
  seealso: ["map", "filter", "forEach"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/squeeze.js
var squeezeDocs = {
  name: "squeeze",
  category: "Matrix",
  syntax: ["squeeze(x)"],
  description: "Remove inner and outer singleton dimensions from a matrix.",
  examples: ["a = zeros(3,2,1)", "size(squeeze(a))", "b = zeros(1,1,3)", "size(squeeze(b))"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "range", "size", "subset", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/subset.js
var subsetDocs = {
  name: "subset",
  category: "Matrix",
  syntax: ["value(index)", "value(index) = replacement", "subset(value, [index])", "subset(value, [index], replacement)"],
  description: "Get or set a subset of the entries of a matrix or characters of a string. Indexes are one-based. There should be one index specification for each dimension of the target. Each specification can be a single index, a list of indices, or a range in colon notation `l:u`. In a range, both the lower bound l and upper bound u are included; and if a bound is omitted it defaults to the most extreme valid value. The cartesian product of the indices specified in each dimension determines the target of the operation.",
  examples: ["d = [1, 2; 3, 4]", "e = []", "e[1, 1:2] = [5, 6]", "e[2, :] = [7, 8]", "f = d * e", "f[2, 1]", "f[:, 1]", "f[[1,2], [1,3]] = [9, 10; 11, 12]", "f"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "trace", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/trace.js
var traceDocs = {
  name: "trace",
  category: "Matrix",
  syntax: ["trace(A)"],
  description: "Calculate the trace of a matrix: the sum of the elements on the main diagonal of a square matrix.",
  examples: ["A = [1, 2, 3; -1, 2, 3; 2, 0, 3]", "trace(A)"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "transpose", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/transpose.js
var transposeDocs = {
  name: "transpose",
  category: "Matrix",
  syntax: ["x'", "transpose(x)"],
  description: "Transpose a matrix",
  examples: ["a = [1, 2, 3; 4, 5, 6]", "a'", "transpose(a)"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "zeros"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/zeros.js
var zerosDocs = {
  name: "zeros",
  category: "Matrix",
  syntax: ["zeros(m)", "zeros(m, n)", "zeros(m, n, p, ...)", "zeros([m])", "zeros([m, n])", "zeros([m, n, p, ...])"],
  description: "Create a matrix containing zeros.",
  examples: ["zeros(3)", "zeros(3, 5)", "a = [1, 2, 3; 4, 5, 6]", "zeros(size(a))"],
  seealso: ["concat", "det", "diag", "identity", "inv", "ones", "range", "size", "squeeze", "subset", "trace", "transpose"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/fft.js
var fftDocs = {
  name: "fft",
  category: "Matrix",
  syntax: ["fft(x)"],
  description: "Calculate N-dimensional Fourier transform",
  examples: ["fft([[1, 0], [1, 0]])"],
  seealso: ["ifft"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/matrix/ifft.js
var ifftDocs = {
  name: "ifft",
  category: "Matrix",
  syntax: ["ifft(x)"],
  description: "Calculate N-dimensional inverse Fourier transform",
  examples: ["ifft([[2, 2], [0, 0]])"],
  seealso: ["fft"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/bernoulli.js
var bernoulliDocs = {
  name: "bernoulli",
  category: "Probability",
  syntax: ["bernoulli(n)"],
  description: "The nth Bernoulli number",
  examples: ["bernoulli(4)", "bernoulli(fraction(12))"],
  seealso: ["combinations", "gamma", "stirlingS2"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/combinations.js
var combinationsDocs = {
  name: "combinations",
  category: "Probability",
  syntax: ["combinations(n, k)"],
  description: "Compute the number of combinations of n items taken k at a time",
  examples: ["combinations(7, 5)"],
  seealso: ["combinationsWithRep", "permutations", "factorial"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/combinationsWithRep.js
var combinationsWithRepDocs = {
  name: "combinationsWithRep",
  category: "Probability",
  syntax: ["combinationsWithRep(n, k)"],
  description: "Compute the number of combinations of n items taken k at a time with replacements.",
  examples: ["combinationsWithRep(7, 5)"],
  seealso: ["combinations", "permutations", "factorial"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/factorial.js
var factorialDocs = {
  name: "factorial",
  category: "Probability",
  syntax: ["n!", "factorial(n)"],
  description: "Compute the factorial of a value",
  examples: ["5!", "5 * 4 * 3 * 2 * 1", "3!"],
  seealso: ["combinations", "combinationsWithRep", "permutations", "gamma"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/gamma.js
var gammaDocs = {
  name: "gamma",
  category: "Probability",
  syntax: ["gamma(n)"],
  description: "Compute the gamma function. For small values, the Lanczos approximation is used, and for large values the extended Stirling approximation.",
  examples: ["gamma(4)", "3!", "gamma(1/2)", "sqrt(pi)"],
  seealso: ["factorial"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/lgamma.js
var lgammaDocs = {
  name: "lgamma",
  category: "Probability",
  syntax: ["lgamma(n)"],
  description: "Logarithm of the gamma function for real, positive numbers and complex numbers, using Lanczos approximation for numbers and Stirling series for complex numbers.",
  examples: ["lgamma(4)", "lgamma(1/2)", "lgamma(i)", "lgamma(complex(1.1, 2))"],
  seealso: ["gamma"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/kldivergence.js
var kldivergenceDocs = {
  name: "kldivergence",
  category: "Probability",
  syntax: ["kldivergence(x, y)"],
  description: "Calculate the Kullback-Leibler (KL) divergence  between two distributions.",
  examples: ["kldivergence([0.7,0.5,0.4], [0.2,0.9,0.5])"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/multinomial.js
var multinomialDocs = {
  name: "multinomial",
  category: "Probability",
  syntax: ["multinomial(A)"],
  description: "Multinomial Coefficients compute the number of ways of picking a1, a2, ..., ai unordered outcomes from `n` possibilities. multinomial takes one array of integers as an argument. The following condition must be enforced: every ai > 0.",
  examples: ["multinomial([1, 2, 1])"],
  seealso: ["combinations", "factorial"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/permutations.js
var permutationsDocs = {
  name: "permutations",
  category: "Probability",
  syntax: ["permutations(n)", "permutations(n, k)"],
  description: "Compute the number of permutations of n items taken k at a time",
  examples: ["permutations(5)", "permutations(5, 3)"],
  seealso: ["combinations", "combinationsWithRep", "factorial"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/pickRandom.js
var pickRandomDocs = {
  name: "pickRandom",
  category: "Probability",
  syntax: ["pickRandom(array)", "pickRandom(array, number)", "pickRandom(array, weights)", "pickRandom(array, number, weights)", "pickRandom(array, weights, number)"],
  description: "Pick a random entry from a given array.",
  examples: ["pickRandom(0:10)", "pickRandom([1, 3, 1, 6])", "pickRandom([1, 3, 1, 6], 2)", "pickRandom([1, 3, 1, 6], [2, 3, 2, 1])", "pickRandom([1, 3, 1, 6], 2, [2, 3, 2, 1])", "pickRandom([1, 3, 1, 6], [2, 3, 2, 1], 2)"],
  seealso: ["random", "randomInt"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/random.js
var randomDocs = {
  name: "random",
  category: "Probability",
  syntax: ["random()", "random(max)", "random(min, max)", "random(size)", "random(size, max)", "random(size, min, max)"],
  description: "Return a random number.",
  examples: ["random()", "random(10, 20)", "random([2, 3])"],
  seealso: ["pickRandom", "randomInt"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/probability/randomInt.js
var randomIntDocs = {
  name: "randomInt",
  category: "Probability",
  syntax: ["randomInt(max)", "randomInt(min, max)", "randomInt(size)", "randomInt(size, max)", "randomInt(size, min, max)"],
  description: "Return a random integer number",
  examples: ["randomInt(10, 20)", "randomInt([2, 3], 10)"],
  seealso: ["pickRandom", "random"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/compare.js
var compareDocs = {
  name: "compare",
  category: "Relational",
  syntax: ["compare(x, y)"],
  description: "Compare two values. Returns 1 when x > y, -1 when x < y, and 0 when x == y.",
  examples: ["compare(2, 3)", "compare(3, 2)", "compare(2, 2)", "compare(5cm, 40mm)", "compare(2, [1, 2, 3])"],
  seealso: ["equal", "unequal", "smaller", "smallerEq", "largerEq", "compareNatural", "compareText"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/compareNatural.js
var compareNaturalDocs = {
  name: "compareNatural",
  category: "Relational",
  syntax: ["compareNatural(x, y)"],
  description: "Compare two values of any type in a deterministic, natural way. Returns 1 when x > y, -1 when x < y, and 0 when x == y.",
  examples: ["compareNatural(2, 3)", "compareNatural(3, 2)", "compareNatural(2, 2)", "compareNatural(5cm, 40mm)", 'compareNatural("2", "10")', "compareNatural(2 + 3i, 2 + 4i)", "compareNatural([1, 2, 4], [1, 2, 3])", "compareNatural([1, 5], [1, 2, 3])", "compareNatural([1, 2], [1, 2])", "compareNatural({a: 2}, {a: 4})"],
  seealso: ["equal", "unequal", "smaller", "smallerEq", "largerEq", "compare", "compareText"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/compareText.js
var compareTextDocs = {
  name: "compareText",
  category: "Relational",
  syntax: ["compareText(x, y)"],
  description: "Compare two strings lexically. Comparison is case sensitive. Returns 1 when x > y, -1 when x < y, and 0 when x == y.",
  examples: ['compareText("B", "A")', 'compareText("A", "B")', 'compareText("A", "A")', 'compareText("2", "10")', 'compare("2", "10")', "compare(2, 10)", 'compareNatural("2", "10")', 'compareText("B", ["A", "B", "C"])'],
  seealso: ["compare", "compareNatural"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/deepEqual.js
var deepEqualDocs = {
  name: "deepEqual",
  category: "Relational",
  syntax: ["deepEqual(x, y)"],
  description: "Check equality of two matrices element wise. Returns true if the size of both matrices is equal and when and each of the elements are equal.",
  examples: ["deepEqual([1,3,4], [1,3,4])", "deepEqual([1,3,4], [1,3])"],
  seealso: ["equal", "unequal", "smaller", "larger", "smallerEq", "largerEq", "compare"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/equal.js
var equalDocs = {
  name: "equal",
  category: "Relational",
  syntax: ["x == y", "equal(x, y)"],
  description: "Check equality of two values. Returns true if the values are equal, and false if not.",
  examples: ["2+2 == 3", "2+2 == 4", "a = 3.2", "b = 6-2.8", "a == b", "50cm == 0.5m"],
  seealso: ["unequal", "smaller", "larger", "smallerEq", "largerEq", "compare", "deepEqual", "equalText"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/equalText.js
var equalTextDocs = {
  name: "equalText",
  category: "Relational",
  syntax: ["equalText(x, y)"],
  description: "Check equality of two strings. Comparison is case sensitive. Returns true if the values are equal, and false if not.",
  examples: ['equalText("Hello", "Hello")', 'equalText("a", "A")', 'equal("2e3", "2000")', 'equalText("2e3", "2000")', 'equalText("B", ["A", "B", "C"])'],
  seealso: ["compare", "compareNatural", "compareText", "equal"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/larger.js
var largerDocs = {
  name: "larger",
  category: "Relational",
  syntax: ["x > y", "larger(x, y)"],
  description: "Check if value x is larger than y. Returns true if x is larger than y, and false if not. Comparing a value with NaN returns false.",
  examples: ["2 > 3", "5 > 2*2", "a = 3.3", "b = 6-2.8", "(a > b)", "(b < a)", "5 cm > 2 inch"],
  seealso: ["equal", "unequal", "smaller", "smallerEq", "largerEq", "compare"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/largerEq.js
var largerEqDocs = {
  name: "largerEq",
  category: "Relational",
  syntax: ["x >= y", "largerEq(x, y)"],
  description: "Check if value x is larger or equal to y. Returns true if x is larger or equal to y, and false if not.",
  examples: ["2 >= 1+1", "2 > 1+1", "a = 3.2", "b = 6-2.8", "(a >= b)"],
  seealso: ["equal", "unequal", "smallerEq", "smaller", "compare"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/smaller.js
var smallerDocs = {
  name: "smaller",
  category: "Relational",
  syntax: ["x < y", "smaller(x, y)"],
  description: "Check if value x is smaller than value y. Returns true if x is smaller than y, and false if not. Comparing a value with NaN returns false.",
  examples: ["2 < 3", "5 < 2*2", "a = 3.3", "b = 6-2.8", "(a < b)", "5 cm < 2 inch"],
  seealso: ["equal", "unequal", "larger", "smallerEq", "largerEq", "compare"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/smallerEq.js
var smallerEqDocs = {
  name: "smallerEq",
  category: "Relational",
  syntax: ["x <= y", "smallerEq(x, y)"],
  description: "Check if value x is smaller or equal to value y. Returns true if x is smaller than y, and false if not.",
  examples: ["2 <= 1+1", "2 < 1+1", "a = 3.2", "b = 6-2.8", "(a <= b)"],
  seealso: ["equal", "unequal", "larger", "smaller", "largerEq", "compare"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/relational/unequal.js
var unequalDocs = {
  name: "unequal",
  category: "Relational",
  syntax: ["x != y", "unequal(x, y)"],
  description: "Check unequality of two values. Returns true if the values are unequal, and false if they are equal.",
  examples: ["2+2 != 3", "2+2 != 4", "a = 3.2", "b = 6-2.8", "a != b", "50cm != 0.5m", "5 cm != 2 inch"],
  seealso: ["equal", "smaller", "larger", "smallerEq", "largerEq", "compare", "deepEqual"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setCartesian.js
var setCartesianDocs = {
  name: "setCartesian",
  category: "Set",
  syntax: ["setCartesian(set1, set2)"],
  description: "Create the cartesian product of two (multi)sets. Multi-dimension arrays will be converted to single-dimension arrays and the values will be sorted in ascending order before the operation.",
  examples: ["setCartesian([1, 2], [3, 4])"],
  seealso: ["setUnion", "setIntersect", "setDifference", "setPowerset"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setDifference.js
var setDifferenceDocs = {
  name: "setDifference",
  category: "Set",
  syntax: ["setDifference(set1, set2)"],
  description: "Create the difference of two (multi)sets: every element of set1, that is not the element of set2. Multi-dimension arrays will be converted to single-dimension arrays before the operation.",
  examples: ["setDifference([1, 2, 3, 4], [3, 4, 5, 6])", "setDifference([[1, 2], [3, 4]], [[3, 4], [5, 6]])"],
  seealso: ["setUnion", "setIntersect", "setSymDifference"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setDistinct.js
var setDistinctDocs = {
  name: "setDistinct",
  category: "Set",
  syntax: ["setDistinct(set)"],
  description: "Collect the distinct elements of a multiset. A multi-dimension array will be converted to a single-dimension array before the operation.",
  examples: ["setDistinct([1, 1, 1, 2, 2, 3])"],
  seealso: ["setMultiplicity"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setIntersect.js
var setIntersectDocs = {
  name: "setIntersect",
  category: "Set",
  syntax: ["setIntersect(set1, set2)"],
  description: "Create the intersection of two (multi)sets. Multi-dimension arrays will be converted to single-dimension arrays before the operation.",
  examples: ["setIntersect([1, 2, 3, 4], [3, 4, 5, 6])", "setIntersect([[1, 2], [3, 4]], [[3, 4], [5, 6]])"],
  seealso: ["setUnion", "setDifference"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setIsSubset.js
var setIsSubsetDocs = {
  name: "setIsSubset",
  category: "Set",
  syntax: ["setIsSubset(set1, set2)"],
  description: "Check whether a (multi)set is a subset of another (multi)set: every element of set1 is the element of set2. Multi-dimension arrays will be converted to single-dimension arrays before the operation.",
  examples: ["setIsSubset([1, 2], [3, 4, 5, 6])", "setIsSubset([3, 4], [3, 4, 5, 6])"],
  seealso: ["setUnion", "setIntersect", "setDifference"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setMultiplicity.js
var setMultiplicityDocs = {
  name: "setMultiplicity",
  category: "Set",
  syntax: ["setMultiplicity(element, set)"],
  description: "Count the multiplicity of an element in a multiset. A multi-dimension array will be converted to a single-dimension array before the operation.",
  examples: ["setMultiplicity(1, [1, 2, 2, 4])", "setMultiplicity(2, [1, 2, 2, 4])"],
  seealso: ["setDistinct", "setSize"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setPowerset.js
var setPowersetDocs = {
  name: "setPowerset",
  category: "Set",
  syntax: ["setPowerset(set)"],
  description: "Create the powerset of a (multi)set: the powerset contains very possible subsets of a (multi)set. A multi-dimension array will be converted to a single-dimension array before the operation.",
  examples: ["setPowerset([1, 2, 3])"],
  seealso: ["setCartesian"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setSize.js
var setSizeDocs = {
  name: "setSize",
  category: "Set",
  syntax: ["setSize(set)", "setSize(set, unique)"],
  description: 'Count the number of elements of a (multi)set. When the second parameter "unique" is true, count only the unique values. A multi-dimension array will be converted to a single-dimension array before the operation.',
  examples: ["setSize([1, 2, 2, 4])", "setSize([1, 2, 2, 4], true)"],
  seealso: ["setUnion", "setIntersect", "setDifference"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setSymDifference.js
var setSymDifferenceDocs = {
  name: "setSymDifference",
  category: "Set",
  syntax: ["setSymDifference(set1, set2)"],
  description: "Create the symmetric difference of two (multi)sets. Multi-dimension arrays will be converted to single-dimension arrays before the operation.",
  examples: ["setSymDifference([1, 2, 3, 4], [3, 4, 5, 6])", "setSymDifference([[1, 2], [3, 4]], [[3, 4], [5, 6]])"],
  seealso: ["setUnion", "setIntersect", "setDifference"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/set/setUnion.js
var setUnionDocs = {
  name: "setUnion",
  category: "Set",
  syntax: ["setUnion(set1, set2)"],
  description: "Create the union of two (multi)sets. Multi-dimension arrays will be converted to single-dimension arrays before the operation.",
  examples: ["setUnion([1, 2, 3, 4], [3, 4, 5, 6])", "setUnion([[1, 2], [3, 4]], [[3, 4], [5, 6]])"],
  seealso: ["setIntersect", "setDifference"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/signal/zpk2tf.js
var zpk2tfDocs = {
  name: "zpk2tf",
  category: "Signal",
  syntax: ["zpk2tf(z, p, k)"],
  description: "Compute the transfer function of a zero-pole-gain model.",
  examples: ["zpk2tf([1, 2], [-1, -2], 1)", "zpk2tf([1, 2], [-1, -2])", "zpk2tf([1 - 3i, 2 + 2i], [-1, -2])"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/signal/freqz.js
var freqzDocs = {
  name: "freqz",
  category: "Signal",
  syntax: ["freqz(b, a)", "freqz(b, a, w)"],
  description: "Calculates the frequency response of a filter given its numerator and denominator coefficients.",
  examples: ["freqz([1, 2], [1, 2, 3])", "freqz([1, 2], [1, 2, 3], [0, 1])", "freqz([1, 2], [1, 2, 3], 512)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/special/erf.js
var erfDocs = {
  name: "erf",
  category: "Special",
  syntax: ["erf(x)"],
  description: "Compute the erf function of a value using a rational Chebyshev approximations for different intervals of x",
  examples: ["erf(0.2)", "erf(-0.5)", "erf(4)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/special/zeta.js
var zetaDocs = {
  name: "zeta",
  category: "Special",
  syntax: ["zeta(s)"],
  description: "Compute the Riemann Zeta Function using an infinite series and Riemann's Functional Equation for the entire complex plane",
  examples: ["zeta(0.2)", "zeta(-0.5)", "zeta(4)"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/mad.js
var madDocs = {
  name: "mad",
  category: "Statistics",
  syntax: ["mad(a, b, c, ...)", "mad(A)"],
  description: "Compute the median absolute deviation of a matrix or a list with values. The median absolute deviation is defined as the median of the absolute deviations from the median.",
  examples: ["mad(10, 20, 30)", "mad([1, 2, 3])"],
  seealso: ["mean", "median", "std", "abs"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/max.js
var maxDocs = {
  name: "max",
  category: "Statistics",
  syntax: ["max(a, b, c, ...)", "max(A)", "max(A, dimension)"],
  description: "Compute the maximum value of a list of values. If any NaN values are found, the function yields the last NaN in the input.",
  examples: ["max(2, 3, 4, 1)", "max([2, 3, 4, 1])", "max([2, 5; 4, 3])", "max([2, 5; 4, 3], 1)", "max([2, 5; 4, 3], 2)", "max(2.7, 7.1, -4.5, 2.0, 4.1)", "min(2.7, 7.1, -4.5, 2.0, 4.1)"],
  seealso: ["mean", "median", "min", "prod", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/mean.js
var meanDocs = {
  name: "mean",
  category: "Statistics",
  syntax: ["mean(a, b, c, ...)", "mean(A)", "mean(A, dimension)"],
  description: "Compute the arithmetic mean of a list of values.",
  examples: ["mean(2, 3, 4, 1)", "mean([2, 3, 4, 1])", "mean([2, 5; 4, 3])", "mean([2, 5; 4, 3], 1)", "mean([2, 5; 4, 3], 2)", "mean([1.0, 2.7, 3.2, 4.0])"],
  seealso: ["max", "median", "min", "prod", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/median.js
var medianDocs = {
  name: "median",
  category: "Statistics",
  syntax: ["median(a, b, c, ...)", "median(A)"],
  description: "Compute the median of all values. The values are sorted and the middle value is returned. In case of an even number of values, the average of the two middle values is returned.",
  examples: ["median(5, 2, 7)", "median([3, -1, 5, 7])"],
  seealso: ["max", "mean", "min", "prod", "std", "sum", "variance", "quantileSeq"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/min.js
var minDocs = {
  name: "min",
  category: "Statistics",
  syntax: ["min(a, b, c, ...)", "min(A)", "min(A, dimension)"],
  description: "Compute the minimum value of a list of values. If any NaN values are found, the function yields the last NaN in the input.",
  examples: ["min(2, 3, 4, 1)", "min([2, 3, 4, 1])", "min([2, 5; 4, 3])", "min([2, 5; 4, 3], 1)", "min([2, 5; 4, 3], 2)", "min(2.7, 7.1, -4.5, 2.0, 4.1)", "max(2.7, 7.1, -4.5, 2.0, 4.1)"],
  seealso: ["max", "mean", "median", "prod", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/mode.js
var modeDocs = {
  name: "mode",
  category: "Statistics",
  syntax: ["mode(a, b, c, ...)", "mode(A)", "mode(A, a, b, B, c, ...)"],
  description: "Computes the mode of all values as an array. In case mode being more than one, multiple values are returned in an array.",
  examples: ["mode(2, 1, 4, 3, 1)", "mode([1, 2.7, 3.2, 4, 2.7])", "mode(1, 4, 6, 1, 6)"],
  seealso: ["max", "mean", "min", "median", "prod", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/prod.js
var prodDocs = {
  name: "prod",
  category: "Statistics",
  syntax: ["prod(a, b, c, ...)", "prod(A)"],
  description: "Compute the product of all values.",
  examples: ["prod(2, 3, 4)", "prod([2, 3, 4])", "prod([2, 5; 4, 3])"],
  seealso: ["max", "mean", "min", "median", "min", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/quantileSeq.js
var quantileSeqDocs = {
  name: "quantileSeq",
  category: "Statistics",
  syntax: ["quantileSeq(A, prob[, sorted])", "quantileSeq(A, [prob1, prob2, ...][, sorted])", "quantileSeq(A, N[, sorted])"],
  description: "Compute the prob order quantile of a matrix or a list with values. The sequence is sorted and the middle value is returned. Supported types of sequence values are: Number, BigNumber, Unit Supported types of probability are: Number, BigNumber. \n\nIn case of a (multi dimensional) array or matrix, the prob order quantile of all elements will be calculated.",
  examples: ["quantileSeq([3, -1, 5, 7], 0.5)", "quantileSeq([3, -1, 5, 7], [1/3, 2/3])", "quantileSeq([3, -1, 5, 7], 2)", "quantileSeq([-1, 3, 5, 7], 0.5, true)"],
  seealso: ["mean", "median", "min", "max", "prod", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/std.js
var stdDocs = {
  name: "std",
  category: "Statistics",
  syntax: ["std(a, b, c, ...)", "std(A)", "std(A, dimension)", "std(A, normalization)", "std(A, dimension, normalization)"],
  description: 'Compute the standard deviation of all values, defined as std(A) = sqrt(variance(A)). Optional parameter normalization can be "unbiased" (default), "uncorrected", or "biased".',
  examples: ["std(2, 4, 6)", "std([2, 4, 6, 8])", 'std([2, 4, 6, 8], "uncorrected")', 'std([2, 4, 6, 8], "biased")', "std([1, 2, 3; 4, 5, 6])"],
  seealso: ["max", "mean", "min", "median", "prod", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/cumsum.js
var cumSumDocs = {
  name: "cumsum",
  category: "Statistics",
  syntax: ["cumsum(a, b, c, ...)", "cumsum(A)"],
  description: "Compute the cumulative sum of all values.",
  examples: ["cumsum(2, 3, 4, 1)", "cumsum([2, 3, 4, 1])", "cumsum([1, 2; 3, 4])", "cumsum([1, 2; 3, 4], 1)", "cumsum([1, 2; 3, 4], 2)"],
  seealso: ["max", "mean", "median", "min", "prod", "std", "sum", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/sum.js
var sumDocs = {
  name: "sum",
  category: "Statistics",
  syntax: ["sum(a, b, c, ...)", "sum(A)", "sum(A, dimension)"],
  description: "Compute the sum of all values.",
  examples: ["sum(2, 3, 4, 1)", "sum([2, 3, 4, 1])", "sum([2, 5; 4, 3])"],
  seealso: ["max", "mean", "median", "min", "prod", "std", "variance"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/variance.js
var varianceDocs = {
  name: "variance",
  category: "Statistics",
  syntax: ["variance(a, b, c, ...)", "variance(A)", "variance(A, dimension)", "variance(A, normalization)", "variance(A, dimension, normalization)"],
  description: 'Compute the variance of all values. Optional parameter normalization can be "unbiased" (default), "uncorrected", or "biased".',
  examples: ["variance(2, 4, 6)", "variance([2, 4, 6, 8])", 'variance([2, 4, 6, 8], "uncorrected")', 'variance([2, 4, 6, 8], "biased")', "variance([1, 2, 3; 4, 5, 6])"],
  seealso: ["max", "mean", "min", "median", "min", "prod", "std", "sum"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/statistics/corr.js
var corrDocs = {
  name: "corr",
  category: "Statistics",
  syntax: ["corr(A,B)"],
  description: "Compute the correlation coefficient of a two list with values, For matrices, the matrix correlation coefficient is calculated.",
  examples: ["corr([2, 4, 6, 8],[1, 2, 3, 6])", "corr(matrix([[1, 2.2, 3, 4.8, 5], [1, 2, 3, 4, 5]]), matrix([[4, 5.3, 6.6, 7, 8], [1, 2, 3, 4, 5]]))"],
  seealso: ["max", "mean", "min", "median", "min", "prod", "std", "sum"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/acos.js
var acosDocs = {
  name: "acos",
  category: "Trigonometry",
  syntax: ["acos(x)"],
  description: "Compute the inverse cosine of a value in radians.",
  examples: ["acos(0.5)", "acos(cos(2.3))"],
  seealso: ["cos", "atan", "asin"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/acosh.js
var acoshDocs = {
  name: "acosh",
  category: "Trigonometry",
  syntax: ["acosh(x)"],
  description: "Calculate the hyperbolic arccos of a value, defined as `acosh(x) = ln(sqrt(x^2 - 1) + x)`.",
  examples: ["acosh(1.5)"],
  seealso: ["cosh", "asinh", "atanh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/acot.js
var acotDocs = {
  name: "acot",
  category: "Trigonometry",
  syntax: ["acot(x)"],
  description: "Calculate the inverse cotangent of a value.",
  examples: ["acot(0.5)", "acot(cot(0.5))", "acot(2)"],
  seealso: ["cot", "atan"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/acoth.js
var acothDocs = {
  name: "acoth",
  category: "Trigonometry",
  syntax: ["acoth(x)"],
  description: "Calculate the inverse hyperbolic tangent of a value, defined as `acoth(x) = (ln((x+1)/x) + ln(x/(x-1))) / 2`.",
  examples: ["acoth(2)", "acoth(0.5)"],
  seealso: ["acsch", "asech"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/acsc.js
var acscDocs = {
  name: "acsc",
  category: "Trigonometry",
  syntax: ["acsc(x)"],
  description: "Calculate the inverse cotangent of a value.",
  examples: ["acsc(2)", "acsc(csc(0.5))", "acsc(0.5)"],
  seealso: ["csc", "asin", "asec"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/acsch.js
var acschDocs = {
  name: "acsch",
  category: "Trigonometry",
  syntax: ["acsch(x)"],
  description: "Calculate the inverse hyperbolic cosecant of a value, defined as `acsch(x) = ln(1/x + sqrt(1/x^2 + 1))`.",
  examples: ["acsch(0.5)"],
  seealso: ["asech", "acoth"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/asec.js
var asecDocs = {
  name: "asec",
  category: "Trigonometry",
  syntax: ["asec(x)"],
  description: "Calculate the inverse secant of a value.",
  examples: ["asec(0.5)", "asec(sec(0.5))", "asec(2)"],
  seealso: ["acos", "acot", "acsc"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/asech.js
var asechDocs = {
  name: "asech",
  category: "Trigonometry",
  syntax: ["asech(x)"],
  description: "Calculate the inverse secant of a value.",
  examples: ["asech(0.5)"],
  seealso: ["acsch", "acoth"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/asin.js
var asinDocs = {
  name: "asin",
  category: "Trigonometry",
  syntax: ["asin(x)"],
  description: "Compute the inverse sine of a value in radians.",
  examples: ["asin(0.5)", "asin(sin(0.5))"],
  seealso: ["sin", "acos", "atan"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/asinh.js
var asinhDocs = {
  name: "asinh",
  category: "Trigonometry",
  syntax: ["asinh(x)"],
  description: "Calculate the hyperbolic arcsine of a value, defined as `asinh(x) = ln(x + sqrt(x^2 + 1))`.",
  examples: ["asinh(0.5)"],
  seealso: ["acosh", "atanh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/atan.js
var atanDocs = {
  name: "atan",
  category: "Trigonometry",
  syntax: ["atan(x)"],
  description: "Compute the inverse tangent of a value in radians.",
  examples: ["atan(0.5)", "atan(tan(0.5))"],
  seealso: ["tan", "acos", "asin"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/atan2.js
var atan2Docs = {
  name: "atan2",
  category: "Trigonometry",
  syntax: ["atan2(y, x)"],
  description: "Computes the principal value of the arc tangent of y/x in radians.",
  examples: ["atan2(2, 2) / pi", "angle = 60 deg in rad", "x = cos(angle)", "y = sin(angle)", "atan2(y, x)"],
  seealso: ["sin", "cos", "tan"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/atanh.js
var atanhDocs = {
  name: "atanh",
  category: "Trigonometry",
  syntax: ["atanh(x)"],
  description: "Calculate the hyperbolic arctangent of a value, defined as `atanh(x) = ln((1 + x)/(1 - x)) / 2`.",
  examples: ["atanh(0.5)"],
  seealso: ["acosh", "asinh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/cos.js
var cosDocs = {
  name: "cos",
  category: "Trigonometry",
  syntax: ["cos(x)"],
  description: "Compute the cosine of x in radians.",
  examples: ["cos(2)", "cos(pi / 4) ^ 2", "cos(180 deg)", "cos(60 deg)", "sin(0.2)^2 + cos(0.2)^2"],
  seealso: ["acos", "sin", "tan"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/cosh.js
var coshDocs = {
  name: "cosh",
  category: "Trigonometry",
  syntax: ["cosh(x)"],
  description: "Compute the hyperbolic cosine of x in radians.",
  examples: ["cosh(0.5)"],
  seealso: ["sinh", "tanh", "coth"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/cot.js
var cotDocs = {
  name: "cot",
  category: "Trigonometry",
  syntax: ["cot(x)"],
  description: "Compute the cotangent of x in radians. Defined as 1/tan(x)",
  examples: ["cot(2)", "1 / tan(2)"],
  seealso: ["sec", "csc", "tan"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/coth.js
var cothDocs = {
  name: "coth",
  category: "Trigonometry",
  syntax: ["coth(x)"],
  description: "Compute the hyperbolic cotangent of x in radians.",
  examples: ["coth(2)", "1 / tanh(2)"],
  seealso: ["sech", "csch", "tanh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/csc.js
var cscDocs = {
  name: "csc",
  category: "Trigonometry",
  syntax: ["csc(x)"],
  description: "Compute the cosecant of x in radians. Defined as 1/sin(x)",
  examples: ["csc(2)", "1 / sin(2)"],
  seealso: ["sec", "cot", "sin"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/csch.js
var cschDocs = {
  name: "csch",
  category: "Trigonometry",
  syntax: ["csch(x)"],
  description: "Compute the hyperbolic cosecant of x in radians. Defined as 1/sinh(x)",
  examples: ["csch(2)", "1 / sinh(2)"],
  seealso: ["sech", "coth", "sinh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/sec.js
var secDocs = {
  name: "sec",
  category: "Trigonometry",
  syntax: ["sec(x)"],
  description: "Compute the secant of x in radians. Defined as 1/cos(x)",
  examples: ["sec(2)", "1 / cos(2)"],
  seealso: ["cot", "csc", "cos"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/sech.js
var sechDocs = {
  name: "sech",
  category: "Trigonometry",
  syntax: ["sech(x)"],
  description: "Compute the hyperbolic secant of x in radians. Defined as 1/cosh(x)",
  examples: ["sech(2)", "1 / cosh(2)"],
  seealso: ["coth", "csch", "cosh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/sin.js
var sinDocs = {
  name: "sin",
  category: "Trigonometry",
  syntax: ["sin(x)"],
  description: "Compute the sine of x in radians.",
  examples: ["sin(2)", "sin(pi / 4) ^ 2", "sin(90 deg)", "sin(30 deg)", "sin(0.2)^2 + cos(0.2)^2"],
  seealso: ["asin", "cos", "tan"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/sinh.js
var sinhDocs = {
  name: "sinh",
  category: "Trigonometry",
  syntax: ["sinh(x)"],
  description: "Compute the hyperbolic sine of x in radians.",
  examples: ["sinh(0.5)"],
  seealso: ["cosh", "tanh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/tan.js
var tanDocs = {
  name: "tan",
  category: "Trigonometry",
  syntax: ["tan(x)"],
  description: "Compute the tangent of x in radians.",
  examples: ["tan(0.5)", "sin(0.5) / cos(0.5)", "tan(pi / 4)", "tan(45 deg)"],
  seealso: ["atan", "sin", "cos"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/trigonometry/tanh.js
var tanhDocs = {
  name: "tanh",
  category: "Trigonometry",
  syntax: ["tanh(x)"],
  description: "Compute the hyperbolic tangent of x in radians.",
  examples: ["tanh(0.5)", "sinh(0.5) / cosh(0.5)"],
  seealso: ["sinh", "cosh"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/units/to.js
var toDocs = {
  name: "to",
  category: "Units",
  syntax: ["x to unit", "to(x, unit)"],
  description: "Change the unit of a value.",
  examples: ["5 inch to cm", "3.2kg to g", "16 bytes in bits"],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/units/toBest.js
var toBestDocs = {
  name: "toBest",
  category: "Units",
  syntax: ["toBest(x)", "toBest(x, unitList)", "toBest(x, unitList, options)"],
  description: "Converts to the most appropriate display unit.",
  examples: ['toBest(unit(5000, "m"))', 'toBest(unit(3500000, "W"))', 'toBest(unit(0.000000123, "A"))', 'toBest(unit(10, "m"), "cm")', 'toBest(unit(10, "m"), "mm,km", {offset: 1.5})'],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/bin.js
var binDocs = {
  name: "bin",
  category: "Utils",
  syntax: ["bin(value)"],
  description: "Format a number as binary",
  examples: ["bin(2)"],
  seealso: ["oct", "hex"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/clone.js
var cloneDocs = {
  name: "clone",
  category: "Utils",
  syntax: ["clone(x)"],
  description: "Clone a variable. Creates a copy of primitive variables, and a deep copy of matrices",
  examples: ["clone(3.5)", "clone(2 - 4i)", "clone(45 deg)", "clone([1, 2; 3, 4])", 'clone("hello world")'],
  seealso: []
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/format.js
var formatDocs = {
  name: "format",
  category: "Utils",
  syntax: ["format(value)", "format(value, precision)"],
  description: "Format a value of any type as string.",
  examples: ["format(2.3)", "format(3 - 4i)", "format([])", "format(pi, 3)"],
  seealso: ["print"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/hasNumericValue.js
var hasNumericValueDocs = {
  name: "hasNumericValue",
  category: "Utils",
  syntax: ["hasNumericValue(x)"],
  description: "Test whether a value is an numeric value. In case of a string, true is returned if the string contains a numeric value.",
  examples: ["hasNumericValue(2)", 'hasNumericValue("2")', 'isNumeric("2")', "hasNumericValue(0)", "hasNumericValue(bignumber(500))", "hasNumericValue(fraction(0.125))", "hasNumericValue(2 + 3i)", 'hasNumericValue([2.3, "foo", false])'],
  seealso: ["isInteger", "isZero", "isNegative", "isPositive", "isNaN", "isNumeric"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/hex.js
var hexDocs = {
  name: "hex",
  category: "Utils",
  syntax: ["hex(value)"],
  description: "Format a number as hexadecimal",
  examples: ["hex(240)"],
  seealso: ["bin", "oct"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isInteger.js
var isIntegerDocs = {
  name: "isInteger",
  category: "Utils",
  syntax: ["isInteger(x)"],
  description: "Test whether a value is an integer number.",
  examples: ["isInteger(2)", "isInteger(3.5)", "isInteger([3, 0.5, -2])"],
  seealso: ["isNegative", "isNumeric", "isPositive", "isZero"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isNaN.js
var isNaNDocs = {
  name: "isNaN",
  category: "Utils",
  syntax: ["isNaN(x)"],
  description: "Test whether a value is NaN (not a number)",
  examples: ["isNaN(2)", "isNaN(0 / 0)", "isNaN(NaN)", "isNaN(Infinity)"],
  seealso: ["isNegative", "isNumeric", "isPositive", "isZero", "isFinite", "isBounded"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isBounded.js
var isBoundedDocs = {
  name: "isBounded",
  category: "Utils",
  syntax: ["isBounded(x)"],
  description: "Test whether a value or its entries are bounded.",
  examples: ["isBounded(Infinity)", "isBounded(bigint(3))", "isBounded([3, -Infinity, -3])"],
  seealso: ["isFinite", "isNumeric", "isNaN", "isNegative", "isPositive"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isFinite.js
var isFiniteDocs = {
  name: "isFinite",
  category: "Utils",
  syntax: ["isFinite(x)"],
  description: "Test whether a value is finite, elementwise on collections.",
  examples: ["isFinite(Infinity)", "isFinite(bigint(3))", "isFinite([3, -Infinity, -3])"],
  seealso: ["isBounded", "isNumeric", "isNaN", "isNegative", "isPositive"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isNegative.js
var isNegativeDocs = {
  name: "isNegative",
  category: "Utils",
  syntax: ["isNegative(x)"],
  description: "Test whether a value is negative: smaller than zero.",
  examples: ["isNegative(2)", "isNegative(0)", "isNegative(-4)", "isNegative([3, 0.5, -2])"],
  seealso: ["isInteger", "isNumeric", "isPositive", "isZero"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isNumeric.js
var isNumericDocs = {
  name: "isNumeric",
  category: "Utils",
  syntax: ["isNumeric(x)"],
  description: "Test whether a value is a numeric value. Returns true when the input is a number, BigNumber, Fraction, or boolean.",
  examples: ["isNumeric(2)", 'isNumeric("2")', 'hasNumericValue("2")', "isNumeric(0)", "isNumeric(bignumber(500))", "isNumeric(fraction(0.125))", "isNumeric(2 + 3i)", 'isNumeric([2.3, "foo", false])'],
  seealso: ["isInteger", "isZero", "isNegative", "isPositive", "isNaN", "hasNumericValue", "isFinite", "isBounded"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isPositive.js
var isPositiveDocs = {
  name: "isPositive",
  category: "Utils",
  syntax: ["isPositive(x)"],
  description: "Test whether a value is positive: larger than zero.",
  examples: ["isPositive(2)", "isPositive(0)", "isPositive(-4)", "isPositive([3, 0.5, -2])"],
  seealso: ["isInteger", "isNumeric", "isNegative", "isZero"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isPrime.js
var isPrimeDocs = {
  name: "isPrime",
  category: "Utils",
  syntax: ["isPrime(x)"],
  description: "Test whether a value is prime: has no divisors other than itself and one.",
  examples: ["isPrime(3)", "isPrime(-2)", "isPrime([2, 17, 100])"],
  seealso: ["isInteger", "isNumeric", "isNegative", "isZero"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/isZero.js
var isZeroDocs = {
  name: "isZero",
  category: "Utils",
  syntax: ["isZero(x)"],
  description: "Test whether a value is zero.",
  examples: ["isZero(2)", "isZero(0)", "isZero(-4)", "isZero([3, 0, -2, 0])"],
  seealso: ["isInteger", "isNumeric", "isNegative", "isPositive"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/numeric.js
var numericDocs = {
  name: "numeric",
  category: "Utils",
  syntax: ["numeric(x)"],
  description: "Convert a numeric input to a specific numeric type: number, BigNumber, bigint, or Fraction.",
  examples: ['numeric("4")', 'numeric("4", "number")', 'numeric("4", "bigint")', 'numeric("4", "BigNumber")', 'numeric("4", "Fraction")', 'numeric(4, "Fraction")', 'numeric(fraction(2, 5), "number")'],
  seealso: ["number", "bigint", "fraction", "bignumber", "string", "format"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/oct.js
var octDocs = {
  name: "oct",
  category: "Utils",
  syntax: ["oct(value)"],
  description: "Format a number as octal",
  examples: ["oct(56)"],
  seealso: ["bin", "hex"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/print.js
var printDocs = {
  name: "print",
  category: "Utils",
  syntax: ["print(template, values)", "print(template, values, precision)"],
  description: "Interpolate values into a string template.",
  examples: ['print("Lucy is $age years old", {age: 5})', 'print("The value of pi is $pi", {pi: pi}, 3)', 'print("Hello, $user.name!", {user: {name: "John"}})', 'print("Values: $1, $2, $3", [6, 9, 4])'],
  seealso: ["format"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/utils/typeOf.js
var typeOfDocs = {
  name: "typeOf",
  category: "Utils",
  syntax: ["typeOf(x)"],
  description: "Get the type of a variable.",
  examples: ["typeOf(3.5)", "typeOf(2 - 4i)", "typeOf(45 deg)", 'typeOf("hello world")'],
  seealso: ["getMatrixDataType"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/function/numeric/solveODE.js
var solveODEDocs = {
  name: "solveODE",
  category: "Numeric",
  syntax: ["solveODE(func, tspan, y0)", "solveODE(func, tspan, y0, options)"],
  description: "Numerical Integration of Ordinary Differential Equations.",
  examples: ["f(t,y) = y", "tspan = [0, 4]", "solveODE(f, tspan, 1)", "solveODE(f, tspan, [1, 2])", 'solveODE(f, tspan, 1, { method:"RK23", maxStep:0.1 })'],
  seealso: ["derivative", "simplifyCore"]
};

// node_modules/mathjs/lib/esm/expression/embeddedDocs/embeddedDocs.js
var embeddedDocs = {
  // construction functions
  bignumber: bignumberDocs,
  bigint: bigintDocs,
  boolean: booleanDocs,
  complex: complexDocs,
  createUnit: createUnitDocs,
  fraction: fractionDocs,
  index: indexDocs,
  matrix: matrixDocs,
  number: numberDocs,
  sparse: sparseDocs,
  splitUnit: splitUnitDocs,
  string: stringDocs,
  unit: unitDocs,
  // constants
  e: eDocs,
  E: eDocs,
  false: falseDocs,
  i: iDocs,
  Infinity: InfinityDocs,
  LN2: LN2Docs,
  LN10: LN10Docs,
  LOG2E: LOG2EDocs,
  LOG10E: LOG10EDocs,
  NaN: NaNDocs,
  null: nullDocs,
  pi: piDocs,
  PI: piDocs,
  phi: phiDocs,
  SQRT1_2: SQRT12Docs,
  SQRT2: SQRT2Docs,
  tau: tauDocs,
  true: trueDocs,
  version: versionDocs,
  // physical constants
  // TODO: more detailed docs for physical constants
  speedOfLight: {
    description: "Speed of light in vacuum",
    examples: ["speedOfLight"]
  },
  gravitationConstant: {
    description: "Newtonian constant of gravitation",
    examples: ["gravitationConstant"]
  },
  planckConstant: {
    description: "Planck constant",
    examples: ["planckConstant"]
  },
  reducedPlanckConstant: {
    description: "Reduced Planck constant",
    examples: ["reducedPlanckConstant"]
  },
  magneticConstant: {
    description: "Magnetic constant (vacuum permeability)",
    examples: ["magneticConstant"]
  },
  electricConstant: {
    description: "Electric constant (vacuum permeability)",
    examples: ["electricConstant"]
  },
  vacuumImpedance: {
    description: "Characteristic impedance of vacuum",
    examples: ["vacuumImpedance"]
  },
  coulomb: {
    description: "Coulomb's constant. Deprecated in favor of coulombConstant",
    examples: ["coulombConstant"]
  },
  coulombConstant: {
    description: "Coulomb's constant",
    examples: ["coulombConstant"]
  },
  elementaryCharge: {
    description: "Elementary charge",
    examples: ["elementaryCharge"]
  },
  bohrMagneton: {
    description: "Bohr magneton",
    examples: ["bohrMagneton"]
  },
  conductanceQuantum: {
    description: "Conductance quantum",
    examples: ["conductanceQuantum"]
  },
  inverseConductanceQuantum: {
    description: "Inverse conductance quantum",
    examples: ["inverseConductanceQuantum"]
  },
  // josephson: {description: 'Josephson constant', examples: ['josephson']},
  magneticFluxQuantum: {
    description: "Magnetic flux quantum",
    examples: ["magneticFluxQuantum"]
  },
  nuclearMagneton: {
    description: "Nuclear magneton",
    examples: ["nuclearMagneton"]
  },
  klitzing: {
    description: "Von Klitzing constant",
    examples: ["klitzing"]
  },
  bohrRadius: {
    description: "Bohr radius",
    examples: ["bohrRadius"]
  },
  classicalElectronRadius: {
    description: "Classical electron radius",
    examples: ["classicalElectronRadius"]
  },
  electronMass: {
    description: "Electron mass",
    examples: ["electronMass"]
  },
  fermiCoupling: {
    description: "Fermi coupling constant",
    examples: ["fermiCoupling"]
  },
  fineStructure: {
    description: "Fine-structure constant",
    examples: ["fineStructure"]
  },
  hartreeEnergy: {
    description: "Hartree energy",
    examples: ["hartreeEnergy"]
  },
  protonMass: {
    description: "Proton mass",
    examples: ["protonMass"]
  },
  deuteronMass: {
    description: "Deuteron Mass",
    examples: ["deuteronMass"]
  },
  neutronMass: {
    description: "Neutron mass",
    examples: ["neutronMass"]
  },
  quantumOfCirculation: {
    description: "Quantum of circulation",
    examples: ["quantumOfCirculation"]
  },
  rydberg: {
    description: "Rydberg constant",
    examples: ["rydberg"]
  },
  thomsonCrossSection: {
    description: "Thomson cross section",
    examples: ["thomsonCrossSection"]
  },
  weakMixingAngle: {
    description: "Weak mixing angle",
    examples: ["weakMixingAngle"]
  },
  efimovFactor: {
    description: "Efimov factor",
    examples: ["efimovFactor"]
  },
  atomicMass: {
    description: "Atomic mass constant",
    examples: ["atomicMass"]
  },
  avogadro: {
    description: "Avogadro's number",
    examples: ["avogadro"]
  },
  boltzmann: {
    description: "Boltzmann constant",
    examples: ["boltzmann"]
  },
  faraday: {
    description: "Faraday constant",
    examples: ["faraday"]
  },
  firstRadiation: {
    description: "First radiation constant",
    examples: ["firstRadiation"]
  },
  loschmidt: {
    description: "Loschmidt constant at T=273.15 K and p=101.325 kPa",
    examples: ["loschmidt"]
  },
  gasConstant: {
    description: "Gas constant",
    examples: ["gasConstant"]
  },
  molarPlanckConstant: {
    description: "Molar Planck constant",
    examples: ["molarPlanckConstant"]
  },
  molarVolume: {
    description: "Molar volume of an ideal gas at T=273.15 K and p=101.325 kPa",
    examples: ["molarVolume"]
  },
  sackurTetrode: {
    description: "Sackur-Tetrode constant at T=1 K and p=101.325 kPa",
    examples: ["sackurTetrode"]
  },
  secondRadiation: {
    description: "Second radiation constant",
    examples: ["secondRadiation"]
  },
  stefanBoltzmann: {
    description: "Stefan-Boltzmann constant",
    examples: ["stefanBoltzmann"]
  },
  wienDisplacement: {
    description: "Wien displacement law constant",
    examples: ["wienDisplacement"]
  },
  // spectralRadiance: {description: 'First radiation constant for spectral radiance', examples: ['spectralRadiance']},
  molarMass: {
    description: "Molar mass constant",
    examples: ["molarMass"]
  },
  molarMassC12: {
    description: "Molar mass constant of carbon-12",
    examples: ["molarMassC12"]
  },
  gravity: {
    description: "Standard acceleration of gravity (standard acceleration of free-fall on Earth)",
    examples: ["gravity"]
  },
  planckLength: {
    description: "Planck length",
    examples: ["planckLength"]
  },
  planckMass: {
    description: "Planck mass",
    examples: ["planckMass"]
  },
  planckTime: {
    description: "Planck time",
    examples: ["planckTime"]
  },
  planckCharge: {
    description: "Planck charge",
    examples: ["planckCharge"]
  },
  planckTemperature: {
    description: "Planck temperature",
    examples: ["planckTemperature"]
  },
  // functions - algebra
  derivative: derivativeDocs,
  lsolve: lsolveDocs,
  lsolveAll: lsolveAllDocs,
  lup: lupDocs,
  lusolve: lusolveDocs,
  leafCount: leafCountDocs,
  polynomialRoot: polynomialRootDocs,
  resolve: resolveDocs,
  simplify: simplifyDocs,
  simplifyConstant: simplifyConstantDocs,
  simplifyCore: simplifyCoreDocs,
  symbolicEqual: symbolicEqualDocs,
  rationalize: rationalizeDocs,
  slu: sluDocs,
  usolve: usolveDocs,
  usolveAll: usolveAllDocs,
  qr: qrDocs,
  // functions - arithmetic
  abs: absDocs,
  add: addDocs,
  cbrt: cbrtDocs,
  ceil: ceilDocs,
  cube: cubeDocs,
  divide: divideDocs,
  dotDivide: dotDivideDocs,
  dotMultiply: dotMultiplyDocs,
  dotPow: dotPowDocs,
  exp: expDocs,
  expm: expmDocs,
  expm1: expm1Docs,
  fix: fixDocs,
  floor: floorDocs,
  gcd: gcdDocs,
  hypot: hypotDocs,
  lcm: lcmDocs,
  log: logDocs,
  log2: log2Docs,
  log1p: log1pDocs,
  log10: log10Docs,
  mod: modDocs,
  multiply: multiplyDocs,
  norm: normDocs,
  nthRoot: nthRootDocs,
  nthRoots: nthRootsDocs,
  pow: powDocs,
  round: roundDocs,
  sign: signDocs,
  sqrt: sqrtDocs,
  sqrtm: sqrtmDocs,
  square: squareDocs,
  subtract: subtractDocs,
  unaryMinus: unaryMinusDocs,
  unaryPlus: unaryPlusDocs,
  xgcd: xgcdDocs,
  invmod: invmodDocs,
  num: numDocs,
  den: denDocs,
  // functions - bitwise
  bitAnd: bitAndDocs,
  bitNot: bitNotDocs,
  bitOr: bitOrDocs,
  bitXor: bitXorDocs,
  leftShift: leftShiftDocs,
  rightArithShift: rightArithShiftDocs,
  rightLogShift: rightLogShiftDocs,
  // functions - combinatorics
  bellNumbers: bellNumbersDocs,
  catalan: catalanDocs,
  composition: compositionDocs,
  stirlingS2: stirlingS2Docs,
  // functions - core
  config: configDocs,
  import: importDocs,
  typed: typedDocs,
  // functions - complex
  arg: argDocs,
  conj: conjDocs,
  re: reDocs,
  im: imDocs,
  // functions - expression
  evaluate: evaluateDocs,
  help: helpDocs,
  parse: parseDocs,
  parser: parserDocs,
  compile: compileDocs,
  // functions - geometry
  distance: distanceDocs,
  intersect: intersectDocs,
  // functions - logical
  and: andDocs,
  not: notDocs,
  nullish: nullishDocs,
  or: orDocs,
  xor: xorDocs,
  // functions - matrix
  mapSlices: mapSlicesDocs,
  concat: concatDocs,
  count: countDocs,
  cross: crossDocs,
  column: columnDocs,
  ctranspose: ctransposeDocs,
  det: detDocs,
  diag: diagDocs,
  diff: diffDocs,
  dot: dotDocs,
  getMatrixDataType: getMatrixDataTypeDocs,
  identity: identityDocs,
  filter: filterDocs,
  flatten: flattenDocs,
  forEach: forEachDocs,
  inv: invDocs,
  pinv: pinvDocs,
  eigs: eigsDocs,
  kron: kronDocs,
  matrixFromFunction: matrixFromFunctionDocs,
  matrixFromRows: matrixFromRowsDocs,
  matrixFromColumns: matrixFromColumnsDocs,
  map: mapDocs,
  ones: onesDocs,
  partitionSelect: partitionSelectDocs,
  range: rangeDocs,
  resize: resizeDocs,
  reshape: reshapeDocs,
  rotate: rotateDocs,
  rotationMatrix: rotationMatrixDocs,
  row: rowDocs,
  size: sizeDocs,
  sort: sortDocs,
  squeeze: squeezeDocs,
  subset: subsetDocs,
  trace: traceDocs,
  transpose: transposeDocs,
  zeros: zerosDocs,
  fft: fftDocs,
  ifft: ifftDocs,
  sylvester: sylvesterDocs,
  schur: schurDocs,
  lyap: lyapDocs,
  // functions - numeric
  solveODE: solveODEDocs,
  // functions - probability
  bernoulli: bernoulliDocs,
  combinations: combinationsDocs,
  combinationsWithRep: combinationsWithRepDocs,
  // distribution: distributionDocs,
  factorial: factorialDocs,
  gamma: gammaDocs,
  kldivergence: kldivergenceDocs,
  lgamma: lgammaDocs,
  multinomial: multinomialDocs,
  permutations: permutationsDocs,
  pickRandom: pickRandomDocs,
  random: randomDocs,
  randomInt: randomIntDocs,
  // functions - relational
  compare: compareDocs,
  compareNatural: compareNaturalDocs,
  compareText: compareTextDocs,
  deepEqual: deepEqualDocs,
  equal: equalDocs,
  equalText: equalTextDocs,
  larger: largerDocs,
  largerEq: largerEqDocs,
  smaller: smallerDocs,
  smallerEq: smallerEqDocs,
  unequal: unequalDocs,
  // functions - set
  setCartesian: setCartesianDocs,
  setDifference: setDifferenceDocs,
  setDistinct: setDistinctDocs,
  setIntersect: setIntersectDocs,
  setIsSubset: setIsSubsetDocs,
  setMultiplicity: setMultiplicityDocs,
  setPowerset: setPowersetDocs,
  setSize: setSizeDocs,
  setSymDifference: setSymDifferenceDocs,
  setUnion: setUnionDocs,
  // functions - signal
  zpk2tf: zpk2tfDocs,
  freqz: freqzDocs,
  // functions - special
  erf: erfDocs,
  zeta: zetaDocs,
  // functions - statistics
  cumsum: cumSumDocs,
  mad: madDocs,
  max: maxDocs,
  mean: meanDocs,
  median: medianDocs,
  min: minDocs,
  mode: modeDocs,
  prod: prodDocs,
  quantileSeq: quantileSeqDocs,
  std: stdDocs,
  sum: sumDocs,
  variance: varianceDocs,
  corr: corrDocs,
  // functions - trigonometry
  acos: acosDocs,
  acosh: acoshDocs,
  acot: acotDocs,
  acoth: acothDocs,
  acsc: acscDocs,
  acsch: acschDocs,
  asec: asecDocs,
  asech: asechDocs,
  asin: asinDocs,
  asinh: asinhDocs,
  atan: atanDocs,
  atanh: atanhDocs,
  atan2: atan2Docs,
  cos: cosDocs,
  cosh: coshDocs,
  cot: cotDocs,
  coth: cothDocs,
  csc: cscDocs,
  csch: cschDocs,
  sec: secDocs,
  sech: sechDocs,
  sin: sinDocs,
  sinh: sinhDocs,
  tan: tanDocs,
  tanh: tanhDocs,
  // functions - units
  to: toDocs,
  toBest: toBestDocs,
  // functions - utils
  clone: cloneDocs,
  format: formatDocs,
  bin: binDocs,
  oct: octDocs,
  hex: hexDocs,
  isNaN: isNaNDocs,
  isBounded: isBoundedDocs,
  isFinite: isFiniteDocs,
  isInteger: isIntegerDocs,
  isNegative: isNegativeDocs,
  isNumeric: isNumericDocs,
  hasNumericValue: hasNumericValueDocs,
  isPositive: isPositiveDocs,
  isPrime: isPrimeDocs,
  isZero: isZeroDocs,
  print: printDocs,
  typeOf: typeOfDocs,
  numeric: numericDocs
};

// node_modules/mathjs/lib/esm/expression/function/help.js
var name5 = "help";
var dependencies6 = ["typed", "mathWithTransform", "Help"];
var createHelp = /* @__PURE__ */ factory(name5, dependencies6, (_ref) => {
  var {
    typed: typed3,
    mathWithTransform: mathWithTransform2,
    Help: Help2
  } = _ref;
  return typed3(name5, {
    any: function any(search) {
      var prop;
      var searchName = search;
      if (typeof search !== "string") {
        for (prop in mathWithTransform2) {
          if (hasOwnProperty(mathWithTransform2, prop) && search === mathWithTransform2[prop]) {
            searchName = prop;
            break;
          }
        }
      }
      var doc = getSafeProperty(embeddedDocs, searchName);
      if (!doc) {
        var searchText = typeof searchName === "function" ? searchName.name : searchName;
        throw new Error('No documentation found on "' + searchText + '"');
      }
      return new Help2(doc);
    }
  });
});

// node_modules/mathjs/lib/esm/type/chain/function/chain.js
var name6 = "chain";
var dependencies7 = ["typed", "Chain"];
var createChain = /* @__PURE__ */ factory(name6, dependencies7, (_ref) => {
  var {
    typed: typed3,
    Chain: Chain2
  } = _ref;
  return typed3(name6, {
    "": function _() {
      return new Chain2();
    },
    any: function any(value) {
      return new Chain2(value);
    }
  });
});

// node_modules/mathjs/lib/esm/function/algebra/resolve.js
var name7 = "resolve";
var dependencies8 = ["typed", "parse", "ConstantNode", "FunctionNode", "OperatorNode", "ParenthesisNode"];
var createResolve = /* @__PURE__ */ factory(name7, dependencies8, (_ref) => {
  var {
    typed: typed3,
    parse: parse2,
    ConstantNode: ConstantNode2,
    FunctionNode: FunctionNode2,
    OperatorNode: OperatorNode2,
    ParenthesisNode: ParenthesisNode2
  } = _ref;
  function _resolve(node, scope) {
    var within = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : /* @__PURE__ */ new Set();
    if (!scope) {
      return node;
    }
    if (isSymbolNode(node)) {
      if (within.has(node.name)) {
        var variables = Array.from(within).join(", ");
        throw new ReferenceError("recursive loop of variable definitions among {".concat(variables, "}"));
      }
      var value = scope.get(node.name);
      if (isNode(value)) {
        var nextWithin = new Set(within);
        nextWithin.add(node.name);
        return _resolve(value, scope, nextWithin);
      } else if (typeof value === "number") {
        return parse2(String(value));
      } else if (value !== void 0) {
        return new ConstantNode2(value);
      } else {
        return node;
      }
    } else if (isOperatorNode(node)) {
      var args = node.args.map(function(arg) {
        return _resolve(arg, scope, within);
      });
      return new OperatorNode2(node.op, node.fn, args, node.implicit);
    } else if (isParenthesisNode(node)) {
      return new ParenthesisNode2(_resolve(node.content, scope, within));
    } else if (isFunctionNode(node)) {
      var _args = node.args.map(function(arg) {
        return _resolve(arg, scope, within);
      });
      return new FunctionNode2(node.name, _args);
    }
    return node.map((child) => _resolve(child, scope, within));
  }
  return typed3("resolve", {
    Node: _resolve,
    "Node, Map | null | undefined": _resolve,
    "Node, Object": (n, scope) => _resolve(n, createMap(scope)),
    // For arrays and matrices, we map `self` rather than `_resolve`
    // because resolve is fairly expensive anyway, and this way
    // we get nice error messages if one entry in the array has wrong type.
    "Array | Matrix": typed3.referToSelf((self2) => (A) => A.map((n) => self2(n))),
    "Array | Matrix, null | undefined": typed3.referToSelf((self2) => (A) => A.map((n) => self2(n))),
    "Array, Object": typed3.referTo("Array,Map", (selfAM) => (A, scope) => selfAM(A, createMap(scope))),
    "Matrix, Object": typed3.referTo("Matrix,Map", (selfMM) => (A, scope) => selfMM(A, createMap(scope))),
    "Array | Matrix, Map": typed3.referToSelf((self2) => (A, scope) => A.map((n) => self2(n, scope)))
  });
});

// node_modules/mathjs/lib/esm/function/algebra/simplify/wildcards.js
function isNumericNode(x) {
  return isConstantNode(x) || isOperatorNode(x) && x.isUnary() && isConstantNode(x.args[0]);
}
function isConstantExpression(x) {
  if (isConstantNode(x)) {
    return true;
  }
  if ((isFunctionNode(x) || isOperatorNode(x)) && x.args.every(isConstantExpression)) {
    return true;
  }
  if (isParenthesisNode(x) && isConstantExpression(x.content)) {
    return true;
  }
  return false;
}

// node_modules/mathjs/lib/esm/function/algebra/simplify/util.js
var import_defineProperty = __toESM(require_defineProperty(), 1);
function ownKeys(e3, r) {
  var t = Object.keys(e3);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e3);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e3, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread(e3) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), true).forEach(function(r2) {
      (0, import_defineProperty.default)(e3, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e3, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r2) {
      Object.defineProperty(e3, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e3;
}
var name8 = "simplifyUtil";
var dependencies9 = ["FunctionNode", "OperatorNode", "SymbolNode"];
var createUtil = /* @__PURE__ */ factory(name8, dependencies9, (_ref) => {
  var {
    FunctionNode: FunctionNode2,
    OperatorNode: OperatorNode2,
    SymbolNode: SymbolNode2
  } = _ref;
  var T = true;
  var F = false;
  var defaultName = "defaultF";
  var defaultContext = {
    /*      */
    add: {
      trivial: T,
      total: T,
      commutative: T,
      associative: T
    },
    /**/
    unaryPlus: {
      trivial: T,
      total: T,
      commutative: T,
      associative: T
    },
    /* */
    subtract: {
      trivial: F,
      total: T,
      commutative: F,
      associative: F
    },
    /* */
    multiply: {
      trivial: T,
      total: T,
      commutative: T,
      associative: T
    },
    /*   */
    divide: {
      trivial: F,
      total: T,
      commutative: F,
      associative: F
    },
    /*    */
    paren: {
      trivial: T,
      total: T,
      commutative: T,
      associative: F
    },
    /* */
    defaultF: {
      trivial: F,
      total: T,
      commutative: F,
      associative: F
    }
  };
  var realContext = {
    divide: {
      total: F
    },
    log: {
      total: F
    }
  };
  var positiveContext = {
    subtract: {
      total: F
    },
    abs: {
      trivial: T
    },
    log: {
      total: T
    }
  };
  function hasProperty(nodeOrName, property) {
    var context = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : defaultContext;
    var name114 = defaultName;
    if (typeof nodeOrName === "string") {
      name114 = nodeOrName;
    } else if (isOperatorNode(nodeOrName)) {
      name114 = nodeOrName.fn.toString();
    } else if (isFunctionNode(nodeOrName)) {
      name114 = nodeOrName.name;
    } else if (isParenthesisNode(nodeOrName)) {
      name114 = "paren";
    }
    if (hasOwnProperty(context, name114)) {
      var properties2 = context[name114];
      if (hasOwnProperty(properties2, property)) {
        return properties2[property];
      }
      if (hasOwnProperty(defaultContext, name114)) {
        return defaultContext[name114][property];
      }
    }
    if (hasOwnProperty(context, defaultName)) {
      var _properties = context[defaultName];
      if (hasOwnProperty(_properties, property)) {
        return _properties[property];
      }
      return defaultContext[defaultName][property];
    }
    if (hasOwnProperty(defaultContext, name114)) {
      var _properties2 = defaultContext[name114];
      if (hasOwnProperty(_properties2, property)) {
        return _properties2[property];
      }
    }
    return defaultContext[defaultName][property];
  }
  function isCommutative(node) {
    var context = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : defaultContext;
    return hasProperty(node, "commutative", context);
  }
  function isAssociative(node) {
    var context = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : defaultContext;
    return hasProperty(node, "associative", context);
  }
  function mergeContext(primary, secondary) {
    var merged = _objectSpread({}, primary);
    for (var prop in secondary) {
      if (hasOwnProperty(primary, prop)) {
        merged[prop] = _objectSpread(_objectSpread({}, secondary[prop]), primary[prop]);
      } else {
        merged[prop] = secondary[prop];
      }
    }
    return merged;
  }
  function flatten2(node, context) {
    if (!node.args || node.args.length === 0) {
      return node;
    }
    node.args = allChildren(node, context);
    for (var i = 0; i < node.args.length; i++) {
      flatten2(node.args[i], context);
    }
  }
  function allChildren(node, context) {
    var op;
    var children = [];
    var _findChildren = function findChildren(node2) {
      for (var i = 0; i < node2.args.length; i++) {
        var child = node2.args[i];
        if (isOperatorNode(child) && op === child.op) {
          _findChildren(child);
        } else {
          children.push(child);
        }
      }
    };
    if (isAssociative(node, context)) {
      op = node.op;
      _findChildren(node);
      return children;
    } else {
      return node.args;
    }
  }
  function unflattenr(node, context) {
    if (!node.args || node.args.length === 0) {
      return;
    }
    var makeNode = createMakeNodeFunction(node);
    var l = node.args.length;
    for (var i = 0; i < l; i++) {
      unflattenr(node.args[i], context);
    }
    if (l > 2 && isAssociative(node, context)) {
      var curnode = node.args.pop();
      while (node.args.length > 0) {
        curnode = makeNode([node.args.pop(), curnode]);
      }
      node.args = curnode.args;
    }
  }
  function unflattenl(node, context) {
    if (!node.args || node.args.length === 0) {
      return;
    }
    var makeNode = createMakeNodeFunction(node);
    var l = node.args.length;
    for (var i = 0; i < l; i++) {
      unflattenl(node.args[i], context);
    }
    if (l > 2 && isAssociative(node, context)) {
      var curnode = node.args.shift();
      while (node.args.length > 0) {
        curnode = makeNode([curnode, node.args.shift()]);
      }
      node.args = curnode.args;
    }
  }
  function createMakeNodeFunction(node) {
    if (isOperatorNode(node)) {
      return function(args) {
        try {
          return new OperatorNode2(node.op, node.fn, args, node.implicit);
        } catch (err) {
          console.error(err);
          return [];
        }
      };
    } else {
      return function(args) {
        return new FunctionNode2(new SymbolNode2(node.name), args);
      };
    }
  }
  return {
    createMakeNodeFunction,
    hasProperty,
    isCommutative,
    isAssociative,
    mergeContext,
    flatten: flatten2,
    allChildren,
    unflattenr,
    unflattenl,
    defaultContext,
    realContext,
    positiveContext
  };
});

// node_modules/mathjs/lib/esm/function/algebra/simplify.js
var name9 = "simplify";
var dependencies10 = ["typed", "parse", "equal", "resolve", "simplifyConstant", "simplifyCore", "AccessorNode", "ArrayNode", "ConstantNode", "FunctionNode", "IndexNode", "ObjectNode", "OperatorNode", "ParenthesisNode", "SymbolNode", "replacer"];
var createSimplify = /* @__PURE__ */ factory(name9, dependencies10, (_ref) => {
  var {
    typed: typed3,
    parse: parse2,
    equal: equal2,
    resolve: resolve2,
    simplifyConstant: simplifyConstant2,
    simplifyCore: simplifyCore2,
    AccessorNode: AccessorNode2,
    ArrayNode: ArrayNode2,
    ConstantNode: ConstantNode2,
    FunctionNode: FunctionNode2,
    IndexNode: IndexNode2,
    ObjectNode: ObjectNode2,
    OperatorNode: OperatorNode2,
    ParenthesisNode: ParenthesisNode2,
    SymbolNode: SymbolNode2,
    replacer: replacer2
  } = _ref;
  var {
    hasProperty,
    isCommutative,
    isAssociative,
    mergeContext,
    flatten: flatten2,
    unflattenr,
    unflattenl,
    createMakeNodeFunction,
    defaultContext,
    realContext,
    positiveContext
  } = createUtil({
    FunctionNode: FunctionNode2,
    OperatorNode: OperatorNode2,
    SymbolNode: SymbolNode2
  });
  typed3.addConversion({
    from: "Object",
    to: "Map",
    convert: createMap
  });
  var simplify3 = typed3("simplify", {
    Node: _simplify,
    "Node, Map": (expr, scope) => _simplify(expr, false, scope),
    "Node, Map, Object": (expr, scope, options) => _simplify(expr, false, scope, options),
    "Node, Array": _simplify,
    "Node, Array, Map": _simplify,
    "Node, Array, Map, Object": _simplify
  });
  typed3.removeConversion({
    from: "Object",
    to: "Map",
    convert: createMap
  });
  simplify3.defaultContext = defaultContext;
  simplify3.realContext = realContext;
  simplify3.positiveContext = positiveContext;
  function removeParens(node) {
    return node.transform(function(node2) {
      return isParenthesisNode(node2) ? removeParens(node2.content) : node2;
    });
  }
  var SUPPORTED_CONSTANTS = {
    true: true,
    false: true,
    e: true,
    i: true,
    Infinity: true,
    LN2: true,
    LN10: true,
    LOG2E: true,
    LOG10E: true,
    NaN: true,
    phi: true,
    pi: true,
    SQRT1_2: true,
    SQRT2: true,
    tau: true
    // null: false,
    // undefined: false,
    // version: false,
  };
  simplify3.rules = [
    simplifyCore2,
    // { l: 'n+0', r: 'n' },     // simplifyCore
    // { l: 'n^0', r: '1' },     // simplifyCore
    // { l: '0*n', r: '0' },     // simplifyCore
    // { l: 'n/n', r: '1'},      // simplifyCore
    // { l: 'n^1', r: 'n' },     // simplifyCore
    // { l: '+n1', r:'n1' },     // simplifyCore
    // { l: 'n--n1', r:'n+n1' }, // simplifyCore
    {
      l: "log(e)",
      r: "1"
    },
    // temporary rules
    // Note initially we tend constants to the right because like-term
    // collection prefers the left, and we would rather collect nonconstants
    {
      s: "n-n1 -> n+-n1",
      // temporarily replace 'subtract' so we can further flatten the 'add' operator
      assuming: {
        subtract: {
          total: true
        }
      }
    },
    {
      s: "n-n -> 0",
      // partial alternative when we can't always subtract
      assuming: {
        subtract: {
          total: false
        }
      }
    },
    {
      s: "-(cl*v) -> v * (-cl)",
      // make non-constant terms positive
      assuming: {
        multiply: {
          commutative: true
        },
        subtract: {
          total: true
        }
      }
    },
    {
      s: "-(cl*v) -> (-cl) * v",
      // non-commutative version, part 1
      assuming: {
        multiply: {
          commutative: false
        },
        subtract: {
          total: true
        }
      }
    },
    {
      s: "-(v*cl) -> v * (-cl)",
      // non-commutative version, part 2
      assuming: {
        multiply: {
          commutative: false
        },
        subtract: {
          total: true
        }
      }
    },
    {
      l: "-(n1/n2)",
      r: "-n1/n2"
    },
    {
      l: "-v",
      r: "v * (-1)"
    },
    // finish making non-constant terms positive
    {
      l: "(n1 + n2)*(-1)",
      r: "n1*(-1) + n2*(-1)",
      repeat: true
    },
    // expand negations to achieve as much sign cancellation as possible
    {
      l: "n/n1^n2",
      r: "n*n1^-n2"
    },
    // temporarily replace 'divide' so we can further flatten the 'multiply' operator
    {
      l: "n/n1",
      r: "n*n1^-1"
    },
    {
      s: "(n1*n2)^n3 -> n1^n3 * n2^n3",
      assuming: {
        multiply: {
          commutative: true
        }
      }
    },
    {
      s: "(n1*n2)^(-1) -> n2^(-1) * n1^(-1)",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    // expand nested exponentiation
    {
      s: "(n ^ n1) ^ n2 -> n ^ (n1 * n2)",
      assuming: {
        divide: {
          total: true
        }
      }
      // 1/(1/n) = n needs 1/n to exist
    },
    // collect like factors; into a sum, only do this for nonconstants
    {
      l: " vd   * ( vd   * n1 + n2)",
      r: "vd^2       * n1 +  vd   * n2"
    },
    {
      s: " vd   * (vd^n4 * n1 + n2)   ->  vd^(1+n4)  * n1 +  vd   * n2",
      assuming: {
        divide: {
          total: true
        }
      }
      // v*1/v = v^(1+-1) needs 1/v
    },
    {
      s: "vd^n3 * ( vd   * n1 + n2)   ->  vd^(n3+1)  * n1 + vd^n3 * n2",
      assuming: {
        divide: {
          total: true
        }
      }
    },
    {
      s: "vd^n3 * (vd^n4 * n1 + n2)   ->  vd^(n3+n4) * n1 + vd^n3 * n2",
      assuming: {
        divide: {
          total: true
        }
      }
    },
    {
      l: "n*n",
      r: "n^2"
    },
    {
      s: "n * n^n1 -> n^(n1+1)",
      assuming: {
        divide: {
          total: true
        }
      }
      // n*1/n = n^(-1+1) needs 1/n
    },
    {
      s: "n^n1 * n^n2 -> n^(n1+n2)",
      assuming: {
        divide: {
          total: true
        }
      }
      // ditto for n^2*1/n^2
    },
    // Unfortunately, to deal with more complicated cancellations, it
    // becomes necessary to simplify constants twice per pass. It's not
    // terribly expensive compared to matching rules, so this should not
    // pose a performance problem.
    simplifyConstant2,
    // First: before collecting like terms
    // collect like terms
    {
      s: "n+n -> 2*n",
      assuming: {
        add: {
          total: true
        }
      }
      // 2 = 1 + 1 needs to exist
    },
    {
      l: "n+-n",
      r: "0"
    },
    {
      l: "vd*n + vd",
      r: "vd*(n+1)"
    },
    // NOTE: leftmost position is special:
    {
      l: "n3*n1 + n3*n2",
      r: "n3*(n1+n2)"
    },
    // All sub-monomials tried there.
    {
      l: "n3^(-n4)*n1 +   n3  * n2",
      r: "n3^(-n4)*(n1 + n3^(n4+1) *n2)"
    },
    {
      l: "n3^(-n4)*n1 + n3^n5 * n2",
      r: "n3^(-n4)*(n1 + n3^(n4+n5)*n2)"
    },
    // noncommutative additional cases (term collection & factoring)
    {
      s: "n*vd + vd -> (n+1)*vd",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    {
      s: "vd + n*vd -> (1+n)*vd",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    {
      s: "n1*n3 + n2*n3 -> (n1+n2)*n3",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    {
      s: "n^n1 * n -> n^(n1+1)",
      assuming: {
        divide: {
          total: true
        },
        multiply: {
          commutative: false
        }
      }
    },
    {
      s: "n1*n3^(-n4) + n2 * n3    -> (n1 + n2*n3^(n4 +  1))*n3^(-n4)",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    {
      s: "n1*n3^(-n4) + n2 * n3^n5 -> (n1 + n2*n3^(n4 + n5))*n3^(-n4)",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    {
      l: "n*cd + cd",
      r: "(n+1)*cd"
    },
    {
      s: "cd*n + cd -> cd*(n+1)",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    {
      s: "cd + cd*n -> cd*(1+n)",
      assuming: {
        multiply: {
          commutative: false
        }
      }
    },
    simplifyConstant2,
    // Second: before returning expressions to "standard form"
    // make factors positive (and undo 'make non-constant terms positive')
    {
      s: "(-n)*n1 -> -(n*n1)",
      assuming: {
        subtract: {
          total: true
        }
      }
    },
    {
      s: "n1*(-n) -> -(n1*n)",
      // in case * non-commutative
      assuming: {
        subtract: {
          total: true
        },
        multiply: {
          commutative: false
        }
      }
    },
    // final ordering of constants
    {
      s: "ce+ve -> ve+ce",
      assuming: {
        add: {
          commutative: true
        }
      },
      imposeContext: {
        add: {
          commutative: false
        }
      }
    },
    {
      s: "vd*cd -> cd*vd",
      assuming: {
        multiply: {
          commutative: true
        }
      },
      imposeContext: {
        multiply: {
          commutative: false
        }
      }
    },
    // undo temporary rules
    // { l: '(-1) * n', r: '-n' }, // #811 added test which proved this is redundant
    {
      l: "n+-n1",
      r: "n-n1"
    },
    // undo replace 'subtract'
    {
      l: "n+-(n1)",
      r: "n-(n1)"
    },
    {
      s: "n*(n1^-1) -> n/n1",
      // undo replace 'divide'; for * commutative
      assuming: {
        multiply: {
          commutative: true
        }
      }
      // o.w. / not conventional
    },
    {
      s: "n*n1^-n2 -> n/n1^n2",
      assuming: {
        multiply: {
          commutative: true
        }
      }
      // o.w. / not conventional
    },
    {
      s: "n^-1 -> 1/n",
      assuming: {
        multiply: {
          commutative: true
        }
      }
      // o.w. / not conventional
    },
    {
      l: "n^1",
      r: "n"
    },
    // can be produced by power cancellation
    {
      s: "n*(n1/n2) -> (n*n1)/n2",
      // '*' before '/'
      assuming: {
        multiply: {
          associative: true
        }
      }
    },
    {
      s: "n-(n1+n2) -> n-n1-n2",
      // '-' before '+'
      assuming: {
        addition: {
          associative: true,
          commutative: true
        }
      }
    },
    // { l: '(n1/n2)/n3', r: 'n1/(n2*n3)' },
    // { l: '(n*n1)/(n*n2)', r: 'n1/n2' },
    // simplifyConstant can leave an extra factor of 1, which can always
    // be eliminated, since the identity always commutes
    {
      l: "1*n",
      r: "n",
      imposeContext: {
        multiply: {
          commutative: true
        }
      }
    },
    {
      s: "n1/(n2/n3) -> (n1*n3)/n2",
      assuming: {
        multiply: {
          associative: true
        }
      }
    },
    {
      l: "n1/(-n2)",
      r: "-n1/n2"
    }
  ];
  function _canonicalizeRule(ruleObject, context) {
    var newRule = {};
    if (ruleObject.s) {
      var lr = ruleObject.s.split("->");
      if (lr.length === 2) {
        newRule.l = lr[0];
        newRule.r = lr[1];
      } else {
        throw SyntaxError("Could not parse rule: " + ruleObject.s);
      }
    } else {
      newRule.l = ruleObject.l;
      newRule.r = ruleObject.r;
    }
    newRule.l = removeParens(parse2(newRule.l));
    newRule.r = removeParens(parse2(newRule.r));
    for (var prop of ["imposeContext", "repeat", "assuming"]) {
      if (prop in ruleObject) {
        newRule[prop] = ruleObject[prop];
      }
    }
    if (ruleObject.evaluate) {
      newRule.evaluate = parse2(ruleObject.evaluate);
    }
    if (isAssociative(newRule.l, context)) {
      var nonCommutative = !isCommutative(newRule.l, context);
      var leftExpandsym;
      if (nonCommutative) leftExpandsym = _getExpandPlaceholderSymbol();
      var makeNode = createMakeNodeFunction(newRule.l);
      var expandsym = _getExpandPlaceholderSymbol();
      newRule.expanded = {};
      newRule.expanded.l = makeNode([newRule.l, expandsym]);
      flatten2(newRule.expanded.l, context);
      unflattenr(newRule.expanded.l, context);
      newRule.expanded.r = makeNode([newRule.r, expandsym]);
      if (nonCommutative) {
        newRule.expandedNC1 = {};
        newRule.expandedNC1.l = makeNode([leftExpandsym, newRule.l]);
        newRule.expandedNC1.r = makeNode([leftExpandsym, newRule.r]);
        newRule.expandedNC2 = {};
        newRule.expandedNC2.l = makeNode([leftExpandsym, newRule.expanded.l]);
        newRule.expandedNC2.r = makeNode([leftExpandsym, newRule.expanded.r]);
      }
    }
    return newRule;
  }
  function _buildRules(rules, context) {
    var ruleSet = [];
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      var newRule = void 0;
      var ruleType = typeof rule;
      switch (ruleType) {
        case "string":
          rule = {
            s: rule
          };
        /* falls through */
        case "object":
          newRule = _canonicalizeRule(rule, context);
          break;
        case "function":
          newRule = rule;
          break;
        default:
          throw TypeError("Unsupported type of rule: " + ruleType);
      }
      ruleSet.push(newRule);
    }
    return ruleSet;
  }
  var _lastsym = 0;
  function _getExpandPlaceholderSymbol() {
    return new SymbolNode2("_p" + _lastsym++);
  }
  function _simplify(expr, rules) {
    var scope = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : createEmptyMap();
    var options = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
    var debug = options.consoleDebug;
    rules = _buildRules(rules || simplify3.rules, options.context);
    var res = resolve2(expr, scope);
    res = removeParens(res);
    var visited = {};
    var str = res.toString({
      parenthesis: "all"
    });
    while (!visited[str]) {
      visited[str] = true;
      _lastsym = 0;
      var laststr = str;
      if (debug) console.log("Working on: ", str);
      for (var i = 0; i < rules.length; i++) {
        var rulestr = "";
        if (typeof rules[i] === "function") {
          res = rules[i](res, options);
          if (debug) rulestr = rules[i].name;
        } else {
          flatten2(res, options.context);
          res = applyRule(res, rules[i], options.context);
          if (debug) {
            rulestr = "".concat(rules[i].l.toString(), " -> ").concat(rules[i].r.toString());
          }
        }
        if (debug) {
          var newstr = res.toString({
            parenthesis: "all"
          });
          if (newstr !== laststr) {
            console.log("Applying", rulestr, "produced", newstr);
            laststr = newstr;
          }
        }
        unflattenl(res, options.context);
      }
      str = res.toString({
        parenthesis: "all"
      });
    }
    return res;
  }
  function mapRule(nodes, rule, context) {
    var resNodes = nodes;
    if (nodes) {
      for (var i = 0; i < nodes.length; ++i) {
        var newNode = applyRule(nodes[i], rule, context);
        if (newNode !== nodes[i]) {
          if (resNodes === nodes) {
            resNodes = nodes.slice();
          }
          resNodes[i] = newNode;
        }
      }
    }
    return resNodes;
  }
  function applyRule(node, rule, context) {
    if (rule.assuming) {
      for (var symbol in rule.assuming) {
        for (var property in rule.assuming[symbol]) {
          if (hasProperty(symbol, property, context) !== rule.assuming[symbol][property]) {
            return node;
          }
        }
      }
    }
    var mergedContext = mergeContext(rule.imposeContext, context);
    var res = node;
    if (res instanceof OperatorNode2 || res instanceof FunctionNode2) {
      var newArgs = mapRule(res.args, rule, context);
      if (newArgs !== res.args) {
        res = res.clone();
        res.args = newArgs;
      }
    } else if (res instanceof ParenthesisNode2) {
      if (res.content) {
        var newContent = applyRule(res.content, rule, context);
        if (newContent !== res.content) {
          res = new ParenthesisNode2(newContent);
        }
      }
    } else if (res instanceof ArrayNode2) {
      var newItems = mapRule(res.items, rule, context);
      if (newItems !== res.items) {
        res = new ArrayNode2(newItems);
      }
    } else if (res instanceof AccessorNode2) {
      var newObj = res.object;
      if (res.object) {
        newObj = applyRule(res.object, rule, context);
      }
      var newIndex = res.index;
      if (res.index) {
        newIndex = applyRule(res.index, rule, context);
      }
      if (newObj !== res.object || newIndex !== res.index) {
        res = new AccessorNode2(newObj, newIndex);
      }
    } else if (res instanceof IndexNode2) {
      var newDims = mapRule(res.dimensions, rule, context);
      if (newDims !== res.dimensions) {
        res = new IndexNode2(newDims);
      }
    } else if (res instanceof ObjectNode2) {
      var changed = false;
      var newProps = {};
      for (var prop in res.properties) {
        newProps[prop] = applyRule(res.properties[prop], rule, context);
        if (newProps[prop] !== res.properties[prop]) {
          changed = true;
        }
      }
      if (changed) {
        res = new ObjectNode2(newProps);
      }
    }
    var repl = rule.r;
    var matches = _ruleMatch(rule.l, res, mergedContext)[0];
    if (!matches && rule.expanded) {
      repl = rule.expanded.r;
      matches = _ruleMatch(rule.expanded.l, res, mergedContext)[0];
    }
    if (!matches && rule.expandedNC1) {
      repl = rule.expandedNC1.r;
      matches = _ruleMatch(rule.expandedNC1.l, res, mergedContext)[0];
      if (!matches) {
        repl = rule.expandedNC2.r;
        matches = _ruleMatch(rule.expandedNC2.l, res, mergedContext)[0];
      }
    }
    if (matches) {
      var implicit = res.implicit;
      res = repl.clone();
      if (implicit && "implicit" in repl) {
        res.implicit = true;
      }
      res = res.transform(function(node2) {
        if (node2.isSymbolNode && hasOwnProperty(matches.placeholders, node2.name)) {
          return matches.placeholders[node2.name].clone();
        } else {
          return node2;
        }
      });
    }
    if (rule.repeat && res !== node) {
      res = applyRule(res, rule, context);
    }
    return res;
  }
  function getSplits(node, context) {
    var res = [];
    var right, rightArgs;
    var makeNode = createMakeNodeFunction(node);
    if (isCommutative(node, context)) {
      for (var i = 0; i < node.args.length; i++) {
        rightArgs = node.args.slice(0);
        rightArgs.splice(i, 1);
        right = rightArgs.length === 1 ? rightArgs[0] : makeNode(rightArgs);
        res.push(makeNode([node.args[i], right]));
      }
    } else {
      for (var _i = 1; _i < node.args.length; _i++) {
        var left = node.args[0];
        if (_i > 1) {
          left = makeNode(node.args.slice(0, _i));
        }
        rightArgs = node.args.slice(_i);
        right = rightArgs.length === 1 ? rightArgs[0] : makeNode(rightArgs);
        res.push(makeNode([left, right]));
      }
    }
    return res;
  }
  function mergeMatch(match1, match2) {
    var res = {
      placeholders: {}
    };
    if (!match1.placeholders && !match2.placeholders) {
      return res;
    } else if (!match1.placeholders) {
      return match2;
    } else if (!match2.placeholders) {
      return match1;
    }
    for (var key in match1.placeholders) {
      if (hasOwnProperty(match1.placeholders, key)) {
        res.placeholders[key] = match1.placeholders[key];
        if (hasOwnProperty(match2.placeholders, key)) {
          if (!_exactMatch(match1.placeholders[key], match2.placeholders[key])) {
            return null;
          }
        }
      }
    }
    for (var _key in match2.placeholders) {
      if (hasOwnProperty(match2.placeholders, _key)) {
        res.placeholders[_key] = match2.placeholders[_key];
      }
    }
    return res;
  }
  function combineChildMatches(list1, list2) {
    var res = [];
    if (list1.length === 0 || list2.length === 0) {
      return res;
    }
    var merged;
    for (var i1 = 0; i1 < list1.length; i1++) {
      for (var i2 = 0; i2 < list2.length; i2++) {
        merged = mergeMatch(list1[i1], list2[i2]);
        if (merged) {
          res.push(merged);
        }
      }
    }
    return res;
  }
  function mergeChildMatches(childMatches) {
    if (childMatches.length === 0) {
      return childMatches;
    }
    var sets = childMatches.reduce(combineChildMatches);
    var uniqueSets = [];
    var unique = {};
    for (var i = 0; i < sets.length; i++) {
      var s = JSON.stringify(sets[i], replacer2);
      if (!unique[s]) {
        unique[s] = true;
        uniqueSets.push(sets[i]);
      }
    }
    return uniqueSets;
  }
  function _ruleMatch(rule, node, context, isSplit) {
    var res = [{
      placeholders: {}
    }];
    if (rule instanceof OperatorNode2 && node instanceof OperatorNode2 || rule instanceof FunctionNode2 && node instanceof FunctionNode2) {
      if (rule instanceof OperatorNode2) {
        if (rule.op !== node.op || rule.fn !== node.fn) {
          return [];
        }
      } else if (rule instanceof FunctionNode2) {
        if (rule.name !== node.name) {
          return [];
        }
      }
      if (node.args.length === 1 && rule.args.length === 1 || !isAssociative(node, context) && node.args.length === rule.args.length || isSplit) {
        var childMatches = [];
        for (var i = 0; i < rule.args.length; i++) {
          var childMatch = _ruleMatch(rule.args[i], node.args[i], context);
          if (childMatch.length === 0) {
            break;
          }
          childMatches.push(childMatch);
        }
        if (childMatches.length !== rule.args.length) {
          if (!isCommutative(node, context) || // exact match in order needed
          rule.args.length === 1) {
            return [];
          }
          if (rule.args.length > 2) {
            throw new Error("permuting >2 commutative non-associative rule arguments not yet implemented");
          }
          var leftMatch = _ruleMatch(rule.args[0], node.args[1], context);
          if (leftMatch.length === 0) {
            return [];
          }
          var rightMatch = _ruleMatch(rule.args[1], node.args[0], context);
          if (rightMatch.length === 0) {
            return [];
          }
          childMatches = [leftMatch, rightMatch];
        }
        res = mergeChildMatches(childMatches);
      } else if (node.args.length >= 2 && rule.args.length === 2) {
        var splits = getSplits(node, context);
        var splitMatches = [];
        for (var _i2 = 0; _i2 < splits.length; _i2++) {
          var matchSet = _ruleMatch(rule, splits[_i2], context, true);
          splitMatches = splitMatches.concat(matchSet);
        }
        return splitMatches;
      } else if (rule.args.length > 2) {
        throw Error("Unexpected non-binary associative function: " + rule.toString());
      } else {
        return [];
      }
    } else if (rule instanceof SymbolNode2) {
      if (rule.name.length === 0) {
        throw new Error("Symbol in rule has 0 length...!?");
      }
      if (SUPPORTED_CONSTANTS[rule.name]) {
        if (rule.name !== node.name) {
          return [];
        }
      } else {
        switch (rule.name[1] >= "a" && rule.name[1] <= "z" ? rule.name.substring(0, 2) : rule.name[0]) {
          case "n":
          case "_p":
            res[0].placeholders[rule.name] = node;
            break;
          case "c":
          case "cl":
            if (isConstantNode(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          case "v":
            if (!isConstantNode(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          case "vl":
            if (isSymbolNode(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          case "cd":
            if (isNumericNode(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          case "vd":
            if (!isNumericNode(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          case "ce":
            if (isConstantExpression(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          case "ve":
            if (!isConstantExpression(node)) {
              res[0].placeholders[rule.name] = node;
            } else {
              return [];
            }
            break;
          default:
            throw new Error("Invalid symbol in rule: " + rule.name);
        }
      }
    } else if (rule instanceof ConstantNode2) {
      if (!equal2(rule.value, node.value)) {
        return [];
      }
    } else {
      return [];
    }
    return res;
  }
  function _exactMatch(p, q) {
    if (p instanceof ConstantNode2 && q instanceof ConstantNode2) {
      if (!equal2(p.value, q.value)) {
        return false;
      }
    } else if (p instanceof SymbolNode2 && q instanceof SymbolNode2) {
      if (p.name !== q.name) {
        return false;
      }
    } else if (p instanceof OperatorNode2 && q instanceof OperatorNode2 || p instanceof FunctionNode2 && q instanceof FunctionNode2) {
      if (p instanceof OperatorNode2) {
        if (p.op !== q.op || p.fn !== q.fn) {
          return false;
        }
      } else if (p instanceof FunctionNode2) {
        if (p.name !== q.name) {
          return false;
        }
      }
      if (p.args.length !== q.args.length) {
        return false;
      }
      for (var i = 0; i < p.args.length; i++) {
        if (!_exactMatch(p.args[i], q.args[i])) {
          return false;
        }
      }
    } else {
      return false;
    }
    return true;
  }
  return simplify3;
});

// node_modules/mathjs/lib/esm/function/algebra/simplifyConstant.js
var name10 = "simplifyConstant";
var dependencies11 = ["typed", "config", "mathWithTransform", "matrix", "isBounded", "?fraction", "?bignumber", "AccessorNode", "ArrayNode", "ConstantNode", "FunctionNode", "IndexNode", "ObjectNode", "OperatorNode", "SymbolNode"];
var createSimplifyConstant = /* @__PURE__ */ factory(name10, dependencies11, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    mathWithTransform: mathWithTransform2,
    matrix: matrix2,
    isBounded: isBounded2,
    fraction,
    bignumber,
    AccessorNode: AccessorNode2,
    ArrayNode: ArrayNode2,
    ConstantNode: ConstantNode2,
    FunctionNode: FunctionNode2,
    IndexNode: IndexNode2,
    ObjectNode: ObjectNode2,
    OperatorNode: OperatorNode2,
    SymbolNode: SymbolNode2
  } = _ref;
  var {
    isCommutative,
    isAssociative,
    allChildren,
    createMakeNodeFunction
  } = createUtil({
    FunctionNode: FunctionNode2,
    OperatorNode: OperatorNode2,
    SymbolNode: SymbolNode2
  });
  var simplifyConstant2 = typed3("simplifyConstant", {
    Node: (node) => _ensureNode(foldFraction(node, {})),
    "Node, Object": function Node_Object(expr, options) {
      return _ensureNode(foldFraction(expr, options));
    }
  });
  function _removeFractions(thing) {
    if (isFraction(thing)) {
      return thing.valueOf();
    }
    if (thing instanceof Array) {
      return thing.map(_removeFractions);
    }
    if (isMatrix(thing)) {
      return matrix2(_removeFractions(thing.valueOf()));
    }
    return thing;
  }
  function _eval(fnname, args, options) {
    try {
      return mathWithTransform2[fnname].apply(null, args);
    } catch (ignore) {
      args = args.map(_removeFractions);
      return _toNumber(mathWithTransform2[fnname].apply(null, args), options);
    }
  }
  var _toNode = typed3({
    Fraction: _fractionToNode,
    number: function number2(n) {
      if (n < 0) {
        return unaryMinusNode(new ConstantNode2(-n));
      }
      return new ConstantNode2(n);
    },
    BigNumber: function BigNumber(n) {
      if (n < 0) {
        return unaryMinusNode(new ConstantNode2(-n));
      }
      return new ConstantNode2(n);
    },
    bigint: function bigint2(n) {
      if (n < 0n) {
        return unaryMinusNode(new ConstantNode2(-n));
      }
      return new ConstantNode2(n);
    },
    Complex: function Complex(s) {
      throw new Error("Cannot convert Complex number to Node");
    },
    string: function string2(s) {
      return new ConstantNode2(s);
    },
    Matrix: function Matrix(m) {
      return new ArrayNode2(m.valueOf().map((e3) => _toNode(e3)));
    }
  });
  function _ensureNode(thing) {
    if (isNode(thing)) {
      return thing;
    }
    return _toNode(thing);
  }
  function _exactFraction(n, options) {
    var exactFractions = options && options.exactFractions !== false;
    if (exactFractions && isBounded2(n) && fraction) {
      var f = fraction(n);
      var fractionsLimit = options && typeof options.fractionsLimit === "number" ? options.fractionsLimit : Infinity;
      if (f.valueOf() === n && f.n < fractionsLimit && f.d < fractionsLimit) {
        return f;
      }
    }
    return n;
  }
  var _toNumber = typed3({
    "string, Object": function string_Object(s, options) {
      var numericType = safeNumberType(s, config4);
      if (numericType === "BigNumber") {
        if (bignumber === void 0) {
          noBignumber();
        }
        return bignumber(s);
      } else if (numericType === "bigint") {
        return BigInt(s);
      } else if (numericType === "Fraction") {
        if (fraction === void 0) {
          noFraction();
        }
        return fraction(s);
      } else {
        var n = parseFloat(s);
        return _exactFraction(n, options);
      }
    },
    "Fraction, Object": function Fraction_Object(s, options) {
      return s;
    },
    // we don't need options here
    "BigNumber, Object": function BigNumber_Object(s, options) {
      return s;
    },
    // we don't need options here
    "number, Object": function number_Object(s, options) {
      return _exactFraction(s, options);
    },
    "bigint, Object": function bigint_Object(s, options) {
      return s;
    },
    "Complex, Object": function Complex_Object(s, options) {
      if (s.im !== 0) {
        return s;
      }
      return _exactFraction(s.re, options);
    },
    "Matrix, Object": function Matrix_Object(s, options) {
      return matrix2(_exactFraction(s.valueOf()));
    },
    "Array, Object": function Array_Object(s, options) {
      return s.map(_exactFraction);
    }
  });
  function unaryMinusNode(n) {
    return new OperatorNode2("-", "unaryMinus", [n]);
  }
  function _fractionToNode(f) {
    var fromBigInt = (value) => config4.number === "BigNumber" && bignumber ? bignumber(value) : Number(value);
    var numeratorValue = f.s * f.n;
    var numeratorNode = numeratorValue < 0n ? new OperatorNode2("-", "unaryMinus", [new ConstantNode2(-fromBigInt(numeratorValue))]) : new ConstantNode2(fromBigInt(numeratorValue));
    return f.d === 1n ? numeratorNode : new OperatorNode2("/", "divide", [numeratorNode, new ConstantNode2(fromBigInt(f.d))]);
  }
  function _foldAccessor(obj, index2, options) {
    if (!isIndexNode(index2)) {
      return new AccessorNode2(_ensureNode(obj), _ensureNode(index2));
    }
    if (isArrayNode(obj) || isMatrix(obj)) {
      var remainingDims = Array.from(index2.dimensions);
      while (remainingDims.length > 0) {
        if (isConstantNode(remainingDims[0]) && typeof remainingDims[0].value !== "string") {
          var first = _toNumber(remainingDims.shift().value, options);
          if (isArrayNode(obj)) {
            obj = obj.items[first - 1];
          } else {
            obj = obj.valueOf()[first - 1];
            if (obj instanceof Array) {
              obj = matrix2(obj);
            }
          }
        } else if (remainingDims.length > 1 && isConstantNode(remainingDims[1]) && typeof remainingDims[1].value !== "string") {
          var second = _toNumber(remainingDims[1].value, options);
          var tryItems = [];
          var fromItems = isArrayNode(obj) ? obj.items : obj.valueOf();
          for (var item of fromItems) {
            if (isArrayNode(item)) {
              tryItems.push(item.items[second - 1]);
            } else if (isMatrix(obj)) {
              tryItems.push(item[second - 1]);
            } else {
              break;
            }
          }
          if (tryItems.length === fromItems.length) {
            if (isArrayNode(obj)) {
              obj = new ArrayNode2(tryItems);
            } else {
              obj = matrix2(tryItems);
            }
            remainingDims.splice(1, 1);
          } else {
            break;
          }
        } else {
          break;
        }
      }
      if (remainingDims.length === index2.dimensions.length) {
        return new AccessorNode2(_ensureNode(obj), index2);
      }
      if (remainingDims.length > 0) {
        index2 = new IndexNode2(remainingDims);
        return new AccessorNode2(_ensureNode(obj), index2);
      }
      return obj;
    }
    if (isObjectNode(obj) && index2.dimensions.length === 1 && isConstantNode(index2.dimensions[0])) {
      var key = index2.dimensions[0].value;
      if (key in obj.properties) {
        return obj.properties[key];
      }
      return new ConstantNode2();
    }
    return new AccessorNode2(_ensureNode(obj), index2);
  }
  function foldOp(fn, args, makeNode, options) {
    var first = args.shift();
    var reduction = args.reduce((sofar, next) => {
      if (!isNode(next)) {
        var last = sofar.pop();
        if (isNode(last)) {
          return [last, next];
        }
        try {
          sofar.push(_eval(fn, [last, next], options));
          return sofar;
        } catch (ignoreandcontinue) {
          sofar.push(last);
        }
      }
      sofar.push(_ensureNode(sofar.pop()));
      var newtree = sofar.length === 1 ? sofar[0] : makeNode(sofar);
      return [makeNode([newtree, _ensureNode(next)])];
    }, [first]);
    if (reduction.length === 1) {
      return reduction[0];
    }
    return makeNode([reduction[0], _toNode(reduction[1])]);
  }
  function foldFraction(node, options) {
    switch (node.type) {
      case "SymbolNode":
        return node;
      case "ConstantNode":
        switch (typeof node.value) {
          case "number":
            return _toNumber(node.value, options);
          case "bigint":
            return _toNumber(node.value, options);
          case "string":
            return node.value;
          default:
            if (!isNaN(node.value)) return _toNumber(node.value, options);
        }
        return node;
      case "FunctionNode":
        if (mathWithTransform2[node.name] && mathWithTransform2[node.name].rawArgs) {
          return node;
        }
        {
          var operatorFunctions = ["add", "multiply"];
          if (!operatorFunctions.includes(node.name)) {
            var args = node.args.map((arg) => foldFraction(arg, options));
            if (!args.some(isNode)) {
              try {
                return _eval(node.name, args, options);
              } catch (ignoreandcontinue) {
              }
            }
            if (node.name === "size" && args.length === 1 && isArrayNode(args[0])) {
              var sz = [];
              var section = args[0];
              while (isArrayNode(section)) {
                sz.push(section.items.length);
                section = section.items[0];
              }
              return matrix2(sz);
            }
            return new FunctionNode2(node.name, args.map(_ensureNode));
          } else {
          }
        }
      /* falls through */
      case "OperatorNode": {
        var fn = node.fn.toString();
        var _args;
        var res;
        var makeNode = createMakeNodeFunction(node);
        if (isOperatorNode(node) && node.isUnary()) {
          _args = [foldFraction(node.args[0], options)];
          if (!isNode(_args[0])) {
            res = _eval(fn, _args, options);
          } else {
            res = makeNode(_args);
          }
        } else if (isAssociative(node, options.context)) {
          _args = allChildren(node, options.context);
          _args = _args.map((arg) => foldFraction(arg, options));
          if (isCommutative(fn, options.context)) {
            var consts = [];
            var vars = [];
            for (var i = 0; i < _args.length; i++) {
              if (!isNode(_args[i])) {
                consts.push(_args[i]);
              } else {
                vars.push(_args[i]);
              }
            }
            if (consts.length > 1) {
              res = foldOp(fn, consts, makeNode, options);
              vars.unshift(res);
              res = foldOp(fn, vars, makeNode, options);
            } else {
              res = foldOp(fn, _args, makeNode, options);
            }
          } else {
            res = foldOp(fn, _args, makeNode, options);
          }
        } else {
          _args = node.args.map((arg) => foldFraction(arg, options));
          res = foldOp(fn, _args, makeNode, options);
        }
        return res;
      }
      case "ParenthesisNode":
        return foldFraction(node.content, options);
      case "AccessorNode":
        return _foldAccessor(foldFraction(node.object, options), foldFraction(node.index, options), options);
      case "ArrayNode": {
        var foldItems = node.items.map((item) => foldFraction(item, options));
        if (foldItems.some(isNode)) {
          return new ArrayNode2(foldItems.map(_ensureNode));
        }
        return matrix2(foldItems);
      }
      case "IndexNode": {
        return new IndexNode2(node.dimensions.map((n) => simplifyConstant2(n, options)));
      }
      case "ObjectNode": {
        var foldProps = {};
        for (var prop in node.properties) {
          foldProps[prop] = simplifyConstant2(node.properties[prop], options);
        }
        return new ObjectNode2(foldProps);
      }
      case "AssignmentNode":
      /* falls through */
      case "BlockNode":
      /* falls through */
      case "FunctionAssignmentNode":
      /* falls through */
      case "RangeNode":
      /* falls through */
      case "ConditionalNode":
      /* falls through */
      default:
        throw new Error("Unimplemented node type in simplifyConstant: ".concat(node.type));
    }
  }
  return simplifyConstant2;
});

// node_modules/mathjs/lib/esm/expression/operators.js
var properties = [{
  // assignment
  AssignmentNode: {},
  FunctionAssignmentNode: {}
}, {
  // conditional expression
  ConditionalNode: {
    latexLeftParens: false,
    latexRightParens: false,
    latexParens: false
    // conditionals don't need parentheses in LaTeX because
    // they are 2 dimensional
  }
}, {
  // logical or
  "OperatorNode:or": {
    op: "or",
    associativity: "left",
    associativeWith: []
  }
}, {
  // logical xor
  "OperatorNode:xor": {
    op: "xor",
    associativity: "left",
    associativeWith: []
  }
}, {
  // logical and
  "OperatorNode:and": {
    op: "and",
    associativity: "left",
    associativeWith: []
  }
}, {
  // bitwise or
  "OperatorNode:bitOr": {
    op: "|",
    associativity: "left",
    associativeWith: []
  }
}, {
  // bitwise xor
  "OperatorNode:bitXor": {
    op: "^|",
    associativity: "left",
    associativeWith: []
  }
}, {
  // bitwise and
  "OperatorNode:bitAnd": {
    op: "&",
    associativity: "left",
    associativeWith: []
  }
}, {
  // relational operators
  "OperatorNode:equal": {
    op: "==",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:unequal": {
    op: "!=",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:smaller": {
    op: "<",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:larger": {
    op: ">",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:smallerEq": {
    op: "<=",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:largerEq": {
    op: ">=",
    associativity: "left",
    associativeWith: []
  },
  RelationalNode: {
    associativity: "left",
    associativeWith: []
  }
}, {
  // bitshift operators
  "OperatorNode:leftShift": {
    op: "<<",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:rightArithShift": {
    op: ">>",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:rightLogShift": {
    op: ">>>",
    associativity: "left",
    associativeWith: []
  }
}, {
  // unit conversion
  "OperatorNode:to": {
    op: "to",
    associativity: "left",
    associativeWith: []
  }
}, {
  // range
  RangeNode: {}
}, {
  // addition, subtraction
  "OperatorNode:add": {
    op: "+",
    associativity: "left",
    associativeWith: ["OperatorNode:add", "OperatorNode:subtract"]
  },
  "OperatorNode:subtract": {
    op: "-",
    associativity: "left",
    associativeWith: []
  }
}, {
  // multiply, divide, modulus
  "OperatorNode:multiply": {
    op: "*",
    associativity: "left",
    associativeWith: ["OperatorNode:multiply", "OperatorNode:divide", "Operator:dotMultiply", "Operator:dotDivide"]
  },
  "OperatorNode:divide": {
    op: "/",
    associativity: "left",
    associativeWith: [],
    latexLeftParens: false,
    latexRightParens: false,
    latexParens: false
    // fractions don't require parentheses because
    // they're 2 dimensional, so parens aren't needed
    // in LaTeX
  },
  "OperatorNode:dotMultiply": {
    op: ".*",
    associativity: "left",
    associativeWith: ["OperatorNode:multiply", "OperatorNode:divide", "OperatorNode:dotMultiply", "OperatorNode:doDivide"]
  },
  "OperatorNode:dotDivide": {
    op: "./",
    associativity: "left",
    associativeWith: []
  },
  "OperatorNode:mod": {
    op: "mod",
    associativity: "left",
    associativeWith: []
  }
}, {
  // Repeat multiplication for implicit multiplication
  "OperatorNode:multiply": {
    associativity: "left",
    associativeWith: ["OperatorNode:multiply", "OperatorNode:divide", "Operator:dotMultiply", "Operator:dotDivide"]
  }
}, {
  // unary prefix operators
  "OperatorNode:unaryPlus": {
    op: "+",
    associativity: "right"
  },
  "OperatorNode:unaryMinus": {
    op: "-",
    associativity: "right"
  },
  "OperatorNode:bitNot": {
    op: "~",
    associativity: "right"
  },
  "OperatorNode:not": {
    op: "not",
    associativity: "right"
  }
}, {
  // exponentiation
  "OperatorNode:pow": {
    op: "^",
    associativity: "right",
    associativeWith: [],
    latexRightParens: false
    // the exponent doesn't need parentheses in
    // LaTeX because it's 2 dimensional
    // (it's on top)
  },
  "OperatorNode:dotPow": {
    op: ".^",
    associativity: "right",
    associativeWith: []
  }
}, {
  // nullish coalescing
  "OperatorNode:nullish": {
    op: "??",
    associativity: "left",
    associativeWith: []
  }
}, {
  // factorial
  "OperatorNode:factorial": {
    op: "!",
    associativity: "left"
  }
}, {
  // matrix transpose
  "OperatorNode:ctranspose": {
    op: "'",
    associativity: "left"
  }
}];
function unwrapParen(_node, parenthesis) {
  if (!parenthesis || parenthesis !== "auto") return _node;
  var node = _node;
  while (isParenthesisNode(node)) node = node.content;
  return node;
}
function getPrecedence(_node, parenthesis, implicit, parent) {
  var node = _node;
  if (parenthesis !== "keep") {
    node = _node.getContent();
  }
  var identifier = node.getIdentifier();
  var precedence = null;
  for (var i = 0; i < properties.length; i++) {
    if (identifier in properties[i]) {
      precedence = i;
      break;
    }
  }
  if (identifier === "OperatorNode:multiply" && node.implicit && implicit !== "show") {
    var leftArg = unwrapParen(node.args[0], parenthesis);
    if (!(isConstantNode(leftArg) && parent && parent.getIdentifier() === "OperatorNode:divide" && rule2Node(unwrapParen(parent.args[0], parenthesis))) && !(leftArg.getIdentifier() === "OperatorNode:divide" && rule2Node(unwrapParen(leftArg.args[0], parenthesis)) && isConstantNode(unwrapParen(leftArg.args[1])))) {
      precedence += 1;
    }
  }
  return precedence;
}
function getAssociativity(_node, parenthesis) {
  var node = _node;
  if (parenthesis !== "keep") {
    node = _node.getContent();
  }
  var identifier = node.getIdentifier();
  var index2 = getPrecedence(node, parenthesis);
  if (index2 === null) {
    return null;
  }
  var property = properties[index2][identifier];
  if (hasOwnProperty(property, "associativity")) {
    if (property.associativity === "left") {
      return "left";
    }
    if (property.associativity === "right") {
      return "right";
    }
    throw Error("'" + identifier + "' has the invalid associativity '" + property.associativity + "'.");
  }
  return null;
}
function isAssociativeWith(nodeA, nodeB, parenthesis) {
  var a = parenthesis !== "keep" ? nodeA.getContent() : nodeA;
  var b = parenthesis !== "keep" ? nodeA.getContent() : nodeB;
  var identifierA = a.getIdentifier();
  var identifierB = b.getIdentifier();
  var index2 = getPrecedence(a, parenthesis);
  if (index2 === null) {
    return null;
  }
  var property = properties[index2][identifierA];
  if (hasOwnProperty(property, "associativeWith") && property.associativeWith instanceof Array) {
    for (var i = 0; i < property.associativeWith.length; i++) {
      if (property.associativeWith[i] === identifierB) {
        return true;
      }
    }
    return false;
  }
  return null;
}
function getOperator(fn) {
  var identifier = "OperatorNode:" + fn;
  for (var group of properties) {
    if (identifier in group) {
      return group[identifier].op;
    }
  }
  return null;
}

// node_modules/mathjs/lib/esm/function/algebra/simplifyCore.js
var name11 = "simplifyCore";
var dependencies12 = ["typed", "parse", "equal", "isZero", "add", "subtract", "multiply", "divide", "pow", "AccessorNode", "ArrayNode", "ConstantNode", "FunctionNode", "IndexNode", "ObjectNode", "OperatorNode", "ParenthesisNode", "SymbolNode"];
var createSimplifyCore = /* @__PURE__ */ factory(name11, dependencies12, (_ref) => {
  var {
    typed: typed3,
    parse: parse2,
    equal: equal2,
    isZero: isZero2,
    add: add3,
    subtract: subtract2,
    multiply: multiply2,
    divide: divide3,
    pow: pow3,
    AccessorNode: AccessorNode2,
    ArrayNode: ArrayNode2,
    ConstantNode: ConstantNode2,
    FunctionNode: FunctionNode2,
    IndexNode: IndexNode2,
    ObjectNode: ObjectNode2,
    OperatorNode: OperatorNode2,
    ParenthesisNode: ParenthesisNode2,
    SymbolNode: SymbolNode2
  } = _ref;
  var node0 = new ConstantNode2(0);
  var node1 = new ConstantNode2(1);
  var nodeT = new ConstantNode2(true);
  var nodeF = new ConstantNode2(false);
  function isAlwaysBoolean(node) {
    return isOperatorNode(node) && ["and", "not", "or"].includes(node.op);
  }
  var {
    hasProperty,
    isCommutative
  } = createUtil({
    FunctionNode: FunctionNode2,
    OperatorNode: OperatorNode2,
    SymbolNode: SymbolNode2
  });
  function _simplifyCore(nodeToSimplify) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var context = options ? options.context : void 0;
    if (hasProperty(nodeToSimplify, "trivial", context)) {
      if (isFunctionNode(nodeToSimplify) && nodeToSimplify.args.length === 1) {
        return _simplifyCore(nodeToSimplify.args[0], options);
      }
      var simpChild = false;
      var childCount = 0;
      nodeToSimplify.forEach((c) => {
        ++childCount;
        if (childCount === 1) {
          simpChild = _simplifyCore(c, options);
        }
      });
      if (childCount === 1) {
        return simpChild;
      }
    }
    var node = nodeToSimplify;
    if (isFunctionNode(node)) {
      var op = getOperator(node.name);
      if (op) {
        if (node.args.length > 2 && hasProperty(node, "associative", context)) {
          while (node.args.length > 2) {
            var last = node.args.pop();
            var seclast = node.args.pop();
            node.args.push(new OperatorNode2(op, node.name, [last, seclast]));
          }
        }
        node = new OperatorNode2(op, node.name, node.args);
      } else {
        return new FunctionNode2(_simplifyCore(node.fn), node.args.map((n) => _simplifyCore(n, options)));
      }
    }
    if (isOperatorNode(node) && node.isUnary()) {
      var a0 = _simplifyCore(node.args[0], options);
      if (node.op === "~") {
        if (isOperatorNode(a0) && a0.isUnary() && a0.op === "~") {
          return a0.args[0];
        }
      }
      if (node.op === "not") {
        if (isOperatorNode(a0) && a0.isUnary() && a0.op === "not") {
          if (isAlwaysBoolean(a0.args[0])) {
            return a0.args[0];
          }
        }
      }
      var finish = true;
      if (node.op === "-") {
        if (isOperatorNode(a0)) {
          if (a0.isBinary() && a0.fn === "subtract") {
            node = new OperatorNode2("-", "subtract", [a0.args[1], a0.args[0]]);
            finish = false;
          }
          if (a0.isUnary() && a0.op === "-") {
            return a0.args[0];
          }
        }
      }
      if (finish) return new OperatorNode2(node.op, node.fn, [a0]);
    }
    if (isOperatorNode(node) && node.isBinary()) {
      var _a = _simplifyCore(node.args[0], options);
      var a1 = _simplifyCore(node.args[1], options);
      if (node.op === "+") {
        if (isConstantNode(_a) && isZero2(_a.value)) {
          return a1;
        }
        if (isConstantNode(a1) && isZero2(a1.value)) {
          return _a;
        }
        if (isOperatorNode(a1) && a1.isUnary() && a1.op === "-") {
          a1 = a1.args[0];
          node = new OperatorNode2("-", "subtract", [_a, a1]);
        }
      }
      if (node.op === "-") {
        if (isOperatorNode(a1) && a1.isUnary() && a1.op === "-") {
          return _simplifyCore(new OperatorNode2("+", "add", [_a, a1.args[0]]), options);
        }
        if (isConstantNode(_a) && isZero2(_a.value)) {
          return _simplifyCore(new OperatorNode2("-", "unaryMinus", [a1]));
        }
        if (isConstantNode(a1) && isZero2(a1.value)) {
          return _a;
        }
        return new OperatorNode2(node.op, node.fn, [_a, a1]);
      }
      if (node.op === "*") {
        if (isConstantNode(_a)) {
          if (isZero2(_a.value)) {
            return node0;
          } else if (equal2(_a.value, 1)) {
            return a1;
          }
        }
        if (isConstantNode(a1)) {
          if (isZero2(a1.value)) {
            return node0;
          } else if (equal2(a1.value, 1)) {
            return _a;
          }
          if (isCommutative(node, context)) {
            return new OperatorNode2(node.op, node.fn, [a1, _a], node.implicit);
          }
        }
        return new OperatorNode2(node.op, node.fn, [_a, a1], node.implicit);
      }
      if (node.op === "/") {
        if (isConstantNode(_a) && isZero2(_a.value)) {
          return node0;
        }
        if (isConstantNode(a1) && equal2(a1.value, 1)) {
          return _a;
        }
        return new OperatorNode2(node.op, node.fn, [_a, a1]);
      }
      if (node.op === "^") {
        if (isConstantNode(a1)) {
          if (isZero2(a1.value)) {
            return node1;
          } else if (equal2(a1.value, 1)) {
            return _a;
          }
        }
      }
      if (node.op === "and") {
        if (isConstantNode(_a)) {
          if (_a.value) {
            if (isAlwaysBoolean(a1)) return a1;
            if (isConstantNode(a1)) {
              return a1.value ? nodeT : nodeF;
            }
          } else {
            return nodeF;
          }
        }
        if (isConstantNode(a1)) {
          if (a1.value) {
            if (isAlwaysBoolean(_a)) return _a;
          } else {
            return nodeF;
          }
        }
      }
      if (node.op === "or") {
        if (isConstantNode(_a)) {
          if (_a.value) {
            return nodeT;
          } else {
            if (isAlwaysBoolean(a1)) return a1;
          }
        }
        if (isConstantNode(a1)) {
          if (a1.value) {
            return nodeT;
          } else {
            if (isAlwaysBoolean(_a)) return _a;
          }
        }
      }
      return new OperatorNode2(node.op, node.fn, [_a, a1]);
    }
    if (isOperatorNode(node)) {
      return new OperatorNode2(node.op, node.fn, node.args.map((a) => _simplifyCore(a, options)));
    }
    if (isArrayNode(node)) {
      return new ArrayNode2(node.items.map((n) => _simplifyCore(n, options)));
    }
    if (isAccessorNode(node)) {
      return new AccessorNode2(_simplifyCore(node.object, options), _simplifyCore(node.index, options));
    }
    if (isIndexNode(node)) {
      return new IndexNode2(node.dimensions.map((n) => _simplifyCore(n, options)));
    }
    if (isObjectNode(node)) {
      var newProps = {};
      for (var prop in node.properties) {
        newProps[prop] = _simplifyCore(node.properties[prop], options);
      }
      return new ObjectNode2(newProps);
    }
    return node;
  }
  return typed3(name11, {
    Node: _simplifyCore,
    "Node,Object": _simplifyCore
  });
});

// node_modules/mathjs/lib/esm/function/algebra/derivative.js
var name12 = "derivative";
var dependencies13 = ["typed", "config", "parse", "simplify", "equal", "isZero", "numeric", "ConstantNode", "FunctionNode", "OperatorNode", "ParenthesisNode", "SymbolNode"];
var createDerivative = /* @__PURE__ */ factory(name12, dependencies13, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    parse: parse2,
    simplify: simplify3,
    equal: equal2,
    isZero: isZero2,
    numeric: numeric3,
    ConstantNode: ConstantNode2,
    FunctionNode: FunctionNode2,
    OperatorNode: OperatorNode2,
    ParenthesisNode: ParenthesisNode2,
    SymbolNode: SymbolNode2
  } = _ref;
  function plainDerivative(expr, variable) {
    var options = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {
      simplify: true
    };
    var cache = /* @__PURE__ */ new Map();
    var variableName = variable.name;
    function isConstCached(node) {
      var cached = cache.get(node);
      if (cached !== void 0) {
        return cached;
      }
      var res2 = _isConst(isConstCached, node, variableName);
      cache.set(node, res2);
      return res2;
    }
    var res = _derivative(expr, isConstCached);
    return options.simplify ? simplify3(res) : res;
  }
  function parseIdentifier(string2) {
    var symbol = parse2(string2);
    if (!symbol.isSymbolNode) {
      throw new TypeError("Invalid variable. " + "Cannot parse ".concat(JSON.stringify(string2), " into a variable in function derivative"));
    }
    return symbol;
  }
  var derivative2 = typed3(name12, {
    "Node, SymbolNode": plainDerivative,
    "Node, SymbolNode, Object": plainDerivative,
    "Node, string": (node, symbol) => plainDerivative(node, parseIdentifier(symbol)),
    "Node, string, Object": (node, symbol, options) => plainDerivative(node, parseIdentifier(symbol), options)
    /* TODO: implement and test syntax with order of derivatives -> implement as an option {order: number}
    'Node, SymbolNode, ConstantNode': function (expr, variable, {order}) {
      let res = expr
      for (let i = 0; i < order; i++) {
        <create caching isConst>
        res = _derivative(res, isConst)
      }
      return res
    }
    */
  });
  derivative2._simplify = true;
  derivative2.toTex = function(deriv) {
    return _derivTex.apply(null, deriv.args);
  };
  var _derivTex = typed3("_derivTex", {
    "Node, SymbolNode": function Node_SymbolNode(expr, x) {
      if (isConstantNode(expr) && typeOf(expr.value) === "string") {
        return _derivTex(parse2(expr.value).toString(), x.toString(), 1);
      } else {
        return _derivTex(expr.toTex(), x.toString(), 1);
      }
    },
    "Node, ConstantNode": function Node_ConstantNode(expr, x) {
      if (typeOf(x.value) === "string") {
        return _derivTex(expr, parse2(x.value));
      } else {
        throw new Error("The second parameter to 'derivative' is a non-string constant");
      }
    },
    "Node, SymbolNode, ConstantNode": function Node_SymbolNode_ConstantNode(expr, x, order) {
      return _derivTex(expr.toString(), x.name, order.value);
    },
    "string, string, number": function string_string_number(expr, x, order) {
      var d;
      if (order === 1) {
        d = "{d\\over d" + x + "}";
      } else {
        d = "{d^{" + order + "}\\over d" + x + "^{" + order + "}}";
      }
      return d + "\\left[".concat(expr, "\\right]");
    }
  });
  var _isConst = typed3("_isConst", {
    "function, ConstantNode, string": function function_ConstantNode_string() {
      return true;
    },
    "function, SymbolNode, string": function function_SymbolNode_string(isConst, node, varName) {
      return node.name !== varName;
    },
    "function, ParenthesisNode, string": function function_ParenthesisNode_string(isConst, node, varName) {
      return isConst(node.content, varName);
    },
    "function, FunctionAssignmentNode, string": function function_FunctionAssignmentNode_string(isConst, node, varName) {
      if (!node.params.includes(varName)) {
        return true;
      }
      return isConst(node.expr, varName);
    },
    "function, FunctionNode | OperatorNode, string": function function_FunctionNode__OperatorNode_string(isConst, node, varName) {
      return node.args.every((arg) => isConst(arg, varName));
    }
  });
  var _derivative = typed3("_derivative", {
    "ConstantNode, function": function ConstantNode_function() {
      return createConstantNode2(0);
    },
    "SymbolNode, function": function SymbolNode_function(node, isConst) {
      if (isConst(node)) {
        return createConstantNode2(0);
      }
      return createConstantNode2(1);
    },
    "ParenthesisNode, function": function ParenthesisNode_function(node, isConst) {
      return new ParenthesisNode2(_derivative(node.content, isConst));
    },
    "FunctionAssignmentNode, function": function FunctionAssignmentNode_function(node, isConst) {
      if (isConst(node)) {
        return createConstantNode2(0);
      }
      return _derivative(node.expr, isConst);
    },
    "FunctionNode, function": function FunctionNode_function(node, isConst) {
      if (isConst(node)) {
        return createConstantNode2(0);
      }
      var arg0 = node.args[0];
      var arg1;
      var div2 = false;
      var negative = false;
      var funcDerivative;
      switch (node.name) {
        case "cbrt":
          div2 = true;
          funcDerivative = new OperatorNode2("*", "multiply", [createConstantNode2(3), new OperatorNode2("^", "pow", [arg0, new OperatorNode2("/", "divide", [createConstantNode2(2), createConstantNode2(3)])])]);
          break;
        case "sqrt":
        case "nthRoot":
          if (node.args.length === 1) {
            div2 = true;
            funcDerivative = new OperatorNode2("*", "multiply", [createConstantNode2(2), new FunctionNode2("sqrt", [arg0])]);
          } else if (node.args.length === 2) {
            arg1 = new OperatorNode2("/", "divide", [createConstantNode2(1), node.args[1]]);
            return _derivative(new OperatorNode2("^", "pow", [arg0, arg1]), isConst);
          }
          break;
        case "log10":
          arg1 = createConstantNode2(10);
        /* fall through! */
        case "log":
          if (!arg1 && node.args.length === 1) {
            funcDerivative = arg0.clone();
            div2 = true;
          } else if (node.args.length === 1 && arg1 || node.args.length === 2 && isConst(node.args[1])) {
            funcDerivative = new OperatorNode2("*", "multiply", [arg0.clone(), new FunctionNode2("log", [arg1 || node.args[1]])]);
            div2 = true;
          } else if (node.args.length === 2) {
            return _derivative(new OperatorNode2("/", "divide", [new FunctionNode2("log", [arg0]), new FunctionNode2("log", [node.args[1]])]), isConst);
          }
          break;
        case "pow":
          if (node.args.length === 2) {
            return _derivative(new OperatorNode2("^", "pow", [arg0, node.args[1]]), isConst);
          }
          break;
        case "exp":
          funcDerivative = new FunctionNode2("exp", [arg0.clone()]);
          break;
        case "sin":
          funcDerivative = new FunctionNode2("cos", [arg0.clone()]);
          break;
        case "cos":
          funcDerivative = new OperatorNode2("-", "unaryMinus", [new FunctionNode2("sin", [arg0.clone()])]);
          break;
        case "tan":
          funcDerivative = new OperatorNode2("^", "pow", [new FunctionNode2("sec", [arg0.clone()]), createConstantNode2(2)]);
          break;
        case "sec":
          funcDerivative = new OperatorNode2("*", "multiply", [node, new FunctionNode2("tan", [arg0.clone()])]);
          break;
        case "csc":
          negative = true;
          funcDerivative = new OperatorNode2("*", "multiply", [node, new FunctionNode2("cot", [arg0.clone()])]);
          break;
        case "cot":
          negative = true;
          funcDerivative = new OperatorNode2("^", "pow", [new FunctionNode2("csc", [arg0.clone()]), createConstantNode2(2)]);
          break;
        case "asin":
          div2 = true;
          funcDerivative = new FunctionNode2("sqrt", [new OperatorNode2("-", "subtract", [createConstantNode2(1), new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)])])]);
          break;
        case "acos":
          div2 = true;
          negative = true;
          funcDerivative = new FunctionNode2("sqrt", [new OperatorNode2("-", "subtract", [createConstantNode2(1), new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)])])]);
          break;
        case "atan":
          div2 = true;
          funcDerivative = new OperatorNode2("+", "add", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)]);
          break;
        case "asec":
          div2 = true;
          funcDerivative = new OperatorNode2("*", "multiply", [new FunctionNode2("abs", [arg0.clone()]), new FunctionNode2("sqrt", [new OperatorNode2("-", "subtract", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)])])]);
          break;
        case "acsc":
          div2 = true;
          negative = true;
          funcDerivative = new OperatorNode2("*", "multiply", [new FunctionNode2("abs", [arg0.clone()]), new FunctionNode2("sqrt", [new OperatorNode2("-", "subtract", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)])])]);
          break;
        case "acot":
          div2 = true;
          negative = true;
          funcDerivative = new OperatorNode2("+", "add", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)]);
          break;
        case "sinh":
          funcDerivative = new FunctionNode2("cosh", [arg0.clone()]);
          break;
        case "cosh":
          funcDerivative = new FunctionNode2("sinh", [arg0.clone()]);
          break;
        case "tanh":
          funcDerivative = new OperatorNode2("^", "pow", [new FunctionNode2("sech", [arg0.clone()]), createConstantNode2(2)]);
          break;
        case "sech":
          negative = true;
          funcDerivative = new OperatorNode2("*", "multiply", [node, new FunctionNode2("tanh", [arg0.clone()])]);
          break;
        case "csch":
          negative = true;
          funcDerivative = new OperatorNode2("*", "multiply", [node, new FunctionNode2("coth", [arg0.clone()])]);
          break;
        case "coth":
          negative = true;
          funcDerivative = new OperatorNode2("^", "pow", [new FunctionNode2("csch", [arg0.clone()]), createConstantNode2(2)]);
          break;
        case "asinh":
          div2 = true;
          funcDerivative = new FunctionNode2("sqrt", [new OperatorNode2("+", "add", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)])]);
          break;
        case "acosh":
          div2 = true;
          funcDerivative = new FunctionNode2("sqrt", [new OperatorNode2("-", "subtract", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)])]);
          break;
        case "atanh":
          div2 = true;
          funcDerivative = new OperatorNode2("-", "subtract", [createConstantNode2(1), new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)])]);
          break;
        case "asech":
          div2 = true;
          negative = true;
          funcDerivative = new OperatorNode2("*", "multiply", [arg0.clone(), new FunctionNode2("sqrt", [new OperatorNode2("-", "subtract", [createConstantNode2(1), new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)])])])]);
          break;
        case "acsch":
          div2 = true;
          negative = true;
          funcDerivative = new OperatorNode2("*", "multiply", [new FunctionNode2("abs", [arg0.clone()]), new FunctionNode2("sqrt", [new OperatorNode2("+", "add", [new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)]), createConstantNode2(1)])])]);
          break;
        case "acoth":
          div2 = true;
          negative = true;
          funcDerivative = new OperatorNode2("-", "subtract", [createConstantNode2(1), new OperatorNode2("^", "pow", [arg0.clone(), createConstantNode2(2)])]);
          break;
        case "abs":
          funcDerivative = new OperatorNode2("/", "divide", [new FunctionNode2(new SymbolNode2("abs"), [arg0.clone()]), arg0.clone()]);
          break;
        case "gamma":
        // Needs digamma function, d/dx(gamma(x)) = gamma(x)digamma(x)
        default:
          throw new Error('Cannot process function "' + node.name + '" in derivative: the function is not supported, undefined, or the number of arguments passed to it are not supported');
      }
      var op, func;
      if (div2) {
        op = "/";
        func = "divide";
      } else {
        op = "*";
        func = "multiply";
      }
      var chainDerivative = _derivative(arg0, isConst);
      if (negative) {
        chainDerivative = new OperatorNode2("-", "unaryMinus", [chainDerivative]);
      }
      return new OperatorNode2(op, func, [chainDerivative, funcDerivative]);
    },
    "OperatorNode, function": function OperatorNode_function(node, isConst) {
      if (isConst(node)) {
        return createConstantNode2(0);
      }
      if (node.op === "+") {
        return new OperatorNode2(node.op, node.fn, node.args.map(function(arg) {
          return _derivative(arg, isConst);
        }));
      }
      if (node.op === "-") {
        if (node.isUnary()) {
          return new OperatorNode2(node.op, node.fn, [_derivative(node.args[0], isConst)]);
        }
        if (node.isBinary()) {
          return new OperatorNode2(node.op, node.fn, [_derivative(node.args[0], isConst), _derivative(node.args[1], isConst)]);
        }
      }
      if (node.op === "*") {
        var constantTerms = node.args.filter(function(arg) {
          return isConst(arg);
        });
        if (constantTerms.length > 0) {
          var nonConstantTerms = node.args.filter(function(arg) {
            return !isConst(arg);
          });
          var nonConstantNode = nonConstantTerms.length === 1 ? nonConstantTerms[0] : new OperatorNode2("*", "multiply", nonConstantTerms);
          var newArgs = constantTerms.concat(_derivative(nonConstantNode, isConst));
          return new OperatorNode2("*", "multiply", newArgs);
        }
        return new OperatorNode2("+", "add", node.args.map(function(argOuter) {
          return new OperatorNode2("*", "multiply", node.args.map(function(argInner) {
            return argInner === argOuter ? _derivative(argInner, isConst) : argInner.clone();
          }));
        }));
      }
      if (node.op === "/" && node.isBinary()) {
        var arg0 = node.args[0];
        var arg1 = node.args[1];
        if (isConst(arg1)) {
          return new OperatorNode2("/", "divide", [_derivative(arg0, isConst), arg1]);
        }
        if (isConst(arg0)) {
          return new OperatorNode2("*", "multiply", [new OperatorNode2("-", "unaryMinus", [arg0]), new OperatorNode2("/", "divide", [_derivative(arg1, isConst), new OperatorNode2("^", "pow", [arg1.clone(), createConstantNode2(2)])])]);
        }
        return new OperatorNode2("/", "divide", [new OperatorNode2("-", "subtract", [new OperatorNode2("*", "multiply", [_derivative(arg0, isConst), arg1.clone()]), new OperatorNode2("*", "multiply", [arg0.clone(), _derivative(arg1, isConst)])]), new OperatorNode2("^", "pow", [arg1.clone(), createConstantNode2(2)])]);
      }
      if (node.op === "^" && node.isBinary()) {
        var _arg = node.args[0];
        var _arg2 = node.args[1];
        if (isConst(_arg)) {
          if (isConstantNode(_arg) && (isZero2(_arg.value) || equal2(_arg.value, 1))) {
            return createConstantNode2(0);
          }
          return new OperatorNode2("*", "multiply", [node, new OperatorNode2("*", "multiply", [new FunctionNode2("log", [_arg.clone()]), _derivative(_arg2.clone(), isConst)])]);
        }
        if (isConst(_arg2)) {
          if (isConstantNode(_arg2)) {
            if (isZero2(_arg2.value)) {
              return createConstantNode2(0);
            }
            if (equal2(_arg2.value, 1)) {
              return _derivative(_arg, isConst);
            }
          }
          var powMinusOne = new OperatorNode2("^", "pow", [_arg.clone(), new OperatorNode2("-", "subtract", [_arg2, createConstantNode2(1)])]);
          return new OperatorNode2("*", "multiply", [_arg2.clone(), new OperatorNode2("*", "multiply", [_derivative(_arg, isConst), powMinusOne])]);
        }
        return new OperatorNode2("*", "multiply", [new OperatorNode2("^", "pow", [_arg.clone(), _arg2.clone()]), new OperatorNode2("+", "add", [new OperatorNode2("*", "multiply", [_derivative(_arg, isConst), new OperatorNode2("/", "divide", [_arg2.clone(), _arg.clone()])]), new OperatorNode2("*", "multiply", [_derivative(_arg2, isConst), new FunctionNode2("log", [_arg.clone()])])])]);
      }
      throw new Error('Cannot process operator "' + node.op + '" in derivative: the operator is not supported, undefined, or the number of arguments passed to it are not supported');
    }
  });
  function createConstantNode2(value, valueType) {
    return new ConstantNode2(numeric3(value, valueType || safeNumberType(String(value), config4)));
  }
  return derivative2;
});

// node_modules/mathjs/lib/esm/function/algebra/rationalize.js
var name13 = "rationalize";
var dependencies14 = ["config", "typed", "equal", "isZero", "add", "subtract", "multiply", "divide", "pow", "parse", "simplifyConstant", "simplifyCore", "simplify", "?bignumber", "?fraction", "mathWithTransform", "matrix", "AccessorNode", "ArrayNode", "ConstantNode", "FunctionNode", "IndexNode", "ObjectNode", "OperatorNode", "SymbolNode", "ParenthesisNode"];
var createRationalize = /* @__PURE__ */ factory(name13, dependencies14, (_ref) => {
  var {
    config: config4,
    typed: typed3,
    equal: equal2,
    isZero: isZero2,
    add: add3,
    subtract: subtract2,
    multiply: multiply2,
    divide: divide3,
    pow: pow3,
    parse: parse2,
    simplifyConstant: simplifyConstant2,
    simplifyCore: simplifyCore2,
    simplify: simplify3,
    fraction,
    bignumber,
    mathWithTransform: mathWithTransform2,
    matrix: matrix2,
    AccessorNode: AccessorNode2,
    ArrayNode: ArrayNode2,
    ConstantNode: ConstantNode2,
    FunctionNode: FunctionNode2,
    IndexNode: IndexNode2,
    ObjectNode: ObjectNode2,
    OperatorNode: OperatorNode2,
    SymbolNode: SymbolNode2,
    ParenthesisNode: ParenthesisNode2
  } = _ref;
  function _rationalize(expr) {
    var scope = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var detailed = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
    var setRules = rulesRationalize();
    var polyRet = polynomial(expr, scope, true, setRules.firstRules);
    var nVars = polyRet.variables.length;
    var noExactFractions = {
      exactFractions: false
    };
    var withExactFractions = {
      exactFractions: true
    };
    expr = polyRet.expression;
    if (nVars >= 1) {
      expr = expandPower(expr);
      var sBefore;
      var rules;
      var eDistrDiv = true;
      var redoInic = false;
      expr = simplify3(expr, setRules.firstRules, {}, noExactFractions);
      var s;
      while (true) {
        rules = eDistrDiv ? setRules.distrDivRules : setRules.sucDivRules;
        expr = simplify3(expr, rules, {}, withExactFractions);
        eDistrDiv = !eDistrDiv;
        s = expr.toString();
        if (s === sBefore) {
          break;
        }
        redoInic = true;
        sBefore = s;
      }
      if (redoInic) {
        expr = simplify3(expr, setRules.firstRulesAgain, {}, noExactFractions);
      }
      expr = simplify3(expr, setRules.finalRules, {}, noExactFractions);
    }
    var coefficients = [];
    var retRationalize = {};
    if (expr.type === "OperatorNode" && expr.isBinary() && expr.op === "/") {
      if (nVars === 1) {
        expr.args[0] = polyToCanonical(expr.args[0], coefficients);
        expr.args[1] = polyToCanonical(expr.args[1]);
      }
      if (detailed) {
        retRationalize.numerator = expr.args[0];
        retRationalize.denominator = expr.args[1];
      }
    } else {
      if (nVars === 1) {
        expr = polyToCanonical(expr, coefficients);
      }
      if (detailed) {
        retRationalize.numerator = expr;
        retRationalize.denominator = null;
      }
    }
    if (!detailed) return expr;
    retRationalize.coefficients = coefficients;
    retRationalize.variables = polyRet.variables;
    retRationalize.expression = expr;
    return retRationalize;
  }
  return typed3(name13, {
    Node: _rationalize,
    "Node, boolean": (expr, detailed) => _rationalize(expr, {}, detailed),
    "Node, Object": _rationalize,
    "Node, Object, boolean": _rationalize
  });
  function polynomial(expr, scope, extended, rules) {
    var variables = [];
    var node = simplify3(expr, rules, scope, {
      exactFractions: false
    });
    extended = !!extended;
    var oper = "+-*" + (extended ? "/" : "");
    recPoly(node);
    var retFunc = {};
    retFunc.expression = node;
    retFunc.variables = variables;
    return retFunc;
    function recPoly(node2) {
      var tp = node2.type;
      if (tp === "FunctionNode") {
        throw new Error("There is an unsolved function call");
      } else if (tp === "OperatorNode") {
        if (node2.op === "^") {
          if (node2.args[1].type !== "ConstantNode" || !isInteger2(parseFloat(node2.args[1].value))) {
            throw new Error("There is a non-integer exponent");
          } else {
            recPoly(node2.args[0]);
          }
        } else {
          if (!oper.includes(node2.op)) {
            throw new Error("Operator " + node2.op + " invalid in polynomial expression");
          }
          for (var i = 0; i < node2.args.length; i++) {
            recPoly(node2.args[i]);
          }
        }
      } else if (tp === "SymbolNode") {
        var _name = node2.name;
        var pos = variables.indexOf(_name);
        if (pos === -1) {
          variables.push(_name);
        }
      } else if (tp === "ParenthesisNode") {
        recPoly(node2.content);
      } else if (tp !== "ConstantNode") {
        throw new Error("type " + tp + " is not allowed in polynomial expression");
      }
    }
  }
  function rulesRationalize() {
    var oldRules = [
      simplifyCore2,
      // sCore
      {
        l: "n+n",
        r: "2*n"
      },
      {
        l: "n+-n",
        r: "0"
      },
      simplifyConstant2,
      // sConstant
      {
        l: "n*(n1^-1)",
        r: "n/n1"
      },
      {
        l: "n*n1^-n2",
        r: "n/n1^n2"
      },
      {
        l: "n1^-1",
        r: "1/n1"
      },
      {
        l: "n*(n1/n2)",
        r: "(n*n1)/n2"
      },
      {
        l: "1*n",
        r: "n"
      }
    ];
    var rulesFirst = [
      {
        l: "(-n1)/(-n2)",
        r: "n1/n2"
      },
      // Unary division
      {
        l: "(-n1)*(-n2)",
        r: "n1*n2"
      },
      // Unary multiplication
      {
        l: "n1--n2",
        r: "n1+n2"
      },
      // '--' elimination
      {
        l: "n1-n2",
        r: "n1+(-n2)"
      },
      // Subtraction turn into add with un�ry minus
      {
        l: "(n1+n2)*n3",
        r: "(n1*n3 + n2*n3)"
      },
      // Distributive 1
      {
        l: "n1*(n2+n3)",
        r: "(n1*n2+n1*n3)"
      },
      // Distributive 2
      {
        l: "c1*n + c2*n",
        r: "(c1+c2)*n"
      },
      // Joining constants
      {
        l: "c1*n + n",
        r: "(c1+1)*n"
      },
      // Joining constants
      {
        l: "c1*n - c2*n",
        r: "(c1-c2)*n"
      },
      // Joining constants
      {
        l: "c1*n - n",
        r: "(c1-1)*n"
      },
      // Joining constants
      {
        l: "v/c",
        r: "(1/c)*v"
      },
      // variable/constant (new!)
      {
        l: "v/-c",
        r: "-(1/c)*v"
      },
      // variable/constant (new!)
      {
        l: "-v*-c",
        r: "c*v"
      },
      // Inversion constant and variable 1
      {
        l: "-v*c",
        r: "-c*v"
      },
      // Inversion constant and variable 2
      {
        l: "v*-c",
        r: "-c*v"
      },
      // Inversion constant and variable 3
      {
        l: "v*c",
        r: "c*v"
      },
      // Inversion constant and variable 4
      {
        l: "-(-n1*n2)",
        r: "(n1*n2)"
      },
      // Unary propagation
      {
        l: "-(n1*n2)",
        r: "(-n1*n2)"
      },
      // Unary propagation
      {
        l: "-(-n1+n2)",
        r: "(n1-n2)"
      },
      // Unary propagation
      {
        l: "-(n1+n2)",
        r: "(-n1-n2)"
      },
      // Unary propagation
      {
        l: "(n1^n2)^n3",
        r: "(n1^(n2*n3))"
      },
      // Power to Power
      {
        l: "-(-n1/n2)",
        r: "(n1/n2)"
      },
      // Division and Unary
      {
        l: "-(n1/n2)",
        r: "(-n1/n2)"
      }
    ];
    var rulesDistrDiv = [
      {
        l: "(n1/n2 + n3/n4)",
        r: "((n1*n4 + n3*n2)/(n2*n4))"
      },
      // Sum of fractions
      {
        l: "(n1/n2 + n3)",
        r: "((n1 + n3*n2)/n2)"
      },
      // Sum fraction with number 1
      {
        l: "(n1 + n2/n3)",
        r: "((n1*n3 + n2)/n3)"
      }
    ];
    var rulesSucDiv = [
      {
        l: "(n1/(n2/n3))",
        r: "((n1*n3)/n2)"
      },
      // Division simplification
      {
        l: "(n1/n2/n3)",
        r: "(n1/(n2*n3))"
      }
    ];
    var setRules = {};
    setRules.firstRules = oldRules.concat(rulesFirst, rulesSucDiv);
    setRules.distrDivRules = rulesDistrDiv;
    setRules.sucDivRules = rulesSucDiv;
    setRules.firstRulesAgain = oldRules.concat(rulesFirst);
    setRules.finalRules = [
      simplifyCore2,
      // simplify.rules[0]
      {
        l: "n*-n",
        r: "-n^2"
      },
      // Joining multiply with power 1
      {
        l: "n*n",
        r: "n^2"
      },
      // Joining multiply with power 2
      simplifyConstant2,
      // simplify.rules[14] old 3rd index in oldRules
      {
        l: "n*-n^n1",
        r: "-n^(n1+1)"
      },
      // Joining multiply with power 3
      {
        l: "n*n^n1",
        r: "n^(n1+1)"
      },
      // Joining multiply with power 4
      {
        l: "n^n1*-n^n2",
        r: "-n^(n1+n2)"
      },
      // Joining multiply with power 5
      {
        l: "n^n1*n^n2",
        r: "n^(n1+n2)"
      },
      // Joining multiply with power 6
      {
        l: "n^n1*-n",
        r: "-n^(n1+1)"
      },
      // Joining multiply with power 7
      {
        l: "n^n1*n",
        r: "n^(n1+1)"
      },
      // Joining multiply with power 8
      {
        l: "n^n1/-n",
        r: "-n^(n1-1)"
      },
      // Joining multiply with power 8
      {
        l: "n^n1/n",
        r: "n^(n1-1)"
      },
      // Joining division with power 1
      {
        l: "n/-n^n1",
        r: "-n^(1-n1)"
      },
      // Joining division with power 2
      {
        l: "n/n^n1",
        r: "n^(1-n1)"
      },
      // Joining division with power 3
      {
        l: "n^n1/-n^n2",
        r: "n^(n1-n2)"
      },
      // Joining division with power 4
      {
        l: "n^n1/n^n2",
        r: "n^(n1-n2)"
      },
      // Joining division with power 5
      {
        l: "n1+(-n2*n3)",
        r: "n1-n2*n3"
      },
      // Solving useless parenthesis 1
      {
        l: "v*(-c)",
        r: "-c*v"
      },
      // Solving useless unary 2
      {
        l: "n1+-n2",
        r: "n1-n2"
      },
      // Solving +- together (new!)
      {
        l: "v*c",
        r: "c*v"
      },
      // inversion constant with variable
      {
        l: "(n1^n2)^n3",
        r: "(n1^(n2*n3))"
      }
      // Power to Power
    ];
    return setRules;
  }
  function expandPower(node, parent, indParent) {
    var tp = node.type;
    var internal = arguments.length > 1;
    if (tp === "OperatorNode" && node.isBinary()) {
      var does = false;
      var val;
      if (node.op === "^") {
        if ((node.args[0].type === "ParenthesisNode" || node.args[0].type === "OperatorNode") && node.args[1].type === "ConstantNode") {
          val = parseFloat(node.args[1].value);
          does = val >= 2 && isInteger2(val);
        }
      }
      if (does) {
        if (val > 2) {
          var nEsqTopo = node.args[0];
          var nDirTopo = new OperatorNode2("^", "pow", [node.args[0].cloneDeep(), new ConstantNode2(val - 1)]);
          node = new OperatorNode2("*", "multiply", [nEsqTopo, nDirTopo]);
        } else {
          node = new OperatorNode2("*", "multiply", [node.args[0], node.args[0].cloneDeep()]);
        }
        if (internal) {
          if (indParent === "content") {
            parent.content = node;
          } else {
            parent.args[indParent] = node;
          }
        }
      }
    }
    if (tp === "ParenthesisNode") {
      expandPower(node.content, node, "content");
    } else if (tp !== "ConstantNode" && tp !== "SymbolNode") {
      for (var i = 0; i < node.args.length; i++) {
        expandPower(node.args[i], node, i);
      }
    }
    if (!internal) {
      return node;
    }
  }
  function polyToCanonical(node, coefficients) {
    if (coefficients === void 0) {
      coefficients = [];
    }
    coefficients[0] = 0;
    var o = {};
    o.cte = 1;
    o.oper = "+";
    o.fire = "";
    var maxExpo = 0;
    var varname = "";
    recurPol(node, null, o);
    maxExpo = coefficients.length - 1;
    var first = true;
    var no;
    for (var i = maxExpo; i >= 0; i--) {
      if (coefficients[i] === 0) continue;
      var n16 = new ConstantNode2(first ? coefficients[i] : Math.abs(coefficients[i]));
      var op = coefficients[i] < 0 ? "-" : "+";
      if (i > 0) {
        var n25 = new SymbolNode2(varname);
        if (i > 1) {
          var n3 = new ConstantNode2(i);
          n25 = new OperatorNode2("^", "pow", [n25, n3]);
        }
        if (coefficients[i] === -1 && first) {
          n16 = new OperatorNode2("-", "unaryMinus", [n25]);
        } else if (Math.abs(coefficients[i]) === 1) {
          n16 = n25;
        } else {
          n16 = new OperatorNode2("*", "multiply", [n16, n25]);
        }
      }
      if (first) {
        no = n16;
      } else if (op === "+") {
        no = new OperatorNode2("+", "add", [no, n16]);
      } else {
        no = new OperatorNode2("-", "subtract", [no, n16]);
      }
      first = false;
    }
    if (first) {
      return new ConstantNode2(0);
    } else {
      return no;
    }
    function recurPol(node2, noPai, o2) {
      var tp = node2.type;
      if (tp === "FunctionNode") {
        throw new Error("There is an unsolved function call");
      } else if (tp === "OperatorNode") {
        if (!"+-*^".includes(node2.op)) throw new Error("Operator " + node2.op + " invalid");
        if (noPai !== null) {
          if ((node2.fn === "unaryMinus" || node2.fn === "pow") && noPai.fn !== "add" && noPai.fn !== "subtract" && noPai.fn !== "multiply") {
            throw new Error("Invalid " + node2.op + " placing");
          }
          if ((node2.fn === "subtract" || node2.fn === "add" || node2.fn === "multiply") && noPai.fn !== "add" && noPai.fn !== "subtract") {
            throw new Error("Invalid " + node2.op + " placing");
          }
          if ((node2.fn === "subtract" || node2.fn === "add" || node2.fn === "unaryMinus") && o2.noFil !== 0) {
            throw new Error("Invalid " + node2.op + " placing");
          }
        }
        if (node2.op === "^" || node2.op === "*") {
          o2.fire = node2.op;
        }
        for (var _i = 0; _i < node2.args.length; _i++) {
          if (node2.fn === "unaryMinus") o2.oper = "-";
          if (node2.op === "+" || node2.fn === "subtract") {
            o2.fire = "";
            o2.cte = 1;
            o2.oper = _i === 0 ? "+" : node2.op;
          }
          o2.noFil = _i;
          recurPol(node2.args[_i], node2, o2);
        }
      } else if (tp === "SymbolNode") {
        if (node2.name !== varname && varname !== "") {
          throw new Error("There is more than one variable");
        }
        varname = node2.name;
        if (noPai === null) {
          coefficients[1] = 1;
          return;
        }
        if (noPai.op === "^" && o2.noFil !== 0) {
          throw new Error("In power the variable should be the first parameter");
        }
        if (noPai.op === "*" && o2.noFil !== 1) {
          throw new Error("In multiply the variable should be the second parameter");
        }
        if (o2.fire === "" || o2.fire === "*") {
          if (maxExpo < 1) coefficients[1] = 0;
          coefficients[1] += o2.cte * (o2.oper === "+" ? 1 : -1);
          maxExpo = Math.max(1, maxExpo);
        }
      } else if (tp === "ConstantNode") {
        var valor = parseFloat(node2.value);
        if (noPai === null) {
          coefficients[0] = valor;
          return;
        }
        if (noPai.op === "^") {
          if (o2.noFil !== 1) throw new Error("Constant cannot be powered");
          if (!isInteger2(valor) || valor <= 0) {
            throw new Error("Non-integer exponent is not allowed");
          }
          for (var _i2 = maxExpo + 1; _i2 < valor; _i2++) coefficients[_i2] = 0;
          if (valor > maxExpo) coefficients[valor] = 0;
          coefficients[valor] += o2.cte * (o2.oper === "+" ? 1 : -1);
          maxExpo = Math.max(valor, maxExpo);
          return;
        }
        o2.cte = valor;
        if (o2.fire === "") {
          coefficients[0] += o2.cte * (o2.oper === "+" ? 1 : -1);
        }
      } else {
        throw new Error("Type " + tp + " is not allowed");
      }
    }
  }
});

// node_modules/decimal.js/decimal.mjs
var EXP_LIMIT = 9e15;
var MAX_DIGITS = 1e9;
var NUMERALS = "0123456789abcdef";
var LN10 = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058";
var PI = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789";
var DEFAULTS = {
  // These values must be integers within the stated ranges (inclusive).
  // Most of these values can be changed at run-time using the `Decimal.config` method.
  // The maximum number of significant digits of the result of a calculation or base conversion.
  // E.g. `Decimal.config({ precision: 20 });`
  precision: 20,
  // 1 to MAX_DIGITS
  // The rounding mode used when rounding to `precision`.
  //
  // ROUND_UP         0 Away from zero.
  // ROUND_DOWN       1 Towards zero.
  // ROUND_CEIL       2 Towards +Infinity.
  // ROUND_FLOOR      3 Towards -Infinity.
  // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
  // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
  // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
  // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
  // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
  //
  // E.g.
  // `Decimal.rounding = 4;`
  // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
  rounding: 4,
  // 0 to 8
  // The modulo mode used when calculating the modulus: a mod n.
  // The quotient (q = a / n) is calculated according to the corresponding rounding mode.
  // The remainder (r) is calculated as: r = a - n * q.
  //
  // UP         0 The remainder is positive if the dividend is negative, else is negative.
  // DOWN       1 The remainder has the same sign as the dividend (JavaScript %).
  // FLOOR      3 The remainder has the same sign as the divisor (Python %).
  // HALF_EVEN  6 The IEEE 754 remainder function.
  // EUCLID     9 Euclidian division. q = sign(n) * floor(a / abs(n)). Always positive.
  //
  // Truncated division (1), floored division (3), the IEEE 754 remainder (6), and Euclidian
  // division (9) are commonly used for the modulus operation. The other rounding modes can also
  // be used, but they may not give useful results.
  modulo: 1,
  // 0 to 9
  // The exponent value at and beneath which `toString` returns exponential notation.
  // JavaScript numbers: -7
  toExpNeg: -7,
  // 0 to -EXP_LIMIT
  // The exponent value at and above which `toString` returns exponential notation.
  // JavaScript numbers: 21
  toExpPos: 21,
  // 0 to EXP_LIMIT
  // The minimum exponent value, beneath which underflow to zero occurs.
  // JavaScript numbers: -324  (5e-324)
  minE: -EXP_LIMIT,
  // -1 to -EXP_LIMIT
  // The maximum exponent value, above which overflow to Infinity occurs.
  // JavaScript numbers: 308  (1.7976931348623157e+308)
  maxE: EXP_LIMIT,
  // 1 to EXP_LIMIT
  // Whether to use cryptographically-secure random number generation, if available.
  crypto: false
  // true/false
};
var inexact;
var quadrant;
var external = true;
var decimalError = "[DecimalError] ";
var invalidArgument = decimalError + "Invalid argument: ";
var precisionLimitExceeded = decimalError + "Precision limit exceeded";
var cryptoUnavailable = decimalError + "crypto unavailable";
var tag = "[object Decimal]";
var mathfloor = Math.floor;
var mathpow = Math.pow;
var isBinary = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i;
var isHex = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i;
var isOctal = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i;
var isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
var BASE = 1e7;
var LOG_BASE = 7;
var MAX_SAFE_INTEGER = 9007199254740991;
var LN10_PRECISION = LN10.length - 1;
var PI_PRECISION = PI.length - 1;
var P = { toStringTag: tag };
P.absoluteValue = P.abs = function() {
  var x = new this.constructor(this);
  if (x.s < 0) x.s = 1;
  return finalise(x);
};
P.ceil = function() {
  return finalise(new this.constructor(this), this.e + 1, 2);
};
P.clampedTo = P.clamp = function(min3, max3) {
  var k, x = this, Ctor = x.constructor;
  min3 = new Ctor(min3);
  max3 = new Ctor(max3);
  if (!min3.s || !max3.s) return new Ctor(NaN);
  if (min3.gt(max3)) throw Error(invalidArgument + max3);
  k = x.cmp(min3);
  return k < 0 ? min3 : x.cmp(max3) > 0 ? max3 : new Ctor(x);
};
P.comparedTo = P.cmp = function(y) {
  var i, j, xdL, ydL, x = this, xd = x.d, yd = (y = new x.constructor(y)).d, xs = x.s, ys = y.s;
  if (!xd || !yd) {
    return !xs || !ys ? NaN : xs !== ys ? xs : xd === yd ? 0 : !xd ^ xs < 0 ? 1 : -1;
  }
  if (!xd[0] || !yd[0]) return xd[0] ? xs : yd[0] ? -ys : 0;
  if (xs !== ys) return xs;
  if (x.e !== y.e) return x.e > y.e ^ xs < 0 ? 1 : -1;
  xdL = xd.length;
  ydL = yd.length;
  for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) {
    if (xd[i] !== yd[i]) return xd[i] > yd[i] ^ xs < 0 ? 1 : -1;
  }
  return xdL === ydL ? 0 : xdL > ydL ^ xs < 0 ? 1 : -1;
};
P.cosine = P.cos = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.d) return new Ctor(NaN);
  if (!x.d[0]) return new Ctor(1);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
  Ctor.rounding = 1;
  x = cosine(Ctor, toLessThanHalfPi(Ctor, x));
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(quadrant == 2 || quadrant == 3 ? x.neg() : x, pr, rm, true);
};
P.cubeRoot = P.cbrt = function() {
  var e3, m, n, r, rep, s, sd, t, t3, t3plusx, x = this, Ctor = x.constructor;
  if (!x.isFinite() || x.isZero()) return new Ctor(x);
  external = false;
  s = x.s * mathpow(x.s * x, 1 / 3);
  if (!s || Math.abs(s) == 1 / 0) {
    n = digitsToString(x.d);
    e3 = x.e;
    if (s = (e3 - n.length + 1) % 3) n += s == 1 || s == -2 ? "0" : "00";
    s = mathpow(n, 1 / 3);
    e3 = mathfloor((e3 + 1) / 3) - (e3 % 3 == (e3 < 0 ? -1 : 2));
    if (s == 1 / 0) {
      n = "5e" + e3;
    } else {
      n = s.toExponential();
      n = n.slice(0, n.indexOf("e") + 1) + e3;
    }
    r = new Ctor(n);
    r.s = x.s;
  } else {
    r = new Ctor(s.toString());
  }
  sd = (e3 = Ctor.precision) + 3;
  for (; ; ) {
    t = r;
    t3 = t.times(t).times(t);
    t3plusx = t3.plus(x);
    r = divide(t3plusx.plus(x).times(t), t3plusx.plus(t3), sd + 2, 1);
    if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
      n = n.slice(sd - 3, sd + 1);
      if (n == "9999" || !rep && n == "4999") {
        if (!rep) {
          finalise(t, e3 + 1, 0);
          if (t.times(t).times(t).eq(x)) {
            r = t;
            break;
          }
        }
        sd += 4;
        rep = 1;
      } else {
        if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
          finalise(r, e3 + 1, 1);
          m = !r.times(r).times(r).eq(x);
        }
        break;
      }
    }
  }
  external = true;
  return finalise(r, e3, Ctor.rounding, m);
};
P.decimalPlaces = P.dp = function() {
  var w, d = this.d, n = NaN;
  if (d) {
    w = d.length - 1;
    n = (w - mathfloor(this.e / LOG_BASE)) * LOG_BASE;
    w = d[w];
    if (w) for (; w % 10 == 0; w /= 10) n--;
    if (n < 0) n = 0;
  }
  return n;
};
P.dividedBy = P.div = function(y) {
  return divide(this, new this.constructor(y));
};
P.dividedToIntegerBy = P.divToInt = function(y) {
  var x = this, Ctor = x.constructor;
  return finalise(divide(x, new Ctor(y), 0, 1, 1), Ctor.precision, Ctor.rounding);
};
P.equals = P.eq = function(y) {
  return this.cmp(y) === 0;
};
P.floor = function() {
  return finalise(new this.constructor(this), this.e + 1, 3);
};
P.greaterThan = P.gt = function(y) {
  return this.cmp(y) > 0;
};
P.greaterThanOrEqualTo = P.gte = function(y) {
  var k = this.cmp(y);
  return k == 1 || k === 0;
};
P.hyperbolicCosine = P.cosh = function() {
  var k, n, pr, rm, len, x = this, Ctor = x.constructor, one = new Ctor(1);
  if (!x.isFinite()) return new Ctor(x.s ? 1 / 0 : NaN);
  if (x.isZero()) return one;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
  Ctor.rounding = 1;
  len = x.d.length;
  if (len < 32) {
    k = Math.ceil(len / 3);
    n = (1 / tinyPow(4, k)).toString();
  } else {
    k = 16;
    n = "2.3283064365386962890625e-10";
  }
  x = taylorSeries(Ctor, 1, x.times(n), new Ctor(1), true);
  var cosh2_x, i = k, d8 = new Ctor(8);
  for (; i--; ) {
    cosh2_x = x.times(x);
    x = one.minus(cosh2_x.times(d8.minus(cosh2_x.times(d8))));
  }
  return finalise(x, Ctor.precision = pr, Ctor.rounding = rm, true);
};
P.hyperbolicSine = P.sinh = function() {
  var k, pr, rm, len, x = this, Ctor = x.constructor;
  if (!x.isFinite() || x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
  Ctor.rounding = 1;
  len = x.d.length;
  if (len < 3) {
    x = taylorSeries(Ctor, 2, x, x, true);
  } else {
    k = 1.4 * Math.sqrt(len);
    k = k > 16 ? 16 : k | 0;
    x = x.times(1 / tinyPow(5, k));
    x = taylorSeries(Ctor, 2, x, x, true);
    var sinh2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
    for (; k--; ) {
      sinh2_x = x.times(x);
      x = x.times(d5.plus(sinh2_x.times(d16.times(sinh2_x).plus(d20))));
    }
  }
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(x, pr, rm, true);
};
P.hyperbolicTangent = P.tanh = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(x.s);
  if (x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + 7;
  Ctor.rounding = 1;
  return divide(x.sinh(), x.cosh(), Ctor.precision = pr, Ctor.rounding = rm);
};
P.inverseCosine = P.acos = function() {
  var x = this, Ctor = x.constructor, k = x.abs().cmp(1), pr = Ctor.precision, rm = Ctor.rounding;
  if (k !== -1) {
    return k === 0 ? x.isNeg() ? getPi(Ctor, pr, rm) : new Ctor(0) : new Ctor(NaN);
  }
  if (x.isZero()) return getPi(Ctor, pr + 4, rm).times(0.5);
  Ctor.precision = pr + 6;
  Ctor.rounding = 1;
  x = new Ctor(1).minus(x).div(x.plus(1)).sqrt().atan();
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.times(2);
};
P.inverseHyperbolicCosine = P.acosh = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (x.lte(1)) return new Ctor(x.eq(1) ? 0 : NaN);
  if (!x.isFinite()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(Math.abs(x.e), x.sd()) + 4;
  Ctor.rounding = 1;
  external = false;
  x = x.times(x).minus(1).sqrt().plus(x);
  external = true;
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.ln();
};
P.inverseHyperbolicSine = P.asinh = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite() || x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + 2 * Math.max(Math.abs(x.e), x.sd()) + 6;
  Ctor.rounding = 1;
  external = false;
  x = x.times(x).plus(1).sqrt().plus(x);
  external = true;
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.ln();
};
P.inverseHyperbolicTangent = P.atanh = function() {
  var pr, rm, wpr, xsd, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(NaN);
  if (x.e >= 0) return new Ctor(x.abs().eq(1) ? x.s / 0 : x.isZero() ? x : NaN);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  xsd = x.sd();
  if (Math.max(xsd, pr) < 2 * -x.e - 1) return finalise(new Ctor(x), pr, rm, true);
  Ctor.precision = wpr = xsd - x.e;
  x = divide(x.plus(1), new Ctor(1).minus(x), wpr + pr, 1);
  Ctor.precision = pr + 4;
  Ctor.rounding = 1;
  x = x.ln();
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.times(0.5);
};
P.inverseSine = P.asin = function() {
  var halfPi, k, pr, rm, x = this, Ctor = x.constructor;
  if (x.isZero()) return new Ctor(x);
  k = x.abs().cmp(1);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (k !== -1) {
    if (k === 0) {
      halfPi = getPi(Ctor, pr + 4, rm).times(0.5);
      halfPi.s = x.s;
      return halfPi;
    }
    return new Ctor(NaN);
  }
  Ctor.precision = pr + 6;
  Ctor.rounding = 1;
  x = x.div(new Ctor(1).minus(x.times(x)).sqrt().plus(1)).atan();
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return x.times(2);
};
P.inverseTangent = P.atan = function() {
  var i, j, k, n, px, t, r, wpr, x2, x = this, Ctor = x.constructor, pr = Ctor.precision, rm = Ctor.rounding;
  if (!x.isFinite()) {
    if (!x.s) return new Ctor(NaN);
    if (pr + 4 <= PI_PRECISION) {
      r = getPi(Ctor, pr + 4, rm).times(0.5);
      r.s = x.s;
      return r;
    }
  } else if (x.isZero()) {
    return new Ctor(x);
  } else if (x.abs().eq(1) && pr + 4 <= PI_PRECISION) {
    r = getPi(Ctor, pr + 4, rm).times(0.25);
    r.s = x.s;
    return r;
  }
  Ctor.precision = wpr = pr + 10;
  Ctor.rounding = 1;
  k = Math.min(28, wpr / LOG_BASE + 2 | 0);
  for (i = k; i; --i) x = x.div(x.times(x).plus(1).sqrt().plus(1));
  external = false;
  j = Math.ceil(wpr / LOG_BASE);
  n = 1;
  x2 = x.times(x);
  r = new Ctor(x);
  px = x;
  for (; i !== -1; ) {
    px = px.times(x2);
    t = r.minus(px.div(n += 2));
    px = px.times(x2);
    r = t.plus(px.div(n += 2));
    if (r.d[j] !== void 0) for (i = j; r.d[i] === t.d[i] && i--; ) ;
  }
  if (k) r = r.times(2 << k - 1);
  external = true;
  return finalise(r, Ctor.precision = pr, Ctor.rounding = rm, true);
};
P.isFinite = function() {
  return !!this.d;
};
P.isInteger = P.isInt = function() {
  return !!this.d && mathfloor(this.e / LOG_BASE) > this.d.length - 2;
};
P.isNaN = function() {
  return !this.s;
};
P.isNegative = P.isNeg = function() {
  return this.s < 0;
};
P.isPositive = P.isPos = function() {
  return this.s > 0;
};
P.isZero = function() {
  return !!this.d && this.d[0] === 0;
};
P.lessThan = P.lt = function(y) {
  return this.cmp(y) < 0;
};
P.lessThanOrEqualTo = P.lte = function(y) {
  return this.cmp(y) < 1;
};
P.logarithm = P.log = function(base) {
  var isBase10, d, denominator, k, inf, num, sd, r, arg = this, Ctor = arg.constructor, pr = Ctor.precision, rm = Ctor.rounding, guard = 5;
  if (base == null) {
    base = new Ctor(10);
    isBase10 = true;
  } else {
    base = new Ctor(base);
    d = base.d;
    if (base.s < 0 || !d || !d[0] || base.eq(1)) return new Ctor(NaN);
    isBase10 = base.eq(10);
  }
  d = arg.d;
  if (arg.s < 0 || !d || !d[0] || arg.eq(1)) {
    return new Ctor(d && !d[0] ? -1 / 0 : arg.s != 1 ? NaN : d ? 0 : 1 / 0);
  }
  if (isBase10) {
    if (d.length > 1) {
      inf = true;
    } else {
      for (k = d[0]; k % 10 === 0; ) k /= 10;
      inf = k !== 1;
    }
  }
  external = false;
  sd = pr + guard;
  num = naturalLogarithm(arg, sd);
  denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
  r = divide(num, denominator, sd, 1);
  if (checkRoundingDigits(r.d, k = pr, rm)) {
    do {
      sd += 10;
      num = naturalLogarithm(arg, sd);
      denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
      r = divide(num, denominator, sd, 1);
      if (!inf) {
        if (+digitsToString(r.d).slice(k + 1, k + 15) + 1 == 1e14) {
          r = finalise(r, pr + 1, 0);
        }
        break;
      }
    } while (checkRoundingDigits(r.d, k += 10, rm));
  }
  external = true;
  return finalise(r, pr, rm);
};
P.minus = P.sub = function(y) {
  var d, e3, i, j, k, len, pr, rm, xd, xe, xLTy, yd, x = this, Ctor = x.constructor;
  y = new Ctor(y);
  if (!x.d || !y.d) {
    if (!x.s || !y.s) y = new Ctor(NaN);
    else if (x.d) y.s = -y.s;
    else y = new Ctor(y.d || x.s !== y.s ? x : NaN);
    return y;
  }
  if (x.s != y.s) {
    y.s = -y.s;
    return x.plus(y);
  }
  xd = x.d;
  yd = y.d;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (!xd[0] || !yd[0]) {
    if (yd[0]) y.s = -y.s;
    else if (xd[0]) y = new Ctor(x);
    else return new Ctor(rm === 3 ? -0 : 0);
    return external ? finalise(y, pr, rm) : y;
  }
  e3 = mathfloor(y.e / LOG_BASE);
  xe = mathfloor(x.e / LOG_BASE);
  xd = xd.slice();
  k = xe - e3;
  if (k) {
    xLTy = k < 0;
    if (xLTy) {
      d = xd;
      k = -k;
      len = yd.length;
    } else {
      d = yd;
      e3 = xe;
      len = xd.length;
    }
    i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
    if (k > i) {
      k = i;
      d.length = 1;
    }
    d.reverse();
    for (i = k; i--; ) d.push(0);
    d.reverse();
  } else {
    i = xd.length;
    len = yd.length;
    xLTy = i < len;
    if (xLTy) len = i;
    for (i = 0; i < len; i++) {
      if (xd[i] != yd[i]) {
        xLTy = xd[i] < yd[i];
        break;
      }
    }
    k = 0;
  }
  if (xLTy) {
    d = xd;
    xd = yd;
    yd = d;
    y.s = -y.s;
  }
  len = xd.length;
  for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
  for (i = yd.length; i > k; ) {
    if (xd[--i] < yd[i]) {
      for (j = i; j && xd[--j] === 0; ) xd[j] = BASE - 1;
      --xd[j];
      xd[i] += BASE;
    }
    xd[i] -= yd[i];
  }
  for (; xd[--len] === 0; ) xd.pop();
  for (; xd[0] === 0; xd.shift()) --e3;
  if (!xd[0]) return new Ctor(rm === 3 ? -0 : 0);
  y.d = xd;
  y.e = getBase10Exponent(xd, e3);
  return external ? finalise(y, pr, rm) : y;
};
P.modulo = P.mod = function(y) {
  var q, x = this, Ctor = x.constructor;
  y = new Ctor(y);
  if (!x.d || !y.s || y.d && !y.d[0]) return new Ctor(NaN);
  if (!y.d || x.d && !x.d[0]) {
    return finalise(new Ctor(x), Ctor.precision, Ctor.rounding);
  }
  external = false;
  if (Ctor.modulo == 9) {
    q = divide(x, y.abs(), 0, 3, 1);
    q.s *= y.s;
  } else {
    q = divide(x, y, 0, Ctor.modulo, 1);
  }
  q = q.times(y);
  external = true;
  return x.minus(q);
};
P.naturalExponential = P.exp = function() {
  return naturalExponential(this);
};
P.naturalLogarithm = P.ln = function() {
  return naturalLogarithm(this);
};
P.negated = P.neg = function() {
  var x = new this.constructor(this);
  x.s = -x.s;
  return finalise(x);
};
P.plus = P.add = function(y) {
  var carry, d, e3, i, k, len, pr, rm, xd, yd, x = this, Ctor = x.constructor;
  y = new Ctor(y);
  if (!x.d || !y.d) {
    if (!x.s || !y.s) y = new Ctor(NaN);
    else if (!x.d) y = new Ctor(y.d || x.s === y.s ? x : NaN);
    return y;
  }
  if (x.s != y.s) {
    y.s = -y.s;
    return x.minus(y);
  }
  xd = x.d;
  yd = y.d;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (!xd[0] || !yd[0]) {
    if (!yd[0]) y = new Ctor(x);
    return external ? finalise(y, pr, rm) : y;
  }
  k = mathfloor(x.e / LOG_BASE);
  e3 = mathfloor(y.e / LOG_BASE);
  xd = xd.slice();
  i = k - e3;
  if (i) {
    if (i < 0) {
      d = xd;
      i = -i;
      len = yd.length;
    } else {
      d = yd;
      e3 = k;
      len = xd.length;
    }
    k = Math.ceil(pr / LOG_BASE);
    len = k > len ? k + 1 : len + 1;
    if (i > len) {
      i = len;
      d.length = 1;
    }
    d.reverse();
    for (; i--; ) d.push(0);
    d.reverse();
  }
  len = xd.length;
  i = yd.length;
  if (len - i < 0) {
    i = len;
    d = yd;
    yd = xd;
    xd = d;
  }
  for (carry = 0; i; ) {
    carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
    xd[i] %= BASE;
  }
  if (carry) {
    xd.unshift(carry);
    ++e3;
  }
  for (len = xd.length; xd[--len] == 0; ) xd.pop();
  y.d = xd;
  y.e = getBase10Exponent(xd, e3);
  return external ? finalise(y, pr, rm) : y;
};
P.precision = P.sd = function(z) {
  var k, x = this;
  if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
  if (x.d) {
    k = getPrecision(x.d);
    if (z && x.e + 1 > k) k = x.e + 1;
  } else {
    k = NaN;
  }
  return k;
};
P.round = function() {
  var x = this, Ctor = x.constructor;
  return finalise(new Ctor(x), x.e + 1, Ctor.rounding);
};
P.sine = P.sin = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(NaN);
  if (x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
  Ctor.rounding = 1;
  x = sine(Ctor, toLessThanHalfPi(Ctor, x));
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(quadrant > 2 ? x.neg() : x, pr, rm, true);
};
P.squareRoot = P.sqrt = function() {
  var m, n, sd, r, rep, t, x = this, d = x.d, e3 = x.e, s = x.s, Ctor = x.constructor;
  if (s !== 1 || !d || !d[0]) {
    return new Ctor(!s || s < 0 && (!d || d[0]) ? NaN : d ? x : 1 / 0);
  }
  external = false;
  s = Math.sqrt(+x);
  if (s == 0 || s == 1 / 0) {
    n = digitsToString(d);
    if ((n.length + e3) % 2 == 0) n += "0";
    s = Math.sqrt(n);
    e3 = mathfloor((e3 + 1) / 2) - (e3 < 0 || e3 % 2);
    if (s == 1 / 0) {
      n = "5e" + e3;
    } else {
      n = s.toExponential();
      n = n.slice(0, n.indexOf("e") + 1) + e3;
    }
    r = new Ctor(n);
  } else {
    r = new Ctor(s.toString());
  }
  sd = (e3 = Ctor.precision) + 3;
  for (; ; ) {
    t = r;
    r = t.plus(divide(x, t, sd + 2, 1)).times(0.5);
    if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
      n = n.slice(sd - 3, sd + 1);
      if (n == "9999" || !rep && n == "4999") {
        if (!rep) {
          finalise(t, e3 + 1, 0);
          if (t.times(t).eq(x)) {
            r = t;
            break;
          }
        }
        sd += 4;
        rep = 1;
      } else {
        if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
          finalise(r, e3 + 1, 1);
          m = !r.times(r).eq(x);
        }
        break;
      }
    }
  }
  external = true;
  return finalise(r, e3, Ctor.rounding, m);
};
P.tangent = P.tan = function() {
  var pr, rm, x = this, Ctor = x.constructor;
  if (!x.isFinite()) return new Ctor(NaN);
  if (x.isZero()) return new Ctor(x);
  pr = Ctor.precision;
  rm = Ctor.rounding;
  Ctor.precision = pr + 10;
  Ctor.rounding = 1;
  x = x.sin();
  x.s = 1;
  x = divide(x, new Ctor(1).minus(x.times(x)).sqrt(), pr + 10, 0);
  Ctor.precision = pr;
  Ctor.rounding = rm;
  return finalise(quadrant == 2 || quadrant == 4 ? x.neg() : x, pr, rm, true);
};
P.times = P.mul = function(y) {
  var carry, e3, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
  y.s *= x.s;
  if (!xd || !xd[0] || !yd || !yd[0]) {
    return new Ctor(!y.s || xd && !xd[0] && !yd || yd && !yd[0] && !xd ? NaN : !xd || !yd ? y.s / 0 : y.s * 0);
  }
  e3 = mathfloor(x.e / LOG_BASE) + mathfloor(y.e / LOG_BASE);
  xdL = xd.length;
  ydL = yd.length;
  if (xdL < ydL) {
    r = xd;
    xd = yd;
    yd = r;
    rL = xdL;
    xdL = ydL;
    ydL = rL;
  }
  r = [];
  rL = xdL + ydL;
  for (i = rL; i--; ) r.push(0);
  for (i = ydL; --i >= 0; ) {
    carry = 0;
    for (k = xdL + i; k > i; ) {
      t = r[k] + yd[i] * xd[k - i - 1] + carry;
      r[k--] = t % BASE | 0;
      carry = t / BASE | 0;
    }
    r[k] = (r[k] + carry) % BASE | 0;
  }
  for (; !r[--rL]; ) r.pop();
  if (carry) ++e3;
  else r.shift();
  y.d = r;
  y.e = getBase10Exponent(r, e3);
  return external ? finalise(y, Ctor.precision, Ctor.rounding) : y;
};
P.toBinary = function(sd, rm) {
  return toStringBinary(this, 2, sd, rm);
};
P.toDecimalPlaces = P.toDP = function(dp, rm) {
  var x = this, Ctor = x.constructor;
  x = new Ctor(x);
  if (dp === void 0) return x;
  checkInt32(dp, 0, MAX_DIGITS);
  if (rm === void 0) rm = Ctor.rounding;
  else checkInt32(rm, 0, 8);
  return finalise(x, dp + x.e + 1, rm);
};
P.toExponential = function(dp, rm) {
  var str, x = this, Ctor = x.constructor;
  if (dp === void 0) {
    str = finiteToString(x, true);
  } else {
    checkInt32(dp, 0, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    x = finalise(new Ctor(x), dp + 1, rm);
    str = finiteToString(x, true, dp + 1);
  }
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toFixed = function(dp, rm) {
  var str, y, x = this, Ctor = x.constructor;
  if (dp === void 0) {
    str = finiteToString(x);
  } else {
    checkInt32(dp, 0, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    y = finalise(new Ctor(x), dp + x.e + 1, rm);
    str = finiteToString(y, false, dp + y.e + 1);
  }
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toFraction = function(maxD) {
  var d, d0, d1, d2, e3, k, n, n0, n16, pr, q, r, x = this, xd = x.d, Ctor = x.constructor;
  if (!xd) return new Ctor(x);
  n16 = d0 = new Ctor(1);
  d1 = n0 = new Ctor(0);
  d = new Ctor(d1);
  e3 = d.e = getPrecision(xd) - x.e - 1;
  k = e3 % LOG_BASE;
  d.d[0] = mathpow(10, k < 0 ? LOG_BASE + k : k);
  if (maxD == null) {
    maxD = e3 > 0 ? d : n16;
  } else {
    n = new Ctor(maxD);
    if (!n.isInt() || n.lt(n16)) throw Error(invalidArgument + n);
    maxD = n.gt(d) ? e3 > 0 ? d : n16 : n;
  }
  external = false;
  n = new Ctor(digitsToString(xd));
  pr = Ctor.precision;
  Ctor.precision = e3 = xd.length * LOG_BASE * 2;
  for (; ; ) {
    q = divide(n, d, 0, 1, 1);
    d2 = d0.plus(q.times(d1));
    if (d2.cmp(maxD) == 1) break;
    d0 = d1;
    d1 = d2;
    d2 = n16;
    n16 = n0.plus(q.times(d2));
    n0 = d2;
    d2 = d;
    d = n.minus(q.times(d2));
    n = d2;
  }
  d2 = divide(maxD.minus(d0), d1, 0, 1, 1);
  n0 = n0.plus(d2.times(n16));
  d0 = d0.plus(d2.times(d1));
  n0.s = n16.s = x.s;
  r = divide(n16, d1, e3, 1).minus(x).abs().cmp(divide(n0, d0, e3, 1).minus(x).abs()) < 1 ? [n16, d1] : [n0, d0];
  Ctor.precision = pr;
  external = true;
  return r;
};
P.toHexadecimal = P.toHex = function(sd, rm) {
  return toStringBinary(this, 16, sd, rm);
};
P.toNearest = function(y, rm) {
  var x = this, Ctor = x.constructor;
  x = new Ctor(x);
  if (y == null) {
    if (!x.d) return x;
    y = new Ctor(1);
    rm = Ctor.rounding;
  } else {
    y = new Ctor(y);
    if (rm === void 0) {
      rm = Ctor.rounding;
    } else {
      checkInt32(rm, 0, 8);
    }
    if (!x.d) return y.s ? x : y;
    if (!y.d) {
      if (y.s) y.s = x.s;
      return y;
    }
  }
  if (y.d[0]) {
    external = false;
    x = divide(x, y, 0, rm, 1).times(y);
    external = true;
    finalise(x);
  } else {
    y.s = x.s;
    x = y;
  }
  return x;
};
P.toNumber = function() {
  return +this;
};
P.toOctal = function(sd, rm) {
  return toStringBinary(this, 8, sd, rm);
};
P.toPower = P.pow = function(y) {
  var e3, k, pr, r, rm, s, x = this, Ctor = x.constructor, yn = +(y = new Ctor(y));
  if (!x.d || !y.d || !x.d[0] || !y.d[0]) return new Ctor(mathpow(+x, yn));
  x = new Ctor(x);
  if (x.eq(1)) return x;
  pr = Ctor.precision;
  rm = Ctor.rounding;
  if (y.eq(1)) return finalise(x, pr, rm);
  e3 = mathfloor(y.e / LOG_BASE);
  if (e3 >= y.d.length - 1 && (k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
    r = intPow(Ctor, x, k, pr);
    return y.s < 0 ? new Ctor(1).div(r) : finalise(r, pr, rm);
  }
  s = x.s;
  if (s < 0) {
    if (e3 < y.d.length - 1) return new Ctor(NaN);
    if ((y.d[e3] & 1) == 0) s = 1;
    if (x.e == 0 && x.d[0] == 1 && x.d.length == 1) {
      x.s = s;
      return x;
    }
  }
  k = mathpow(+x, yn);
  e3 = k == 0 || !isFinite(k) ? mathfloor(yn * (Math.log("0." + digitsToString(x.d)) / Math.LN10 + x.e + 1)) : new Ctor(k + "").e;
  if (e3 > Ctor.maxE + 1 || e3 < Ctor.minE - 1) return new Ctor(e3 > 0 ? s / 0 : 0);
  external = false;
  Ctor.rounding = x.s = 1;
  k = Math.min(12, (e3 + "").length);
  r = naturalExponential(y.times(naturalLogarithm(x, pr + k)), pr);
  if (r.d) {
    r = finalise(r, pr + 5, 1);
    if (checkRoundingDigits(r.d, pr, rm)) {
      e3 = pr + 10;
      r = finalise(naturalExponential(y.times(naturalLogarithm(x, e3 + k)), e3), e3 + 5, 1);
      if (+digitsToString(r.d).slice(pr + 1, pr + 15) + 1 == 1e14) {
        r = finalise(r, pr + 1, 0);
      }
    }
  }
  r.s = s;
  external = true;
  Ctor.rounding = rm;
  return finalise(r, pr, rm);
};
P.toPrecision = function(sd, rm) {
  var str, x = this, Ctor = x.constructor;
  if (sd === void 0) {
    str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
  } else {
    checkInt32(sd, 1, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
    x = finalise(new Ctor(x), sd, rm);
    str = finiteToString(x, sd <= x.e || x.e <= Ctor.toExpNeg, sd);
  }
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toSignificantDigits = P.toSD = function(sd, rm) {
  var x = this, Ctor = x.constructor;
  if (sd === void 0) {
    sd = Ctor.precision;
    rm = Ctor.rounding;
  } else {
    checkInt32(sd, 1, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
  }
  return finalise(new Ctor(x), sd, rm);
};
P.toString = function() {
  var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
  return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.truncated = P.trunc = function() {
  return finalise(new this.constructor(this), this.e + 1, 1);
};
P.valueOf = P.toJSON = function() {
  var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
  return x.isNeg() ? "-" + str : str;
};
function digitsToString(d) {
  var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
  if (indexOfLastWord > 0) {
    str += w;
    for (i = 1; i < indexOfLastWord; i++) {
      ws = d[i] + "";
      k = LOG_BASE - ws.length;
      if (k) str += getZeroString(k);
      str += ws;
    }
    w = d[i];
    ws = w + "";
    k = LOG_BASE - ws.length;
    if (k) str += getZeroString(k);
  } else if (w === 0) {
    return "0";
  }
  for (; w % 10 === 0; ) w /= 10;
  return str + w;
}
function checkInt32(i, min3, max3) {
  if (i !== ~~i || i < min3 || i > max3) {
    throw Error(invalidArgument + i);
  }
}
function checkRoundingDigits(d, i, rm, repeating) {
  var di, k, r, rd;
  for (k = d[0]; k >= 10; k /= 10) --i;
  if (--i < 0) {
    i += LOG_BASE;
    di = 0;
  } else {
    di = Math.ceil((i + 1) / LOG_BASE);
    i %= LOG_BASE;
  }
  k = mathpow(10, LOG_BASE - i);
  rd = d[di] % k | 0;
  if (repeating == null) {
    if (i < 3) {
      if (i == 0) rd = rd / 100 | 0;
      else if (i == 1) rd = rd / 10 | 0;
      r = rm < 4 && rd == 99999 || rm > 3 && rd == 49999 || rd == 5e4 || rd == 0;
    } else {
      r = (rm < 4 && rd + 1 == k || rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 100 | 0) == mathpow(10, i - 2) - 1 || (rd == k / 2 || rd == 0) && (d[di + 1] / k / 100 | 0) == 0;
    }
  } else {
    if (i < 4) {
      if (i == 0) rd = rd / 1e3 | 0;
      else if (i == 1) rd = rd / 100 | 0;
      else if (i == 2) rd = rd / 10 | 0;
      r = (repeating || rm < 4) && rd == 9999 || !repeating && rm > 3 && rd == 4999;
    } else {
      r = ((repeating || rm < 4) && rd + 1 == k || !repeating && rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 1e3 | 0) == mathpow(10, i - 3) - 1;
    }
  }
  return r;
}
function convertBase(str, baseIn, baseOut) {
  var j, arr = [0], arrL, i = 0, strL = str.length;
  for (; i < strL; ) {
    for (arrL = arr.length; arrL--; ) arr[arrL] *= baseIn;
    arr[0] += NUMERALS.indexOf(str.charAt(i++));
    for (j = 0; j < arr.length; j++) {
      if (arr[j] > baseOut - 1) {
        if (arr[j + 1] === void 0) arr[j + 1] = 0;
        arr[j + 1] += arr[j] / baseOut | 0;
        arr[j] %= baseOut;
      }
    }
  }
  return arr.reverse();
}
function cosine(Ctor, x) {
  var k, len, y;
  if (x.isZero()) return x;
  len = x.d.length;
  if (len < 32) {
    k = Math.ceil(len / 3);
    y = (1 / tinyPow(4, k)).toString();
  } else {
    k = 16;
    y = "2.3283064365386962890625e-10";
  }
  Ctor.precision += k;
  x = taylorSeries(Ctor, 1, x.times(y), new Ctor(1));
  for (var i = k; i--; ) {
    var cos2x = x.times(x);
    x = cos2x.times(cos2x).minus(cos2x).times(8).plus(1);
  }
  Ctor.precision -= k;
  return x;
}
var divide = /* @__PURE__ */ (function() {
  function multiplyInteger(x, k, base) {
    var temp, carry = 0, i = x.length;
    for (x = x.slice(); i--; ) {
      temp = x[i] * k + carry;
      x[i] = temp % base | 0;
      carry = temp / base | 0;
    }
    if (carry) x.unshift(carry);
    return x;
  }
  function compare2(a, b, aL, bL) {
    var i, r;
    if (aL != bL) {
      r = aL > bL ? 1 : -1;
    } else {
      for (i = r = 0; i < aL; i++) {
        if (a[i] != b[i]) {
          r = a[i] > b[i] ? 1 : -1;
          break;
        }
      }
    }
    return r;
  }
  function subtract2(a, b, aL, base) {
    var i = 0;
    for (; aL--; ) {
      a[aL] -= i;
      i = a[aL] < b[aL] ? 1 : 0;
      a[aL] = i * base + a[aL] - b[aL];
    }
    for (; !a[0] && a.length > 1; ) a.shift();
  }
  return function(x, y, pr, rm, dp, base) {
    var cmp, e3, i, k, logBase, more, prod2, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign4 = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
    if (!xd || !xd[0] || !yd || !yd[0]) {
      return new Ctor(
        // Return NaN if either NaN, or both Infinity or 0.
        !x.s || !y.s || (xd ? yd && xd[0] == yd[0] : !yd) ? NaN : (
          // Return ±0 if x is 0 or y is ±Infinity, or return ±Infinity as y is 0.
          xd && xd[0] == 0 || !yd ? sign4 * 0 : sign4 / 0
        )
      );
    }
    if (base) {
      logBase = 1;
      e3 = x.e - y.e;
    } else {
      base = BASE;
      logBase = LOG_BASE;
      e3 = mathfloor(x.e / logBase) - mathfloor(y.e / logBase);
    }
    yL = yd.length;
    xL = xd.length;
    q = new Ctor(sign4);
    qd = q.d = [];
    for (i = 0; yd[i] == (xd[i] || 0); i++) ;
    if (yd[i] > (xd[i] || 0)) e3--;
    if (pr == null) {
      sd = pr = Ctor.precision;
      rm = Ctor.rounding;
    } else if (dp) {
      sd = pr + (x.e - y.e) + 1;
    } else {
      sd = pr;
    }
    if (sd < 0) {
      qd.push(1);
      more = true;
    } else {
      sd = sd / logBase + 2 | 0;
      i = 0;
      if (yL == 1) {
        k = 0;
        yd = yd[0];
        sd++;
        for (; (i < xL || k) && sd--; i++) {
          t = k * base + (xd[i] || 0);
          qd[i] = t / yd | 0;
          k = t % yd | 0;
        }
        more = k || i < xL;
      } else {
        k = base / (yd[0] + 1) | 0;
        if (k > 1) {
          yd = multiplyInteger(yd, k, base);
          xd = multiplyInteger(xd, k, base);
          yL = yd.length;
          xL = xd.length;
        }
        xi = yL;
        rem = xd.slice(0, yL);
        remL = rem.length;
        for (; remL < yL; ) rem[remL++] = 0;
        yz = yd.slice();
        yz.unshift(0);
        yd0 = yd[0];
        if (yd[1] >= base / 2) ++yd0;
        do {
          k = 0;
          cmp = compare2(yd, rem, yL, remL);
          if (cmp < 0) {
            rem0 = rem[0];
            if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
            k = rem0 / yd0 | 0;
            if (k > 1) {
              if (k >= base) k = base - 1;
              prod2 = multiplyInteger(yd, k, base);
              prodL = prod2.length;
              remL = rem.length;
              cmp = compare2(prod2, rem, prodL, remL);
              if (cmp == 1) {
                k--;
                subtract2(prod2, yL < prodL ? yz : yd, prodL, base);
              }
            } else {
              if (k == 0) cmp = k = 1;
              prod2 = yd.slice();
            }
            prodL = prod2.length;
            if (prodL < remL) prod2.unshift(0);
            subtract2(rem, prod2, remL, base);
            if (cmp == -1) {
              remL = rem.length;
              cmp = compare2(yd, rem, yL, remL);
              if (cmp < 1) {
                k++;
                subtract2(rem, yL < remL ? yz : yd, remL, base);
              }
            }
            remL = rem.length;
          } else if (cmp === 0) {
            k++;
            rem = [0];
          }
          qd[i++] = k;
          if (cmp && rem[0]) {
            rem[remL++] = xd[xi] || 0;
          } else {
            rem = [xd[xi]];
            remL = 1;
          }
        } while ((xi++ < xL || rem[0] !== void 0) && sd--);
        more = rem[0] !== void 0;
      }
      if (!qd[0]) qd.shift();
    }
    if (logBase == 1) {
      q.e = e3;
      inexact = more;
    } else {
      for (i = 1, k = qd[0]; k >= 10; k /= 10) i++;
      q.e = i + e3 * logBase - 1;
      finalise(q, dp ? pr + q.e + 1 : pr, rm, more);
    }
    return q;
  };
})();
function finalise(x, sd, rm, isTruncated) {
  var digits2, i, j, k, rd, roundUp, w, xd, xdi, Ctor = x.constructor;
  out: if (sd != null) {
    xd = x.d;
    if (!xd) return x;
    for (digits2 = 1, k = xd[0]; k >= 10; k /= 10) digits2++;
    i = sd - digits2;
    if (i < 0) {
      i += LOG_BASE;
      j = sd;
      w = xd[xdi = 0];
      rd = w / mathpow(10, digits2 - j - 1) % 10 | 0;
    } else {
      xdi = Math.ceil((i + 1) / LOG_BASE);
      k = xd.length;
      if (xdi >= k) {
        if (isTruncated) {
          for (; k++ <= xdi; ) xd.push(0);
          w = rd = 0;
          digits2 = 1;
          i %= LOG_BASE;
          j = i - LOG_BASE + 1;
        } else {
          break out;
        }
      } else {
        w = k = xd[xdi];
        for (digits2 = 1; k >= 10; k /= 10) digits2++;
        i %= LOG_BASE;
        j = i - LOG_BASE + digits2;
        rd = j < 0 ? 0 : w / mathpow(10, digits2 - j - 1) % 10 | 0;
      }
    }
    isTruncated = isTruncated || sd < 0 || xd[xdi + 1] !== void 0 || (j < 0 ? w : w % mathpow(10, digits2 - j - 1));
    roundUp = rm < 4 ? (rd || isTruncated) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || isTruncated || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
    (i > 0 ? j > 0 ? w / mathpow(10, digits2 - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
    if (sd < 1 || !xd[0]) {
      xd.length = 0;
      if (roundUp) {
        sd -= x.e + 1;
        xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
        x.e = -sd || 0;
      } else {
        xd[0] = x.e = 0;
      }
      return x;
    }
    if (i == 0) {
      xd.length = xdi;
      k = 1;
      xdi--;
    } else {
      xd.length = xdi + 1;
      k = mathpow(10, LOG_BASE - i);
      xd[xdi] = j > 0 ? (w / mathpow(10, digits2 - j) % mathpow(10, j) | 0) * k : 0;
    }
    if (roundUp) {
      for (; ; ) {
        if (xdi == 0) {
          for (i = 1, j = xd[0]; j >= 10; j /= 10) i++;
          j = xd[0] += k;
          for (k = 1; j >= 10; j /= 10) k++;
          if (i != k) {
            x.e++;
            if (xd[0] == BASE) xd[0] = 1;
          }
          break;
        } else {
          xd[xdi] += k;
          if (xd[xdi] != BASE) break;
          xd[xdi--] = 0;
          k = 1;
        }
      }
    }
    for (i = xd.length; xd[--i] === 0; ) xd.pop();
  }
  if (external) {
    if (x.e > Ctor.maxE) {
      x.d = null;
      x.e = NaN;
    } else if (x.e < Ctor.minE) {
      x.e = 0;
      x.d = [0];
    }
  }
  return x;
}
function finiteToString(x, isExp, sd) {
  if (!x.isFinite()) return nonFiniteToString(x);
  var k, e3 = x.e, str = digitsToString(x.d), len = str.length;
  if (isExp) {
    if (sd && (k = sd - len) > 0) {
      str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
    } else if (len > 1) {
      str = str.charAt(0) + "." + str.slice(1);
    }
    str = str + (x.e < 0 ? "e" : "e+") + x.e;
  } else if (e3 < 0) {
    str = "0." + getZeroString(-e3 - 1) + str;
    if (sd && (k = sd - len) > 0) str += getZeroString(k);
  } else if (e3 >= len) {
    str += getZeroString(e3 + 1 - len);
    if (sd && (k = sd - e3 - 1) > 0) str = str + "." + getZeroString(k);
  } else {
    if ((k = e3 + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
    if (sd && (k = sd - len) > 0) {
      if (e3 + 1 === len) str += ".";
      str += getZeroString(k);
    }
  }
  return str;
}
function getBase10Exponent(digits2, e3) {
  var w = digits2[0];
  for (e3 *= LOG_BASE; w >= 10; w /= 10) e3++;
  return e3;
}
function getLn10(Ctor, sd, pr) {
  if (sd > LN10_PRECISION) {
    external = true;
    if (pr) Ctor.precision = pr;
    throw Error(precisionLimitExceeded);
  }
  return finalise(new Ctor(LN10), sd, 1, true);
}
function getPi(Ctor, sd, rm) {
  if (sd > PI_PRECISION) throw Error(precisionLimitExceeded);
  return finalise(new Ctor(PI), sd, rm, true);
}
function getPrecision(digits2) {
  var w = digits2.length - 1, len = w * LOG_BASE + 1;
  w = digits2[w];
  if (w) {
    for (; w % 10 == 0; w /= 10) len--;
    for (w = digits2[0]; w >= 10; w /= 10) len++;
  }
  return len;
}
function getZeroString(k) {
  var zs = "";
  for (; k--; ) zs += "0";
  return zs;
}
function intPow(Ctor, x, n, pr) {
  var isTruncated, r = new Ctor(1), k = Math.ceil(pr / LOG_BASE + 4);
  external = false;
  for (; ; ) {
    if (n % 2) {
      r = r.times(x);
      if (truncate(r.d, k)) isTruncated = true;
    }
    n = mathfloor(n / 2);
    if (n === 0) {
      n = r.d.length - 1;
      if (isTruncated && r.d[n] === 0) ++r.d[n];
      break;
    }
    x = x.times(x);
    truncate(x.d, k);
  }
  external = true;
  return r;
}
function isOdd(n) {
  return n.d[n.d.length - 1] & 1;
}
function maxOrMin(Ctor, args, n) {
  var k, y, x = new Ctor(args[0]), i = 0;
  for (; ++i < args.length; ) {
    y = new Ctor(args[i]);
    if (!y.s) {
      x = y;
      break;
    }
    k = x.cmp(y);
    if (k === n || k === 0 && x.s === n) {
      x = y;
    }
  }
  return x;
}
function naturalExponential(x, sd) {
  var denominator, guard, j, pow3, sum3, t, wpr, rep = 0, i = 0, k = 0, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
  if (!x.d || !x.d[0] || x.e > 17) {
    return new Ctor(x.d ? !x.d[0] ? 1 : x.s < 0 ? 0 : 1 / 0 : x.s ? x.s < 0 ? 0 : x : 0 / 0);
  }
  if (sd == null) {
    external = false;
    wpr = pr;
  } else {
    wpr = sd;
  }
  t = new Ctor(0.03125);
  while (x.e > -2) {
    x = x.times(t);
    k += 5;
  }
  guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
  wpr += guard;
  denominator = pow3 = sum3 = new Ctor(1);
  Ctor.precision = wpr;
  for (; ; ) {
    pow3 = finalise(pow3.times(x), wpr, 1);
    denominator = denominator.times(++i);
    t = sum3.plus(divide(pow3, denominator, wpr, 1));
    if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum3.d).slice(0, wpr)) {
      j = k;
      while (j--) sum3 = finalise(sum3.times(sum3), wpr, 1);
      if (sd == null) {
        if (rep < 3 && checkRoundingDigits(sum3.d, wpr - guard, rm, rep)) {
          Ctor.precision = wpr += 10;
          denominator = pow3 = t = new Ctor(1);
          i = 0;
          rep++;
        } else {
          return finalise(sum3, Ctor.precision = pr, rm, external = true);
        }
      } else {
        Ctor.precision = pr;
        return sum3;
      }
    }
    sum3 = t;
  }
}
function naturalLogarithm(y, sd) {
  var c, c0, denominator, e3, numerator, rep, sum3, t, wpr, x1, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
  if (x.s < 0 || !xd || !xd[0] || !x.e && xd[0] == 1 && xd.length == 1) {
    return new Ctor(xd && !xd[0] ? -1 / 0 : x.s != 1 ? NaN : xd ? 0 : x);
  }
  if (sd == null) {
    external = false;
    wpr = pr;
  } else {
    wpr = sd;
  }
  Ctor.precision = wpr += guard;
  c = digitsToString(xd);
  c0 = c.charAt(0);
  if (Math.abs(e3 = x.e) < 15e14) {
    while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
      x = x.times(y);
      c = digitsToString(x.d);
      c0 = c.charAt(0);
      n++;
    }
    e3 = x.e;
    if (c0 > 1) {
      x = new Ctor("0." + c);
      e3++;
    } else {
      x = new Ctor(c0 + "." + c.slice(1));
    }
  } else {
    t = getLn10(Ctor, wpr + 2, pr).times(e3 + "");
    x = naturalLogarithm(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
    Ctor.precision = pr;
    return sd == null ? finalise(x, pr, rm, external = true) : x;
  }
  x1 = x;
  sum3 = numerator = x = divide(x.minus(1), x.plus(1), wpr, 1);
  x2 = finalise(x.times(x), wpr, 1);
  denominator = 3;
  for (; ; ) {
    numerator = finalise(numerator.times(x2), wpr, 1);
    t = sum3.plus(divide(numerator, new Ctor(denominator), wpr, 1));
    if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum3.d).slice(0, wpr)) {
      sum3 = sum3.times(2);
      if (e3 !== 0) sum3 = sum3.plus(getLn10(Ctor, wpr + 2, pr).times(e3 + ""));
      sum3 = divide(sum3, new Ctor(n), wpr, 1);
      if (sd == null) {
        if (checkRoundingDigits(sum3.d, wpr - guard, rm, rep)) {
          Ctor.precision = wpr += guard;
          t = numerator = x = divide(x1.minus(1), x1.plus(1), wpr, 1);
          x2 = finalise(x.times(x), wpr, 1);
          denominator = rep = 1;
        } else {
          return finalise(sum3, Ctor.precision = pr, rm, external = true);
        }
      } else {
        Ctor.precision = pr;
        return sum3;
      }
    }
    sum3 = t;
    denominator += 2;
  }
}
function nonFiniteToString(x) {
  return String(x.s * x.s / 0);
}
function parseDecimal(x, str) {
  var e3, i, len;
  if ((e3 = str.indexOf(".")) > -1) str = str.replace(".", "");
  if ((i = str.search(/e/i)) > 0) {
    if (e3 < 0) e3 = i;
    e3 += +str.slice(i + 1);
    str = str.substring(0, i);
  } else if (e3 < 0) {
    e3 = str.length;
  }
  for (i = 0; str.charCodeAt(i) === 48; i++) ;
  for (len = str.length; str.charCodeAt(len - 1) === 48; --len) ;
  str = str.slice(i, len);
  if (str) {
    len -= i;
    x.e = e3 = e3 - i - 1;
    x.d = [];
    i = (e3 + 1) % LOG_BASE;
    if (e3 < 0) i += LOG_BASE;
    if (i < len) {
      if (i) x.d.push(+str.slice(0, i));
      for (len -= LOG_BASE; i < len; ) x.d.push(+str.slice(i, i += LOG_BASE));
      str = str.slice(i);
      i = LOG_BASE - str.length;
    } else {
      i -= len;
    }
    for (; i--; ) str += "0";
    x.d.push(+str);
    if (external) {
      if (x.e > x.constructor.maxE) {
        x.d = null;
        x.e = NaN;
      } else if (x.e < x.constructor.minE) {
        x.e = 0;
        x.d = [0];
      }
    }
  } else {
    x.e = 0;
    x.d = [0];
  }
  return x;
}
function parseOther(x, str) {
  var base, Ctor, divisor, i, isFloat, len, p, xd, xe;
  if (str.indexOf("_") > -1) {
    str = str.replace(/(\d)_(?=\d)/g, "$1");
    if (isDecimal.test(str)) return parseDecimal(x, str);
  } else if (str === "Infinity" || str === "NaN") {
    if (!+str) x.s = NaN;
    x.e = NaN;
    x.d = null;
    return x;
  }
  if (isHex.test(str)) {
    base = 16;
    str = str.toLowerCase();
  } else if (isBinary.test(str)) {
    base = 2;
  } else if (isOctal.test(str)) {
    base = 8;
  } else {
    throw Error(invalidArgument + str);
  }
  i = str.search(/p/i);
  if (i > 0) {
    p = +str.slice(i + 1);
    str = str.substring(2, i);
  } else {
    str = str.slice(2);
  }
  i = str.indexOf(".");
  isFloat = i >= 0;
  Ctor = x.constructor;
  if (isFloat) {
    str = str.replace(".", "");
    len = str.length;
    i = len - i;
    divisor = intPow(Ctor, new Ctor(base), i, i * 2);
  }
  xd = convertBase(str, base, BASE);
  xe = xd.length - 1;
  for (i = xe; xd[i] === 0; --i) xd.pop();
  if (i < 0) return new Ctor(x.s * 0);
  x.e = getBase10Exponent(xd, xe);
  x.d = xd;
  external = false;
  if (isFloat) x = divide(x, divisor, len * 4);
  if (p) x = x.times(Math.abs(p) < 54 ? mathpow(2, p) : Decimal.pow(2, p));
  external = true;
  return x;
}
function sine(Ctor, x) {
  var k, len = x.d.length;
  if (len < 3) {
    return x.isZero() ? x : taylorSeries(Ctor, 2, x, x);
  }
  k = 1.4 * Math.sqrt(len);
  k = k > 16 ? 16 : k | 0;
  x = x.times(1 / tinyPow(5, k));
  x = taylorSeries(Ctor, 2, x, x);
  var sin2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
  for (; k--; ) {
    sin2_x = x.times(x);
    x = x.times(d5.plus(sin2_x.times(d16.times(sin2_x).minus(d20))));
  }
  return x;
}
function taylorSeries(Ctor, n, x, y, isHyperbolic) {
  var j, t, u, x2, i = 1, pr = Ctor.precision, k = Math.ceil(pr / LOG_BASE);
  external = false;
  x2 = x.times(x);
  u = new Ctor(y);
  for (; ; ) {
    t = divide(u.times(x2), new Ctor(n++ * n++), pr, 1);
    u = isHyperbolic ? y.plus(t) : y.minus(t);
    y = divide(t.times(x2), new Ctor(n++ * n++), pr, 1);
    t = u.plus(y);
    if (t.d[k] !== void 0) {
      for (j = k; t.d[j] === u.d[j] && j--; ) ;
      if (j == -1) break;
    }
    j = u;
    u = y;
    y = t;
    t = j;
    i++;
  }
  external = true;
  t.d.length = k + 1;
  return t;
}
function tinyPow(b, e3) {
  var n = b;
  while (--e3) n *= b;
  return n;
}
function toLessThanHalfPi(Ctor, x) {
  var t, isNeg = x.s < 0, pi3 = getPi(Ctor, Ctor.precision, 1), halfPi = pi3.times(0.5);
  x = x.abs();
  if (x.lte(halfPi)) {
    quadrant = isNeg ? 4 : 1;
    return x;
  }
  t = x.divToInt(pi3);
  if (t.isZero()) {
    quadrant = isNeg ? 3 : 2;
  } else {
    x = x.minus(t.times(pi3));
    if (x.lte(halfPi)) {
      quadrant = isOdd(t) ? isNeg ? 2 : 3 : isNeg ? 4 : 1;
      return x;
    }
    quadrant = isOdd(t) ? isNeg ? 1 : 4 : isNeg ? 3 : 2;
  }
  return x.minus(pi3).abs();
}
function toStringBinary(x, baseOut, sd, rm) {
  var base, e3, i, k, len, roundUp, str, xd, y, Ctor = x.constructor, isExp = sd !== void 0;
  if (isExp) {
    checkInt32(sd, 1, MAX_DIGITS);
    if (rm === void 0) rm = Ctor.rounding;
    else checkInt32(rm, 0, 8);
  } else {
    sd = Ctor.precision;
    rm = Ctor.rounding;
  }
  if (!x.isFinite()) {
    str = nonFiniteToString(x);
  } else {
    str = finiteToString(x);
    i = str.indexOf(".");
    if (isExp) {
      base = 2;
      if (baseOut == 16) {
        sd = sd * 4 - 3;
      } else if (baseOut == 8) {
        sd = sd * 3 - 2;
      }
    } else {
      base = baseOut;
    }
    if (i >= 0) {
      str = str.replace(".", "");
      y = new Ctor(1);
      y.e = str.length - i;
      y.d = convertBase(finiteToString(y), 10, base);
      y.e = y.d.length;
    }
    xd = convertBase(str, 10, base);
    e3 = len = xd.length;
    for (; xd[--len] == 0; ) xd.pop();
    if (!xd[0]) {
      str = isExp ? "0p+0" : "0";
    } else {
      if (i < 0) {
        e3--;
      } else {
        x = new Ctor(x);
        x.d = xd;
        x.e = e3;
        x = divide(x, y, sd, rm, 0, base);
        xd = x.d;
        e3 = x.e;
        roundUp = inexact;
      }
      i = xd[sd];
      k = base / 2;
      roundUp = roundUp || xd[sd + 1] !== void 0;
      roundUp = rm < 4 ? (i !== void 0 || roundUp) && (rm === 0 || rm === (x.s < 0 ? 3 : 2)) : i > k || i === k && (rm === 4 || roundUp || rm === 6 && xd[sd - 1] & 1 || rm === (x.s < 0 ? 8 : 7));
      xd.length = sd;
      if (roundUp) {
        for (; ++xd[--sd] > base - 1; ) {
          xd[sd] = 0;
          if (!sd) {
            ++e3;
            xd.unshift(1);
          }
        }
      }
      for (len = xd.length; !xd[len - 1]; --len) ;
      for (i = 0, str = ""; i < len; i++) str += NUMERALS.charAt(xd[i]);
      if (isExp) {
        if (len > 1) {
          if (baseOut == 16 || baseOut == 8) {
            i = baseOut == 16 ? 4 : 3;
            for (--len; len % i; len++) str += "0";
            xd = convertBase(str, base, baseOut);
            for (len = xd.length; !xd[len - 1]; --len) ;
            for (i = 1, str = "1."; i < len; i++) str += NUMERALS.charAt(xd[i]);
          } else {
            str = str.charAt(0) + "." + str.slice(1);
          }
        }
        str = str + (e3 < 0 ? "p" : "p+") + e3;
      } else if (e3 < 0) {
        for (; ++e3; ) str = "0" + str;
        str = "0." + str;
      } else {
        if (++e3 > len) for (e3 -= len; e3--; ) str += "0";
        else if (e3 < len) str = str.slice(0, e3) + "." + str.slice(e3);
      }
    }
    str = (baseOut == 16 ? "0x" : baseOut == 2 ? "0b" : baseOut == 8 ? "0o" : "") + str;
  }
  return x.s < 0 ? "-" + str : str;
}
function truncate(arr, len) {
  if (arr.length > len) {
    arr.length = len;
    return true;
  }
}
function abs(x) {
  return new this(x).abs();
}
function acos(x) {
  return new this(x).acos();
}
function acosh2(x) {
  return new this(x).acosh();
}
function add(x, y) {
  return new this(x).plus(y);
}
function asin(x) {
  return new this(x).asin();
}
function asinh2(x) {
  return new this(x).asinh();
}
function atan(x) {
  return new this(x).atan();
}
function atanh2(x) {
  return new this(x).atanh();
}
function atan2(y, x) {
  y = new this(y);
  x = new this(x);
  var r, pr = this.precision, rm = this.rounding, wpr = pr + 4;
  if (!y.s || !x.s) {
    r = new this(NaN);
  } else if (!y.d && !x.d) {
    r = getPi(this, wpr, 1).times(x.s > 0 ? 0.25 : 0.75);
    r.s = y.s;
  } else if (!x.d || y.isZero()) {
    r = x.s < 0 ? getPi(this, pr, rm) : new this(0);
    r.s = y.s;
  } else if (!y.d || x.isZero()) {
    r = getPi(this, wpr, 1).times(0.5);
    r.s = y.s;
  } else if (x.s < 0) {
    this.precision = wpr;
    this.rounding = 1;
    r = this.atan(divide(y, x, wpr, 1));
    x = getPi(this, wpr, 1);
    this.precision = pr;
    this.rounding = rm;
    r = y.s < 0 ? r.minus(x) : r.plus(x);
  } else {
    r = this.atan(divide(y, x, wpr, 1));
  }
  return r;
}
function cbrt3(x) {
  return new this(x).cbrt();
}
function ceil(x) {
  return finalise(x = new this(x), x.e + 1, 2);
}
function clamp(x, min3, max3) {
  return new this(x).clamp(min3, max3);
}
function config3(obj) {
  if (!obj || typeof obj !== "object") throw Error(decimalError + "Object expected");
  var i, p, v, useDefaults = obj.defaults === true, ps = [
    "precision",
    1,
    MAX_DIGITS,
    "rounding",
    0,
    8,
    "toExpNeg",
    -EXP_LIMIT,
    0,
    "toExpPos",
    0,
    EXP_LIMIT,
    "maxE",
    0,
    EXP_LIMIT,
    "minE",
    -EXP_LIMIT,
    0,
    "modulo",
    0,
    9
  ];
  for (i = 0; i < ps.length; i += 3) {
    if (p = ps[i], useDefaults) this[p] = DEFAULTS[p];
    if ((v = obj[p]) !== void 0) {
      if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
      else throw Error(invalidArgument + p + ": " + v);
    }
  }
  if (p = "crypto", useDefaults) this[p] = DEFAULTS[p];
  if ((v = obj[p]) !== void 0) {
    if (v === true || v === false || v === 0 || v === 1) {
      if (v) {
        if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) {
          this[p] = true;
        } else {
          throw Error(cryptoUnavailable);
        }
      } else {
        this[p] = false;
      }
    } else {
      throw Error(invalidArgument + p + ": " + v);
    }
  }
  return this;
}
function cos(x) {
  return new this(x).cos();
}
function cosh2(x) {
  return new this(x).cosh();
}
function clone2(obj) {
  var i, p, ps;
  function Decimal2(v) {
    var e3, i2, t, x = this;
    if (!(x instanceof Decimal2)) return new Decimal2(v);
    x.constructor = Decimal2;
    if (isDecimalInstance(v)) {
      x.s = v.s;
      if (external) {
        if (!v.d || v.e > Decimal2.maxE) {
          x.e = NaN;
          x.d = null;
        } else if (v.e < Decimal2.minE) {
          x.e = 0;
          x.d = [0];
        } else {
          x.e = v.e;
          x.d = v.d.slice();
        }
      } else {
        x.e = v.e;
        x.d = v.d ? v.d.slice() : v.d;
      }
      return;
    }
    t = typeof v;
    if (t === "number") {
      if (v === 0) {
        x.s = 1 / v < 0 ? -1 : 1;
        x.e = 0;
        x.d = [0];
        return;
      }
      if (v < 0) {
        v = -v;
        x.s = -1;
      } else {
        x.s = 1;
      }
      if (v === ~~v && v < 1e7) {
        for (e3 = 0, i2 = v; i2 >= 10; i2 /= 10) e3++;
        if (external) {
          if (e3 > Decimal2.maxE) {
            x.e = NaN;
            x.d = null;
          } else if (e3 < Decimal2.minE) {
            x.e = 0;
            x.d = [0];
          } else {
            x.e = e3;
            x.d = [v];
          }
        } else {
          x.e = e3;
          x.d = [v];
        }
        return;
      }
      if (v * 0 !== 0) {
        if (!v) x.s = NaN;
        x.e = NaN;
        x.d = null;
        return;
      }
      return parseDecimal(x, v.toString());
    }
    if (t === "string") {
      if ((i2 = v.charCodeAt(0)) === 45) {
        v = v.slice(1);
        x.s = -1;
      } else {
        if (i2 === 43) v = v.slice(1);
        x.s = 1;
      }
      return isDecimal.test(v) ? parseDecimal(x, v) : parseOther(x, v);
    }
    if (t === "bigint") {
      if (v < 0) {
        v = -v;
        x.s = -1;
      } else {
        x.s = 1;
      }
      return parseDecimal(x, v.toString());
    }
    throw Error(invalidArgument + v);
  }
  Decimal2.prototype = P;
  Decimal2.ROUND_UP = 0;
  Decimal2.ROUND_DOWN = 1;
  Decimal2.ROUND_CEIL = 2;
  Decimal2.ROUND_FLOOR = 3;
  Decimal2.ROUND_HALF_UP = 4;
  Decimal2.ROUND_HALF_DOWN = 5;
  Decimal2.ROUND_HALF_EVEN = 6;
  Decimal2.ROUND_HALF_CEIL = 7;
  Decimal2.ROUND_HALF_FLOOR = 8;
  Decimal2.EUCLID = 9;
  Decimal2.config = Decimal2.set = config3;
  Decimal2.clone = clone2;
  Decimal2.isDecimal = isDecimalInstance;
  Decimal2.abs = abs;
  Decimal2.acos = acos;
  Decimal2.acosh = acosh2;
  Decimal2.add = add;
  Decimal2.asin = asin;
  Decimal2.asinh = asinh2;
  Decimal2.atan = atan;
  Decimal2.atanh = atanh2;
  Decimal2.atan2 = atan2;
  Decimal2.cbrt = cbrt3;
  Decimal2.ceil = ceil;
  Decimal2.clamp = clamp;
  Decimal2.cos = cos;
  Decimal2.cosh = cosh2;
  Decimal2.div = div;
  Decimal2.exp = exp;
  Decimal2.floor = floor;
  Decimal2.hypot = hypot;
  Decimal2.ln = ln;
  Decimal2.log = log;
  Decimal2.log10 = log103;
  Decimal2.log2 = log23;
  Decimal2.max = max;
  Decimal2.min = min;
  Decimal2.mod = mod;
  Decimal2.mul = mul;
  Decimal2.pow = pow;
  Decimal2.random = random;
  Decimal2.round = round;
  Decimal2.sign = sign2;
  Decimal2.sin = sin;
  Decimal2.sinh = sinh2;
  Decimal2.sqrt = sqrt;
  Decimal2.sub = sub;
  Decimal2.sum = sum;
  Decimal2.tan = tan;
  Decimal2.tanh = tanh2;
  Decimal2.trunc = trunc;
  if (obj === void 0) obj = {};
  if (obj) {
    if (obj.defaults !== true) {
      ps = ["precision", "rounding", "toExpNeg", "toExpPos", "maxE", "minE", "modulo", "crypto"];
      for (i = 0; i < ps.length; ) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
    }
  }
  Decimal2.config(obj);
  return Decimal2;
}
function div(x, y) {
  return new this(x).div(y);
}
function exp(x) {
  return new this(x).exp();
}
function floor(x) {
  return finalise(x = new this(x), x.e + 1, 3);
}
function hypot() {
  var i, n, t = new this(0);
  external = false;
  for (i = 0; i < arguments.length; ) {
    n = new this(arguments[i++]);
    if (!n.d) {
      if (n.s) {
        external = true;
        return new this(1 / 0);
      }
      t = n;
    } else if (t.d) {
      t = t.plus(n.times(n));
    }
  }
  external = true;
  return t.sqrt();
}
function isDecimalInstance(obj) {
  return obj instanceof Decimal || obj && obj.toStringTag === tag || false;
}
function ln(x) {
  return new this(x).ln();
}
function log(x, y) {
  return new this(x).log(y);
}
function log23(x) {
  return new this(x).log(2);
}
function log103(x) {
  return new this(x).log(10);
}
function max() {
  return maxOrMin(this, arguments, -1);
}
function min() {
  return maxOrMin(this, arguments, 1);
}
function mod(x, y) {
  return new this(x).mod(y);
}
function mul(x, y) {
  return new this(x).mul(y);
}
function pow(x, y) {
  return new this(x).pow(y);
}
function random(sd) {
  var d, e3, k, n, i = 0, r = new this(1), rd = [];
  if (sd === void 0) sd = this.precision;
  else checkInt32(sd, 1, MAX_DIGITS);
  k = Math.ceil(sd / LOG_BASE);
  if (!this.crypto) {
    for (; i < k; ) rd[i++] = Math.random() * 1e7 | 0;
  } else if (crypto.getRandomValues) {
    d = crypto.getRandomValues(new Uint32Array(k));
    for (; i < k; ) {
      n = d[i];
      if (n >= 429e7) {
        d[i] = crypto.getRandomValues(new Uint32Array(1))[0];
      } else {
        rd[i++] = n % 1e7;
      }
    }
  } else if (crypto.randomBytes) {
    d = crypto.randomBytes(k *= 4);
    for (; i < k; ) {
      n = d[i] + (d[i + 1] << 8) + (d[i + 2] << 16) + ((d[i + 3] & 127) << 24);
      if (n >= 214e7) {
        crypto.randomBytes(4).copy(d, i);
      } else {
        rd.push(n % 1e7);
        i += 4;
      }
    }
    i = k / 4;
  } else {
    throw Error(cryptoUnavailable);
  }
  k = rd[--i];
  sd %= LOG_BASE;
  if (k && sd) {
    n = mathpow(10, LOG_BASE - sd);
    rd[i] = (k / n | 0) * n;
  }
  for (; rd[i] === 0; i--) rd.pop();
  if (i < 0) {
    e3 = 0;
    rd = [0];
  } else {
    e3 = -1;
    for (; rd[0] === 0; e3 -= LOG_BASE) rd.shift();
    for (k = 1, n = rd[0]; n >= 10; n /= 10) k++;
    if (k < LOG_BASE) e3 -= LOG_BASE - k;
  }
  r.e = e3;
  r.d = rd;
  return r;
}
function round(x) {
  return finalise(x = new this(x), x.e + 1, this.rounding);
}
function sign2(x) {
  x = new this(x);
  return x.d ? x.d[0] ? x.s : 0 * x.s : x.s || NaN;
}
function sin(x) {
  return new this(x).sin();
}
function sinh2(x) {
  return new this(x).sinh();
}
function sqrt(x) {
  return new this(x).sqrt();
}
function sub(x, y) {
  return new this(x).sub(y);
}
function sum() {
  var i = 0, args = arguments, x = new this(args[i]);
  external = false;
  for (; x.s && ++i < args.length; ) x = x.plus(args[i]);
  external = true;
  return finalise(x, this.precision, this.rounding);
}
function tan(x) {
  return new this(x).tan();
}
function tanh2(x) {
  return new this(x).tanh();
}
function trunc(x) {
  return finalise(x = new this(x), x.e + 1, 1);
}
P[/* @__PURE__ */ Symbol.for("nodejs.util.inspect.custom")] = P.toString;
P[Symbol.toStringTag] = "Decimal";
var Decimal = P.constructor = clone2(DEFAULTS);
LN10 = new Decimal(LN10);
PI = new Decimal(PI);
var decimal_default = Decimal;

// node_modules/mathjs/lib/esm/error/IndexError.js
function IndexError(index2, min3, max3) {
  if (!(this instanceof IndexError)) {
    throw new SyntaxError("Constructor must be called with the new operator");
  }
  this.index = index2;
  if (arguments.length < 3) {
    this.min = 0;
    this.max = min3;
  } else {
    this.min = min3;
    this.max = max3;
  }
  if (this.min !== void 0 && this.index < this.min) {
    this.message = "Index out of range (" + this.index + " < " + this.min + ")";
  } else if (this.max !== void 0 && this.index >= this.max) {
    this.message = "Index out of range (" + this.index + " > " + (this.max - 1) + ")";
  } else {
    this.message = "Index out of range (" + this.index + ")";
  }
  this.stack = new Error().stack;
}
IndexError.prototype = new RangeError();
IndexError.prototype.constructor = RangeError;
IndexError.prototype.name = "IndexError";
IndexError.prototype.isIndexError = true;

// node_modules/mathjs/lib/esm/utils/array.js
var import_extends2 = __toESM(require_extends(), 1);

// node_modules/mathjs/lib/esm/error/DimensionError.js
function DimensionError(actual, expected, relation) {
  if (!(this instanceof DimensionError)) {
    throw new SyntaxError("Constructor must be called with the new operator");
  }
  this.actual = actual;
  this.expected = expected;
  this.relation = relation;
  this.message = "Dimension mismatch (" + (Array.isArray(actual) ? "[" + actual.join(", ") + "]" : actual) + " " + (this.relation || "!=") + " " + (Array.isArray(expected) ? "[" + expected.join(", ") + "]" : expected) + ")";
  this.stack = new Error().stack;
}
DimensionError.prototype = new RangeError();
DimensionError.prototype.constructor = RangeError;
DimensionError.prototype.name = "DimensionError";
DimensionError.prototype.isDimensionError = true;

// node_modules/mathjs/lib/esm/utils/array.js
function arraySize(x) {
  var s = [];
  while (Array.isArray(x)) {
    s.push(x.length);
    x = x[0];
  }
  return s;
}
function validateIndex(index2, length) {
  if (index2 !== void 0) {
    if (!isNumber(index2) || !isInteger2(index2)) {
      throw new TypeError("Index must be an integer (value: " + index2 + ")");
    }
    if (index2 < 0 || typeof length === "number" && index2 >= length) {
      throw new IndexError(index2, length);
    }
  }
}
function reshape(array, sizes) {
  var flatArray = flatten(array, true);
  var currentLength = flatArray.length;
  if (!Array.isArray(array) || !Array.isArray(sizes)) {
    throw new TypeError("Array expected");
  }
  if (sizes.length === 0) {
    throw new DimensionError(0, currentLength, "!=");
  }
  sizes = processSizesWildcard(sizes, currentLength);
  var newLength = product2(sizes);
  if (currentLength !== newLength) {
    throw new DimensionError(newLength, currentLength, "!=");
  }
  try {
    return _reshape(flatArray, sizes);
  } catch (e3) {
    if (e3 instanceof DimensionError) {
      throw new DimensionError(newLength, currentLength, "!=");
    }
    throw e3;
  }
}
function processSizesWildcard(sizes, currentLength) {
  var newLength = product2(sizes);
  var processedSizes = sizes.slice();
  var WILDCARD = -1;
  var wildCardIndex = sizes.indexOf(WILDCARD);
  var isMoreThanOneWildcard = sizes.indexOf(WILDCARD, wildCardIndex + 1) >= 0;
  if (isMoreThanOneWildcard) {
    throw new Error("More than one wildcard in sizes");
  }
  var hasWildcard = wildCardIndex >= 0;
  var canReplaceWildcard = currentLength % newLength === 0;
  if (hasWildcard) {
    if (canReplaceWildcard) {
      processedSizes[wildCardIndex] = -currentLength / newLength;
    } else {
      throw new Error("Could not replace wildcard, since " + currentLength + " is no multiple of " + -newLength);
    }
  }
  return processedSizes;
}
function product2(array) {
  return array.reduce((prev, curr) => prev * curr, 1);
}
function _reshape(array, sizes) {
  var tmpArray = array;
  var tmpArray2;
  for (var sizeIndex = sizes.length - 1; sizeIndex > 0; sizeIndex--) {
    var size2 = sizes[sizeIndex];
    tmpArray2 = [];
    var length = tmpArray.length / size2;
    for (var i = 0; i < length; i++) {
      tmpArray2.push(tmpArray.slice(i * size2, (i + 1) * size2));
    }
    tmpArray = tmpArray2;
  }
  return tmpArray;
}
function flatten(array) {
  var isRectangular = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
  if (!Array.isArray(array)) {
    return array;
  }
  if (typeof isRectangular !== "boolean") {
    throw new TypeError("Boolean expected for second argument of flatten");
  }
  var flat = [];
  if (isRectangular) {
    _flattenRectangular(array);
  } else {
    _flatten(array);
  }
  return flat;
  function _flatten(array2) {
    for (var i = 0; i < array2.length; i++) {
      var item = array2[i];
      if (Array.isArray(item)) {
        _flatten(item);
      } else {
        flat.push(item);
      }
    }
  }
  function _flattenRectangular(array2) {
    if (Array.isArray(array2[0])) {
      for (var i = 0; i < array2.length; i++) {
        _flattenRectangular(array2[i]);
      }
    } else {
      for (var _i = 0; _i < array2.length; _i++) {
        flat.push(array2[_i]);
      }
    }
  }
}
function map(array, callback) {
  return Array.prototype.map.call(array, callback);
}
function forEach(array, callback) {
  Array.prototype.forEach.call(array, callback);
}
function filter(array, callback) {
  if (arraySize(array).length !== 1) {
    throw new Error("Only one dimensional matrices supported");
  }
  return Array.prototype.filter.call(array, callback);
}
function filterRegExp(array, regexp) {
  if (arraySize(array).length !== 1) {
    throw new Error("Only one dimensional matrices supported");
  }
  return Array.prototype.filter.call(array, (entry) => regexp.test(entry));
}
function join(array, separator) {
  return Array.prototype.join.call(array, separator);
}
function concatRecursive(a, b, concatDim, dim) {
  if (dim < concatDim) {
    if (a.length !== b.length) {
      throw new DimensionError(a.length, b.length);
    }
    var c = [];
    for (var i = 0; i < a.length; i++) {
      c[i] = concatRecursive(a[i], b[i], concatDim, dim + 1);
    }
    return c;
  } else {
    return a.concat(b);
  }
}
function concat() {
  var arrays = Array.prototype.slice.call(arguments, 0, -1);
  var concatDim = Array.prototype.slice.call(arguments, -1);
  if (arrays.length === 1) {
    return arrays[0];
  }
  if (arrays.length > 1) {
    return arrays.slice(1).reduce(function(A, B) {
      return concatRecursive(A, B, concatDim, 0);
    }, arrays[0]);
  } else {
    throw new Error("Wrong number of arguments in function concat");
  }
}
function broadcastSizes() {
  for (var _len = arguments.length, sizes = new Array(_len), _key = 0; _key < _len; _key++) {
    sizes[_key] = arguments[_key];
  }
  var dimensions = sizes.map((s) => s.length);
  var N = Math.max(...dimensions);
  var sizeMax = new Array(N).fill(null);
  for (var i = 0; i < sizes.length; i++) {
    var size2 = sizes[i];
    var dim = dimensions[i];
    for (var j = 0; j < dim; j++) {
      var n = N - dim + j;
      if (size2[j] > sizeMax[n]) {
        sizeMax[n] = size2[j];
      }
    }
  }
  for (var _i2 = 0; _i2 < sizes.length; _i2++) {
    checkBroadcastingRules(sizes[_i2], sizeMax);
  }
  return sizeMax;
}
function checkBroadcastingRules(size2, toSize) {
  var N = toSize.length;
  var dim = size2.length;
  for (var j = 0; j < dim; j++) {
    var n = N - dim + j;
    if (size2[j] < toSize[n] && size2[j] > 1 || size2[j] > toSize[n]) {
      throw new Error("shape mismatch: mismatch is found in arg with shape (".concat(size2, ") not possible to broadcast dimension ").concat(dim, " with size ").concat(size2[j], " to size ").concat(toSize[n]));
    }
  }
}
function broadcastTo(array, toSize) {
  var Asize = arraySize(array);
  if (deepStrictEqual(Asize, toSize)) {
    return array;
  }
  checkBroadcastingRules(Asize, toSize);
  var broadcastedSize = broadcastSizes(Asize, toSize);
  var N = broadcastedSize.length;
  var paddedSize = [...Array(N - Asize.length).fill(1), ...Asize];
  var A = clone3(array);
  if (Asize.length < N) {
    A = reshape(A, paddedSize);
    Asize = arraySize(A);
  }
  for (var dim = 0; dim < N; dim++) {
    if (Asize[dim] < broadcastedSize[dim]) {
      A = stretch(A, broadcastedSize[dim], dim);
      Asize = arraySize(A);
    }
  }
  return A;
}
function stretch(arrayToStretch, sizeToStretch, dimToStretch) {
  return concat(...Array(sizeToStretch).fill(arrayToStretch), dimToStretch);
}
function get(array, index2) {
  if (!Array.isArray(array)) {
    throw new Error("Array expected");
  }
  if (!Array.isArray(index2)) {
    throw new Error("Array expected for index");
  }
  var size2 = arraySize(array);
  if (index2.length !== size2.length) {
    throw new DimensionError(index2.length, size2.length);
  }
  for (var x = 0; x < index2.length; x++) {
    validateIndex(index2[x], size2[x]);
  }
  return index2.reduce((acc, curr) => acc[curr], array);
}
function deepMap(array, callback) {
  var skipIndex = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
  if (array.length === 0) {
    return [];
  }
  if (skipIndex) {
    return recursiveMap(array);
  }
  var index2 = [];
  return recursiveMapWithIndex(array, 0);
  function recursiveMapWithIndex(value, depth) {
    if (Array.isArray(value)) {
      var N = value.length;
      var result = Array(N);
      for (var i = 0; i < N; i++) {
        index2[depth] = i;
        result[i] = recursiveMapWithIndex(value[i], depth + 1);
      }
      return result;
    } else {
      return callback(value, index2.slice(0, depth), array);
    }
  }
  function recursiveMap(value) {
    if (Array.isArray(value)) {
      var N = value.length;
      var result = Array(N);
      for (var i = 0; i < N; i++) {
        result[i] = recursiveMap(value[i]);
      }
      return result;
    } else {
      return callback(value);
    }
  }
}
function deepForEach(array, callback) {
  var skipIndex = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
  if (array.length === 0) {
    return;
  }
  if (skipIndex) {
    recursiveForEach(array);
    return;
  }
  var index2 = [];
  recursiveForEachWithIndex(array, 0);
  function recursiveForEachWithIndex(value, depth) {
    if (Array.isArray(value)) {
      var N = value.length;
      for (var i = 0; i < N; i++) {
        index2[depth] = i;
        recursiveForEachWithIndex(value[i], depth + 1);
      }
    } else {
      callback(value, index2.slice(0, depth), array);
    }
  }
  function recursiveForEach(value) {
    if (Array.isArray(value)) {
      var N = value.length;
      for (var i = 0; i < N; i++) {
        recursiveForEach(value[i]);
      }
    } else {
      callback(value);
    }
  }
}
function clone3(array) {
  return (0, import_extends2.default)([], array);
}

// node_modules/mathjs/lib/esm/utils/switch.js
function _switch(mat) {
  var I = mat.length;
  var J = mat[0].length;
  var i, j;
  var ret = [];
  for (j = 0; j < J; j++) {
    var tmp = [];
    for (i = 0; i < I; i++) {
      tmp.push(mat[i][j]);
    }
    ret.push(tmp);
  }
  return ret;
}

// node_modules/mathjs/lib/esm/utils/collection.js
function containsCollections(array) {
  for (var i = 0; i < array.length; i++) {
    if (isCollection(array[i])) {
      return true;
    }
  }
  return false;
}
function deepForEach2(array, callback) {
  if (isMatrix(array)) {
    array.forEach((x) => callback(x), false, true);
  } else {
    deepForEach(array, callback, true);
  }
}
function deepMap2(array, callback, skipZeros) {
  if (!skipZeros) {
    if (isMatrix(array)) {
      return array.map((x) => callback(x), false, true);
    } else {
      return deepMap(array, callback, true);
    }
  }
  var skipZerosCallback = (x) => x === 0 ? x : callback(x);
  if (isMatrix(array)) {
    return array.map((x) => skipZerosCallback(x), false, true);
  } else {
    return deepMap(array, skipZerosCallback, true);
  }
}
function reduce(mat, dim, callback) {
  var size2 = Array.isArray(mat) ? arraySize(mat) : mat.size();
  if (dim < 0 || dim >= size2.length) {
    throw new IndexError(dim, size2.length);
  }
  if (isMatrix(mat)) {
    return mat.create(_reduce(mat.valueOf(), dim, callback), mat.datatype());
  } else {
    return _reduce(mat, dim, callback);
  }
}
function _reduce(mat, dim, callback) {
  var i, ret, val, tran;
  if (dim <= 0) {
    if (!Array.isArray(mat[0])) {
      val = mat[0];
      for (i = 1; i < mat.length; i++) {
        val = callback(val, mat[i]);
      }
      return val;
    } else {
      tran = _switch(mat);
      ret = [];
      for (i = 0; i < tran.length; i++) {
        ret[i] = _reduce(tran[i], dim - 1, callback);
      }
      return ret;
    }
  } else {
    ret = [];
    for (i = 0; i < mat.length; i++) {
      ret[i] = _reduce(mat[i], dim - 1, callback);
    }
    return ret;
  }
}

// node_modules/mathjs/lib/esm/function/arithmetic/ceil.js
var name14 = "ceil";
var bigTen = new decimal_default(10);
var createCeilNumber = /* @__PURE__ */ factory(name14, ["typed", "config", "round"], (_ref) => {
  var {
    typed: typed3,
    config: config4,
    round: round3
  } = _ref;
  function _ceilNumber(x) {
    var c = Math.ceil(x);
    var r = round3(x);
    if (c === r) return c;
    if (nearlyEqual(x, r, config4.relTol, config4.absTol) && !nearlyEqual(x, c, config4.relTol, config4.absTol)) {
      return r;
    }
    return c;
  }
  return typed3(name14, {
    number: _ceilNumber,
    "number, number": function number_number(x, n) {
      if (!isInteger2(n)) {
        throw new RangeError("number of decimals in function ceil must be an integer");
      }
      if (n < 0 || n > 15) {
        throw new RangeError("number of decimals in ceil number must be in range 0-15");
      }
      var shift = 10 ** n;
      return _ceilNumber(x * shift) / shift;
    }
  });
});

// node_modules/mathjs/lib/esm/function/arithmetic/fix.js
var name15 = "fix";
var createFixNumber = /* @__PURE__ */ factory(name15, ["typed", "ceil", "floor"], (_ref) => {
  var {
    typed: typed3,
    ceil: ceil3,
    floor: floor3
  } = _ref;
  return typed3(name15, {
    number: function number2(x) {
      return x > 0 ? floor3(x) : ceil3(x);
    },
    "number, number": function number_number(x, n) {
      return x > 0 ? floor3(x, n) : ceil3(x, n);
    }
  });
});

// node_modules/mathjs/lib/esm/function/arithmetic/floor.js
var name16 = "floor";
var bigTen2 = new decimal_default(10);
var createFloorNumber = /* @__PURE__ */ factory(name16, ["typed", "config", "round"], (_ref) => {
  var {
    typed: typed3,
    config: config4,
    round: round3
  } = _ref;
  function _floorNumber(x) {
    var f = Math.floor(x);
    var r = round3(x);
    if (f === r) return f;
    if (nearlyEqual(x, r, config4.relTol, config4.absTol) && !nearlyEqual(x, f, config4.relTol, config4.absTol)) {
      return r;
    }
    return f;
  }
  return typed3(name16, {
    number: _floorNumber,
    "number, number": function number_number(x, n) {
      if (!isInteger2(n)) {
        throw new RangeError("number of decimals in function floor must be an integer");
      }
      if (n < 0 || n > 15) {
        throw new RangeError("number of decimals in floor number must be in range 0 - 15");
      }
      var shift = 10 ** n;
      return _floorNumber(x * shift) / shift;
    }
  });
});

// node_modules/mathjs/lib/esm/function/arithmetic/hypot.js
var name17 = "hypot";
var dependencies15 = ["typed", "abs", "addScalar", "divideScalar", "multiplyScalar", "sqrt", "smaller", "isPositive"];
var createHypot = /* @__PURE__ */ factory(name17, dependencies15, (_ref) => {
  var {
    typed: typed3,
    abs: abs3,
    addScalar: addScalar2,
    divideScalar: divideScalar2,
    multiplyScalar: multiplyScalar2,
    sqrt: sqrt3,
    smaller: smaller2,
    isPositive: isPositive2
  } = _ref;
  return typed3(name17, {
    "... number | BigNumber": _hypot,
    Array: _hypot,
    Matrix: (M) => _hypot(flatten(M.toArray(), true))
  });
  function _hypot(args) {
    var result = 0;
    var largest = 0;
    for (var i = 0; i < args.length; i++) {
      if (isComplex(args[i])) {
        throw new TypeError("Unexpected type of argument to hypot");
      }
      var value = abs3(args[i]);
      if (smaller2(largest, value)) {
        result = multiplyScalar2(result, multiplyScalar2(divideScalar2(largest, value), divideScalar2(largest, value)));
        result = addScalar2(result, 1);
        largest = value;
      } else {
        result = addScalar2(result, isPositive2(value) ? multiplyScalar2(divideScalar2(value, largest), divideScalar2(value, largest)) : value);
      }
    }
    return multiplyScalar2(largest, sqrt3(result));
  }
});

// node_modules/mathjs/lib/esm/function/combinatorics/stirlingS2.js
var name18 = "stirlingS2";
var dependencies16 = ["typed", "addScalar", "subtractScalar", "multiplyScalar", "divideScalar", "pow", "factorial", "combinations", "isNegative", "isInteger", "number", "?bignumber", "larger"];
var createStirlingS2 = /* @__PURE__ */ factory(name18, dependencies16, (_ref) => {
  var {
    typed: typed3,
    addScalar: addScalar2,
    subtractScalar: subtractScalar2,
    multiplyScalar: multiplyScalar2,
    divideScalar: divideScalar2,
    pow: pow3,
    factorial: factorial2,
    combinations: combinations2,
    isNegative: isNegative2,
    isInteger: isInteger4,
    number: number2,
    bignumber,
    larger: larger2
  } = _ref;
  var smallCache = [];
  var bigCache = [];
  return typed3(name18, {
    "number | BigNumber, number | BigNumber": function number__BigNumber_number__BigNumber(n, k) {
      if (!isInteger4(n) || isNegative2(n) || !isInteger4(k) || isNegative2(k)) {
        throw new TypeError("Non-negative integer value expected in function stirlingS2");
      } else if (larger2(k, n)) {
        throw new TypeError("k must be less than or equal to n in function stirlingS2");
      }
      var big = !(isNumber(n) && isNumber(k));
      var cache = big ? bigCache : smallCache;
      var make = big ? bignumber : number2;
      var nn = number2(n);
      var nk = number2(k);
      if (cache[nn] && cache[nn].length > nk) {
        return cache[nn][nk];
      }
      for (var m = 0; m <= nn; ++m) {
        if (!cache[m]) {
          cache[m] = [m === 0 ? make(1) : make(0)];
        }
        if (m === 0) continue;
        var row = cache[m];
        var prev = cache[m - 1];
        for (var i = row.length; i <= m && i <= nk; ++i) {
          if (i === m) {
            row[i] = 1;
          } else {
            row[i] = addScalar2(multiplyScalar2(make(i), prev[i]), prev[i - 1]);
          }
        }
      }
      return cache[nn][nk];
    }
  });
});

// node_modules/mathjs/lib/esm/function/combinatorics/bellNumbers.js
var name19 = "bellNumbers";
var dependencies17 = ["typed", "addScalar", "isNegative", "isInteger", "stirlingS2"];
var createBellNumbers = /* @__PURE__ */ factory(name19, dependencies17, (_ref) => {
  var {
    typed: typed3,
    addScalar: addScalar2,
    isNegative: isNegative2,
    isInteger: isInteger4,
    stirlingS2: stirlingS22
  } = _ref;
  return typed3(name19, {
    "number | BigNumber": function number__BigNumber(n) {
      if (!isInteger4(n) || isNegative2(n)) {
        throw new TypeError("Non-negative integer value expected in function bellNumbers");
      }
      var result = 0;
      for (var i = 0; i <= n; i++) {
        result = addScalar2(result, stirlingS22(n, i));
      }
      return result;
    }
  });
});

// node_modules/mathjs/lib/esm/function/combinatorics/catalan.js
var name20 = "catalan";
var dependencies18 = ["typed", "addScalar", "divideScalar", "multiplyScalar", "combinations", "isNegative", "isInteger"];
var createCatalan = /* @__PURE__ */ factory(name20, dependencies18, (_ref) => {
  var {
    typed: typed3,
    addScalar: addScalar2,
    divideScalar: divideScalar2,
    multiplyScalar: multiplyScalar2,
    combinations: combinations2,
    isNegative: isNegative2,
    isInteger: isInteger4
  } = _ref;
  return typed3(name20, {
    "number | BigNumber": function number__BigNumber(n) {
      if (!isInteger4(n) || isNegative2(n)) {
        throw new TypeError("Non-negative integer value expected in function catalan");
      }
      return divideScalar2(combinations2(multiplyScalar2(n, 2), n), addScalar2(n, 1));
    }
  });
});

// node_modules/mathjs/lib/esm/function/combinatorics/composition.js
var name21 = "composition";
var dependencies19 = ["typed", "addScalar", "combinations", "isNegative", "isPositive", "isInteger", "larger"];
var createComposition = /* @__PURE__ */ factory(name21, dependencies19, (_ref) => {
  var {
    typed: typed3,
    addScalar: addScalar2,
    combinations: combinations2,
    isPositive: isPositive2,
    isNegative: isNegative2,
    isInteger: isInteger4,
    larger: larger2
  } = _ref;
  return typed3(name21, {
    "number | BigNumber, number | BigNumber": function number__BigNumber_number__BigNumber(n, k) {
      if (!isInteger4(n) || !isPositive2(n) || !isInteger4(k) || !isPositive2(k)) {
        throw new TypeError("Positive integer value expected in function composition");
      } else if (larger2(k, n)) {
        throw new TypeError("k must be less than or equal to n in function composition");
      }
      return combinations2(addScalar2(n, -1), addScalar2(k, -1));
    }
  });
});

// node_modules/mathjs/lib/esm/version.js
var version = "15.2.0";

// node_modules/mathjs/lib/esm/utils/lruQueue.js
function lruQueue(limit) {
  var size2 = 0;
  var base = 1;
  var queue = /* @__PURE__ */ Object.create(null);
  var map3 = /* @__PURE__ */ Object.create(null);
  var index2 = 0;
  var del = function del2(id) {
    var oldIndex = map3[id];
    if (!oldIndex) return;
    delete queue[oldIndex];
    delete map3[id];
    --size2;
    if (base !== oldIndex) return;
    if (!size2) {
      index2 = 0;
      base = 1;
      return;
    }
    while (!Object.prototype.hasOwnProperty.call(queue, ++base)) {
    }
  };
  limit = Math.abs(limit);
  return {
    hit: function hit(id) {
      var oldIndex = map3[id];
      var nuIndex = ++index2;
      queue[nuIndex] = id;
      map3[id] = nuIndex;
      if (!oldIndex) {
        ++size2;
        if (size2 <= limit) return void 0;
        id = queue[base];
        del(id);
        return id;
      }
      delete queue[oldIndex];
      if (base !== oldIndex) return void 0;
      while (!Object.prototype.hasOwnProperty.call(queue, ++base)) {
      }
      return void 0;
    },
    delete: del,
    clear: function clear() {
      size2 = index2 = 0;
      base = 1;
      queue = /* @__PURE__ */ Object.create(null);
      map3 = /* @__PURE__ */ Object.create(null);
    }
  };
}

// node_modules/mathjs/lib/esm/utils/function.js
function memoize(fn) {
  var {
    hasher: hasher2,
    limit
  } = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  limit = limit == null ? Number.POSITIVE_INFINITY : limit;
  hasher2 = hasher2 == null ? JSON.stringify : hasher2;
  return function memoize2() {
    if (typeof memoize2.cache !== "object") {
      memoize2.cache = {
        values: /* @__PURE__ */ new Map(),
        lru: lruQueue(limit || Number.POSITIVE_INFINITY)
      };
    }
    var args = [];
    for (var i = 0; i < arguments.length; i++) {
      args[i] = arguments[i];
    }
    var hash = hasher2(args);
    if (memoize2.cache.values.has(hash)) {
      memoize2.cache.lru.hit(hash);
      return memoize2.cache.values.get(hash);
    }
    var newVal = fn.apply(fn, args);
    memoize2.cache.values.set(hash, newVal);
    memoize2.cache.values.delete(memoize2.cache.lru.hit(hash));
    return newVal;
  };
}

// node_modules/mathjs/lib/esm/utils/bignumber/constants.js
var createBigNumberE = memoize(function(BigNumber) {
  return new BigNumber(1).exp();
}, {
  hasher
});
var createBigNumberPhi = memoize(function(BigNumber) {
  return new BigNumber(1).plus(new BigNumber(5).sqrt()).div(2);
}, {
  hasher
});
var createBigNumberPi = memoize(function(BigNumber) {
  return BigNumber.acos(-1);
}, {
  hasher
});
var createBigNumberTau = memoize(function(BigNumber) {
  return createBigNumberPi(BigNumber).times(2);
}, {
  hasher
});
function hasher(args) {
  return args[0].precision;
}

// node_modules/mathjs/lib/esm/constants.js
var createTrue = /* @__PURE__ */ factory("true", [], () => true);
var createFalse = /* @__PURE__ */ factory("false", [], () => false);
var createNull = /* @__PURE__ */ factory("null", [], () => null);
var createInfinity = /* @__PURE__ */ recreateFactory("Infinity", ["config", "?BigNumber"], (_ref) => {
  var {
    config: config4,
    BigNumber
  } = _ref;
  return config4.number === "BigNumber" ? new BigNumber(Infinity) : Infinity;
});
var createNaN = /* @__PURE__ */ recreateFactory("NaN", ["config", "?BigNumber"], (_ref2) => {
  var {
    config: config4,
    BigNumber
  } = _ref2;
  return config4.number === "BigNumber" ? new BigNumber(NaN) : NaN;
});
var createPi = /* @__PURE__ */ recreateFactory("pi", ["config", "?BigNumber"], (_ref3) => {
  var {
    config: config4,
    BigNumber
  } = _ref3;
  return config4.number === "BigNumber" ? createBigNumberPi(BigNumber) : pi;
});
var createTau = /* @__PURE__ */ recreateFactory("tau", ["config", "?BigNumber"], (_ref4) => {
  var {
    config: config4,
    BigNumber
  } = _ref4;
  return config4.number === "BigNumber" ? createBigNumberTau(BigNumber) : tau;
});
var createE = /* @__PURE__ */ recreateFactory("e", ["config", "?BigNumber"], (_ref5) => {
  var {
    config: config4,
    BigNumber
  } = _ref5;
  return config4.number === "BigNumber" ? createBigNumberE(BigNumber) : e;
});
var createPhi = /* @__PURE__ */ recreateFactory("phi", ["config", "?BigNumber"], (_ref6) => {
  var {
    config: config4,
    BigNumber
  } = _ref6;
  return config4.number === "BigNumber" ? createBigNumberPhi(BigNumber) : phi;
});
var createLN2 = /* @__PURE__ */ recreateFactory("LN2", ["config", "?BigNumber"], (_ref7) => {
  var {
    config: config4,
    BigNumber
  } = _ref7;
  return config4.number === "BigNumber" ? new BigNumber(2).ln() : Math.LN2;
});
var createLN10 = /* @__PURE__ */ recreateFactory("LN10", ["config", "?BigNumber"], (_ref8) => {
  var {
    config: config4,
    BigNumber
  } = _ref8;
  return config4.number === "BigNumber" ? new BigNumber(10).ln() : Math.LN10;
});
var createLOG2E = /* @__PURE__ */ recreateFactory("LOG2E", ["config", "?BigNumber"], (_ref9) => {
  var {
    config: config4,
    BigNumber
  } = _ref9;
  return config4.number === "BigNumber" ? new BigNumber(1).div(new BigNumber(2).ln()) : Math.LOG2E;
});
var createLOG10E = /* @__PURE__ */ recreateFactory("LOG10E", ["config", "?BigNumber"], (_ref0) => {
  var {
    config: config4,
    BigNumber
  } = _ref0;
  return config4.number === "BigNumber" ? new BigNumber(1).div(new BigNumber(10).ln()) : Math.LOG10E;
});
var createSQRT1_2 = /* @__PURE__ */ recreateFactory(
  // eslint-disable-line camelcase
  "SQRT1_2",
  ["config", "?BigNumber"],
  (_ref1) => {
    var {
      config: config4,
      BigNumber
    } = _ref1;
    return config4.number === "BigNumber" ? new BigNumber("0.5").sqrt() : Math.SQRT1_2;
  }
);
var createSQRT2 = /* @__PURE__ */ recreateFactory("SQRT2", ["config", "?BigNumber"], (_ref10) => {
  var {
    config: config4,
    BigNumber
  } = _ref10;
  return config4.number === "BigNumber" ? new BigNumber(2).sqrt() : Math.SQRT2;
});
var createVersion = /* @__PURE__ */ factory("version", [], () => version);
function recreateFactory(name114, dependencies102, create) {
  return factory(name114, dependencies102, create, {
    recreateOnConfigChange: true
  });
}

// node_modules/mathjs/lib/esm/type/number.js
var name22 = "number";
var dependencies20 = ["typed"];
function getNonDecimalNumberParts(input) {
  var nonDecimalWithRadixMatch = input.match(/(0[box])([0-9a-fA-F]*)\.([0-9a-fA-F]*)/);
  if (nonDecimalWithRadixMatch) {
    var radix = {
      "0b": 2,
      "0o": 8,
      "0x": 16
    }[nonDecimalWithRadixMatch[1]];
    var integerPart = nonDecimalWithRadixMatch[2];
    var fractionalPart = nonDecimalWithRadixMatch[3];
    return {
      input,
      radix,
      integerPart,
      fractionalPart
    };
  } else {
    return null;
  }
}
function makeNumberFromNonDecimalParts(parts) {
  var n = parseInt(parts.integerPart, parts.radix);
  var f = 0;
  for (var i = 0; i < parts.fractionalPart.length; i++) {
    var digitValue = parseInt(parts.fractionalPart[i], parts.radix);
    f += digitValue / Math.pow(parts.radix, i + 1);
  }
  var result = n + f;
  if (isNaN(result)) {
    throw new SyntaxError('String "' + parts.input + '" is not a valid number');
  }
  return result;
}
var createNumber = /* @__PURE__ */ factory(name22, dependencies20, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  var number2 = typed3("number", {
    "": function _() {
      return 0;
    },
    number: function number3(x) {
      return x;
    },
    string: function string2(x) {
      if (x === "NaN") return NaN;
      var nonDecimalNumberParts = getNonDecimalNumberParts(x);
      if (nonDecimalNumberParts) {
        return makeNumberFromNonDecimalParts(nonDecimalNumberParts);
      }
      var size2 = 0;
      var wordSizeSuffixMatch = x.match(/(0[box][0-9a-fA-F]*)i([0-9]*)/);
      if (wordSizeSuffixMatch) {
        size2 = Number(wordSizeSuffixMatch[2]);
        x = wordSizeSuffixMatch[1];
      }
      var num = Number(x);
      if (isNaN(num)) {
        throw new SyntaxError('String "' + x + '" is not a valid number');
      }
      if (wordSizeSuffixMatch) {
        if (num > 2 ** size2 - 1) {
          throw new SyntaxError('String "'.concat(x, '" is out of range'));
        }
        if (num >= 2 ** (size2 - 1)) {
          num = num - 2 ** size2;
        }
      }
      return num;
    },
    BigNumber: function BigNumber(x) {
      return x.toNumber();
    },
    bigint: function bigint2(x) {
      return Number(x);
    },
    Fraction: function Fraction(x) {
      return x.valueOf();
    },
    Unit: typed3.referToSelf((self2) => (x) => {
      var clone6 = x.clone();
      clone6.value = self2(x.value);
      return clone6;
    }),
    null: function _null2(x) {
      return 0;
    },
    "Unit, string | Unit": function Unit_string__Unit(unit, valuelessUnit) {
      return unit.toNumber(valuelessUnit);
    },
    "Array | Matrix": typed3.referToSelf((self2) => (x) => deepMap2(x, self2))
  });
  number2.fromJSON = function(json) {
    return parseFloat(json.value);
  };
  return number2;
});

// node_modules/mathjs/lib/esm/type/bigint.js
var name23 = "bigint";
var dependencies21 = ["typed"];
var createBigint = /* @__PURE__ */ factory(name23, dependencies21, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  var bigint2 = typed3("bigint", {
    "": function _() {
      return 0n;
    },
    bigint: function bigint3(x) {
      return x;
    },
    number: function number2(x) {
      return BigInt(x.toFixed());
    },
    BigNumber: function BigNumber(x) {
      return BigInt(x.round().toString());
    },
    Fraction: function Fraction(x) {
      return BigInt(x.valueOf().toFixed());
    },
    "string | boolean": function string__boolean(x) {
      return BigInt(x);
    },
    null: function _null2(x) {
      return 0n;
    },
    "Array | Matrix": typed3.referToSelf((self2) => (x) => deepMap2(x, self2))
  });
  bigint2.fromJSON = function(json) {
    return BigInt(json.value);
  };
  return bigint2;
});

// node_modules/mathjs/lib/esm/type/string.js
var name24 = "string";
var dependencies22 = ["typed"];
var createString = /* @__PURE__ */ factory(name24, dependencies22, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name24, {
    "": function _() {
      return "";
    },
    number: format,
    null: function _null2(x) {
      return "null";
    },
    boolean: function boolean2(x) {
      return x + "";
    },
    string: function string2(x) {
      return x;
    },
    "Array | Matrix": typed3.referToSelf((self2) => (x) => deepMap2(x, self2)),
    any: function any(x) {
      return String(x);
    }
  });
});

// node_modules/mathjs/lib/esm/type/boolean.js
var name25 = "boolean";
var dependencies23 = ["typed"];
var createBoolean = /* @__PURE__ */ factory(name25, dependencies23, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name25, {
    "": function _() {
      return false;
    },
    boolean: function boolean2(x) {
      return x;
    },
    number: function number2(x) {
      return !!x;
    },
    null: function _null2(x) {
      return false;
    },
    BigNumber: function BigNumber(x) {
      return !x.isZero();
    },
    string: function string2(x) {
      var lcase = x.toLowerCase();
      if (lcase === "true") {
        return true;
      } else if (lcase === "false") {
        return false;
      }
      var num = Number(x);
      if (x !== "" && !isNaN(num)) {
        return !!num;
      }
      throw new Error('Cannot convert "' + x + '" to a boolean');
    },
    "Array | Matrix": typed3.referToSelf((self2) => (x) => deepMap2(x, self2))
  });
});

// node_modules/mathjs/lib/esm/expression/function/parser.js
var name26 = "parser";
var dependencies24 = ["typed", "Parser"];
var createParser = /* @__PURE__ */ factory(name26, dependencies24, (_ref) => {
  var {
    typed: typed3,
    Parser: Parser3
  } = _ref;
  return typed3(name26, {
    "": function _() {
      return new Parser3();
    }
  });
});

// node_modules/mathjs/lib/esm/expression/keywords.js
var keywords = /* @__PURE__ */ new Set(["end"]);

// node_modules/mathjs/lib/esm/expression/node/Node.js
var name27 = "Node";
var dependencies25 = ["mathWithTransform"];
var createNode = /* @__PURE__ */ factory(name27, dependencies25, (_ref) => {
  var {
    mathWithTransform: mathWithTransform2
  } = _ref;
  function _validateScope(scope) {
    for (var symbol of [...keywords]) {
      if (scope.has(symbol)) {
        throw new Error('Scope contains an illegal symbol, "' + symbol + '" is a reserved keyword');
      }
    }
  }
  class Node2 {
    get type() {
      return "Node";
    }
    get isNode() {
      return true;
    }
    /**
     * Evaluate the node
     * @param {Object} [scope]  Scope to read/write variables
     * @return {*}              Returns the result
     */
    evaluate(scope) {
      return this.compile().evaluate(scope);
    }
    /**
     * Compile the node into an optimized, evauatable JavaScript function
     * @return {{evaluate: function([Object])}} object
     *                Returns an object with a function 'evaluate',
     *                which can be invoked as expr.evaluate([scope: Object]),
     *                where scope is an optional object with
     *                variables.
     */
    compile() {
      var expr = this._compile(mathWithTransform2, {});
      var args = {};
      var context = null;
      function evaluate2(scope) {
        var s = createMap(scope);
        _validateScope(s);
        return expr(s, args, context);
      }
      return {
        evaluate: evaluate2
      };
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      throw new Error("Method _compile must be implemented by type " + this.type);
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      throw new Error("Cannot run forEach on a Node interface");
    }
    /**
     * Create a new Node whose children are the results of calling the
     * provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {OperatorNode} Returns a transformed copy of the node
     */
    map(callback) {
      throw new Error("Cannot run map on a Node interface");
    }
    /**
     * Validate whether an object is a Node, for use with map
     * @param {Node} node
     * @returns {Node} Returns the input if it's a node, else throws an Error
     * @protected
     */
    _ifNode(node) {
      if (!isNode(node)) {
        throw new TypeError("Callback function must return a Node");
      }
      return node;
    }
    /**
     * Recursively traverse all nodes in a node tree. Executes given callback for
     * this node and each of its child nodes.
     * @param {function(node: Node, path: string, parent: Node)} callback
     *          A callback called for every node in the node tree.
     */
    traverse(callback) {
      callback(this, null, null);
      function _traverse(node, callback2) {
        node.forEach(function(child, path, parent) {
          callback2(child, path, parent);
          _traverse(child, callback2);
        });
      }
      _traverse(this, callback);
    }
    /**
     * Recursively transform a node tree via a transform function.
     *
     * For example, to replace all nodes of type SymbolNode having name 'x' with
     * a ConstantNode with value 2:
     *
     *     const res = Node.transform(function (node, path, parent) {
     *       if (node && node.isSymbolNode) && (node.name === 'x')) {
     *         return new ConstantNode(2)
     *       }
     *       else {
     *         return node
     *       }
     *     })
     *
     * @param {function(node: Node, path: string, parent: Node) : Node} callback
     *          A mapping function accepting a node, and returning
     *          a replacement for the node or the original node. The "signature"
     *          of the callback must be:
     *          callback(node: Node, index: string, parent: Node) : Node
     * @return {Node} Returns the original node or its replacement
     */
    transform(callback) {
      function _transform(child, path, parent) {
        var replacement = callback(child, path, parent);
        if (replacement !== child) {
          return replacement;
        }
        return child.map(_transform);
      }
      return _transform(this, null, null);
    }
    /**
     * Find any node in the node tree matching given filter function. For
     * example, to find all nodes of type SymbolNode having name 'x':
     *
     *     const results = Node.filter(function (node) {
     *       return (node && node.isSymbolNode) && (node.name === 'x')
     *     })
     *
     * @param {function(node: Node, path: string, parent: Node) : Node} callback
     *            A test function returning true when a node matches, and false
     *            otherwise. Function signature:
     *            callback(node: Node, index: string, parent: Node) : boolean
     * @return {Node[]} nodes
     *            An array with nodes matching given filter criteria
     */
    filter(callback) {
      var nodes = [];
      this.traverse(function(node, path, parent) {
        if (callback(node, path, parent)) {
          nodes.push(node);
        }
      });
      return nodes;
    }
    /**
     * Create a shallow clone of this node
     * @return {Node}
     */
    clone() {
      throw new Error("Cannot clone a Node interface");
    }
    /**
     * Create a deep clone of this node
     * @return {Node}
     */
    cloneDeep() {
      return this.map(function(node) {
        return node.cloneDeep();
      });
    }
    /**
     * Deep compare this node with another node.
     * @param {Node} other
     * @return {boolean} Returns true when both nodes are of the same type and
     *                   contain the same values (as do their childs)
     */
    equals(other) {
      return other ? this.type === other.type && deepStrictEqual(this, other) : false;
    }
    /**
     * Get string representation. (wrapper function)
     *
     * This function can get an object of the following form:
     * {
     *    handler: //This can be a callback function of the form
     *             // "function callback(node, options)"or
     *             // a map that maps function names (used in FunctionNodes)
     *             // to callbacks
     *    parenthesis: "keep" //the parenthesis option (This is optional)
     * }
     *
     * @param {Object} [options]
     * @return {string}
     */
    toString(options) {
      var customString = this._getCustomString(options);
      if (typeof customString !== "undefined") {
        return customString;
      }
      return this._toString(options);
    }
    /**
     * Internal function to generate the string output.
     * This has to be implemented by every Node
     *
     * @throws {Error}
     */
    _toString() {
      throw new Error("_toString not implemented for " + this.type);
    }
    /**
     * Get a JSON representation of the node
     * Both .toJSON() and the static .fromJSON(json) should be implemented by all
     * implementations of Node
     * @returns {Object}
     */
    toJSON() {
      throw new Error("Cannot serialize object: toJSON not implemented by " + this.type);
    }
    /**
     * Get HTML representation. (wrapper function)
     *
     * This function can get an object of the following form:
     * {
     *    handler: //This can be a callback function of the form
     *             // "function callback(node, options)" or
     *             // a map that maps function names (used in FunctionNodes)
     *             // to callbacks
     *    parenthesis: "keep" //the parenthesis option (This is optional)
     * }
     *
     * @param {Object} [options]
     * @return {string}
     */
    toHTML(options) {
      var customString = this._getCustomString(options);
      if (typeof customString !== "undefined") {
        return customString;
      }
      return this._toHTML(options);
    }
    /**
     * Internal function to generate the HTML output.
     * This has to be implemented by every Node
     *
     * @throws {Error}
     */
    _toHTML() {
      throw new Error("_toHTML not implemented for " + this.type);
    }
    /**
     * Get LaTeX representation. (wrapper function)
     *
     * This function can get an object of the following form:
     * {
     *    handler: //This can be a callback function of the form
     *             // "function callback(node, options)"or
     *             // a map that maps function names (used in FunctionNodes)
     *             // to callbacks
     *    parenthesis: "keep" //the parenthesis option (This is optional)
     * }
     *
     * @param {Object} [options]
     * @return {string}
     */
    toTex(options) {
      var customString = this._getCustomString(options);
      if (typeof customString !== "undefined") {
        return customString;
      }
      return this._toTex(options);
    }
    /**
     * Internal function to generate the LaTeX output.
     * This has to be implemented by every Node
     *
     * @param {Object} [options]
     * @throws {Error}
     */
    _toTex(options) {
      throw new Error("_toTex not implemented for " + this.type);
    }
    /**
     * Helper used by `to...` functions.
     */
    _getCustomString(options) {
      if (options && typeof options === "object") {
        switch (typeof options.handler) {
          case "object":
          case "undefined":
            return;
          case "function":
            return options.handler(this, options);
          default:
            throw new TypeError("Object or function expected as callback");
        }
      }
    }
    /**
     * Get identifier.
     * @return {string}
     */
    getIdentifier() {
      return this.type;
    }
    /**
     * Get the content of the current Node.
     * @return {Node} node
     **/
    getContent() {
      return this;
    }
  }
  return Node2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/AccessorNode.js
var import_defineProperty2 = __toESM(require_defineProperty(), 1);

// node_modules/mathjs/lib/esm/expression/transform/utils/errorTransform.js
function errorTransform(err) {
  if (err && err.isIndexError) {
    return new IndexError(err.index + 1, err.min + 1, err.max !== void 0 ? err.max + 1 : void 0);
  }
  return err;
}

// node_modules/mathjs/lib/esm/expression/node/utils/access.js
function accessFactory(_ref) {
  var {
    subset: subset2
  } = _ref;
  return function access(object, index2) {
    try {
      if (Array.isArray(object)) {
        return subset2(object, index2);
      } else if (object && typeof object.subset === "function") {
        return object.subset(index2);
      } else if (typeof object === "string") {
        return subset2(object, index2);
      } else if (typeof object === "object") {
        if (!index2.isObjectProperty()) {
          throw new TypeError("Cannot apply a numeric index as object property");
        }
        return getSafeProperty(object, index2.getObjectProperty());
      } else {
        throw new TypeError("Cannot apply index: unsupported type of object");
      }
    } catch (err) {
      throw errorTransform(err);
    }
  };
}

// node_modules/mathjs/lib/esm/expression/node/AccessorNode.js
var name28 = "AccessorNode";
var dependencies26 = ["subset", "Node"];
var createAccessorNode = /* @__PURE__ */ factory(name28, dependencies26, (_ref) => {
  var {
    subset: subset2,
    Node: Node2
  } = _ref;
  var access = accessFactory({
    subset: subset2
  });
  function needParenthesis(node) {
    return !(isAccessorNode(node) || isArrayNode(node) || isConstantNode(node) || isFunctionNode(node) || isObjectNode(node) || isParenthesisNode(node) || isSymbolNode(node));
  }
  class AccessorNode2 extends Node2 {
    /**
     * @constructor AccessorNode
     * @extends {Node}
     * Access an object property or get a matrix subset
     *
     * @param {Node} object                 The object from which to retrieve
     *                                      a property or subset.
     * @param {IndexNode} index             IndexNode containing ranges
     * @param {boolean} [optionalChaining=false]
     *     Optional property, if the accessor was written as optional-chaining
     *     using `a?.b`, or `a?.["b"] with bracket notation.
     *     Forces evaluate to undefined if the given object is undefined or null.
     */
    constructor(object, index2) {
      var optionalChaining = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : false;
      super();
      if (!isNode(object)) {
        throw new TypeError('Node expected for parameter "object"');
      }
      if (!isIndexNode(index2)) {
        throw new TypeError('IndexNode expected for parameter "index"');
      }
      this.object = object;
      this.index = index2;
      this.optionalChaining = optionalChaining;
    }
    // readonly property name
    get name() {
      if (this.index) {
        return this.index.isObjectProperty() ? this.index.getObjectProperty() : "";
      } else {
        return this.object.name || "";
      }
    }
    get type() {
      return name28;
    }
    get isAccessorNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalObject = this.object._compile(math2, argNames);
      var evalIndex = this.index._compile(math2, argNames);
      var optionalChaining = this.optionalChaining;
      var prevOptionalChaining = isAccessorNode(this.object) && this.object.optionalChaining;
      if (this.index.isObjectProperty()) {
        var prop = this.index.getObjectProperty();
        return function evalAccessorNode(scope, args, context) {
          var ctx = context || {};
          var object = evalObject(scope, args, ctx);
          if (optionalChaining && object == null) {
            ctx.optionalShortCircuit = true;
            return void 0;
          }
          if (prevOptionalChaining && ctx !== null && ctx !== void 0 && ctx.optionalShortCircuit) {
            return void 0;
          }
          return getSafeProperty(object, prop);
        };
      } else {
        return function evalAccessorNode(scope, args, context) {
          var ctx = context || {};
          var object = evalObject(scope, args, ctx);
          if (optionalChaining && object == null) {
            ctx.optionalShortCircuit = true;
            return void 0;
          }
          if (prevOptionalChaining && ctx !== null && ctx !== void 0 && ctx.optionalShortCircuit) {
            return void 0;
          }
          var index2 = evalIndex(scope, args, object);
          return access(object, index2);
        };
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.object, "object", this);
      callback(this.index, "index", this);
    }
    /**
     * Create a new AccessorNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {AccessorNode} Returns a transformed copy of the node
     */
    map(callback) {
      return new AccessorNode2(this._ifNode(callback(this.object, "object", this)), this._ifNode(callback(this.index, "index", this)), this.optionalChaining);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {AccessorNode}
     */
    clone() {
      return new AccessorNode2(this.object, this.index, this.optionalChaining);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string}
     */
    _toString(options) {
      var object = this.object.toString(options);
      if (needParenthesis(this.object)) {
        object = "(" + object + ")";
      }
      var optionalChaining = this.optionalChaining ? this.index.dotNotation ? "?" : "?." : "";
      return object + optionalChaining + this.index.toString(options);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string}
     */
    _toHTML(options) {
      var object = this.object.toHTML(options);
      if (needParenthesis(this.object)) {
        object = '<span class="math-parenthesis math-round-parenthesis">(</span>' + object + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      return object + this.index.toHTML(options);
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string}
     */
    _toTex(options) {
      var object = this.object.toTex(options);
      if (needParenthesis(this.object)) {
        object = "\\left(' + object + '\\right)";
      }
      return object + this.index.toTex(options);
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name28,
        object: this.object,
        index: this.index,
        optionalChaining: this.optionalChaining
      };
    }
    /**
     * Instantiate an AccessorNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     `{"mathjs": "AccessorNode", object: ..., index: ...}`,
     *     where mathjs is optional
     * @returns {AccessorNode}
     */
    static fromJSON(json) {
      return new AccessorNode2(json.object, json.index, json.optionalChaining);
    }
  }
  (0, import_defineProperty2.default)(AccessorNode2, "name", name28);
  return AccessorNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/ArrayNode.js
var import_defineProperty3 = __toESM(require_defineProperty(), 1);
var name29 = "ArrayNode";
var dependencies27 = ["Node"];
var createArrayNode = /* @__PURE__ */ factory(name29, dependencies27, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  class ArrayNode2 extends Node2 {
    /**
     * @constructor ArrayNode
     * @extends {Node}
     * Holds an 1-dimensional array with items
     * @param {Node[]} [items]   1 dimensional array with items
     */
    constructor(items) {
      super();
      this.items = items || [];
      if (!Array.isArray(this.items) || !this.items.every(isNode)) {
        throw new TypeError("Array containing Nodes expected");
      }
    }
    get type() {
      return name29;
    }
    get isArrayNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalItems = map(this.items, function(item) {
        return item._compile(math2, argNames);
      });
      var asMatrix = math2.config.matrix !== "Array";
      if (asMatrix) {
        var matrix2 = math2.matrix;
        return function evalArrayNode(scope, args, context) {
          return matrix2(map(evalItems, function(evalItem) {
            return evalItem(scope, args, context);
          }));
        };
      } else {
        return function evalArrayNode(scope, args, context) {
          return map(evalItems, function(evalItem) {
            return evalItem(scope, args, context);
          });
        };
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      for (var i = 0; i < this.items.length; i++) {
        var node = this.items[i];
        callback(node, "items[" + i + "]", this);
      }
    }
    /**
     * Create a new ArrayNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {ArrayNode} Returns a transformed copy of the node
     */
    map(callback) {
      var items = [];
      for (var i = 0; i < this.items.length; i++) {
        items[i] = this._ifNode(callback(this.items[i], "items[" + i + "]", this));
      }
      return new ArrayNode2(items);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {ArrayNode}
     */
    clone() {
      return new ArrayNode2(this.items.slice(0));
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toString(options) {
      var items = this.items.map(function(node) {
        return node.toString(options);
      });
      return "[" + items.join(", ") + "]";
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name29,
        items: this.items
      };
    }
    /**
     * Instantiate an ArrayNode from its JSON representation
     * @param {Object} json  An object structured like
     *                       `{"mathjs": "ArrayNode", items: [...]}`,
     *                       where mathjs is optional
     * @returns {ArrayNode}
     */
    static fromJSON(json) {
      return new ArrayNode2(json.items);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toHTML(options) {
      var items = this.items.map(function(node) {
        return node.toHTML(options);
      });
      return '<span class="math-parenthesis math-square-parenthesis">[</span>' + items.join('<span class="math-separator">,</span>') + '<span class="math-parenthesis math-square-parenthesis">]</span>';
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      function itemsToTex(items, nested) {
        var mixedItems = items.some(isArrayNode) && !items.every(isArrayNode);
        var itemsFormRow = nested || mixedItems;
        var itemSep = itemsFormRow ? "&" : "\\\\";
        var itemsTex = items.map(function(node) {
          if (node.items) {
            return itemsToTex(node.items, !nested);
          } else {
            return node.toTex(options);
          }
        }).join(itemSep);
        return mixedItems || !itemsFormRow || itemsFormRow && !nested ? "\\begin{bmatrix}" + itemsTex + "\\end{bmatrix}" : itemsTex;
      }
      return itemsToTex(this.items, false);
    }
  }
  (0, import_defineProperty3.default)(ArrayNode2, "name", name29);
  return ArrayNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/AssignmentNode.js
var import_defineProperty4 = __toESM(require_defineProperty(), 1);

// node_modules/mathjs/lib/esm/expression/node/utils/assign.js
function assignFactory(_ref) {
  var {
    subset: subset2,
    matrix: matrix2
  } = _ref;
  return function assign(object, index2, value) {
    try {
      if (Array.isArray(object)) {
        var result = matrix2(object).subset(index2, value).valueOf();
        result.forEach((item, index3) => {
          object[index3] = item;
        });
        return object;
      } else if (object && typeof object.subset === "function") {
        return object.subset(index2, value);
      } else if (typeof object === "string") {
        return subset2(object, index2, value);
      } else if (typeof object === "object") {
        if (!index2.isObjectProperty()) {
          throw TypeError("Cannot apply a numeric index as object property");
        }
        setSafeProperty(object, index2.getObjectProperty(), value);
        return object;
      } else {
        throw new TypeError("Cannot apply index: unsupported type of object");
      }
    } catch (err) {
      throw errorTransform(err);
    }
  };
}

// node_modules/mathjs/lib/esm/expression/node/AssignmentNode.js
var name30 = "AssignmentNode";
var dependencies28 = [
  "subset",
  "?matrix",
  // FIXME: should not be needed at all, should be handled by subset
  "Node"
];
var createAssignmentNode = /* @__PURE__ */ factory(name30, dependencies28, (_ref) => {
  var {
    subset: subset2,
    matrix: matrix2,
    Node: Node2
  } = _ref;
  var access = accessFactory({
    subset: subset2
  });
  var assign = assignFactory({
    subset: subset2,
    matrix: matrix2
  });
  function needParenthesis(node, parenthesis, implicit) {
    if (!parenthesis) {
      parenthesis = "keep";
    }
    var precedence = getPrecedence(node, parenthesis, implicit);
    var exprPrecedence = getPrecedence(node.value, parenthesis, implicit);
    return parenthesis === "all" || exprPrecedence !== null && exprPrecedence <= precedence;
  }
  class AssignmentNode2 extends Node2 {
    /**
     * @constructor AssignmentNode
     * @extends {Node}
     *
     * Define a symbol, like `a=3.2`, update a property like `a.b=3.2`, or
     * replace a subset of a matrix like `A[2,2]=42`.
     *
     * Syntax:
     *
     *     new AssignmentNode(symbol, value)
     *     new AssignmentNode(object, index, value)
     *
     * Usage:
     *
     *    new AssignmentNode(new SymbolNode('a'), new ConstantNode(2))  // a=2
     *    new AssignmentNode(new SymbolNode('a'),
     *                       new IndexNode('b'),
     *                       new ConstantNode(2))   // a.b=2
     *    new AssignmentNode(new SymbolNode('a'),
     *                       new IndexNode(1, 2),
     *                       new ConstantNode(3))  // a[1,2]=3
     *
     * @param {SymbolNode | AccessorNode} object
     *     Object on which to assign a value
     * @param {IndexNode} [index=null]
     *     Index, property name or matrix index. Optional. If not provided
     *     and `object` is a SymbolNode, the property is assigned to the
     *     global scope.
     * @param {Node} value
     *     The value to be assigned
     */
    constructor(object, index2, value) {
      super();
      this.object = object;
      this.index = value ? index2 : null;
      this.value = value || index2;
      if (!isSymbolNode(object) && !isAccessorNode(object)) {
        throw new TypeError('SymbolNode or AccessorNode expected as "object"');
      }
      if (isSymbolNode(object) && object.name === "end") {
        throw new Error('Cannot assign to symbol "end"');
      }
      if (this.index && !isIndexNode(this.index)) {
        throw new TypeError('IndexNode expected as "index"');
      }
      if (!isNode(this.value)) {
        throw new TypeError('Node expected as "value"');
      }
    }
    // class name for typing purposes:
    // readonly property name
    get name() {
      if (this.index) {
        return this.index.isObjectProperty() ? this.index.getObjectProperty() : "";
      } else {
        return this.object.name || "";
      }
    }
    get type() {
      return name30;
    }
    get isAssignmentNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalObject = this.object._compile(math2, argNames);
      var evalIndex = this.index ? this.index._compile(math2, argNames) : null;
      var evalValue = this.value._compile(math2, argNames);
      var name114 = this.object.name;
      if (!this.index) {
        if (!isSymbolNode(this.object)) {
          throw new TypeError("SymbolNode expected as object");
        }
        return function evalAssignmentNode(scope, args, context) {
          var value = evalValue(scope, args, context);
          scope.set(name114, value);
          return value;
        };
      } else if (this.index.isObjectProperty()) {
        var prop = this.index.getObjectProperty();
        return function evalAssignmentNode(scope, args, context) {
          var object = evalObject(scope, args, context);
          var value = evalValue(scope, args, context);
          setSafeProperty(object, prop, value);
          return value;
        };
      } else if (isSymbolNode(this.object)) {
        return function evalAssignmentNode(scope, args, context) {
          var childObject = evalObject(scope, args, context);
          var value = evalValue(scope, args, context);
          var index2 = evalIndex(scope, args, childObject);
          scope.set(name114, assign(childObject, index2, value));
          return value;
        };
      } else {
        var evalParentObject = this.object.object._compile(math2, argNames);
        if (this.object.index.isObjectProperty()) {
          var parentProp = this.object.index.getObjectProperty();
          return function evalAssignmentNode(scope, args, context) {
            var parent = evalParentObject(scope, args, context);
            var childObject = getSafeProperty(parent, parentProp);
            var index2 = evalIndex(scope, args, childObject);
            var value = evalValue(scope, args, context);
            setSafeProperty(parent, parentProp, assign(childObject, index2, value));
            return value;
          };
        } else {
          var evalParentIndex = this.object.index._compile(math2, argNames);
          return function evalAssignmentNode(scope, args, context) {
            var parent = evalParentObject(scope, args, context);
            var parentIndex = evalParentIndex(scope, args, parent);
            var childObject = access(parent, parentIndex);
            var index2 = evalIndex(scope, args, childObject);
            var value = evalValue(scope, args, context);
            assign(parent, parentIndex, assign(childObject, index2, value));
            return value;
          };
        }
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.object, "object", this);
      if (this.index) {
        callback(this.index, "index", this);
      }
      callback(this.value, "value", this);
    }
    /**
     * Create a new AssignmentNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {AssignmentNode} Returns a transformed copy of the node
     */
    map(callback) {
      var object = this._ifNode(callback(this.object, "object", this));
      var index2 = this.index ? this._ifNode(callback(this.index, "index", this)) : null;
      var value = this._ifNode(callback(this.value, "value", this));
      return new AssignmentNode2(object, index2, value);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {AssignmentNode}
     */
    clone() {
      return new AssignmentNode2(this.object, this.index, this.value);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string}
     */
    _toString(options) {
      var object = this.object.toString(options);
      var index2 = this.index ? this.index.toString(options) : "";
      var value = this.value.toString(options);
      if (needParenthesis(this, options && options.parenthesis, options && options.implicit)) {
        value = "(" + value + ")";
      }
      return object + index2 + " = " + value;
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name30,
        object: this.object,
        index: this.index,
        value: this.value
      };
    }
    /**
     * Instantiate an AssignmentNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     `{"mathjs": "AssignmentNode", object: ..., index: ..., value: ...}`,
     *     where mathjs is optional
     * @returns {AssignmentNode}
     */
    static fromJSON(json) {
      return new AssignmentNode2(json.object, json.index, json.value);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string}
     */
    _toHTML(options) {
      var object = this.object.toHTML(options);
      var index2 = this.index ? this.index.toHTML(options) : "";
      var value = this.value.toHTML(options);
      if (needParenthesis(this, options && options.parenthesis, options && options.implicit)) {
        value = '<span class="math-paranthesis math-round-parenthesis">(</span>' + value + '<span class="math-paranthesis math-round-parenthesis">)</span>';
      }
      return object + index2 + '<span class="math-operator math-assignment-operator math-variable-assignment-operator math-binary-operator">=</span>' + value;
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string}
     */
    _toTex(options) {
      var object = this.object.toTex(options);
      var index2 = this.index ? this.index.toTex(options) : "";
      var value = this.value.toTex(options);
      if (needParenthesis(this, options && options.parenthesis, options && options.implicit)) {
        value = "\\left(".concat(value, "\\right)");
      }
      return object + index2 + "=" + value;
    }
  }
  (0, import_defineProperty4.default)(AssignmentNode2, "name", name30);
  return AssignmentNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/BlockNode.js
var import_defineProperty5 = __toESM(require_defineProperty(), 1);
var name31 = "BlockNode";
var dependencies29 = ["ResultSet", "Node"];
var createBlockNode = /* @__PURE__ */ factory(name31, dependencies29, (_ref) => {
  var {
    ResultSet: ResultSet2,
    Node: Node2
  } = _ref;
  class BlockNode2 extends Node2 {
    /**
     * @constructor BlockNode
     * @extends {Node}
     * Holds a set with blocks
     * @param {Array.<{node: Node} | {node: Node, visible: boolean}>} blocks
     *            An array with blocks, where a block is constructed as an
     *            Object with properties block, which is a Node, and visible,
     *            which is a boolean. The property visible is optional and
     *            is true by default
     */
    constructor(blocks) {
      super();
      if (!Array.isArray(blocks)) throw new Error("Array expected");
      this.blocks = blocks.map(function(block) {
        var node = block && block.node;
        var visible = block && block.visible !== void 0 ? block.visible : true;
        if (!isNode(node)) throw new TypeError('Property "node" must be a Node');
        if (typeof visible !== "boolean") {
          throw new TypeError('Property "visible" must be a boolean');
        }
        return {
          node,
          visible
        };
      });
    }
    get type() {
      return name31;
    }
    get isBlockNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalBlocks = map(this.blocks, function(block) {
        return {
          evaluate: block.node._compile(math2, argNames),
          visible: block.visible
        };
      });
      return function evalBlockNodes(scope, args, context) {
        var results = [];
        forEach(evalBlocks, function evalBlockNode(block) {
          var result = block.evaluate(scope, args, context);
          if (block.visible) {
            results.push(result);
          }
        });
        return new ResultSet2(results);
      };
    }
    /**
     * Execute a callback for each of the child blocks of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      for (var i = 0; i < this.blocks.length; i++) {
        callback(this.blocks[i].node, "blocks[" + i + "].node", this);
      }
    }
    /**
     * Create a new BlockNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {BlockNode} Returns a transformed copy of the node
     */
    map(callback) {
      var blocks = [];
      for (var i = 0; i < this.blocks.length; i++) {
        var block = this.blocks[i];
        var node = this._ifNode(callback(block.node, "blocks[" + i + "].node", this));
        blocks[i] = {
          node,
          visible: block.visible
        };
      }
      return new BlockNode2(blocks);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {BlockNode}
     */
    clone() {
      var blocks = this.blocks.map(function(block) {
        return {
          node: block.node,
          visible: block.visible
        };
      });
      return new BlockNode2(blocks);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toString(options) {
      return this.blocks.map(function(param) {
        return param.node.toString(options) + (param.visible ? "" : ";");
      }).join("\n");
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name31,
        blocks: this.blocks
      };
    }
    /**
     * Instantiate an BlockNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     `{"mathjs": "BlockNode", blocks: [{node: ..., visible: false}, ...]}`,
     *     where mathjs is optional
     * @returns {BlockNode}
     */
    static fromJSON(json) {
      return new BlockNode2(json.blocks);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toHTML(options) {
      return this.blocks.map(function(param) {
        return param.node.toHTML(options) + (param.visible ? "" : '<span class="math-separator">;</span>');
      }).join('<span class="math-separator"><br /></span>');
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      return this.blocks.map(function(param) {
        return param.node.toTex(options) + (param.visible ? "" : ";");
      }).join("\\;\\;\n");
    }
  }
  (0, import_defineProperty5.default)(BlockNode2, "name", name31);
  return BlockNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/ConditionalNode.js
var import_defineProperty6 = __toESM(require_defineProperty(), 1);
var name32 = "ConditionalNode";
var dependencies30 = ["Node"];
var createConditionalNode = /* @__PURE__ */ factory(name32, dependencies30, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  function testCondition(condition) {
    if (typeof condition === "number" || typeof condition === "boolean" || typeof condition === "string") {
      return !!condition;
    }
    if (condition) {
      if (isBigNumber(condition)) {
        return !condition.isZero();
      }
      if (isComplex(condition)) {
        return !!(condition.re || condition.im);
      }
      if (isUnit(condition)) {
        return !!condition.value;
      }
    }
    if (condition === null || condition === void 0) {
      return false;
    }
    throw new TypeError('Unsupported type of condition "' + typeOf(condition) + '"');
  }
  class ConditionalNode2 extends Node2 {
    /**
     * A lazy evaluating conditional operator: 'condition ? trueExpr : falseExpr'
     *
     * @param {Node} condition   Condition, must result in a boolean
     * @param {Node} trueExpr    Expression evaluated when condition is true
     * @param {Node} falseExpr   Expression evaluated when condition is true
     *
     * @constructor ConditionalNode
     * @extends {Node}
     */
    constructor(condition, trueExpr, falseExpr) {
      super();
      if (!isNode(condition)) {
        throw new TypeError("Parameter condition must be a Node");
      }
      if (!isNode(trueExpr)) {
        throw new TypeError("Parameter trueExpr must be a Node");
      }
      if (!isNode(falseExpr)) {
        throw new TypeError("Parameter falseExpr must be a Node");
      }
      this.condition = condition;
      this.trueExpr = trueExpr;
      this.falseExpr = falseExpr;
    }
    get type() {
      return name32;
    }
    get isConditionalNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalCondition = this.condition._compile(math2, argNames);
      var evalTrueExpr = this.trueExpr._compile(math2, argNames);
      var evalFalseExpr = this.falseExpr._compile(math2, argNames);
      return function evalConditionalNode(scope, args, context) {
        return testCondition(evalCondition(scope, args, context)) ? evalTrueExpr(scope, args, context) : evalFalseExpr(scope, args, context);
      };
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.condition, "condition", this);
      callback(this.trueExpr, "trueExpr", this);
      callback(this.falseExpr, "falseExpr", this);
    }
    /**
     * Create a new ConditionalNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {ConditionalNode} Returns a transformed copy of the node
     */
    map(callback) {
      return new ConditionalNode2(this._ifNode(callback(this.condition, "condition", this)), this._ifNode(callback(this.trueExpr, "trueExpr", this)), this._ifNode(callback(this.falseExpr, "falseExpr", this)));
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {ConditionalNode}
     */
    clone() {
      return new ConditionalNode2(this.condition, this.trueExpr, this.falseExpr);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var precedence = getPrecedence(this, parenthesis, options && options.implicit);
      var condition = this.condition.toString(options);
      var conditionPrecedence = getPrecedence(this.condition, parenthesis, options && options.implicit);
      if (parenthesis === "all" || this.condition.type === "OperatorNode" || conditionPrecedence !== null && conditionPrecedence <= precedence) {
        condition = "(" + condition + ")";
      }
      var trueExpr = this.trueExpr.toString(options);
      var truePrecedence = getPrecedence(this.trueExpr, parenthesis, options && options.implicit);
      if (parenthesis === "all" || this.trueExpr.type === "OperatorNode" || truePrecedence !== null && truePrecedence <= precedence) {
        trueExpr = "(" + trueExpr + ")";
      }
      var falseExpr = this.falseExpr.toString(options);
      var falsePrecedence = getPrecedence(this.falseExpr, parenthesis, options && options.implicit);
      if (parenthesis === "all" || this.falseExpr.type === "OperatorNode" || falsePrecedence !== null && falsePrecedence <= precedence) {
        falseExpr = "(" + falseExpr + ")";
      }
      return condition + " ? " + trueExpr + " : " + falseExpr;
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name32,
        condition: this.condition,
        trueExpr: this.trueExpr,
        falseExpr: this.falseExpr
      };
    }
    /**
     * Instantiate an ConditionalNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     ```
     *     {"mathjs": "ConditionalNode",
     *      "condition": ...,
     *      "trueExpr": ...,
     *      "falseExpr": ...}
     *     ```
     *     where mathjs is optional
     * @returns {ConditionalNode}
     */
    static fromJSON(json) {
      return new ConditionalNode2(json.condition, json.trueExpr, json.falseExpr);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var precedence = getPrecedence(this, parenthesis, options && options.implicit);
      var condition = this.condition.toHTML(options);
      var conditionPrecedence = getPrecedence(this.condition, parenthesis, options && options.implicit);
      if (parenthesis === "all" || this.condition.type === "OperatorNode" || conditionPrecedence !== null && conditionPrecedence <= precedence) {
        condition = '<span class="math-parenthesis math-round-parenthesis">(</span>' + condition + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      var trueExpr = this.trueExpr.toHTML(options);
      var truePrecedence = getPrecedence(this.trueExpr, parenthesis, options && options.implicit);
      if (parenthesis === "all" || this.trueExpr.type === "OperatorNode" || truePrecedence !== null && truePrecedence <= precedence) {
        trueExpr = '<span class="math-parenthesis math-round-parenthesis">(</span>' + trueExpr + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      var falseExpr = this.falseExpr.toHTML(options);
      var falsePrecedence = getPrecedence(this.falseExpr, parenthesis, options && options.implicit);
      if (parenthesis === "all" || this.falseExpr.type === "OperatorNode" || falsePrecedence !== null && falsePrecedence <= precedence) {
        falseExpr = '<span class="math-parenthesis math-round-parenthesis">(</span>' + falseExpr + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      return condition + '<span class="math-operator math-conditional-operator">?</span>' + trueExpr + '<span class="math-operator math-conditional-operator">:</span>' + falseExpr;
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      return "\\begin{cases} {" + this.trueExpr.toTex(options) + "}, &\\quad{\\text{if }\\;" + this.condition.toTex(options) + "}\\\\{" + this.falseExpr.toTex(options) + "}, &\\quad{\\text{otherwise}}\\end{cases}";
    }
  }
  (0, import_defineProperty6.default)(ConditionalNode2, "name", name32);
  return ConditionalNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/ConstantNode.js
var import_defineProperty7 = __toESM(require_defineProperty(), 1);

// node_modules/mathjs/lib/esm/utils/latex.js
var import_escape_latex = __toESM(require_dist(), 1);
var latexSymbols = {
  // GREEK LETTERS
  Alpha: "A",
  alpha: "\\alpha",
  Beta: "B",
  beta: "\\beta",
  Gamma: "\\Gamma",
  gamma: "\\gamma",
  Delta: "\\Delta",
  delta: "\\delta",
  Epsilon: "E",
  epsilon: "\\epsilon",
  varepsilon: "\\varepsilon",
  Zeta: "Z",
  zeta: "\\zeta",
  Eta: "H",
  eta: "\\eta",
  Theta: "\\Theta",
  theta: "\\theta",
  vartheta: "\\vartheta",
  Iota: "I",
  iota: "\\iota",
  Kappa: "K",
  kappa: "\\kappa",
  varkappa: "\\varkappa",
  Lambda: "\\Lambda",
  lambda: "\\lambda",
  Mu: "M",
  mu: "\\mu",
  Nu: "N",
  nu: "\\nu",
  Xi: "\\Xi",
  xi: "\\xi",
  Omicron: "O",
  omicron: "o",
  Pi: "\\Pi",
  pi: "\\pi",
  varpi: "\\varpi",
  Rho: "P",
  rho: "\\rho",
  varrho: "\\varrho",
  Sigma: "\\Sigma",
  sigma: "\\sigma",
  varsigma: "\\varsigma",
  Tau: "T",
  tau: "\\tau",
  Upsilon: "\\Upsilon",
  upsilon: "\\upsilon",
  Phi: "\\Phi",
  phi: "\\phi",
  varphi: "\\varphi",
  Chi: "X",
  chi: "\\chi",
  Psi: "\\Psi",
  psi: "\\psi",
  Omega: "\\Omega",
  omega: "\\omega",
  // logic
  true: "\\mathrm{True}",
  false: "\\mathrm{False}",
  // other
  i: "i",
  // TODO use \i ??
  inf: "\\infty",
  Inf: "\\infty",
  infinity: "\\infty",
  Infinity: "\\infty",
  oo: "\\infty",
  lim: "\\lim",
  undefined: "\\mathbf{?}"
};
var latexOperators = {
  transpose: "^\\top",
  ctranspose: "^H",
  factorial: "!",
  pow: "^",
  dotPow: ".^\\wedge",
  // TODO find ideal solution
  unaryPlus: "+",
  unaryMinus: "-",
  bitNot: "\\~",
  // TODO find ideal solution
  not: "\\neg",
  multiply: "\\cdot",
  divide: "\\frac",
  // TODO how to handle that properly?
  dotMultiply: ".\\cdot",
  // TODO find ideal solution
  dotDivide: ".:",
  // TODO find ideal solution
  mod: "\\mod",
  add: "+",
  subtract: "-",
  to: "\\rightarrow",
  leftShift: "<<",
  rightArithShift: ">>",
  rightLogShift: ">>>",
  equal: "=",
  unequal: "\\neq",
  smaller: "<",
  larger: ">",
  smallerEq: "\\leq",
  largerEq: "\\geq",
  bitAnd: "\\&",
  bitXor: "\\underline{|}",
  bitOr: "|",
  and: "\\wedge",
  xor: "\\veebar",
  or: "\\vee"
};
var latexFunctions = {
  // arithmetic
  abs: {
    1: "\\left|${args[0]}\\right|"
  },
  add: {
    2: "\\left(${args[0]}".concat(latexOperators.add, "${args[1]}\\right)")
  },
  cbrt: {
    1: "\\sqrt[3]{${args[0]}}"
  },
  ceil: {
    1: "\\left\\lceil${args[0]}\\right\\rceil"
  },
  cube: {
    1: "\\left(${args[0]}\\right)^3"
  },
  divide: {
    2: "\\frac{${args[0]}}{${args[1]}}"
  },
  dotDivide: {
    2: "\\left(${args[0]}".concat(latexOperators.dotDivide, "${args[1]}\\right)")
  },
  dotMultiply: {
    2: "\\left(${args[0]}".concat(latexOperators.dotMultiply, "${args[1]}\\right)")
  },
  dotPow: {
    2: "\\left(${args[0]}".concat(latexOperators.dotPow, "${args[1]}\\right)")
  },
  exp: {
    1: "\\exp\\left(${args[0]}\\right)"
  },
  expm1: "\\left(e".concat(latexOperators.pow, "{${args[0]}}-1\\right)"),
  fix: {
    1: "\\mathrm{${name}}\\left(${args[0]}\\right)"
  },
  floor: {
    1: "\\left\\lfloor${args[0]}\\right\\rfloor"
  },
  fraction: {
    2: "\\frac{${args[0]}}{${args[1]}}"
  },
  gcd: "\\gcd\\left(${args}\\right)",
  hypot: "\\hypot\\left(${args}\\right)",
  log: {
    1: "\\ln\\left(${args[0]}\\right)",
    2: "\\log_{${args[1]}}\\left(${args[0]}\\right)"
  },
  log10: {
    1: "\\log_{10}\\left(${args[0]}\\right)"
  },
  log1p: {
    1: "\\ln\\left(${args[0]}+1\\right)",
    2: "\\log_{${args[1]}}\\left(${args[0]}+1\\right)"
  },
  log2: "\\log_{2}\\left(${args[0]}\\right)",
  mod: {
    2: "\\left(${args[0]}".concat(latexOperators.mod, "${args[1]}\\right)")
  },
  multiply: {
    2: "\\left(${args[0]}".concat(latexOperators.multiply, "${args[1]}\\right)")
  },
  norm: {
    1: "\\left\\|${args[0]}\\right\\|",
    2: void 0
    // use default template
  },
  nthRoot: {
    2: "\\sqrt[${args[1]}]{${args[0]}}"
  },
  nthRoots: {
    2: "\\{y : y^${args[1]} = {${args[0]}}\\}"
  },
  pow: {
    2: "\\left(${args[0]}\\right)".concat(latexOperators.pow, "{${args[1]}}")
  },
  round: {
    1: "\\left\\lfloor${args[0]}\\right\\rceil",
    2: void 0
    // use default template
  },
  sign: {
    1: "\\mathrm{${name}}\\left(${args[0]}\\right)"
  },
  sqrt: {
    1: "\\sqrt{${args[0]}}"
  },
  square: {
    1: "\\left(${args[0]}\\right)^2"
  },
  subtract: {
    2: "\\left(${args[0]}".concat(latexOperators.subtract, "${args[1]}\\right)")
  },
  unaryMinus: {
    1: "".concat(latexOperators.unaryMinus, "\\left(${args[0]}\\right)")
  },
  unaryPlus: {
    1: "".concat(latexOperators.unaryPlus, "\\left(${args[0]}\\right)")
  },
  // bitwise
  bitAnd: {
    2: "\\left(${args[0]}".concat(latexOperators.bitAnd, "${args[1]}\\right)")
  },
  bitNot: {
    1: latexOperators.bitNot + "\\left(${args[0]}\\right)"
  },
  bitOr: {
    2: "\\left(${args[0]}".concat(latexOperators.bitOr, "${args[1]}\\right)")
  },
  bitXor: {
    2: "\\left(${args[0]}".concat(latexOperators.bitXor, "${args[1]}\\right)")
  },
  leftShift: {
    2: "\\left(${args[0]}".concat(latexOperators.leftShift, "${args[1]}\\right)")
  },
  rightArithShift: {
    2: "\\left(${args[0]}".concat(latexOperators.rightArithShift, "${args[1]}\\right)")
  },
  rightLogShift: {
    2: "\\left(${args[0]}".concat(latexOperators.rightLogShift, "${args[1]}\\right)")
  },
  // combinatorics
  bellNumbers: {
    1: "\\mathrm{B}_{${args[0]}}"
  },
  catalan: {
    1: "\\mathrm{C}_{${args[0]}}"
  },
  stirlingS2: {
    2: "\\mathrm{S}\\left(${args}\\right)"
  },
  // complex
  arg: {
    1: "\\arg\\left(${args[0]}\\right)"
  },
  conj: {
    1: "\\left(${args[0]}\\right)^*"
  },
  im: {
    1: "\\Im\\left\\lbrace${args[0]}\\right\\rbrace"
  },
  re: {
    1: "\\Re\\left\\lbrace${args[0]}\\right\\rbrace"
  },
  // logical
  and: {
    2: "\\left(${args[0]}".concat(latexOperators.and, "${args[1]}\\right)")
  },
  not: {
    1: latexOperators.not + "\\left(${args[0]}\\right)"
  },
  or: {
    2: "\\left(${args[0]}".concat(latexOperators.or, "${args[1]}\\right)")
  },
  xor: {
    2: "\\left(${args[0]}".concat(latexOperators.xor, "${args[1]}\\right)")
  },
  // matrix
  cross: {
    2: "\\left(${args[0]}\\right)\\times\\left(${args[1]}\\right)"
  },
  ctranspose: {
    1: "\\left(${args[0]}\\right)".concat(latexOperators.ctranspose)
  },
  det: {
    1: "\\det\\left(${args[0]}\\right)"
  },
  dot: {
    2: "\\left(${args[0]}\\cdot${args[1]}\\right)"
  },
  expm: {
    1: "\\exp\\left(${args[0]}\\right)"
  },
  inv: {
    1: "\\left(${args[0]}\\right)^{-1}"
  },
  pinv: {
    1: "\\left(${args[0]}\\right)^{+}"
  },
  sqrtm: {
    1: "{${args[0]}}".concat(latexOperators.pow, "{\\frac{1}{2}}")
  },
  trace: {
    1: "\\mathrm{tr}\\left(${args[0]}\\right)"
  },
  transpose: {
    1: "\\left(${args[0]}\\right)".concat(latexOperators.transpose)
  },
  // probability
  combinations: {
    2: "\\binom{${args[0]}}{${args[1]}}"
  },
  combinationsWithRep: {
    2: "\\left(\\!\\!{\\binom{${args[0]}}{${args[1]}}}\\!\\!\\right)"
  },
  factorial: {
    1: "\\left(${args[0]}\\right)".concat(latexOperators.factorial)
  },
  gamma: {
    1: "\\Gamma\\left(${args[0]}\\right)"
  },
  lgamma: {
    1: "\\ln\\Gamma\\left(${args[0]}\\right)"
  },
  // relational
  equal: {
    2: "\\left(${args[0]}".concat(latexOperators.equal, "${args[1]}\\right)")
  },
  larger: {
    2: "\\left(${args[0]}".concat(latexOperators.larger, "${args[1]}\\right)")
  },
  largerEq: {
    2: "\\left(${args[0]}".concat(latexOperators.largerEq, "${args[1]}\\right)")
  },
  smaller: {
    2: "\\left(${args[0]}".concat(latexOperators.smaller, "${args[1]}\\right)")
  },
  smallerEq: {
    2: "\\left(${args[0]}".concat(latexOperators.smallerEq, "${args[1]}\\right)")
  },
  unequal: {
    2: "\\left(${args[0]}".concat(latexOperators.unequal, "${args[1]}\\right)")
  },
  // special
  erf: {
    1: "erf\\left(${args[0]}\\right)"
  },
  // statistics
  max: "\\max\\left(${args}\\right)",
  min: "\\min\\left(${args}\\right)",
  variance: "\\mathrm{Var}\\left(${args}\\right)",
  // trigonometry
  acos: {
    1: "\\cos^{-1}\\left(${args[0]}\\right)"
  },
  acosh: {
    1: "\\cosh^{-1}\\left(${args[0]}\\right)"
  },
  acot: {
    1: "\\cot^{-1}\\left(${args[0]}\\right)"
  },
  acoth: {
    1: "\\coth^{-1}\\left(${args[0]}\\right)"
  },
  acsc: {
    1: "\\csc^{-1}\\left(${args[0]}\\right)"
  },
  acsch: {
    1: "\\mathrm{csch}^{-1}\\left(${args[0]}\\right)"
  },
  asec: {
    1: "\\sec^{-1}\\left(${args[0]}\\right)"
  },
  asech: {
    1: "\\mathrm{sech}^{-1}\\left(${args[0]}\\right)"
  },
  asin: {
    1: "\\sin^{-1}\\left(${args[0]}\\right)"
  },
  asinh: {
    1: "\\sinh^{-1}\\left(${args[0]}\\right)"
  },
  atan: {
    1: "\\tan^{-1}\\left(${args[0]}\\right)"
  },
  atan2: {
    2: "\\mathrm{atan2}\\left(${args}\\right)"
  },
  atanh: {
    1: "\\tanh^{-1}\\left(${args[0]}\\right)"
  },
  cos: {
    1: "\\cos\\left(${args[0]}\\right)"
  },
  cosh: {
    1: "\\cosh\\left(${args[0]}\\right)"
  },
  cot: {
    1: "\\cot\\left(${args[0]}\\right)"
  },
  coth: {
    1: "\\coth\\left(${args[0]}\\right)"
  },
  csc: {
    1: "\\csc\\left(${args[0]}\\right)"
  },
  csch: {
    1: "\\mathrm{csch}\\left(${args[0]}\\right)"
  },
  sec: {
    1: "\\sec\\left(${args[0]}\\right)"
  },
  sech: {
    1: "\\mathrm{sech}\\left(${args[0]}\\right)"
  },
  sin: {
    1: "\\sin\\left(${args[0]}\\right)"
  },
  sinh: {
    1: "\\sinh\\left(${args[0]}\\right)"
  },
  tan: {
    1: "\\tan\\left(${args[0]}\\right)"
  },
  tanh: {
    1: "\\tanh\\left(${args[0]}\\right)"
  },
  // unit
  to: {
    2: "\\left(${args[0]}".concat(latexOperators.to, "${args[1]}\\right)")
  },
  // utils
  numeric: function numeric(node, options) {
    return node.args[0].toTex();
  },
  // type
  number: {
    0: "0",
    1: "\\left(${args[0]}\\right)",
    2: "\\left(\\left(${args[0]}\\right)${args[1]}\\right)"
  },
  string: {
    0: '\\mathtt{""}',
    1: "\\mathrm{string}\\left(${args[0]}\\right)"
  },
  bignumber: {
    0: "0",
    1: "\\left(${args[0]}\\right)"
  },
  bigint: {
    0: "0",
    1: "\\left(${args[0]}\\right)"
  },
  complex: {
    0: "0",
    1: "\\left(${args[0]}\\right)",
    2: "\\left(\\left(${args[0]}\\right)+".concat(latexSymbols.i, "\\cdot\\left(${args[1]}\\right)\\right)")
  },
  matrix: {
    0: "\\begin{bmatrix}\\end{bmatrix}",
    1: "\\left(${args[0]}\\right)",
    2: "\\left(${args[0]}\\right)"
  },
  sparse: {
    0: "\\begin{bsparse}\\end{bsparse}",
    1: "\\left(${args[0]}\\right)"
  },
  unit: {
    1: "\\left(${args[0]}\\right)",
    2: "\\left(\\left(${args[0]}\\right)${args[1]}\\right)"
  }
};
var defaultTemplate = "\\mathrm{${name}}\\left(${args}\\right)";
var latexUnits = {
  deg: "^\\circ"
};
function escapeLatex(string2) {
  return (0, import_escape_latex.default)(string2, {
    preserveFormatting: true
  });
}
function toSymbol(name114, isUnit2) {
  isUnit2 = typeof isUnit2 === "undefined" ? false : isUnit2;
  if (isUnit2) {
    if (hasOwnProperty(latexUnits, name114)) {
      return latexUnits[name114];
    }
    return "\\mathrm{" + escapeLatex(name114) + "}";
  }
  if (hasOwnProperty(latexSymbols, name114)) {
    return latexSymbols[name114];
  }
  return escapeLatex(name114);
}

// node_modules/mathjs/lib/esm/expression/node/ConstantNode.js
var name33 = "ConstantNode";
var dependencies31 = ["Node", "isBounded"];
var createConstantNode = /* @__PURE__ */ factory(name33, dependencies31, (_ref) => {
  var {
    Node: Node2,
    isBounded: isBounded2
  } = _ref;
  class ConstantNode2 extends Node2 {
    /**
     * A ConstantNode holds a constant value like a number or string.
     *
     * Usage:
     *
     *     new ConstantNode(2.3)
     *     new ConstantNode('hello')
     *
     * @param {*} value    Value can be any type (number, BigNumber, bigint, string, ...)
     * @constructor ConstantNode
     * @extends {Node}
     */
    constructor(value) {
      super();
      this.value = value;
    }
    get type() {
      return name33;
    }
    get isConstantNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var value = this.value;
      return function evalConstantNode() {
        return value;
      };
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
    }
    /**
     * Create a new ConstantNode with children produced by the given callback.
     * Trivial because there are no children.
     * @param {function(child: Node, path: string, parent: Node) : Node} callback
     * @returns {ConstantNode} Returns a clone of the node
     */
    map(callback) {
      return this.clone();
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {ConstantNode}
     */
    clone() {
      return new ConstantNode2(this.value);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      return format3(this.value, options);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var value = this._toString(options);
      switch (typeOf(this.value)) {
        case "number":
        case "bigint":
        case "BigNumber":
        case "Fraction":
          return '<span class="math-number">' + value + "</span>";
        case "string":
          return '<span class="math-string">' + value + "</span>";
        case "boolean":
          return '<span class="math-boolean">' + value + "</span>";
        case "null":
          return '<span class="math-null-symbol">' + value + "</span>";
        case "undefined":
          return '<span class="math-undefined">' + value + "</span>";
        default:
          return '<span class="math-symbol">' + value + "</span>";
      }
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name33,
        value: this.value
      };
    }
    /**
     * Instantiate a ConstantNode from its JSON representation
     * @param {Object} json  An object structured like
     *                       `{"mathjs": "SymbolNode", value: 2.3}`,
     *                       where mathjs is optional
     * @returns {ConstantNode}
     */
    static fromJSON(json) {
      return new ConstantNode2(json.value);
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var value = this._toString(options);
      var type = typeOf(this.value);
      switch (type) {
        case "string":
          return "\\mathtt{" + escapeLatex(value) + "}";
        case "number":
        case "BigNumber": {
          if (!isBounded2(this.value)) {
            return this.value.valueOf() < 0 ? "-\\infty" : "\\infty";
          }
          var index2 = value.toLowerCase().indexOf("e");
          if (index2 !== -1) {
            return value.substring(0, index2) + "\\cdot10^{" + value.substring(index2 + 1) + "}";
          }
          return value;
        }
        case "bigint": {
          return value.toString();
        }
        case "Fraction":
          return this.value.toLatex();
        default:
          return value;
      }
    }
  }
  (0, import_defineProperty7.default)(ConstantNode2, "name", name33);
  return ConstantNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/FunctionAssignmentNode.js
var import_defineProperty8 = __toESM(require_defineProperty(), 1);
var name34 = "FunctionAssignmentNode";
var dependencies32 = ["typed", "Node"];
var createFunctionAssignmentNode = /* @__PURE__ */ factory(name34, dependencies32, (_ref) => {
  var {
    typed: typed3,
    Node: Node2
  } = _ref;
  function needParenthesis(node, parenthesis, implicit) {
    var precedence = getPrecedence(node, parenthesis, implicit);
    var exprPrecedence = getPrecedence(node.expr, parenthesis, implicit);
    return parenthesis === "all" || exprPrecedence !== null && exprPrecedence <= precedence;
  }
  class FunctionAssignmentNode2 extends Node2 {
    /**
     * @constructor FunctionAssignmentNode
     * @extends {Node}
     * Function assignment
     *
     * @param {string} name           Function name
     * @param {string[] | Array.<{name: string, type: string}>} params
     *                                Array with function parameter names, or an
     *                                array with objects containing the name
     *                                and type of the parameter
     * @param {Node} expr             The function expression
     */
    constructor(name114, params, expr) {
      super();
      if (typeof name114 !== "string") {
        throw new TypeError('String expected for parameter "name"');
      }
      if (!Array.isArray(params)) {
        throw new TypeError('Array containing strings or objects expected for parameter "params"');
      }
      if (!isNode(expr)) {
        throw new TypeError('Node expected for parameter "expr"');
      }
      if (keywords.has(name114)) {
        throw new Error('Illegal function name, "' + name114 + '" is a reserved keyword');
      }
      var paramNames = /* @__PURE__ */ new Set();
      for (var param of params) {
        var _name = typeof param === "string" ? param : param.name;
        if (paramNames.has(_name)) {
          throw new Error('Duplicate parameter name "'.concat(_name, '"'));
        } else {
          paramNames.add(_name);
        }
      }
      this.name = name114;
      this.params = params.map(function(param2) {
        return param2 && param2.name || param2;
      });
      this.types = params.map(function(param2) {
        return param2 && param2.type || "any";
      });
      this.expr = expr;
    }
    get type() {
      return name34;
    }
    get isFunctionAssignmentNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var childArgNames = Object.create(argNames);
      forEach(this.params, function(param) {
        childArgNames[param] = true;
      });
      var expr = this.expr;
      var evalExpr = expr._compile(math2, childArgNames);
      var name114 = this.name;
      var params = this.params;
      var signature = join(this.types, ",");
      var syntax = name114 + "(" + join(this.params, ", ") + ")";
      return function evalFunctionAssignmentNode(scope, args, context) {
        var signatures = {};
        signatures[signature] = function() {
          var childArgs = Object.create(args);
          for (var i = 0; i < params.length; i++) {
            childArgs[params[i]] = arguments[i];
          }
          return evalExpr(scope, childArgs, context);
        };
        var fn = typed3(name114, signatures);
        fn.syntax = syntax;
        fn.expr = expr.toString();
        scope.set(name114, fn);
        return fn;
      };
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.expr, "expr", this);
    }
    /**
     * Create a new FunctionAssignmentNode whose children are the results of
     * calling the provided callback function for each child of the original
     * node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {FunctionAssignmentNode} Returns a transformed copy of the node
     */
    map(callback) {
      var expr = this._ifNode(callback(this.expr, "expr", this));
      return new FunctionAssignmentNode2(this.name, this.params.slice(0), expr);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {FunctionAssignmentNode}
     */
    clone() {
      return new FunctionAssignmentNode2(this.name, this.params.slice(0), this.expr);
    }
    /**
     * get string representation
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var expr = this.expr.toString(options);
      if (needParenthesis(this, parenthesis, options && options.implicit)) {
        expr = "(" + expr + ")";
      }
      return this.name + "(" + this.params.join(", ") + ") = " + expr;
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      var types = this.types;
      return {
        mathjs: name34,
        name: this.name,
        params: this.params.map(function(param, index2) {
          return {
            name: param,
            type: types[index2]
          };
        }),
        expr: this.expr
      };
    }
    /**
     * Instantiate an FunctionAssignmentNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     ```
     *     {"mathjs": "FunctionAssignmentNode",
     *      name: ..., params: ..., expr: ...}
     *     ```
     *     where mathjs is optional
     * @returns {FunctionAssignmentNode}
     */
    static fromJSON(json) {
      return new FunctionAssignmentNode2(json.name, json.params, json.expr);
    }
    /**
     * get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var params = [];
      for (var i = 0; i < this.params.length; i++) {
        params.push('<span class="math-symbol math-parameter">' + escape(this.params[i]) + "</span>");
      }
      var expr = this.expr.toHTML(options);
      if (needParenthesis(this, parenthesis, options && options.implicit)) {
        expr = '<span class="math-parenthesis math-round-parenthesis">(</span>' + expr + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      return '<span class="math-function">' + escape(this.name) + '</span><span class="math-parenthesis math-round-parenthesis">(</span>' + params.join('<span class="math-separator">,</span>') + '<span class="math-parenthesis math-round-parenthesis">)</span><span class="math-operator math-assignment-operator math-variable-assignment-operator math-binary-operator">=</span>' + expr;
    }
    /**
     * get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var expr = this.expr.toTex(options);
      if (needParenthesis(this, parenthesis, options && options.implicit)) {
        expr = "\\left(".concat(expr, "\\right)");
      }
      return "\\mathrm{" + this.name + "}\\left(" + this.params.map(toSymbol).join(",") + "\\right)=" + expr;
    }
  }
  (0, import_defineProperty8.default)(FunctionAssignmentNode2, "name", name34);
  return FunctionAssignmentNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/IndexNode.js
var import_defineProperty9 = __toESM(require_defineProperty(), 1);
var name35 = "IndexNode";
var dependencies33 = ["Node", "size"];
var createIndexNode = /* @__PURE__ */ factory(name35, dependencies33, (_ref) => {
  var {
    Node: Node2,
    size: size2
  } = _ref;
  class IndexNode2 extends Node2 {
    /**
     * @constructor IndexNode
     * @extends Node
     *
     * Describes a subset of a matrix or an object property.
     * Cannot be used on its own, needs to be used within an AccessorNode or
     * AssignmentNode.
     *
     * @param {Node[]} dimensions
     * @param {boolean} [dotNotation=false]
     *     Optional property describing whether this index was written using dot
     *     notation like `a.b`, or using bracket notation like `a["b"]`
     *     (which is the default). This property is used for string conversion.
     */
    constructor(dimensions, dotNotation) {
      super();
      this.dimensions = dimensions;
      this.dotNotation = dotNotation || false;
      if (!Array.isArray(dimensions) || !dimensions.every(isNode)) {
        throw new TypeError('Array containing Nodes expected for parameter "dimensions"');
      }
      if (this.dotNotation && !this.isObjectProperty()) {
        throw new Error("dotNotation only applicable for object properties");
      }
    }
    get type() {
      return name35;
    }
    get isIndexNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalDimensions = map(this.dimensions, function(dimension, i) {
        var needsEnd = dimension.filter((node) => node.isSymbolNode && node.name === "end").length > 0;
        if (needsEnd) {
          var childArgNames = Object.create(argNames);
          childArgNames.end = true;
          var _evalDimension = dimension._compile(math2, childArgNames);
          return function evalDimension(scope, args, context) {
            if (!isMatrix(context) && !isArray(context) && !isString(context)) {
              throw new TypeError('Cannot resolve "end": context must be a Matrix, Array, or string but is ' + typeOf(context));
            }
            var s = size2(context);
            var childArgs = Object.create(args);
            childArgs.end = s[i];
            return _evalDimension(scope, childArgs, context);
          };
        } else {
          return dimension._compile(math2, argNames);
        }
      });
      var index2 = getSafeProperty(math2, "index");
      return function evalIndexNode(scope, args, context) {
        var dimensions = map(evalDimensions, function(evalDimension) {
          return evalDimension(scope, args, context);
        });
        return index2(...dimensions);
      };
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      for (var i = 0; i < this.dimensions.length; i++) {
        callback(this.dimensions[i], "dimensions[" + i + "]", this);
      }
    }
    /**
     * Create a new IndexNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {IndexNode} Returns a transformed copy of the node
     */
    map(callback) {
      var dimensions = [];
      for (var i = 0; i < this.dimensions.length; i++) {
        dimensions[i] = this._ifNode(callback(this.dimensions[i], "dimensions[" + i + "]", this));
      }
      return new IndexNode2(dimensions, this.dotNotation);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {IndexNode}
     */
    clone() {
      return new IndexNode2(this.dimensions.slice(0), this.dotNotation);
    }
    /**
     * Test whether this IndexNode contains a single property name
     * @return {boolean}
     */
    isObjectProperty() {
      return this.dimensions.length === 1 && isConstantNode(this.dimensions[0]) && typeof this.dimensions[0].value === "string";
    }
    /**
     * Returns the property name if IndexNode contains a property.
     * If not, returns null.
     * @return {string | null}
     */
    getObjectProperty() {
      return this.isObjectProperty() ? this.dimensions[0].value : null;
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      return this.dotNotation ? "." + this.getObjectProperty() : "[" + this.dimensions.join(", ") + "]";
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name35,
        dimensions: this.dimensions,
        dotNotation: this.dotNotation
      };
    }
    /**
     * Instantiate an IndexNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     `{"mathjs": "IndexNode", dimensions: [...], dotNotation: false}`,
     *     where mathjs is optional
     * @returns {IndexNode}
     */
    static fromJSON(json) {
      return new IndexNode2(json.dimensions, json.dotNotation);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var dimensions = [];
      for (var i = 0; i < this.dimensions.length; i++) {
        dimensions[i] = this.dimensions[i].toHTML();
      }
      if (this.dotNotation) {
        return '<span class="math-operator math-accessor-operator">.</span><span class="math-symbol math-property">' + escape(this.getObjectProperty()) + "</span>";
      } else {
        return '<span class="math-parenthesis math-square-parenthesis">[</span>' + dimensions.join('<span class="math-separator">,</span>') + '<span class="math-parenthesis math-square-parenthesis">]</span>';
      }
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var dimensions = this.dimensions.map(function(range2) {
        return range2.toTex(options);
      });
      return this.dotNotation ? "." + this.getObjectProperty() : "_{" + dimensions.join(",") + "}";
    }
  }
  (0, import_defineProperty9.default)(IndexNode2, "name", name35);
  return IndexNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/ObjectNode.js
var import_defineProperty10 = __toESM(require_defineProperty(), 1);
var name36 = "ObjectNode";
var dependencies34 = ["Node"];
var createObjectNode = /* @__PURE__ */ factory(name36, dependencies34, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  class ObjectNode2 extends Node2 {
    /**
     * @constructor ObjectNode
     * @extends {Node}
     * Holds an object with keys/values
     * @param {Object.<string, Node>} [properties]   object with key/value pairs
     */
    constructor(properties2) {
      super();
      this.properties = properties2 || {};
      if (properties2) {
        if (!(typeof properties2 === "object") || !Object.keys(properties2).every(function(key) {
          return isNode(properties2[key]);
        })) {
          throw new TypeError("Object containing Nodes expected");
        }
      }
    }
    get type() {
      return name36;
    }
    get isObjectNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var evalEntries = {};
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          var stringifiedKey = stringify(key);
          var parsedKey = JSON.parse(stringifiedKey);
          var prop = getSafeProperty(this.properties, key);
          evalEntries[parsedKey] = prop._compile(math2, argNames);
        }
      }
      return function evalObjectNode(scope, args, context) {
        var obj = {};
        for (var _key in evalEntries) {
          if (hasOwnProperty(evalEntries, _key)) {
            obj[_key] = evalEntries[_key](scope, args, context);
          }
        }
        return obj;
      };
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          callback(this.properties[key], "properties[" + stringify(key) + "]", this);
        }
      }
    }
    /**
     * Create a new ObjectNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {ObjectNode} Returns a transformed copy of the node
     */
    map(callback) {
      var properties2 = {};
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          properties2[key] = this._ifNode(callback(this.properties[key], "properties[" + stringify(key) + "]", this));
        }
      }
      return new ObjectNode2(properties2);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {ObjectNode}
     */
    clone() {
      var properties2 = {};
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          properties2[key] = this.properties[key];
        }
      }
      return new ObjectNode2(properties2);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toString(options) {
      var entries = [];
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          entries.push(stringify(key) + ": " + this.properties[key].toString(options));
        }
      }
      return "{" + entries.join(", ") + "}";
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name36,
        properties: this.properties
      };
    }
    /**
     * Instantiate an OperatorNode from its JSON representation
     * @param {Object} json  An object structured like
     *                       `{"mathjs": "ObjectNode", "properties": {...}}`,
     *                       where mathjs is optional
     * @returns {ObjectNode}
     */
    static fromJSON(json) {
      return new ObjectNode2(json.properties);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toHTML(options) {
      var entries = [];
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          entries.push('<span class="math-symbol math-property">' + escape(key) + '</span><span class="math-operator math-assignment-operator math-property-assignment-operator math-binary-operator">:</span>' + this.properties[key].toHTML(options));
        }
      }
      return '<span class="math-parenthesis math-curly-parenthesis">{</span>' + entries.join('<span class="math-separator">,</span>') + '<span class="math-parenthesis math-curly-parenthesis">}</span>';
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var entries = [];
      for (var key in this.properties) {
        if (hasOwnProperty(this.properties, key)) {
          entries.push("\\mathbf{" + key + ":} & " + this.properties[key].toTex(options) + "\\\\");
        }
      }
      var tex = "\\left\\{\\begin{array}{ll}" + entries.join("\n") + "\\end{array}\\right\\}";
      return tex;
    }
  }
  (0, import_defineProperty10.default)(ObjectNode2, "name", name36);
  return ObjectNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/OperatorNode.js
var import_defineProperty11 = __toESM(require_defineProperty(), 1);

// node_modules/mathjs/lib/esm/utils/scope.js
function createSubScope(parentScope, args) {
  return new PartitionedMap(parentScope, new ObjectWrappingMap(args), new Set(Object.keys(args)));
}

// node_modules/mathjs/lib/esm/expression/node/OperatorNode.js
var name37 = "OperatorNode";
var dependencies35 = ["Node"];
var createOperatorNode = /* @__PURE__ */ factory(name37, dependencies35, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  function startsWithConstant(expr, parenthesis) {
    var curNode = expr;
    if (parenthesis === "auto") {
      while (isParenthesisNode(curNode)) curNode = curNode.content;
    }
    if (isConstantNode(curNode)) return true;
    if (isOperatorNode(curNode)) {
      return startsWithConstant(curNode.args[0], parenthesis);
    }
    return false;
  }
  function calculateNecessaryParentheses(root, parenthesis, implicit, args, latex) {
    var precedence = getPrecedence(root, parenthesis, implicit);
    var associativity = getAssociativity(root, parenthesis);
    if (parenthesis === "all" || args.length > 2 && root.getIdentifier() !== "OperatorNode:add" && root.getIdentifier() !== "OperatorNode:multiply") {
      return args.map(function(arg) {
        switch (arg.getContent().type) {
          // Nodes that don't need extra parentheses
          case "ArrayNode":
          case "ConstantNode":
          case "SymbolNode":
          case "ParenthesisNode":
            return false;
          default:
            return true;
        }
      });
    }
    var result;
    switch (args.length) {
      case 0:
        result = [];
        break;
      case 1:
        {
          var operandPrecedence = getPrecedence(args[0], parenthesis, implicit, root);
          if (latex && operandPrecedence !== null) {
            var operandIdentifier;
            var rootIdentifier;
            if (parenthesis === "keep") {
              operandIdentifier = args[0].getIdentifier();
              rootIdentifier = root.getIdentifier();
            } else {
              operandIdentifier = args[0].getContent().getIdentifier();
              rootIdentifier = root.getContent().getIdentifier();
            }
            if (properties[precedence][rootIdentifier].latexLeftParens === false) {
              result = [false];
              break;
            }
            if (properties[operandPrecedence][operandIdentifier].latexParens === false) {
              result = [false];
              break;
            }
          }
          if (operandPrecedence === null) {
            result = [false];
            break;
          }
          if (operandPrecedence <= precedence) {
            result = [true];
            break;
          }
          result = [false];
        }
        break;
      case 2:
        {
          var lhsParens;
          var lhsPrecedence = getPrecedence(args[0], parenthesis, implicit, root);
          var assocWithLhs = isAssociativeWith(root, args[0], parenthesis);
          if (lhsPrecedence === null) {
            lhsParens = false;
          } else if (lhsPrecedence === precedence && associativity === "right" && !assocWithLhs) {
            lhsParens = true;
          } else if (lhsPrecedence < precedence) {
            lhsParens = true;
          } else {
            lhsParens = false;
          }
          var rhsParens;
          var rhsPrecedence = getPrecedence(args[1], parenthesis, implicit, root);
          var assocWithRhs = isAssociativeWith(root, args[1], parenthesis);
          if (rhsPrecedence === null) {
            rhsParens = false;
          } else if (rhsPrecedence === precedence && associativity === "left" && !assocWithRhs) {
            rhsParens = true;
          } else if (rhsPrecedence < precedence) {
            rhsParens = true;
          } else {
            rhsParens = false;
          }
          if (latex) {
            var _rootIdentifier;
            var lhsIdentifier;
            var rhsIdentifier;
            if (parenthesis === "keep") {
              _rootIdentifier = root.getIdentifier();
              lhsIdentifier = root.args[0].getIdentifier();
              rhsIdentifier = root.args[1].getIdentifier();
            } else {
              _rootIdentifier = root.getContent().getIdentifier();
              lhsIdentifier = root.args[0].getContent().getIdentifier();
              rhsIdentifier = root.args[1].getContent().getIdentifier();
            }
            if (lhsPrecedence !== null) {
              if (properties[precedence][_rootIdentifier].latexLeftParens === false) {
                lhsParens = false;
              }
              if (properties[lhsPrecedence][lhsIdentifier].latexParens === false) {
                lhsParens = false;
              }
            }
            if (rhsPrecedence !== null) {
              if (properties[precedence][_rootIdentifier].latexRightParens === false) {
                rhsParens = false;
              }
              if (properties[rhsPrecedence][rhsIdentifier].latexParens === false) {
                rhsParens = false;
              }
            }
          }
          result = [lhsParens, rhsParens];
        }
        break;
      default:
        if (root.getIdentifier() === "OperatorNode:add" || root.getIdentifier() === "OperatorNode:multiply") {
          result = args.map(function(arg) {
            var argPrecedence = getPrecedence(arg, parenthesis, implicit, root);
            var assocWithArg = isAssociativeWith(root, arg, parenthesis);
            var argAssociativity = getAssociativity(arg, parenthesis);
            if (argPrecedence === null) {
              return false;
            } else if (precedence === argPrecedence && associativity === argAssociativity && !assocWithArg) {
              return true;
            } else if (argPrecedence < precedence) {
              return true;
            }
            return false;
          });
        }
        break;
    }
    if (args.length >= 2 && root.getIdentifier() === "OperatorNode:multiply" && root.implicit && parenthesis !== "all" && implicit === "hide") {
      for (var i = 1; i < result.length; ++i) {
        if (startsWithConstant(args[i], parenthesis) && !result[i - 1] && (parenthesis !== "keep" || !isParenthesisNode(args[i - 1]))) {
          result[i] = true;
        }
      }
    }
    return result;
  }
  class OperatorNode2 extends Node2 {
    /**
     * @constructor OperatorNode
     * @extends {Node}
     * An operator with two arguments, like 2+3
     *
     * @param {string} op           Operator name, for example '+'
     * @param {string} fn           Function name, for example 'add'
     * @param {Node[]} args         Operator arguments
     * @param {boolean} [implicit]  Is this an implicit multiplication?
     * @param {boolean} [isPercentage] Is this an percentage Operation?
     */
    constructor(op, fn, args, implicit, isPercentage) {
      super();
      if (typeof op !== "string") {
        throw new TypeError('string expected for parameter "op"');
      }
      if (typeof fn !== "string") {
        throw new TypeError('string expected for parameter "fn"');
      }
      if (!Array.isArray(args) || !args.every(isNode)) {
        throw new TypeError('Array containing Nodes expected for parameter "args"');
      }
      this.implicit = implicit === true;
      this.isPercentage = isPercentage === true;
      this.op = op;
      this.fn = fn;
      this.args = args || [];
    }
    get type() {
      return name37;
    }
    get isOperatorNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      if (typeof this.fn !== "string" || !isSafeMethod(math2, this.fn)) {
        if (!math2[this.fn]) {
          throw new Error("Function " + this.fn + ' missing in provided namespace "math"');
        } else {
          throw new Error('No access to function "' + this.fn + '"');
        }
      }
      var fn = getSafeProperty(math2, this.fn);
      var evalArgs = map(this.args, function(arg) {
        return arg._compile(math2, argNames);
      });
      if (typeof fn === "function" && fn.rawArgs === true) {
        var rawArgs = this.args;
        return function evalOperatorNode(scope, args, context) {
          return fn(rawArgs, math2, createSubScope(scope, args));
        };
      } else if (evalArgs.length === 1) {
        var evalArg0 = evalArgs[0];
        return function evalOperatorNode(scope, args, context) {
          return fn(evalArg0(scope, args, context));
        };
      } else if (evalArgs.length === 2) {
        var _evalArg = evalArgs[0];
        var evalArg1 = evalArgs[1];
        return function evalOperatorNode(scope, args, context) {
          return fn(_evalArg(scope, args, context), evalArg1(scope, args, context));
        };
      } else {
        return function evalOperatorNode(scope, args, context) {
          return fn.apply(null, map(evalArgs, function(evalArg) {
            return evalArg(scope, args, context);
          }));
        };
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      for (var i = 0; i < this.args.length; i++) {
        callback(this.args[i], "args[" + i + "]", this);
      }
    }
    /**
     * Create a new OperatorNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {OperatorNode} Returns a transformed copy of the node
     */
    map(callback) {
      var args = [];
      for (var i = 0; i < this.args.length; i++) {
        args[i] = this._ifNode(callback(this.args[i], "args[" + i + "]", this));
      }
      return new OperatorNode2(this.op, this.fn, args, this.implicit, this.isPercentage);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {OperatorNode}
     */
    clone() {
      return new OperatorNode2(this.op, this.fn, this.args.slice(0), this.implicit, this.isPercentage);
    }
    /**
     * Check whether this is an unary OperatorNode:
     * has exactly one argument, like `-a`.
     * @return {boolean}
     *     Returns true when an unary operator node, false otherwise.
     */
    isUnary() {
      return this.args.length === 1;
    }
    /**
     * Check whether this is a binary OperatorNode:
     * has exactly two arguments, like `a + b`.
     * @return {boolean}
     *     Returns true when a binary operator node, false otherwise.
     */
    isBinary() {
      return this.args.length === 2;
    }
    /**
     * Get string representation.
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var implicit = options && options.implicit ? options.implicit : "hide";
      var args = this.args;
      var parens = calculateNecessaryParentheses(this, parenthesis, implicit, args, false);
      if (args.length === 1) {
        var assoc = getAssociativity(this, parenthesis);
        var operand = args[0].toString(options);
        if (parens[0]) {
          operand = "(" + operand + ")";
        }
        var opIsNamed = /[a-zA-Z]+/.test(this.op);
        if (assoc === "right") {
          return this.op + (opIsNamed ? " " : "") + operand;
        } else if (assoc === "left") {
          return operand + (opIsNamed ? " " : "") + this.op;
        }
        return operand + this.op;
      } else if (args.length === 2) {
        var lhs = args[0].toString(options);
        var rhs = args[1].toString(options);
        if (parens[0]) {
          lhs = "(" + lhs + ")";
        }
        if (parens[1]) {
          rhs = "(" + rhs + ")";
        }
        if (this.implicit && this.getIdentifier() === "OperatorNode:multiply" && implicit === "hide") {
          return lhs + " " + rhs;
        }
        return lhs + " " + this.op + " " + rhs;
      } else if (args.length > 2 && (this.getIdentifier() === "OperatorNode:add" || this.getIdentifier() === "OperatorNode:multiply")) {
        var stringifiedArgs = args.map(function(arg, index2) {
          arg = arg.toString(options);
          if (parens[index2]) {
            arg = "(" + arg + ")";
          }
          return arg;
        });
        if (this.implicit && this.getIdentifier() === "OperatorNode:multiply" && implicit === "hide") {
          return stringifiedArgs.join(" ");
        }
        return stringifiedArgs.join(" " + this.op + " ");
      } else {
        return this.fn + "(" + this.args.join(", ") + ")";
      }
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name37,
        op: this.op,
        fn: this.fn,
        args: this.args,
        implicit: this.implicit,
        isPercentage: this.isPercentage
      };
    }
    /**
     * Instantiate an OperatorNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     ```
     *     {"mathjs": "OperatorNode",
     *      "op": "+", "fn": "add", "args": [...],
     *      "implicit": false,
     *      "isPercentage":false}
     *     ```
     *     where mathjs is optional
     * @returns {OperatorNode}
     */
    static fromJSON(json) {
      return new OperatorNode2(json.op, json.fn, json.args, json.implicit, json.isPercentage);
    }
    /**
     * Get HTML representation.
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var implicit = options && options.implicit ? options.implicit : "hide";
      var args = this.args;
      var parens = calculateNecessaryParentheses(this, parenthesis, implicit, args, false);
      if (args.length === 1) {
        var assoc = getAssociativity(this, parenthesis);
        var operand = args[0].toHTML(options);
        if (parens[0]) {
          operand = '<span class="math-parenthesis math-round-parenthesis">(</span>' + operand + '<span class="math-parenthesis math-round-parenthesis">)</span>';
        }
        if (assoc === "right") {
          return '<span class="math-operator math-unary-operator math-lefthand-unary-operator">' + escape(this.op) + "</span>" + operand;
        } else {
          return operand + '<span class="math-operator math-unary-operator math-righthand-unary-operator">' + escape(this.op) + "</span>";
        }
      } else if (args.length === 2) {
        var lhs = args[0].toHTML(options);
        var rhs = args[1].toHTML(options);
        if (parens[0]) {
          lhs = '<span class="math-parenthesis math-round-parenthesis">(</span>' + lhs + '<span class="math-parenthesis math-round-parenthesis">)</span>';
        }
        if (parens[1]) {
          rhs = '<span class="math-parenthesis math-round-parenthesis">(</span>' + rhs + '<span class="math-parenthesis math-round-parenthesis">)</span>';
        }
        if (this.implicit && this.getIdentifier() === "OperatorNode:multiply" && implicit === "hide") {
          return lhs + '<span class="math-operator math-binary-operator math-implicit-binary-operator"></span>' + rhs;
        }
        return lhs + '<span class="math-operator math-binary-operator math-explicit-binary-operator">' + escape(this.op) + "</span>" + rhs;
      } else {
        var stringifiedArgs = args.map(function(arg, index2) {
          arg = arg.toHTML(options);
          if (parens[index2]) {
            arg = '<span class="math-parenthesis math-round-parenthesis">(</span>' + arg + '<span class="math-parenthesis math-round-parenthesis">)</span>';
          }
          return arg;
        });
        if (args.length > 2 && (this.getIdentifier() === "OperatorNode:add" || this.getIdentifier() === "OperatorNode:multiply")) {
          if (this.implicit && this.getIdentifier() === "OperatorNode:multiply" && implicit === "hide") {
            return stringifiedArgs.join('<span class="math-operator math-binary-operator math-implicit-binary-operator"></span>');
          }
          return stringifiedArgs.join('<span class="math-operator math-binary-operator math-explicit-binary-operator">' + escape(this.op) + "</span>");
        } else {
          return '<span class="math-function">' + escape(this.fn) + '</span><span class="math-paranthesis math-round-parenthesis">(</span>' + stringifiedArgs.join('<span class="math-separator">,</span>') + '<span class="math-paranthesis math-round-parenthesis">)</span>';
        }
      }
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var implicit = options && options.implicit ? options.implicit : "hide";
      var args = this.args;
      var parens = calculateNecessaryParentheses(this, parenthesis, implicit, args, true);
      var op = latexOperators[this.fn];
      op = typeof op === "undefined" ? this.op : op;
      if (args.length === 1) {
        var assoc = getAssociativity(this, parenthesis);
        var operand = args[0].toTex(options);
        if (parens[0]) {
          operand = "\\left(".concat(operand, "\\right)");
        }
        if (assoc === "right") {
          return op + operand;
        } else if (assoc === "left") {
          return operand + op;
        }
        return operand + op;
      } else if (args.length === 2) {
        var lhs = args[0];
        var lhsTex = lhs.toTex(options);
        if (parens[0]) {
          lhsTex = "\\left(".concat(lhsTex, "\\right)");
        }
        var rhs = args[1];
        var rhsTex = rhs.toTex(options);
        if (parens[1]) {
          rhsTex = "\\left(".concat(rhsTex, "\\right)");
        }
        var lhsIdentifier;
        if (parenthesis === "keep") {
          lhsIdentifier = lhs.getIdentifier();
        } else {
          lhsIdentifier = lhs.getContent().getIdentifier();
        }
        switch (this.getIdentifier()) {
          case "OperatorNode:divide":
            return op + "{" + lhsTex + "}{" + rhsTex + "}";
          case "OperatorNode:pow":
            lhsTex = "{" + lhsTex + "}";
            rhsTex = "{" + rhsTex + "}";
            switch (lhsIdentifier) {
              case "ConditionalNode":
              //
              case "OperatorNode:divide":
                lhsTex = "\\left(".concat(lhsTex, "\\right)");
            }
            break;
          case "OperatorNode:multiply":
            if (this.implicit && implicit === "hide") {
              return lhsTex + "~" + rhsTex;
            }
        }
        return lhsTex + op + rhsTex;
      } else if (args.length > 2 && (this.getIdentifier() === "OperatorNode:add" || this.getIdentifier() === "OperatorNode:multiply")) {
        var texifiedArgs = args.map(function(arg, index2) {
          arg = arg.toTex(options);
          if (parens[index2]) {
            arg = "\\left(".concat(arg, "\\right)");
          }
          return arg;
        });
        if (this.getIdentifier() === "OperatorNode:multiply" && this.implicit && implicit === "hide") {
          return texifiedArgs.join("~");
        }
        return texifiedArgs.join(op);
      } else {
        return "\\mathrm{" + this.fn + "}\\left(" + args.map(function(arg) {
          return arg.toTex(options);
        }).join(",") + "\\right)";
      }
    }
    /**
     * Get identifier.
     * @return {string}
     */
    getIdentifier() {
      return this.type + ":" + this.fn;
    }
  }
  (0, import_defineProperty11.default)(OperatorNode2, "name", name37);
  return OperatorNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/ParenthesisNode.js
var import_defineProperty12 = __toESM(require_defineProperty(), 1);
var name38 = "ParenthesisNode";
var dependencies36 = ["Node"];
var createParenthesisNode = /* @__PURE__ */ factory(name38, dependencies36, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  class ParenthesisNode2 extends Node2 {
    /**
     * @constructor ParenthesisNode
     * @extends {Node}
     * A parenthesis node describes manual parenthesis from the user input
     * @param {Node} content
     * @extends {Node}
     */
    constructor(content) {
      super();
      if (!isNode(content)) {
        throw new TypeError('Node expected for parameter "content"');
      }
      this.content = content;
    }
    get type() {
      return name38;
    }
    get isParenthesisNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      return this.content._compile(math2, argNames);
    }
    /**
     * Get the content of the current Node.
     * @return {Node} content
     * @override
     **/
    getContent() {
      return this.content.getContent();
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.content, "content", this);
    }
    /**
     * Create a new ParenthesisNode whose child is the result of calling
     * the provided callback function on the child of this node.
     * @param {function(child: Node, path: string, parent: Node) : Node} callback
     * @returns {ParenthesisNode} Returns a clone of the node
     */
    map(callback) {
      var content = callback(this.content, "content", this);
      return new ParenthesisNode2(content);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {ParenthesisNode}
     */
    clone() {
      return new ParenthesisNode2(this.content);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toString(options) {
      if (!options || options && !options.parenthesis || options && options.parenthesis === "keep") {
        return "(" + this.content.toString(options) + ")";
      }
      return this.content.toString(options);
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name38,
        content: this.content
      };
    }
    /**
     * Instantiate an ParenthesisNode from its JSON representation
     * @param {Object} json  An object structured like
     *                       `{"mathjs": "ParenthesisNode", "content": ...}`,
     *                       where mathjs is optional
     * @returns {ParenthesisNode}
     */
    static fromJSON(json) {
      return new ParenthesisNode2(json.content);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toHTML(options) {
      if (!options || options && !options.parenthesis || options && options.parenthesis === "keep") {
        return '<span class="math-parenthesis math-round-parenthesis">(</span>' + this.content.toHTML(options) + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      return this.content.toHTML(options);
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toTex(options) {
      if (!options || options && !options.parenthesis || options && options.parenthesis === "keep") {
        return "\\left(".concat(this.content.toTex(options), "\\right)");
      }
      return this.content.toTex(options);
    }
  }
  (0, import_defineProperty12.default)(ParenthesisNode2, "name", name38);
  return ParenthesisNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/RangeNode.js
var import_defineProperty13 = __toESM(require_defineProperty(), 1);
var name39 = "RangeNode";
var dependencies37 = ["Node"];
var createRangeNode = /* @__PURE__ */ factory(name39, dependencies37, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  function calculateNecessaryParentheses(node, parenthesis, implicit) {
    var precedence = getPrecedence(node, parenthesis, implicit);
    var parens = {};
    var startPrecedence = getPrecedence(node.start, parenthesis, implicit);
    parens.start = startPrecedence !== null && startPrecedence <= precedence || parenthesis === "all";
    if (node.step) {
      var stepPrecedence = getPrecedence(node.step, parenthesis, implicit);
      parens.step = stepPrecedence !== null && stepPrecedence <= precedence || parenthesis === "all";
    }
    var endPrecedence = getPrecedence(node.end, parenthesis, implicit);
    parens.end = endPrecedence !== null && endPrecedence <= precedence || parenthesis === "all";
    return parens;
  }
  class RangeNode2 extends Node2 {
    /**
     * @constructor RangeNode
     * @extends {Node}
     * create a range
     * @param {Node} start  included lower-bound
     * @param {Node} end    included upper-bound
     * @param {Node} [step] optional step
     */
    constructor(start, end, step) {
      super();
      if (!isNode(start)) throw new TypeError("Node expected");
      if (!isNode(end)) throw new TypeError("Node expected");
      if (step && !isNode(step)) throw new TypeError("Node expected");
      if (arguments.length > 3) throw new Error("Too many arguments");
      this.start = start;
      this.end = end;
      this.step = step || null;
    }
    get type() {
      return name39;
    }
    get isRangeNode() {
      return true;
    }
    /**
     * Check whether the RangeNode needs the `end` symbol to be defined.
     * This end is the size of the Matrix in current dimension.
     * @return {boolean}
     */
    needsEnd() {
      var endSymbols = this.filter(function(node) {
        return isSymbolNode(node) && node.name === "end";
      });
      return endSymbols.length > 0;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var range2 = math2.range;
      var evalStart = this.start._compile(math2, argNames);
      var evalEnd = this.end._compile(math2, argNames);
      if (this.step) {
        var evalStep = this.step._compile(math2, argNames);
        return function evalRangeNode(scope, args, context) {
          return range2(evalStart(scope, args, context), evalEnd(scope, args, context), evalStep(scope, args, context));
        };
      } else {
        return function evalRangeNode(scope, args, context) {
          return range2(evalStart(scope, args, context), evalEnd(scope, args, context));
        };
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.start, "start", this);
      callback(this.end, "end", this);
      if (this.step) {
        callback(this.step, "step", this);
      }
    }
    /**
     * Create a new RangeNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {RangeNode} Returns a transformed copy of the node
     */
    map(callback) {
      return new RangeNode2(this._ifNode(callback(this.start, "start", this)), this._ifNode(callback(this.end, "end", this)), this.step && this._ifNode(callback(this.step, "step", this)));
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {RangeNode}
     */
    clone() {
      return new RangeNode2(this.start, this.end, this.step && this.step);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var parens = calculateNecessaryParentheses(this, parenthesis, options && options.implicit);
      var str;
      var start = this.start.toString(options);
      if (parens.start) {
        start = "(" + start + ")";
      }
      str = start;
      if (this.step) {
        var step = this.step.toString(options);
        if (parens.step) {
          step = "(" + step + ")";
        }
        str += ":" + step;
      }
      var end = this.end.toString(options);
      if (parens.end) {
        end = "(" + end + ")";
      }
      str += ":" + end;
      return str;
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name39,
        start: this.start,
        end: this.end,
        step: this.step
      };
    }
    /**
     * Instantiate an RangeNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     `{"mathjs": "RangeNode", "start": ..., "end": ..., "step": ...}`,
     *     where mathjs is optional
     * @returns {RangeNode}
     */
    static fromJSON(json) {
      return new RangeNode2(json.start, json.end, json.step);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var parens = calculateNecessaryParentheses(this, parenthesis, options && options.implicit);
      var str;
      var start = this.start.toHTML(options);
      if (parens.start) {
        start = '<span class="math-parenthesis math-round-parenthesis">(</span>' + start + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      str = start;
      if (this.step) {
        var step = this.step.toHTML(options);
        if (parens.step) {
          step = '<span class="math-parenthesis math-round-parenthesis">(</span>' + step + '<span class="math-parenthesis math-round-parenthesis">)</span>';
        }
        str += '<span class="math-operator math-range-operator">:</span>' + step;
      }
      var end = this.end.toHTML(options);
      if (parens.end) {
        end = '<span class="math-parenthesis math-round-parenthesis">(</span>' + end + '<span class="math-parenthesis math-round-parenthesis">)</span>';
      }
      str += '<span class="math-operator math-range-operator">:</span>' + end;
      return str;
    }
    /**
     * Get LaTeX representation
     * @params {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var parens = calculateNecessaryParentheses(this, parenthesis, options && options.implicit);
      var str = this.start.toTex(options);
      if (parens.start) {
        str = "\\left(".concat(str, "\\right)");
      }
      if (this.step) {
        var step = this.step.toTex(options);
        if (parens.step) {
          step = "\\left(".concat(step, "\\right)");
        }
        str += ":" + step;
      }
      var end = this.end.toTex(options);
      if (parens.end) {
        end = "\\left(".concat(end, "\\right)");
      }
      str += ":" + end;
      return str;
    }
  }
  (0, import_defineProperty13.default)(RangeNode2, "name", name39);
  return RangeNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/RelationalNode.js
var import_defineProperty14 = __toESM(require_defineProperty(), 1);
var name40 = "RelationalNode";
var dependencies38 = ["Node"];
var createRelationalNode = /* @__PURE__ */ factory(name40, dependencies38, (_ref) => {
  var {
    Node: Node2
  } = _ref;
  var operatorMap = {
    equal: "==",
    unequal: "!=",
    smaller: "<",
    larger: ">",
    smallerEq: "<=",
    largerEq: ">="
  };
  class RelationalNode2 extends Node2 {
    /**
     * A node representing a chained conditional expression, such as 'x > y > z'
     *
     * @param {String[]} conditionals
     *     An array of conditional operators used to compare the parameters
     * @param {Node[]} params
     *     The parameters that will be compared
     *
     * @constructor RelationalNode
     * @extends {Node}
     */
    constructor(conditionals, params) {
      super();
      if (!Array.isArray(conditionals)) {
        throw new TypeError("Parameter conditionals must be an array");
      }
      if (!Array.isArray(params)) {
        throw new TypeError("Parameter params must be an array");
      }
      if (conditionals.length !== params.length - 1) {
        throw new TypeError("Parameter params must contain exactly one more element than parameter conditionals");
      }
      this.conditionals = conditionals;
      this.params = params;
    }
    get type() {
      return name40;
    }
    get isRelationalNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math2, argNames) {
      var self2 = this;
      var compiled = this.params.map((p) => p._compile(math2, argNames));
      return function evalRelationalNode(scope, args, context) {
        var evalLhs;
        var evalRhs = compiled[0](scope, args, context);
        for (var i = 0; i < self2.conditionals.length; i++) {
          evalLhs = evalRhs;
          evalRhs = compiled[i + 1](scope, args, context);
          var condFn = getSafeProperty(math2, self2.conditionals[i]);
          if (!condFn(evalLhs, evalRhs)) {
            return false;
          }
        }
        return true;
      };
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      this.params.forEach((n, i) => callback(n, "params[" + i + "]", this), this);
    }
    /**
     * Create a new RelationalNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {RelationalNode} Returns a transformed copy of the node
     */
    map(callback) {
      return new RelationalNode2(this.conditionals.slice(), this.params.map((n, i) => this._ifNode(callback(n, "params[" + i + "]", this)), this));
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {RelationalNode}
     */
    clone() {
      return new RelationalNode2(this.conditionals, this.params);
    }
    /**
     * Get string representation.
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var precedence = getPrecedence(this, parenthesis, options && options.implicit);
      var paramStrings = this.params.map(function(p, index2) {
        var paramPrecedence = getPrecedence(p, parenthesis, options && options.implicit);
        return parenthesis === "all" || paramPrecedence !== null && paramPrecedence <= precedence ? "(" + p.toString(options) + ")" : p.toString(options);
      });
      var ret = paramStrings[0];
      for (var i = 0; i < this.conditionals.length; i++) {
        ret += " " + operatorMap[this.conditionals[i]];
        ret += " " + paramStrings[i + 1];
      }
      return ret;
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name40,
        conditionals: this.conditionals,
        params: this.params
      };
    }
    /**
     * Instantiate a RelationalNode from its JSON representation
     * @param {Object} json
     *     An object structured like
     *     `{"mathjs": "RelationalNode", "conditionals": ..., "params": ...}`,
     *     where mathjs is optional
     * @returns {RelationalNode}
     */
    static fromJSON(json) {
      return new RelationalNode2(json.conditionals, json.params);
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var precedence = getPrecedence(this, parenthesis, options && options.implicit);
      var paramStrings = this.params.map(function(p, index2) {
        var paramPrecedence = getPrecedence(p, parenthesis, options && options.implicit);
        return parenthesis === "all" || paramPrecedence !== null && paramPrecedence <= precedence ? '<span class="math-parenthesis math-round-parenthesis">(</span>' + p.toHTML(options) + '<span class="math-parenthesis math-round-parenthesis">)</span>' : p.toHTML(options);
      });
      var ret = paramStrings[0];
      for (var i = 0; i < this.conditionals.length; i++) {
        ret += '<span class="math-operator math-binary-operator math-explicit-binary-operator">' + escape(operatorMap[this.conditionals[i]]) + "</span>" + paramStrings[i + 1];
      }
      return ret;
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var parenthesis = options && options.parenthesis ? options.parenthesis : "keep";
      var precedence = getPrecedence(this, parenthesis, options && options.implicit);
      var paramStrings = this.params.map(function(p, index2) {
        var paramPrecedence = getPrecedence(p, parenthesis, options && options.implicit);
        return parenthesis === "all" || paramPrecedence !== null && paramPrecedence <= precedence ? "\\left(" + p.toTex(options) + "\right)" : p.toTex(options);
      });
      var ret = paramStrings[0];
      for (var i = 0; i < this.conditionals.length; i++) {
        ret += latexOperators[this.conditionals[i]] + paramStrings[i + 1];
      }
      return ret;
    }
  }
  (0, import_defineProperty14.default)(RelationalNode2, "name", name40);
  return RelationalNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/SymbolNode.js
var name41 = "SymbolNode";
var dependencies39 = ["math", "?Unit", "Node"];
var createSymbolNode = /* @__PURE__ */ factory(name41, dependencies39, (_ref) => {
  var {
    math: math2,
    Unit,
    Node: Node2
  } = _ref;
  function isValuelessUnit(name114) {
    return Unit ? Unit.isValuelessUnit(name114) : false;
  }
  class SymbolNode2 extends Node2 {
    /**
     * @constructor SymbolNode
     * @extends {Node}
     * A symbol node can hold and resolve a symbol
     * @param {string} name
     * @extends {Node}
     */
    constructor(name114) {
      super();
      if (typeof name114 !== "string") {
        throw new TypeError('String expected for parameter "name"');
      }
      this.name = name114;
    }
    get type() {
      return "SymbolNode";
    }
    get isSymbolNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math3, argNames) {
      var name114 = this.name;
      if (argNames[name114] === true) {
        return function(scope, args, context) {
          return getSafeProperty(args, name114);
        };
      } else if (name114 in math3) {
        return function(scope, args, context) {
          return scope.has(name114) ? scope.get(name114) : getSafeProperty(math3, name114);
        };
      } else {
        var isUnit2 = isValuelessUnit(name114);
        return function(scope, args, context) {
          return scope.has(name114) ? scope.get(name114) : isUnit2 ? new Unit(null, name114) : SymbolNode2.onUndefinedSymbol(name114);
        };
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
    }
    /**
     * Create a new SymbolNode with children produced by the given callback.
     * Trivial since a SymbolNode has no children
     * @param {function(child: Node, path: string, parent: Node) : Node} callback
     * @returns {SymbolNode} Returns a clone of the node
     */
    map(callback) {
      return this.clone();
    }
    /**
     * Throws an error 'Undefined symbol {name}'
     * @param {string} name
     */
    static onUndefinedSymbol(name114) {
      throw new Error("Undefined symbol " + name114);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {SymbolNode}
     */
    clone() {
      return new SymbolNode2(this.name);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toString(options) {
      return this.name;
    }
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toHTML(options) {
      var name114 = escape(this.name);
      if (name114 === "true" || name114 === "false") {
        return '<span class="math-symbol math-boolean">' + name114 + "</span>";
      } else if (name114 === "i") {
        return '<span class="math-symbol math-imaginary-symbol">' + name114 + "</span>";
      } else if (name114 === "Infinity") {
        return '<span class="math-symbol math-infinity-symbol">' + name114 + "</span>";
      } else if (name114 === "NaN") {
        return '<span class="math-symbol math-nan-symbol">' + name114 + "</span>";
      } else if (name114 === "null") {
        return '<span class="math-symbol math-null-symbol">' + name114 + "</span>";
      } else if (name114 === "undefined") {
        return '<span class="math-symbol math-undefined-symbol">' + name114 + "</span>";
      }
      return '<span class="math-symbol">' + name114 + "</span>";
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: "SymbolNode",
        name: this.name
      };
    }
    /**
     * Instantiate a SymbolNode from its JSON representation
     * @param {Object} json  An object structured like
     *                       `{"mathjs": "SymbolNode", name: "x"}`,
     *                       where mathjs is optional
     * @returns {SymbolNode}
     */
    static fromJSON(json) {
      return new SymbolNode2(json.name);
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     * @override
     */
    _toTex(options) {
      var isUnit2 = false;
      if (typeof math2[this.name] === "undefined" && isValuelessUnit(this.name)) {
        isUnit2 = true;
      }
      var symbol = toSymbol(this.name, isUnit2);
      if (symbol[0] === "\\") {
        return symbol;
      }
      return " " + symbol;
    }
  }
  return SymbolNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/node/FunctionNode.js
var import_defineProperty15 = __toESM(require_defineProperty(), 1);
var name42 = "FunctionNode";
var dependencies40 = ["math", "Node", "SymbolNode"];
var createFunctionNode = /* @__PURE__ */ factory(name42, dependencies40, (_ref) => {
  var _FunctionNode;
  var {
    math: math2,
    Node: Node2,
    SymbolNode: SymbolNode2
  } = _ref;
  var strin = (entity) => format3(entity, {
    truncate: 78
  });
  function expandTemplate(template, node, options) {
    var latex = "";
    var regex = /\$(?:\{([a-z_][a-z_0-9]*)(?:\[([0-9]+)\])?\}|\$)/gi;
    var inputPos = 0;
    var match;
    while ((match = regex.exec(template)) !== null) {
      latex += template.substring(inputPos, match.index);
      inputPos = match.index;
      if (match[0] === "$$") {
        latex += "$";
        inputPos++;
      } else {
        inputPos += match[0].length;
        var property = node[match[1]];
        if (!property) {
          throw new ReferenceError("Template: Property " + match[1] + " does not exist.");
        }
        if (match[2] === void 0) {
          switch (typeof property) {
            case "string":
              latex += property;
              break;
            case "object":
              if (isNode(property)) {
                latex += property.toTex(options);
              } else if (Array.isArray(property)) {
                latex += property.map(function(arg, index2) {
                  if (isNode(arg)) {
                    return arg.toTex(options);
                  }
                  throw new TypeError("Template: " + match[1] + "[" + index2 + "] is not a Node.");
                }).join(",");
              } else {
                throw new TypeError("Template: " + match[1] + " has to be a Node, String or array of Nodes");
              }
              break;
            default:
              throw new TypeError("Template: " + match[1] + " has to be a Node, String or array of Nodes");
          }
        } else {
          if (isNode(property[match[2]] && property[match[2]])) {
            latex += property[match[2]].toTex(options);
          } else {
            throw new TypeError("Template: " + match[1] + "[" + match[2] + "] is not a Node.");
          }
        }
      }
    }
    latex += template.slice(inputPos);
    return latex;
  }
  class FunctionNode2 extends Node2 {
    /**
     * @constructor FunctionNode
     * @extends {./Node}
     * invoke a list with arguments on a node
     * @param {./Node | string} fn
     *     Item resolving to a function on which to invoke
     *     the arguments, typically a SymbolNode or AccessorNode
     * @param {./Node[]} args
     */
    constructor(fn, args, optional) {
      super();
      if (typeof fn === "string") {
        fn = new SymbolNode2(fn);
      }
      if (!isNode(fn)) throw new TypeError('Node expected as parameter "fn"');
      if (!Array.isArray(args) || !args.every(isNode)) {
        throw new TypeError('Array containing Nodes expected for parameter "args"');
      }
      var optionalType = typeof optional;
      if (!(optionalType === "undefined" || optionalType === "boolean")) {
        throw new TypeError("optional flag, if specified, must be boolean");
      }
      this.fn = fn;
      this.args = args || [];
      this.optional = !!optional;
    }
    // readonly property name
    get name() {
      return this.fn.name || "";
    }
    get type() {
      return name42;
    }
    get isFunctionNode() {
      return true;
    }
    /**
     * Compile a node into a JavaScript function.
     * This basically pre-calculates as much as possible and only leaves open
     * calculations which depend on a dynamic scope with variables.
     * @param {Object} math     Math.js namespace with functions and constants.
     * @param {Object} argNames An object with argument names as key and `true`
     *                          as value. Used in the SymbolNode to optimize
     *                          for arguments from user assigned functions
     *                          (see FunctionAssignmentNode) or special symbols
     *                          like `end` (see IndexNode).
     * @return {function} Returns a function which can be called like:
     *                        evalNode(scope: Object, args: Object, context: *)
     */
    _compile(math3, argNames) {
      var evalArgs = this.args.map((arg) => arg._compile(math3, argNames));
      var fromOptionalChaining = this.optional || isAccessorNode(this.fn) && this.fn.optionalChaining;
      if (isSymbolNode(this.fn)) {
        var _name = this.fn.name;
        if (!argNames[_name]) {
          var fn = _name in math3 ? getSafeProperty(math3, _name) : void 0;
          var isRaw = typeof fn === "function" && fn.rawArgs === true;
          var resolveFn = (scope) => {
            var value;
            if (scope.has(_name)) {
              value = scope.get(_name);
            } else if (_name in math3) {
              value = getSafeProperty(math3, _name);
            } else if (fromOptionalChaining) value = void 0;
            else return FunctionNode2.onUndefinedFunction(_name);
            if (typeof value === "function" || fromOptionalChaining && value === void 0) {
              return value;
            }
            throw new TypeError("'".concat(_name, "' is not a function; its value is:\n  ").concat(strin(value)));
          };
          if (isRaw) {
            var rawArgs = this.args;
            return function evalFunctionNode(scope, args, context) {
              var fn2 = resolveFn(scope);
              if (fn2.rawArgs === true) {
                return fn2(rawArgs, math3, createSubScope(scope, args));
              } else {
                var values = evalArgs.map((evalArg) => evalArg(scope, args, context));
                return fn2(...values);
              }
            };
          } else {
            switch (evalArgs.length) {
              case 0:
                return function evalFunctionNode(scope, args, context) {
                  var fn2 = resolveFn(scope);
                  if (fromOptionalChaining && fn2 === void 0) return void 0;
                  return fn2();
                };
              case 1:
                return function evalFunctionNode(scope, args, context) {
                  var fn2 = resolveFn(scope);
                  if (fromOptionalChaining && fn2 === void 0) return void 0;
                  var evalArg0 = evalArgs[0];
                  return fn2(evalArg0(scope, args, context));
                };
              case 2:
                return function evalFunctionNode(scope, args, context) {
                  var fn2 = resolveFn(scope);
                  if (fromOptionalChaining && fn2 === void 0) return void 0;
                  var evalArg0 = evalArgs[0];
                  var evalArg1 = evalArgs[1];
                  return fn2(evalArg0(scope, args, context), evalArg1(scope, args, context));
                };
              default:
                return function evalFunctionNode(scope, args, context) {
                  var fn2 = resolveFn(scope);
                  if (fromOptionalChaining && fn2 === void 0) return void 0;
                  var values = evalArgs.map((evalArg) => evalArg(scope, args, context));
                  return fn2(...values);
                };
            }
          }
        } else {
          var _rawArgs = this.args;
          return function evalFunctionNode(scope, args, context) {
            var fn2 = getSafeProperty(args, _name);
            if (fromOptionalChaining && fn2 === void 0) return void 0;
            if (typeof fn2 !== "function") {
              throw new TypeError("Argument '".concat(_name, "' was not a function; received: ").concat(strin(fn2)));
            }
            if (fn2.rawArgs) {
              return fn2(_rawArgs, math3, createSubScope(scope, args));
            } else {
              var values = evalArgs.map((evalArg) => evalArg(scope, args, context));
              return fn2.apply(fn2, values);
            }
          };
        }
      } else if (isAccessorNode(this.fn) && isIndexNode(this.fn.index) && this.fn.index.isObjectProperty()) {
        var evalObject = this.fn.object._compile(math3, argNames);
        var prop = this.fn.index.getObjectProperty();
        var _rawArgs2 = this.args;
        return function evalFunctionNode(scope, args, context) {
          var object = evalObject(scope, args, context);
          if (fromOptionalChaining && (object == null || object[prop] === void 0)) {
            return void 0;
          }
          var fn2 = getSafeMethod(object, prop);
          if (fn2 !== null && fn2 !== void 0 && fn2.rawArgs) {
            return fn2(_rawArgs2, math3, createSubScope(scope, args));
          } else {
            var values = evalArgs.map((evalArg) => evalArg(scope, args, context));
            return fn2.apply(object, values);
          }
        };
      } else {
        var fnExpr = this.fn.toString();
        var evalFn = this.fn._compile(math3, argNames);
        var _rawArgs3 = this.args;
        return function evalFunctionNode(scope, args, context) {
          var fn2 = evalFn(scope, args, context);
          if (fromOptionalChaining && fn2 === void 0) return void 0;
          if (typeof fn2 !== "function") {
            throw new TypeError("Expression '".concat(fnExpr, "' did not evaluate to a function; value is:") + "\n  ".concat(strin(fn2)));
          }
          if (fn2.rawArgs) {
            return fn2(_rawArgs3, math3, createSubScope(scope, args));
          } else {
            var values = evalArgs.map((evalArg) => evalArg(scope, args, context));
            return fn2.apply(fn2, values);
          }
        };
      }
    }
    /**
     * Execute a callback for each of the child nodes of this node
     * @param {function(child: Node, path: string, parent: Node)} callback
     */
    forEach(callback) {
      callback(this.fn, "fn", this);
      for (var i = 0; i < this.args.length; i++) {
        callback(this.args[i], "args[" + i + "]", this);
      }
    }
    /**
     * Create a new FunctionNode whose children are the results of calling
     * the provided callback function for each child of the original node.
     * @param {function(child: Node, path: string, parent: Node): Node} callback
     * @returns {FunctionNode} Returns a transformed copy of the node
     */
    map(callback) {
      var fn = this._ifNode(callback(this.fn, "fn", this));
      var args = [];
      for (var i = 0; i < this.args.length; i++) {
        args[i] = this._ifNode(callback(this.args[i], "args[" + i + "]", this));
      }
      return new FunctionNode2(fn, args);
    }
    /**
     * Create a clone of this node, a shallow copy
     * @return {FunctionNode}
     */
    clone() {
      return new FunctionNode2(this.fn, this.args.slice(0));
    }
    /**
     * Throws an error 'Undefined function {name}'
     * @param {string} name
     */
    /**
     * Get string representation. (wrapper function)
     * This overrides parts of Node's toString function.
     * If callback is an object containing callbacks, it
     * calls the correct callback for the current node,
     * otherwise it falls back to calling Node's toString
     * function.
     *
     * @param {Object} options
     * @return {string} str
     * @override
     */
    toString(options) {
      var customString;
      var name114 = this.fn.toString(options);
      if (options && typeof options.handler === "object" && hasOwnProperty(options.handler, name114)) {
        customString = options.handler[name114](this, options);
      }
      if (typeof customString !== "undefined") {
        return customString;
      }
      return super.toString(options);
    }
    /**
     * Get string representation
     * @param {Object} options
     * @return {string} str
     */
    _toString(options) {
      var args = this.args.map(function(arg) {
        return arg.toString(options);
      });
      var fn = isFunctionAssignmentNode(this.fn) ? "(" + this.fn.toString(options) + ")" : this.fn.toString(options);
      return fn + "(" + args.join(", ") + ")";
    }
    /**
     * Get a JSON representation of the node
     * @returns {Object}
     */
    toJSON() {
      return {
        mathjs: name42,
        fn: this.fn,
        args: this.args
      };
    }
    /**
     * Instantiate an AssignmentNode from its JSON representation
     * @param {Object} json  An object structured like
     *                       `{"mathjs": "FunctionNode", fn: ..., args: ...}`,
     *                       where mathjs is optional
     * @returns {FunctionNode}
     */
    /**
     * Get HTML representation
     * @param {Object} options
     * @return {string} str
     */
    _toHTML(options) {
      var args = this.args.map(function(arg) {
        return arg.toHTML(options);
      });
      return '<span class="math-function">' + escape(this.fn) + '</span><span class="math-paranthesis math-round-parenthesis">(</span>' + args.join('<span class="math-separator">,</span>') + '<span class="math-paranthesis math-round-parenthesis">)</span>';
    }
    /**
     * Get LaTeX representation. (wrapper function)
     * This overrides parts of Node's toTex function.
     * If callback is an object containing callbacks, it
     * calls the correct callback for the current node,
     * otherwise it falls back to calling Node's toTex
     * function.
     *
     * @param {Object} options
     * @return {string}
     */
    toTex(options) {
      var customTex;
      if (options && typeof options.handler === "object" && hasOwnProperty(options.handler, this.name)) {
        customTex = options.handler[this.name](this, options);
      }
      if (typeof customTex !== "undefined") {
        return customTex;
      }
      return super.toTex(options);
    }
    /**
     * Get LaTeX representation
     * @param {Object} options
     * @return {string} str
     */
    _toTex(options) {
      var args = this.args.map(function(arg) {
        return arg.toTex(options);
      });
      var latexConverter;
      if (latexFunctions[this.name]) {
        latexConverter = latexFunctions[this.name];
      }
      if (math2[this.name] && (typeof math2[this.name].toTex === "function" || typeof math2[this.name].toTex === "object" || typeof math2[this.name].toTex === "string")) {
        latexConverter = math2[this.name].toTex;
      }
      var customToTex;
      switch (typeof latexConverter) {
        case "function":
          customToTex = latexConverter(this, options);
          break;
        case "string":
          customToTex = expandTemplate(latexConverter, this, options);
          break;
        case "object":
          switch (typeof latexConverter[args.length]) {
            case "function":
              customToTex = latexConverter[args.length](this, options);
              break;
            case "string":
              customToTex = expandTemplate(latexConverter[args.length], this, options);
              break;
          }
      }
      if (typeof customToTex !== "undefined") {
        return customToTex;
      }
      return expandTemplate(defaultTemplate, this, options);
    }
    /**
     * Get identifier.
     * @return {string}
     */
    getIdentifier() {
      return this.type + ":" + this.name;
    }
  }
  _FunctionNode = FunctionNode2;
  (0, import_defineProperty15.default)(FunctionNode2, "name", name42);
  (0, import_defineProperty15.default)(FunctionNode2, "onUndefinedFunction", function(name114) {
    throw new Error("Undefined function " + name114);
  });
  (0, import_defineProperty15.default)(FunctionNode2, "fromJSON", function(json) {
    return new _FunctionNode(json.fn, json.args);
  });
  return FunctionNode2;
}, {
  isClass: true,
  isNode: true
});

// node_modules/mathjs/lib/esm/expression/parse.js
var import_extends3 = __toESM(require_extends(), 1);
var name43 = "parse";
var dependencies41 = ["typed", "numeric", "config", "AccessorNode", "ArrayNode", "AssignmentNode", "BlockNode", "ConditionalNode", "ConstantNode", "FunctionAssignmentNode", "FunctionNode", "IndexNode", "ObjectNode", "OperatorNode", "ParenthesisNode", "RangeNode", "RelationalNode", "SymbolNode"];
var createParse = /* @__PURE__ */ factory(name43, dependencies41, (_ref) => {
  var {
    typed: typed3,
    numeric: numeric3,
    config: config4,
    AccessorNode: AccessorNode2,
    ArrayNode: ArrayNode2,
    AssignmentNode: AssignmentNode2,
    BlockNode: BlockNode2,
    ConditionalNode: ConditionalNode2,
    ConstantNode: ConstantNode2,
    FunctionAssignmentNode: FunctionAssignmentNode2,
    FunctionNode: FunctionNode2,
    IndexNode: IndexNode2,
    ObjectNode: ObjectNode2,
    OperatorNode: OperatorNode2,
    ParenthesisNode: ParenthesisNode2,
    RangeNode: RangeNode2,
    RelationalNode: RelationalNode2,
    SymbolNode: SymbolNode2
  } = _ref;
  var parse2 = typed3(name43, {
    string: function string2(expression) {
      return parseStart(expression, {});
    },
    "Array | Matrix": function Array__Matrix(expressions) {
      return parseMultiple(expressions, {});
    },
    "string, Object": function string_Object(expression, options) {
      var extraNodes = options.nodes !== void 0 ? options.nodes : {};
      return parseStart(expression, extraNodes);
    },
    "Array | Matrix, Object": parseMultiple
  });
  function parseMultiple(expressions) {
    var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    var extraNodes = options.nodes !== void 0 ? options.nodes : {};
    return deepMap2(expressions, function(elem) {
      if (typeof elem !== "string") throw new TypeError("String expected");
      return parseStart(elem, extraNodes);
    });
  }
  var TOKENTYPE = {
    NULL: 0,
    DELIMITER: 1,
    NUMBER: 2,
    SYMBOL: 3,
    UNKNOWN: 4
  };
  var DELIMITERS = {
    ",": true,
    "(": true,
    ")": true,
    "[": true,
    "]": true,
    "{": true,
    "}": true,
    '"': true,
    "'": true,
    ";": true,
    "+": true,
    "-": true,
    "*": true,
    ".*": true,
    "/": true,
    "./": true,
    "%": true,
    "^": true,
    ".^": true,
    "~": true,
    "!": true,
    "&": true,
    "|": true,
    "^|": true,
    "=": true,
    ":": true,
    "?": true,
    "?.": true,
    "??": true,
    "==": true,
    "!=": true,
    "<": true,
    ">": true,
    "<=": true,
    ">=": true,
    "<<": true,
    ">>": true,
    ">>>": true
  };
  var NAMED_DELIMITERS = {
    mod: true,
    to: true,
    in: true,
    and: true,
    xor: true,
    or: true,
    not: true
  };
  var CONSTANTS = {
    true: true,
    false: false,
    null: null,
    undefined: void 0
  };
  var NUMERIC_CONSTANTS = ["NaN", "Infinity"];
  var ESCAPE_CHARACTERS = {
    '"': '"',
    "'": "'",
    "\\": "\\",
    "/": "/",
    b: "\b",
    f: "\f",
    n: "\n",
    r: "\r",
    t: "	"
    // note that \u is handled separately in parseStringToken()
  };
  function initialState() {
    return {
      extraNodes: {},
      // current extra nodes, must be careful not to mutate
      expression: "",
      // current expression
      comment: "",
      // last parsed comment
      index: 0,
      // current index in expr
      token: "",
      // current token
      tokenType: TOKENTYPE.NULL,
      // type of the token
      nestingLevel: 0,
      // level of nesting inside parameters, used to ignore newline characters
      conditionalLevel: null
      // when a conditional is being parsed, the level of the conditional is stored here
    };
  }
  function currentString(state, length) {
    return state.expression.substr(state.index, length);
  }
  function currentCharacter(state) {
    return currentString(state, 1);
  }
  function next(state) {
    state.index++;
  }
  function prevCharacter(state) {
    return state.expression.charAt(state.index - 1);
  }
  function nextCharacter(state) {
    return state.expression.charAt(state.index + 1);
  }
  function getToken(state) {
    state.tokenType = TOKENTYPE.NULL;
    state.token = "";
    state.comment = "";
    while (true) {
      if (currentCharacter(state) === "#") {
        while (currentCharacter(state) !== "\n" && currentCharacter(state) !== "") {
          state.comment += currentCharacter(state);
          next(state);
        }
      }
      if (parse2.isWhitespace(currentCharacter(state), state.nestingLevel)) {
        next(state);
      } else {
        break;
      }
    }
    if (currentCharacter(state) === "") {
      state.tokenType = TOKENTYPE.DELIMITER;
      return;
    }
    if (currentCharacter(state) === "\n" && !state.nestingLevel) {
      state.tokenType = TOKENTYPE.DELIMITER;
      state.token = currentCharacter(state);
      next(state);
      return;
    }
    var c1 = currentCharacter(state);
    var c2 = currentString(state, 2);
    var c3 = currentString(state, 3);
    if (c3.length === 3 && DELIMITERS[c3]) {
      state.tokenType = TOKENTYPE.DELIMITER;
      state.token = c3;
      next(state);
      next(state);
      next(state);
      return;
    }
    if (c2.length === 2 && DELIMITERS[c2] && (c2 !== "?." || !parse2.isDigit(state.expression.charAt(state.index + 2)))) {
      state.tokenType = TOKENTYPE.DELIMITER;
      state.token = c2;
      next(state);
      next(state);
      return;
    }
    if (DELIMITERS[c1]) {
      state.tokenType = TOKENTYPE.DELIMITER;
      state.token = c1;
      next(state);
      return;
    }
    if (parse2.isDigitDot(c1)) {
      state.tokenType = TOKENTYPE.NUMBER;
      var _c = currentString(state, 2);
      if (_c === "0b" || _c === "0o" || _c === "0x") {
        state.token += currentCharacter(state);
        next(state);
        state.token += currentCharacter(state);
        next(state);
        while (parse2.isAlpha(currentCharacter(state), prevCharacter(state), nextCharacter(state)) || parse2.isDigit(currentCharacter(state))) {
          state.token += currentCharacter(state);
          next(state);
        }
        if (currentCharacter(state) === ".") {
          state.token += ".";
          next(state);
          while (parse2.isAlpha(currentCharacter(state), prevCharacter(state), nextCharacter(state)) || parse2.isDigit(currentCharacter(state))) {
            state.token += currentCharacter(state);
            next(state);
          }
        } else if (currentCharacter(state) === "i") {
          state.token += "i";
          next(state);
          while (parse2.isDigit(currentCharacter(state))) {
            state.token += currentCharacter(state);
            next(state);
          }
        }
        return;
      }
      if (currentCharacter(state) === ".") {
        state.token += currentCharacter(state);
        next(state);
        if (!parse2.isDigit(currentCharacter(state))) {
          state.tokenType = TOKENTYPE.DELIMITER;
          return;
        }
      } else {
        while (parse2.isDigit(currentCharacter(state))) {
          state.token += currentCharacter(state);
          next(state);
        }
        if (parse2.isDecimalMark(currentCharacter(state), nextCharacter(state))) {
          state.token += currentCharacter(state);
          next(state);
        }
      }
      while (parse2.isDigit(currentCharacter(state))) {
        state.token += currentCharacter(state);
        next(state);
      }
      if (currentCharacter(state) === "E" || currentCharacter(state) === "e") {
        if (parse2.isDigit(nextCharacter(state)) || nextCharacter(state) === "-" || nextCharacter(state) === "+") {
          state.token += currentCharacter(state);
          next(state);
          if (currentCharacter(state) === "+" || currentCharacter(state) === "-") {
            state.token += currentCharacter(state);
            next(state);
          }
          if (!parse2.isDigit(currentCharacter(state))) {
            throw createSyntaxError(state, 'Digit expected, got "' + currentCharacter(state) + '"');
          }
          while (parse2.isDigit(currentCharacter(state))) {
            state.token += currentCharacter(state);
            next(state);
          }
          if (parse2.isDecimalMark(currentCharacter(state), nextCharacter(state))) {
            throw createSyntaxError(state, 'Digit expected, got "' + currentCharacter(state) + '"');
          }
        } else if (parse2.isDecimalMark(nextCharacter(state), state.expression.charAt(state.index + 2))) {
          next(state);
          throw createSyntaxError(state, 'Digit expected, got "' + currentCharacter(state) + '"');
        }
      }
      return;
    }
    if (parse2.isAlpha(currentCharacter(state), prevCharacter(state), nextCharacter(state))) {
      while (parse2.isAlpha(currentCharacter(state), prevCharacter(state), nextCharacter(state)) || parse2.isDigit(currentCharacter(state))) {
        state.token += currentCharacter(state);
        next(state);
      }
      if (hasOwnProperty(NAMED_DELIMITERS, state.token)) {
        state.tokenType = TOKENTYPE.DELIMITER;
      } else {
        state.tokenType = TOKENTYPE.SYMBOL;
      }
      return;
    }
    state.tokenType = TOKENTYPE.UNKNOWN;
    while (currentCharacter(state) !== "") {
      state.token += currentCharacter(state);
      next(state);
    }
    throw createSyntaxError(state, 'Syntax error in part "' + state.token + '"');
  }
  function getTokenSkipNewline(state) {
    do {
      getToken(state);
    } while (state.token === "\n");
  }
  function openParams(state) {
    state.nestingLevel++;
  }
  function closeParams(state) {
    state.nestingLevel--;
  }
  parse2.isAlpha = function isAlpha(c, cPrev, cNext) {
    return parse2.isValidLatinOrGreek(c) || parse2.isValidMathSymbol(c, cNext) || parse2.isValidMathSymbol(cPrev, c);
  };
  parse2.isValidLatinOrGreek = function isValidLatinOrGreek(c) {
    return /^[a-zA-Z_$\u00C0-\u02AF\u0370-\u03FF\u2100-\u214F]$/.test(c);
  };
  parse2.isValidMathSymbol = function isValidMathSymbol(high, low) {
    return /^[\uD835]$/.test(high) && /^[\uDC00-\uDFFF]$/.test(low) && /^[^\uDC55\uDC9D\uDCA0\uDCA1\uDCA3\uDCA4\uDCA7\uDCA8\uDCAD\uDCBA\uDCBC\uDCC4\uDD06\uDD0B\uDD0C\uDD15\uDD1D\uDD3A\uDD3F\uDD45\uDD47-\uDD49\uDD51\uDEA6\uDEA7\uDFCC\uDFCD]$/.test(low);
  };
  parse2.isWhitespace = function isWhitespace(c, nestingLevel) {
    return c === " " || c === "	" || c === "\xA0" || c === "\n" && nestingLevel > 0;
  };
  parse2.isDecimalMark = function isDecimalMark(c, cNext) {
    return c === "." && cNext !== "/" && cNext !== "*" && cNext !== "^";
  };
  parse2.isDigitDot = function isDigitDot(c) {
    return c >= "0" && c <= "9" || c === ".";
  };
  parse2.isDigit = function isDigit(c) {
    return c >= "0" && c <= "9";
  };
  function parseStart(expression, extraNodes) {
    var state = initialState();
    (0, import_extends3.default)(state, {
      expression,
      extraNodes
    });
    getToken(state);
    var node = parseBlock(state);
    if (state.token !== "") {
      if (state.tokenType === TOKENTYPE.DELIMITER) {
        throw createError(state, "Unexpected operator " + state.token);
      } else {
        throw createSyntaxError(state, 'Unexpected part "' + state.token + '"');
      }
    }
    return node;
  }
  function parseBlock(state) {
    var node;
    var blocks = [];
    var visible;
    if (state.token !== "" && state.token !== "\n" && state.token !== ";") {
      node = parseAssignment(state);
      if (state.comment) {
        node.comment = state.comment;
      }
    }
    while (state.token === "\n" || state.token === ";") {
      if (blocks.length === 0 && node) {
        visible = state.token !== ";";
        blocks.push({
          node,
          visible
        });
      }
      getToken(state);
      if (state.token !== "\n" && state.token !== ";" && state.token !== "") {
        node = parseAssignment(state);
        if (state.comment) {
          node.comment = state.comment;
        }
        visible = state.token !== ";";
        blocks.push({
          node,
          visible
        });
      }
    }
    if (blocks.length > 0) {
      return new BlockNode2(blocks);
    } else {
      if (!node) {
        node = new ConstantNode2(void 0);
        if (state.comment) {
          node.comment = state.comment;
        }
      }
      return node;
    }
  }
  function parseAssignment(state) {
    var name114, args, value, valid;
    var node = parseConditional(state);
    if (state.token === "=") {
      if (isSymbolNode(node)) {
        name114 = node.name;
        getTokenSkipNewline(state);
        value = parseAssignment(state);
        return new AssignmentNode2(new SymbolNode2(name114), value);
      } else if (isAccessorNode(node)) {
        if (node.optionalChaining) {
          throw createSyntaxError(state, "Cannot assign to optional chain");
        }
        getTokenSkipNewline(state);
        value = parseAssignment(state);
        return new AssignmentNode2(node.object, node.index, value);
      } else if (isFunctionNode(node) && isSymbolNode(node.fn)) {
        valid = true;
        args = [];
        name114 = node.name;
        node.args.forEach(function(arg, index2) {
          if (isSymbolNode(arg)) {
            args[index2] = arg.name;
          } else {
            valid = false;
          }
        });
        if (valid) {
          getTokenSkipNewline(state);
          value = parseAssignment(state);
          return new FunctionAssignmentNode2(name114, args, value);
        }
      }
      throw createSyntaxError(state, "Invalid left hand side of assignment operator =");
    }
    return node;
  }
  function parseConditional(state) {
    var node = parseLogicalOr(state);
    while (state.token === "?") {
      var prev = state.conditionalLevel;
      state.conditionalLevel = state.nestingLevel;
      getTokenSkipNewline(state);
      var condition = node;
      var trueExpr = parseAssignment(state);
      if (state.token !== ":") throw createSyntaxError(state, "False part of conditional expression expected");
      state.conditionalLevel = null;
      getTokenSkipNewline(state);
      var falseExpr = parseAssignment(state);
      node = new ConditionalNode2(condition, trueExpr, falseExpr);
      state.conditionalLevel = prev;
    }
    return node;
  }
  function parseLogicalOr(state) {
    var node = parseLogicalXor(state);
    while (state.token === "or") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("or", "or", [node, parseLogicalXor(state)]);
    }
    return node;
  }
  function parseLogicalXor(state) {
    var node = parseLogicalAnd(state);
    while (state.token === "xor") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("xor", "xor", [node, parseLogicalAnd(state)]);
    }
    return node;
  }
  function parseLogicalAnd(state) {
    var node = parseBitwiseOr(state);
    while (state.token === "and") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("and", "and", [node, parseBitwiseOr(state)]);
    }
    return node;
  }
  function parseBitwiseOr(state) {
    var node = parseBitwiseXor(state);
    while (state.token === "|") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("|", "bitOr", [node, parseBitwiseXor(state)]);
    }
    return node;
  }
  function parseBitwiseXor(state) {
    var node = parseBitwiseAnd(state);
    while (state.token === "^|") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("^|", "bitXor", [node, parseBitwiseAnd(state)]);
    }
    return node;
  }
  function parseBitwiseAnd(state) {
    var node = parseRelational(state);
    while (state.token === "&") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("&", "bitAnd", [node, parseRelational(state)]);
    }
    return node;
  }
  function parseRelational(state) {
    var params = [parseShift(state)];
    var conditionals = [];
    var operators = {
      "==": "equal",
      "!=": "unequal",
      "<": "smaller",
      ">": "larger",
      "<=": "smallerEq",
      ">=": "largerEq"
    };
    while (hasOwnProperty(operators, state.token)) {
      var cond = {
        name: state.token,
        fn: operators[state.token]
      };
      conditionals.push(cond);
      getTokenSkipNewline(state);
      params.push(parseShift(state));
    }
    if (params.length === 1) {
      return params[0];
    } else if (params.length === 2) {
      return new OperatorNode2(conditionals[0].name, conditionals[0].fn, params);
    } else {
      return new RelationalNode2(conditionals.map((c) => c.fn), params);
    }
  }
  function parseShift(state) {
    var node, name114, fn, params;
    node = parseConversion(state);
    var operators = {
      "<<": "leftShift",
      ">>": "rightArithShift",
      ">>>": "rightLogShift"
    };
    while (hasOwnProperty(operators, state.token)) {
      name114 = state.token;
      fn = operators[name114];
      getTokenSkipNewline(state);
      params = [node, parseConversion(state)];
      node = new OperatorNode2(name114, fn, params);
    }
    return node;
  }
  function parseConversion(state) {
    var node, name114, fn, params;
    node = parseRange(state);
    var operators = {
      to: "to",
      in: "to"
      // alias of 'to'
    };
    while (hasOwnProperty(operators, state.token)) {
      name114 = state.token;
      fn = operators[name114];
      getTokenSkipNewline(state);
      if (name114 === "in" && "])},;".includes(state.token)) {
        node = new OperatorNode2("*", "multiply", [node, new SymbolNode2("in")], true);
      } else {
        params = [node, parseRange(state)];
        node = new OperatorNode2(name114, fn, params);
      }
    }
    return node;
  }
  function parseRange(state) {
    var node;
    var params = [];
    if (state.token === ":") {
      if (state.conditionalLevel === state.nestingLevel) {
        throw createSyntaxError(state, "The true-expression of a conditional operator may not be empty");
      } else {
        node = new ConstantNode2(1);
      }
    } else {
      node = parseAddSubtract(state);
    }
    if (state.token === ":" && state.conditionalLevel !== state.nestingLevel) {
      params.push(node);
      while (state.token === ":" && params.length < 3) {
        getTokenSkipNewline(state);
        if (state.token === ")" || state.token === "]" || state.token === "," || state.token === "") {
          params.push(new SymbolNode2("end"));
        } else {
          params.push(parseAddSubtract(state));
        }
      }
      if (params.length === 3) {
        node = new RangeNode2(params[0], params[2], params[1]);
      } else {
        node = new RangeNode2(params[0], params[1]);
      }
    }
    return node;
  }
  function parseAddSubtract(state) {
    var node, name114, fn, params;
    node = parseMultiplyDivideModulus(state);
    var operators = {
      "+": "add",
      "-": "subtract"
    };
    while (hasOwnProperty(operators, state.token)) {
      name114 = state.token;
      fn = operators[name114];
      getTokenSkipNewline(state);
      var rightNode = parseMultiplyDivideModulus(state);
      if (rightNode.isPercentage) {
        params = [node, new OperatorNode2("*", "multiply", [node, rightNode])];
      } else {
        params = [node, rightNode];
      }
      node = new OperatorNode2(name114, fn, params);
    }
    return node;
  }
  function parseMultiplyDivideModulus(state) {
    var node, last, name114, fn;
    node = parseImplicitMultiplication(state);
    last = node;
    var operators = {
      "*": "multiply",
      ".*": "dotMultiply",
      "/": "divide",
      "./": "dotDivide",
      "%": "mod",
      mod: "mod"
    };
    while (true) {
      if (hasOwnProperty(operators, state.token)) {
        name114 = state.token;
        fn = operators[name114];
        getTokenSkipNewline(state);
        last = parseImplicitMultiplication(state);
        node = new OperatorNode2(name114, fn, [node, last]);
      } else {
        break;
      }
    }
    return node;
  }
  function parseImplicitMultiplication(state) {
    var node, last;
    node = parseRule2(state);
    last = node;
    while (true) {
      if (state.tokenType === TOKENTYPE.SYMBOL || state.token === "in" && isConstantNode(node) || state.token === "in" && isOperatorNode(node) && node.fn === "unaryMinus" && isConstantNode(node.args[0]) || state.tokenType === TOKENTYPE.NUMBER && !isConstantNode(last) && (!isOperatorNode(last) || last.op === "!") || state.token === "(") {
        last = parseRule2(state);
        node = new OperatorNode2(
          "*",
          "multiply",
          [node, last],
          true
          /* implicit */
        );
      } else {
        break;
      }
    }
    return node;
  }
  function parseRule2(state) {
    var node = parseUnaryPercentage(state);
    var last = node;
    var tokenStates = [];
    while (true) {
      if (state.token === "/" && rule2Node(last)) {
        tokenStates.push((0, import_extends3.default)({}, state));
        getTokenSkipNewline(state);
        if (state.tokenType === TOKENTYPE.NUMBER) {
          tokenStates.push((0, import_extends3.default)({}, state));
          getTokenSkipNewline(state);
          if (state.tokenType === TOKENTYPE.SYMBOL || state.token === "(" || state.token === "in") {
            (0, import_extends3.default)(state, tokenStates.pop());
            tokenStates.pop();
            last = parseUnaryPercentage(state);
            node = new OperatorNode2("/", "divide", [node, last]);
          } else {
            tokenStates.pop();
            (0, import_extends3.default)(state, tokenStates.pop());
            break;
          }
        } else {
          (0, import_extends3.default)(state, tokenStates.pop());
          break;
        }
      } else {
        break;
      }
    }
    return node;
  }
  function parseUnaryPercentage(state) {
    var node = parseUnary(state);
    if (state.token === "%") {
      var previousState = (0, import_extends3.default)({}, state);
      getTokenSkipNewline(state);
      try {
        parseUnary(state);
        (0, import_extends3.default)(state, previousState);
      } catch (_unused) {
        node = new OperatorNode2("/", "divide", [node, new ConstantNode2(100)], false, true);
      }
    }
    return node;
  }
  function parseUnary(state) {
    var name114, params, fn;
    var operators = {
      "-": "unaryMinus",
      "+": "unaryPlus",
      "~": "bitNot",
      not: "not"
    };
    if (hasOwnProperty(operators, state.token)) {
      fn = operators[state.token];
      name114 = state.token;
      getTokenSkipNewline(state);
      params = [parseUnary(state)];
      return new OperatorNode2(name114, fn, params);
    }
    return parsePow(state);
  }
  function parsePow(state) {
    var node, name114, fn, params;
    node = parseNullishCoalescing(state);
    if (state.token === "^" || state.token === ".^") {
      name114 = state.token;
      fn = name114 === "^" ? "pow" : "dotPow";
      getTokenSkipNewline(state);
      params = [node, parseUnary(state)];
      node = new OperatorNode2(name114, fn, params);
    }
    return node;
  }
  function parseNullishCoalescing(state) {
    var node = parseLeftHandOperators(state);
    while (state.token === "??") {
      getTokenSkipNewline(state);
      node = new OperatorNode2("??", "nullish", [node, parseLeftHandOperators(state)]);
    }
    return node;
  }
  function parseLeftHandOperators(state) {
    var node, name114, fn, params;
    node = parseCustomNodes(state);
    var operators = {
      "!": "factorial",
      "'": "ctranspose"
    };
    while (hasOwnProperty(operators, state.token)) {
      name114 = state.token;
      fn = operators[name114];
      getToken(state);
      params = [node];
      node = new OperatorNode2(name114, fn, params);
      node = parseAccessors(state, node);
    }
    return node;
  }
  function parseCustomNodes(state) {
    var params = [];
    if (state.tokenType === TOKENTYPE.SYMBOL && hasOwnProperty(state.extraNodes, state.token)) {
      var CustomNode = state.extraNodes[state.token];
      getToken(state);
      if (state.token === "(") {
        params = [];
        openParams(state);
        getToken(state);
        if (state.token !== ")") {
          params.push(parseAssignment(state));
          while (state.token === ",") {
            getToken(state);
            params.push(parseAssignment(state));
          }
        }
        if (state.token !== ")") {
          throw createSyntaxError(state, "Parenthesis ) expected");
        }
        closeParams(state);
        getToken(state);
      }
      return new CustomNode(params);
    }
    return parseSymbol(state);
  }
  function parseSymbol(state) {
    var node, name114;
    if (state.tokenType === TOKENTYPE.SYMBOL || state.tokenType === TOKENTYPE.DELIMITER && state.token in NAMED_DELIMITERS) {
      name114 = state.token;
      getToken(state);
      if (hasOwnProperty(CONSTANTS, name114)) {
        node = new ConstantNode2(CONSTANTS[name114]);
      } else if (NUMERIC_CONSTANTS.includes(name114)) {
        node = new ConstantNode2(numeric3(name114, "number"));
      } else {
        node = new SymbolNode2(name114);
      }
      node = parseAccessors(state, node);
      return node;
    }
    return parseString(state);
  }
  function parseAccessors(state, node, types) {
    var params;
    while (true) {
      var optional = false;
      if (state.token === "?.") {
        optional = true;
        getToken(state);
      }
      var hasNextAccessor = (state.token === "(" || state.token === "[" || state.token === ".") && (!types || types.includes(state.token));
      if (!(optional || hasNextAccessor)) {
        break;
      }
      params = [];
      if (state.token === "(") {
        if (optional || isSymbolNode(node) || isAccessorNode(node)) {
          openParams(state);
          getToken(state);
          if (state.token !== ")") {
            params.push(parseAssignment(state));
            while (state.token === ",") {
              getToken(state);
              params.push(parseAssignment(state));
            }
          }
          if (state.token !== ")") {
            throw createSyntaxError(state, "Parenthesis ) expected");
          }
          closeParams(state);
          getToken(state);
          node = new FunctionNode2(node, params, optional);
        } else {
          return node;
        }
      } else if (state.token === "[") {
        openParams(state);
        getToken(state);
        if (state.token !== "]") {
          params.push(parseAssignment(state));
          while (state.token === ",") {
            getToken(state);
            params.push(parseAssignment(state));
          }
        }
        if (state.token !== "]") {
          throw createSyntaxError(state, "Parenthesis ] expected");
        }
        closeParams(state);
        getToken(state);
        node = new AccessorNode2(node, new IndexNode2(params), optional);
      } else {
        if (!optional) getToken(state);
        var isPropertyName = state.tokenType === TOKENTYPE.SYMBOL || state.tokenType === TOKENTYPE.DELIMITER && state.token in NAMED_DELIMITERS;
        if (!isPropertyName) {
          var message = "Property name expected after ";
          message += optional ? "optional chain" : "dot";
          throw createSyntaxError(state, message);
        }
        params.push(new ConstantNode2(state.token));
        getToken(state);
        var dotNotation = true;
        node = new AccessorNode2(node, new IndexNode2(params, dotNotation), optional);
      }
    }
    return node;
  }
  function parseString(state) {
    var node, str;
    if (state.token === '"' || state.token === "'") {
      str = parseStringToken(state, state.token);
      node = new ConstantNode2(str);
      node = parseAccessors(state, node);
      return node;
    }
    return parseMatrix(state);
  }
  function parseStringToken(state, quote) {
    var str = "";
    while (currentCharacter(state) !== "" && currentCharacter(state) !== quote) {
      if (currentCharacter(state) === "\\") {
        next(state);
        var char = currentCharacter(state);
        var escapeChar = ESCAPE_CHARACTERS[char];
        if (escapeChar !== void 0) {
          str += escapeChar;
          state.index += 1;
        } else if (char === "u") {
          var unicode = state.expression.slice(state.index + 1, state.index + 5);
          if (/^[0-9A-Fa-f]{4}$/.test(unicode)) {
            str += String.fromCharCode(parseInt(unicode, 16));
            state.index += 5;
          } else {
            throw createSyntaxError(state, "Invalid unicode character \\u".concat(unicode));
          }
        } else {
          throw createSyntaxError(state, "Bad escape character \\".concat(char));
        }
      } else {
        str += currentCharacter(state);
        next(state);
      }
    }
    getToken(state);
    if (state.token !== quote) {
      throw createSyntaxError(state, "End of string ".concat(quote, " expected"));
    }
    getToken(state);
    return str;
  }
  function parseMatrix(state) {
    var array, params, rows, cols;
    if (state.token === "[") {
      openParams(state);
      getToken(state);
      if (state.token !== "]") {
        var row = parseRow(state);
        if (state.token === ";") {
          rows = 1;
          params = [row];
          while (state.token === ";") {
            getToken(state);
            if (state.token !== "]") {
              params[rows] = parseRow(state);
              rows++;
            }
          }
          if (state.token !== "]") {
            throw createSyntaxError(state, "End of matrix ] expected");
          }
          closeParams(state);
          getToken(state);
          cols = params[0].items.length;
          for (var r = 1; r < rows; r++) {
            if (params[r].items.length !== cols) {
              throw createError(state, "Column dimensions mismatch (" + params[r].items.length + " !== " + cols + ")");
            }
          }
          array = new ArrayNode2(params);
        } else {
          if (state.token !== "]") {
            throw createSyntaxError(state, "End of matrix ] expected");
          }
          closeParams(state);
          getToken(state);
          array = row;
        }
      } else {
        closeParams(state);
        getToken(state);
        array = new ArrayNode2([]);
      }
      return parseAccessors(state, array);
    }
    return parseObject(state);
  }
  function parseRow(state) {
    var params = [parseAssignment(state)];
    var len = 1;
    while (state.token === ",") {
      getToken(state);
      if (state.token !== "]" && state.token !== ";") {
        params[len] = parseAssignment(state);
        len++;
      }
    }
    return new ArrayNode2(params);
  }
  function parseObject(state) {
    if (state.token === "{") {
      openParams(state);
      var key;
      var properties2 = {};
      do {
        getToken(state);
        if (state.token !== "}") {
          if (state.token === '"' || state.token === "'") {
            key = parseStringToken(state, state.token);
          } else if (state.tokenType === TOKENTYPE.SYMBOL || state.tokenType === TOKENTYPE.DELIMITER && state.token in NAMED_DELIMITERS) {
            key = state.token;
            getToken(state);
          } else {
            throw createSyntaxError(state, "Symbol or string expected as object key");
          }
          if (state.token !== ":") {
            throw createSyntaxError(state, "Colon : expected after object key");
          }
          getToken(state);
          properties2[key] = parseAssignment(state);
        }
      } while (state.token === ",");
      if (state.token !== "}") {
        throw createSyntaxError(state, "Comma , or bracket } expected after object value");
      }
      closeParams(state);
      getToken(state);
      var node = new ObjectNode2(properties2);
      node = parseAccessors(state, node);
      return node;
    }
    return parseNumber(state);
  }
  function parseNumber(state) {
    var numberStr;
    if (state.tokenType === TOKENTYPE.NUMBER) {
      numberStr = state.token;
      getToken(state);
      var numericType = safeNumberType(numberStr, config4);
      var value = numeric3(numberStr, numericType);
      return new ConstantNode2(value);
    }
    return parseParentheses(state);
  }
  function parseParentheses(state) {
    var node;
    if (state.token === "(") {
      openParams(state);
      getToken(state);
      node = parseAssignment(state);
      if (state.token !== ")") {
        throw createSyntaxError(state, "Parenthesis ) expected");
      }
      closeParams(state);
      getToken(state);
      node = new ParenthesisNode2(node);
      node = parseAccessors(state, node);
      return node;
    }
    return parseEnd(state);
  }
  function parseEnd(state) {
    if (state.token === "") {
      throw createSyntaxError(state, "Unexpected end of expression");
    } else {
      throw createSyntaxError(state, "Value expected");
    }
  }
  function col(state) {
    return state.index - state.token.length + 1;
  }
  function createSyntaxError(state, message) {
    var c = col(state);
    var error = new SyntaxError(message + " (char " + c + ")");
    error.char = c;
    return error;
  }
  function createError(state, message) {
    var c = col(state);
    var error = new SyntaxError(message + " (char " + c + ")");
    error.char = c;
    return error;
  }
  typed3.addConversion({
    from: "string",
    to: "Node",
    convert: parse2
  });
  return parse2;
});

// node_modules/mathjs/lib/esm/expression/function/compile.js
var name44 = "compile";
var dependencies42 = ["typed", "parse"];
var createCompile = /* @__PURE__ */ factory(name44, dependencies42, (_ref) => {
  var {
    typed: typed3,
    parse: parse2
  } = _ref;
  return typed3(name44, {
    string: function string2(expr) {
      return parse2(expr).compile();
    },
    "Array | Matrix": function Array__Matrix(expr) {
      return deepMap2(expr, function(entry) {
        return parse2(entry).compile();
      });
    }
  });
});

// node_modules/mathjs/lib/esm/expression/function/evaluate.js
var name45 = "evaluate";
var dependencies43 = ["typed", "parse"];
var createEvaluate = /* @__PURE__ */ factory(name45, dependencies43, (_ref) => {
  var {
    typed: typed3,
    parse: parse2
  } = _ref;
  return typed3(name45, {
    string: function string2(expr) {
      var scope = createEmptyMap();
      return parse2(expr).compile().evaluate(scope);
    },
    "string, Map | Object": function string_Map__Object(expr, scope) {
      return parse2(expr).compile().evaluate(scope);
    },
    "Array | Matrix": function Array__Matrix(expr) {
      var scope = createEmptyMap();
      return deepMap2(expr, function(entry) {
        return parse2(entry).compile().evaluate(scope);
      });
    },
    "Array | Matrix, Map | Object": function Array__Matrix_Map__Object(expr, scope) {
      return deepMap2(expr, function(entry) {
        return parse2(entry).compile().evaluate(scope);
      });
    }
  });
});

// node_modules/mathjs/lib/esm/expression/Parser.js
var name46 = "Parser";
var dependencies44 = ["evaluate", "parse"];
var createParserClass = /* @__PURE__ */ factory(name46, dependencies44, (_ref) => {
  var {
    evaluate: evaluate2,
    parse: parse2
  } = _ref;
  function Parser3() {
    if (!(this instanceof Parser3)) {
      throw new SyntaxError("Constructor must be called with the new operator");
    }
    Object.defineProperty(this, "scope", {
      value: createEmptyMap(),
      writable: false
    });
  }
  Parser3.prototype.type = "Parser";
  Parser3.prototype.isParser = true;
  Parser3.prototype.evaluate = function(expr) {
    return evaluate2(expr, this.scope);
  };
  Parser3.prototype.get = function(name114) {
    if (this.scope.has(name114)) {
      return this.scope.get(name114);
    }
  };
  Parser3.prototype.getAll = function() {
    return toObject(this.scope);
  };
  Parser3.prototype.getAllAsMap = function() {
    return this.scope;
  };
  function isValidVariableName(name114) {
    if (name114.length === 0) {
      return false;
    }
    for (var i = 0; i < name114.length; i++) {
      var cPrev = name114.charAt(i - 1);
      var c = name114.charAt(i);
      var cNext = name114.charAt(i + 1);
      var valid = parse2.isAlpha(c, cPrev, cNext) || i > 0 && parse2.isDigit(c);
      if (!valid) {
        return false;
      }
    }
    return true;
  }
  Parser3.prototype.set = function(name114, value) {
    if (!isValidVariableName(name114)) {
      throw new Error("Invalid variable name: '".concat(name114, "'. Variable names must follow the specified rules."));
    }
    this.scope.set(name114, value);
    return value;
  };
  Parser3.prototype.remove = function(name114) {
    this.scope.delete(name114);
  };
  Parser3.prototype.clear = function() {
    this.scope.clear();
  };
  Parser3.prototype.toJSON = function() {
    var json = {
      mathjs: "Parser",
      variables: {},
      functions: {}
    };
    for (var [_name2, value] of this.scope) {
      if (isFunction(value)) {
        if (!isExpressionFunction(value)) {
          throw new Error("Cannot serialize external function ".concat(_name2));
        }
        json.functions[_name2] = "".concat(value.syntax, " = ").concat(value.expr);
      } else {
        json.variables[_name2] = value;
      }
    }
    return json;
  };
  Parser3.fromJSON = function(json) {
    var parser2 = new Parser3();
    Object.entries(json.variables).forEach((_ref2) => {
      var [name114, value] = _ref2;
      return parser2.set(name114, value);
    });
    Object.entries(json.functions).forEach((_ref3) => {
      var [_name, fn] = _ref3;
      return parser2.evaluate(fn);
    });
    return parser2;
  };
  return Parser3;
}, {
  isClass: true
});
function isExpressionFunction(value) {
  return typeof value === "function" && typeof value.syntax === "string" && typeof value.expr === "string";
}

// node_modules/mathjs/lib/esm/function/matrix/mapSlices.js
var name47 = "mapSlices";
var dependencies45 = ["typed", "isInteger"];
var createMapSlices = /* @__PURE__ */ factory(name47, dependencies45, (_ref) => {
  var {
    typed: typed3,
    isInteger: isInteger4
  } = _ref;
  return typed3(name47, {
    "Array | Matrix, number | BigNumber, function": function Array__Matrix_number__BigNumber_function(mat, dim, callback) {
      if (!isInteger4(dim)) {
        throw new TypeError("Integer number expected for dimension");
      }
      var size2 = Array.isArray(mat) ? arraySize(mat) : mat.size();
      if (dim < 0 || dim >= size2.length) {
        throw new IndexError(dim, size2.length);
      }
      if (isMatrix(mat)) {
        return mat.create(_mapSlices(mat.valueOf(), dim, callback), mat.datatype());
      } else {
        return _mapSlices(mat, dim, callback);
      }
    }
  });
}, {
  formerly: "apply"
});
function _mapSlices(mat, dim, callback) {
  var i, ret, tran;
  if (dim <= 0) {
    if (!Array.isArray(mat[0])) {
      return callback(mat);
    } else {
      tran = _switch2(mat);
      ret = [];
      for (i = 0; i < tran.length; i++) {
        ret[i] = _mapSlices(tran[i], dim - 1, callback);
      }
      return ret;
    }
  } else {
    ret = [];
    for (i = 0; i < mat.length; i++) {
      ret[i] = _mapSlices(mat[i], dim - 1, callback);
    }
    return ret;
  }
}
function _switch2(mat) {
  var I = mat.length;
  var J = mat[0].length;
  var i, j;
  var ret = [];
  for (j = 0; j < J; j++) {
    var tmp = [];
    for (i = 0; i < I; i++) {
      tmp.push(mat[i][j]);
    }
    ret.push(tmp);
  }
  return ret;
}

// node_modules/mathjs/lib/esm/utils/optimizeCallback.js
var import_typed_function2 = __toESM(require_typed_function(), 1);
function optimizeCallback(callback, array, name114, isUnary) {
  if (import_typed_function2.default.isTypedFunction(callback)) {
    var numberOfArguments;
    if (isUnary) {
      numberOfArguments = 1;
    } else {
      var size2 = array.isMatrix ? array.size() : arraySize(array);
      var isEmpty = size2.length ? size2[size2.length - 1] === 0 : true;
      if (isEmpty) {
        return {
          isUnary,
          fn: callback
        };
      }
      var firstIndex = size2.map(() => 0);
      var firstValue = array.isMatrix ? array.get(firstIndex) : get(array, firstIndex);
      numberOfArguments = _findNumberOfArgumentsTyped(callback, firstValue, firstIndex, array);
    }
    var fastCallback;
    if (array.isMatrix && array.dataType !== "mixed" && array.dataType !== void 0) {
      var singleSignature = _findSingleSignatureWithArity(callback, numberOfArguments);
      fastCallback = singleSignature !== void 0 ? singleSignature : callback;
    } else {
      fastCallback = callback;
    }
    if (numberOfArguments >= 1 && numberOfArguments <= 3) {
      return {
        isUnary: numberOfArguments === 1,
        fn: function fn() {
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          return _tryFunctionWithArgs(fastCallback, args.slice(0, numberOfArguments), name114, callback.name);
        }
      };
    }
    return {
      isUnary: false,
      fn: function fn() {
        for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
          args[_key2] = arguments[_key2];
        }
        return _tryFunctionWithArgs(fastCallback, args, name114, callback.name);
      }
    };
  }
  if (isUnary === void 0) {
    return {
      isUnary: _findIfCallbackIsUnary(callback),
      fn: callback
    };
  } else {
    return {
      isUnary,
      fn: callback
    };
  }
}
function _findSingleSignatureWithArity(callback, arity) {
  var matchingFunctions = [];
  Object.entries(callback.signatures).forEach((_ref) => {
    var [signature, func] = _ref;
    if (signature.split(",").length === arity) {
      matchingFunctions.push(func);
    }
  });
  if (matchingFunctions.length === 1) {
    return matchingFunctions[0];
  }
}
function _findIfCallbackIsUnary(callback) {
  if (callback.length !== 1) return false;
  var callbackStr = callback.toString();
  if (/arguments/.test(callbackStr)) return false;
  var paramsStr = callbackStr.match(/\(.*?\)/);
  if (/\.\.\./.test(paramsStr)) return false;
  return true;
}
function _findNumberOfArgumentsTyped(callback, value, index2, array) {
  var testArgs = [value, index2, array];
  for (var i = 3; i > 0; i--) {
    var args = testArgs.slice(0, i);
    if (import_typed_function2.default.resolve(callback, args) !== null) {
      return i;
    }
  }
}
function _tryFunctionWithArgs(func, args, mappingFnName, callbackName) {
  try {
    return func(...args);
  } catch (err) {
    _createCallbackError(err, args, mappingFnName, callbackName);
  }
}
function _createCallbackError(err, args, mappingFnName, callbackName) {
  var _err$data;
  if (err instanceof TypeError && ((_err$data = err.data) === null || _err$data === void 0 ? void 0 : _err$data.category) === "wrongType") {
    var argsDesc = [];
    argsDesc.push("value: ".concat(typeOf(args[0])));
    if (args.length >= 2) {
      argsDesc.push("index: ".concat(typeOf(args[1])));
    }
    if (args.length >= 3) {
      argsDesc.push("array: ".concat(typeOf(args[2])));
    }
    throw new TypeError("Function ".concat(mappingFnName, " cannot apply callback arguments ") + "".concat(callbackName, "(").concat(argsDesc.join(", "), ") at index ").concat(JSON.stringify(args[1])));
  } else {
    throw new TypeError("Function ".concat(mappingFnName, " cannot apply callback arguments ") + "to function ".concat(callbackName, ": ").concat(err.message));
  }
}

// node_modules/mathjs/lib/esm/function/matrix/filter.js
var name48 = "filter";
var dependencies46 = ["typed"];
var createFilter = /* @__PURE__ */ factory(name48, dependencies46, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3("filter", {
    "Array, function": _filterCallback,
    "Matrix, function": function Matrix_function(x, test) {
      return x.create(_filterCallback(x.valueOf(), test), x.datatype());
    },
    "Array, RegExp": filterRegExp,
    "Matrix, RegExp": function Matrix_RegExp(x, test) {
      return x.create(filterRegExp(x.valueOf(), test), x.datatype());
    }
  });
});
function _filterCallback(x, callback) {
  var fastCallback = optimizeCallback(callback, x, "filter");
  if (fastCallback.isUnary) {
    return filter(x, fastCallback.fn);
  }
  return filter(x, function(value, index2, array) {
    return fastCallback.fn(value, [index2], array);
  });
}

// node_modules/mathjs/lib/esm/function/matrix/forEach.js
var name49 = "forEach";
var dependencies47 = ["typed"];
var createForEach = /* @__PURE__ */ factory(name49, dependencies47, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name49, {
    "Array, function": _forEach,
    "Matrix, function": function Matrix_function(x, callback) {
      x.forEach(callback);
    }
  });
});
function _forEach(array, callback) {
  var fastCallback = optimizeCallback(callback, array, name49);
  deepForEach(array, fastCallback.fn, fastCallback.isUnary);
}

// node_modules/mathjs/lib/esm/function/matrix/map.js
var name50 = "map";
var dependencies48 = ["typed"];
var createMap2 = /* @__PURE__ */ factory(name50, dependencies48, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name50, {
    "Array, function": _mapArray,
    "Matrix, function": function Matrix_function(x, callback) {
      return x.map(callback);
    },
    "Array|Matrix, Array|Matrix, ...Array|Matrix|function": (A, B, rest) => _mapMultiple([A, B, ...rest.slice(0, rest.length - 1)], rest[rest.length - 1])
  });
  function _mapMultiple(Arrays, multiCallback) {
    if (typeof multiCallback !== "function") {
      throw new Error("Last argument must be a callback function");
    }
    var firstArrayIsMatrix = Arrays[0].isMatrix;
    var sizes = Arrays.map((M) => M.isMatrix ? M.size() : arraySize(M));
    var newSize = broadcastSizes(...sizes);
    var numberOfArrays = Arrays.length;
    var _get = firstArrayIsMatrix ? (matrix2, idx) => matrix2.get(idx) : get;
    var firstValues = Arrays.map((collection, i) => {
      var firstIndex = sizes[i].map(() => 0);
      return collection.isMatrix ? collection.get(firstIndex) : get(collection, firstIndex);
    });
    var callbackArgCount = typed3.isTypedFunction(multiCallback) ? _getTypedCallbackArgCount(multiCallback, firstValues, newSize.map(() => 0), Arrays) : _getCallbackArgCount(multiCallback, numberOfArrays);
    if (callbackArgCount < 2) {
      var _callback = _getLimitedCallback(callbackArgCount, multiCallback, null);
      return mapMultiple(Arrays, _callback);
    }
    var broadcastedArrays = firstArrayIsMatrix ? Arrays.map((M) => M.isMatrix ? M.create(broadcastTo(M.toArray(), newSize), M.datatype()) : Arrays[0].create(broadcastTo(M.valueOf(), newSize))) : Arrays.map((M) => M.isMatrix ? broadcastTo(M.toArray(), newSize) : broadcastTo(M, newSize));
    var callback = _getLimitedCallback(callbackArgCount, multiCallback, broadcastedArrays);
    var broadcastedArraysCallback = (x, idx) => callback([x, ...broadcastedArrays.slice(1).map((array) => _get(array, idx))], idx);
    if (firstArrayIsMatrix) {
      return broadcastedArrays[0].map(broadcastedArraysCallback);
    } else {
      return _mapArray(broadcastedArrays[0], broadcastedArraysCallback);
    }
  }
  function mapMultiple(collections, callback) {
    var firstCollection = collections[0];
    var arrays = collections.map((collection) => collection.isMatrix ? collection.valueOf() : collection);
    var sizes = collections.map((collection) => collection.isMatrix ? collection.size() : arraySize(collection));
    var finalSize = broadcastSizes(...sizes);
    var offsets = sizes.map((size2) => finalSize.length - size2.length);
    var maxDepth = finalSize.length - 1;
    var callbackUsesIndex = callback.length > 1;
    var index2 = callbackUsesIndex ? [] : null;
    var resultsArray = iterate(arrays, 0);
    if (firstCollection.isMatrix) {
      var resultsMatrix = firstCollection.create();
      resultsMatrix._data = resultsArray;
      resultsMatrix._size = finalSize;
      return resultsMatrix;
    } else {
      return resultsArray;
    }
    function iterate(arrays2) {
      var depth = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
      var currentDimensionSize = finalSize[depth];
      var result = Array(currentDimensionSize);
      if (depth < maxDepth) {
        var _loop = function _loop3(i2) {
          if (index2) index2[depth] = i2;
          result[i2] = iterate(arrays2.map((array, arrayIndex) => offsets[arrayIndex] > depth ? array : array.length === 1 ? array[0] : array[i2]), depth + 1);
        };
        for (var i = 0; i < currentDimensionSize; i++) {
          _loop(i);
        }
      } else {
        var _loop2 = function _loop22(_i2) {
          if (index2) index2[depth] = _i2;
          result[_i2] = callback(arrays2.map((a) => a.length === 1 ? a[0] : a[_i2]), index2 ? index2.slice() : void 0);
        };
        for (var _i = 0; _i < currentDimensionSize; _i++) {
          _loop2(_i);
        }
      }
      return result;
    }
  }
  function _getLimitedCallback(callbackArgCount, multiCallback, broadcastedArrays) {
    switch (callbackArgCount) {
      case 0:
        return (x) => multiCallback(...x);
      case 1:
        return (x, idx) => multiCallback(...x, idx);
      case 2:
        return (x, idx) => multiCallback(...x, idx, ...broadcastedArrays);
    }
  }
  function _getCallbackArgCount(callback, numberOfArrays) {
    var callbackStr = callback.toString();
    if (/arguments/.test(callbackStr)) return 2;
    var paramsStr = callbackStr.match(/\(.*?\)/);
    if (/\.\.\./.test(paramsStr)) return 2;
    if (callback.length > numberOfArrays + 1) {
      return 2;
    }
    if (callback.length === numberOfArrays + 1) {
      return 1;
    }
    return 0;
  }
  function _getTypedCallbackArgCount(callback, values, idx, arrays) {
    if (typed3.resolve(callback, [...values, idx, ...arrays]) !== null) {
      return 2;
    }
    if (typed3.resolve(callback, [...values, idx]) !== null) {
      return 1;
    }
    if (typed3.resolve(callback, values) !== null) {
      return 0;
    }
    return 0;
  }
  function _mapArray(array, callback) {
    var fastCallback = optimizeCallback(callback, array, name50);
    return deepMap(array, fastCallback.fn, fastCallback.isUnary);
  }
});

// node_modules/mathjs/lib/esm/function/matrix/range.js
var name51 = "range";
var dependencies49 = ["typed", "config", "?matrix", "?bignumber", "equal", "smaller", "smallerEq", "larger", "largerEq", "add", "isZero", "isPositive"];
var createRange = /* @__PURE__ */ factory(name51, dependencies49, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    matrix: matrix2,
    bignumber,
    smaller: smaller2,
    smallerEq: smallerEq2,
    larger: larger2,
    largerEq: largerEq2,
    add: add3,
    isZero: isZero2,
    isPositive: isPositive2
  } = _ref;
  return typed3(name51, {
    // TODO: simplify signatures when typed-function supports default values and optional arguments
    string: _strRange,
    "string, boolean": _strRange,
    number: function number2(oops) {
      throw new TypeError("Too few arguments to function range(): ".concat(oops));
    },
    boolean: function boolean2(oops) {
      throw new TypeError("Unexpected type of argument 1 to function range(): ".concat(oops, ", number|bigint|BigNumber|Fraction"));
    },
    "number, number": function number_number(start, end) {
      return _out(_range(start, end, 1, false));
    },
    "number, number, number": function number_number_number(start, end, step) {
      return _out(_range(start, end, step, false));
    },
    "number, number, boolean": function number_number_boolean(start, end, includeEnd) {
      return _out(_range(start, end, 1, includeEnd));
    },
    "number, number, number, boolean": function number_number_number_boolean(start, end, step, includeEnd) {
      return _out(_range(start, end, step, includeEnd));
    },
    // Handle bigints; if either limit is bigint, range should be too
    "bigint, bigint|number": function bigint_bigintNumber(start, end) {
      return _out(_range(start, end, 1n, false));
    },
    "number, bigint": function number_bigint(start, end) {
      return _out(_range(BigInt(start), end, 1n, false));
    },
    "bigint, bigint|number, bigint|number": function bigint_bigintNumber_bigintNumber(start, end, step) {
      return _out(_range(start, end, BigInt(step), false));
    },
    "number, bigint, bigint|number": function number_bigint_bigintNumber(start, end, step) {
      return _out(_range(BigInt(start), end, BigInt(step), false));
    },
    "bigint, bigint|number, boolean": function bigint_bigintNumber_boolean(start, end, includeEnd) {
      return _out(_range(start, end, 1n, includeEnd));
    },
    "number, bigint, boolean": function number_bigint_boolean(start, end, includeEnd) {
      return _out(_range(BigInt(start), end, 1n, includeEnd));
    },
    "bigint, bigint|number, bigint|number, boolean": function bigint_bigintNumber_bigintNumber_boolean(start, end, step, includeEnd) {
      return _out(_range(start, end, BigInt(step), includeEnd));
    },
    "number, bigint, bigint|number, boolean": function number_bigint_bigintNumber_boolean(start, end, step, includeEnd) {
      return _out(_range(BigInt(start), end, BigInt(step), includeEnd));
    },
    "BigNumber, BigNumber": function BigNumber_BigNumber(start, end) {
      var BigNumber = start.constructor;
      return _out(_range(start, end, new BigNumber(1), false));
    },
    "BigNumber, BigNumber, BigNumber": function BigNumber_BigNumber_BigNumber(start, end, step) {
      return _out(_range(start, end, step, false));
    },
    "BigNumber, BigNumber, boolean": function BigNumber_BigNumber_boolean(start, end, includeEnd) {
      var BigNumber = start.constructor;
      return _out(_range(start, end, new BigNumber(1), includeEnd));
    },
    "BigNumber, BigNumber, BigNumber, boolean": function BigNumber_BigNumber_BigNumber_boolean(start, end, step, includeEnd) {
      return _out(_range(start, end, step, includeEnd));
    },
    "Fraction, Fraction": function Fraction_Fraction(start, end) {
      return _out(_range(start, end, 1, false));
    },
    "Fraction, Fraction, Fraction": function Fraction_Fraction_Fraction(start, end, step) {
      return _out(_range(start, end, step, false));
    },
    "Fraction, Fraction, boolean": function Fraction_Fraction_boolean(start, end, includeEnd) {
      return _out(_range(start, end, 1, includeEnd));
    },
    "Fraction, Fraction, Fraction, boolean": function Fraction_Fraction_Fraction_boolean(start, end, step, includeEnd) {
      return _out(_range(start, end, step, includeEnd));
    },
    "Unit, Unit, Unit": function Unit_Unit_Unit(start, end, step) {
      return _out(_range(start, end, step, false));
    },
    "Unit, Unit, Unit, boolean": function Unit_Unit_Unit_boolean(start, end, step, includeEnd) {
      return _out(_range(start, end, step, includeEnd));
    }
  });
  function _out(arr) {
    if (config4.matrix === "Matrix") {
      return matrix2 ? matrix2(arr) : noMatrix();
    }
    return arr;
  }
  function _strRange(str, includeEnd) {
    var r = _parse(str);
    if (!r) {
      throw new SyntaxError('String "' + str + '" is no valid range');
    }
    if (config4.number === "BigNumber") {
      if (bignumber === void 0) {
        noBignumber();
      }
      return _out(_range(bignumber(r.start), bignumber(r.end), bignumber(r.step)), includeEnd);
    } else {
      return _out(_range(r.start, r.end, r.step, includeEnd));
    }
  }
  function _range(start, end, step, includeEnd) {
    var array = [];
    if (isZero2(step)) throw new Error("Step must be non-zero");
    var ongoing = isPositive2(step) ? includeEnd ? smallerEq2 : smaller2 : includeEnd ? largerEq2 : larger2;
    var x = start;
    while (ongoing(x, end)) {
      array.push(x);
      x = add3(x, step);
    }
    return array;
  }
  function _parse(str) {
    var args = str.split(":");
    var nums = args.map(function(arg) {
      return Number(arg);
    });
    var invalid = nums.some(function(num) {
      return isNaN(num);
    });
    if (invalid) {
      return null;
    }
    switch (nums.length) {
      case 2:
        return {
          start: nums[0],
          end: nums[1],
          step: 1
        };
      case 3:
        return {
          start: nums[0],
          end: nums[2],
          step: nums[1]
        };
      default:
        return null;
    }
  }
});

// node_modules/mathjs/lib/esm/function/matrix/size.js
var name52 = "size";
var dependencies50 = ["typed"];
var createSize = /* @__PURE__ */ factory(name52, dependencies50, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name52, {
    Matrix: (x) => x.size(),
    Array: arraySize,
    string: (x) => [x.length],
    // scalar
    "number | Complex | BigNumber | Unit | boolean | null": (_x) => []
  });
});

// node_modules/mathjs/lib/esm/function/matrix/partitionSelect.js
var name53 = "partitionSelect";
var dependencies51 = ["typed", "isNumeric", "isNaN", "compare"];
var createPartitionSelect = /* @__PURE__ */ factory(name53, dependencies51, (_ref) => {
  var {
    typed: typed3,
    isNumeric: isNumeric2,
    isNaN: mathIsNaN,
    compare: compare2
  } = _ref;
  var asc = compare2;
  var desc = (a, b) => -compare2(a, b);
  return typed3(name53, {
    "Array | Matrix, number": function Array__Matrix_number(x, k) {
      return _partitionSelect(x, k, asc);
    },
    "Array | Matrix, number, string": function Array__Matrix_number_string(x, k, compare3) {
      if (compare3 === "asc") {
        return _partitionSelect(x, k, asc);
      } else if (compare3 === "desc") {
        return _partitionSelect(x, k, desc);
      } else {
        throw new Error('Compare string must be "asc" or "desc"');
      }
    },
    "Array | Matrix, number, function": _partitionSelect
  });
  function _partitionSelect(x, k, compare3) {
    if (!isInteger2(k) || k < 0) {
      throw new Error("k must be a non-negative integer");
    }
    if (isMatrix(x)) {
      var size2 = x.size();
      if (size2.length > 1) {
        throw new Error("Only one dimensional matrices supported");
      }
      return quickSelect(x.valueOf(), k, compare3);
    }
    if (Array.isArray(x)) {
      return quickSelect(x, k, compare3);
    }
  }
  function quickSelect(arr, k, compare3) {
    if (k >= arr.length) {
      throw new Error("k out of bounds");
    }
    for (var i = 0; i < arr.length; i++) {
      if (isNumeric2(arr[i]) && mathIsNaN(arr[i])) {
        return arr[i];
      }
    }
    var from = 0;
    var to = arr.length - 1;
    while (from < to) {
      var r = from;
      var w = to;
      var pivot = arr[Math.floor(Math.random() * (to - from + 1)) + from];
      while (r < w) {
        if (compare3(arr[r], pivot) >= 0) {
          var tmp = arr[w];
          arr[w] = arr[r];
          arr[r] = tmp;
          --w;
        } else {
          ++r;
        }
      }
      if (compare3(arr[r], pivot) > 0) {
        --r;
      }
      if (k <= r) {
        to = r;
      } else {
        from = r + 1;
      }
    }
    return arr[k];
  }
});

// node_modules/mathjs/lib/esm/function/probability/bernoulli.js
var name54 = "bernoulli";
var dependencies52 = ["typed", "config", "isInteger", "number", "?BigNumber", "?Fraction"];
var createBernoulli = /* @__PURE__ */ factory(name54, dependencies52, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    number: number2,
    BigNumber: _BigNumber,
    Fraction
  } = _ref;
  var numberCache = [void 0];
  var fractionCache = [void 0];
  var bigCache = [void 0];
  var cachedPrecision = 50;
  return typed3(name54, {
    number: (index2) => _bernoulli(index2, (n) => n, numberCache, (a, b) => a + b, (a, b) => a * b, (a, b) => a / b),
    "bigint | Fraction": (index2) => _bernoulli(number2(index2), (n) => new Fraction(n), fractionCache, (a, b) => a.add(b), (a, b) => a.mul(b), (a, b) => a.div(b)),
    BigNumber: (index2) => {
      if (config4.precision !== cachedPrecision) {
        bigCache = [void 0];
        cachedPrecision = config4.precision;
      }
      return _bernoulli(number2(index2), (n) => new _BigNumber(n), bigCache, (a, b) => a.add(b), (a, b) => a.mul(b), (a, b) => a.div(b));
    }
  });
});
function _bernoulli(index2, promote, A, plus, times, divide3) {
  if (index2 < 0 || !isInteger2(index2)) {
    throw new RangeError("Bernoulli index must be nonnegative integer");
  }
  if (index2 === 0) return promote(1);
  if (index2 === 1) return divide3(promote(-1), promote(2));
  if (index2 % 2 === 1) return promote(0);
  var one = promote(1);
  if (A.length === 1) {
    A.push([divide3(one, promote(-3)), divide3(one, promote(-2)), divide3(one, promote(6))]);
  }
  var half = index2 / 2;
  var zero = promote(0);
  var two = promote(2);
  while (A.length <= half) {
    var i = A.length;
    var lim = Math.floor((i + 1) / 2);
    var a = zero;
    for (var m = 1; m < lim; ++m) {
      a = plus(a, times(A[m][0], A[i - m][0]));
    }
    a = times(a, two);
    if (i % 2 === 0) a = plus(a, times(A[lim][0], A[lim][0]));
    a = divide3(a, promote(-(2 * i + 1)));
    var prefactor = divide3(times(A[i - 1][1], promote(-i * (2 * i - 1))), two);
    A.push([a, prefactor, times(prefactor, a)]);
  }
  return A[half][2];
}

// node_modules/mathjs/lib/esm/function/probability/combinationsWithRep.js
var name55 = "combinationsWithRep";
var dependencies53 = ["typed"];
var createCombinationsWithRep = /* @__PURE__ */ factory(name55, dependencies53, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name55, {
    "number, number": function number_number(n, k) {
      if (!isInteger2(n) || n < 0) {
        throw new TypeError("Positive integer value expected in function combinationsWithRep");
      }
      if (!isInteger2(k) || k < 0) {
        throw new TypeError("Positive integer value expected in function combinationsWithRep");
      }
      if (n < 1) {
        throw new TypeError("k must be less than or equal to n + k - 1");
      }
      if (k < n - 1) {
        var _prodrange = product(n, n + k - 1);
        return _prodrange / product(1, k);
      }
      var prodrange = product(k + 1, n + k - 1);
      return prodrange / product(1, n - 1);
    },
    "BigNumber, BigNumber": function BigNumber_BigNumber(n, k) {
      var BigNumber = n.constructor;
      var result, i;
      var one = new BigNumber(1);
      var nMinusOne = n.minus(one);
      if (!isPositiveInteger(n) || !isPositiveInteger(k)) {
        throw new TypeError("Positive integer value expected in function combinationsWithRep");
      }
      if (n.lt(one)) {
        throw new TypeError("k must be less than or equal to n + k - 1 in function combinationsWithRep");
      }
      result = one;
      if (k.lt(nMinusOne)) {
        for (i = one; i.lte(nMinusOne); i = i.plus(one)) {
          result = result.times(k.plus(i)).dividedBy(i);
        }
      } else {
        for (i = one; i.lte(k); i = i.plus(one)) {
          result = result.times(nMinusOne.plus(i)).dividedBy(i);
        }
      }
      return result;
    }
  });
});
function isPositiveInteger(n) {
  return n.isInteger() && n.gte(0);
}

// node_modules/mathjs/lib/esm/function/probability/factorial.js
var name56 = "factorial";
var dependencies54 = ["typed", "gamma"];
var createFactorial = /* @__PURE__ */ factory(name56, dependencies54, (_ref) => {
  var {
    typed: typed3,
    gamma: gamma3
  } = _ref;
  return typed3(name56, {
    number: function number2(n) {
      if (n < 0) {
        throw new Error("Value must be non-negative");
      }
      return gamma3(n + 1);
    },
    BigNumber: function BigNumber(n) {
      if (n.isNegative()) {
        throw new Error("Value must be non-negative");
      }
      return gamma3(n.plus(1));
    },
    "Array | Matrix": typed3.referToSelf((self2) => (n) => deepMap2(n, self2))
  });
});

// node_modules/mathjs/lib/esm/function/probability/multinomial.js
var name57 = "multinomial";
var dependencies55 = ["typed", "add", "divide", "multiply", "factorial", "isInteger", "isPositive"];
var createMultinomial = /* @__PURE__ */ factory(name57, dependencies55, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    divide: divide3,
    multiply: multiply2,
    factorial: factorial2,
    isInteger: isInteger4,
    isPositive: isPositive2
  } = _ref;
  return typed3(name57, {
    "Array | Matrix": function Array__Matrix(a) {
      var sum3 = 0;
      var denom = 1;
      deepForEach2(a, function(ai) {
        if (!isInteger4(ai) || !isPositive2(ai)) {
          throw new TypeError("Positive integer value expected in function multinomial");
        }
        sum3 = add3(sum3, ai);
        denom = multiply2(denom, factorial2(ai));
      });
      return divide3(factorial2(sum3), denom);
    }
  });
});

// node_modules/mathjs/lib/esm/function/probability/permutations.js
var name58 = "permutations";
var dependencies56 = ["typed", "factorial"];
var createPermutations = /* @__PURE__ */ factory(name58, dependencies56, (_ref) => {
  var {
    typed: typed3,
    factorial: factorial2
  } = _ref;
  return typed3(name58, {
    "number | BigNumber": factorial2,
    "number, number": function number_number(n, k) {
      if (!isInteger2(n) || n < 0) {
        throw new TypeError("Positive integer value expected in function permutations");
      }
      if (!isInteger2(k) || k < 0) {
        throw new TypeError("Positive integer value expected in function permutations");
      }
      if (k > n) {
        throw new TypeError("second argument k must be less than or equal to first argument n");
      }
      return product(n - k + 1, n);
    },
    "BigNumber, BigNumber": function BigNumber_BigNumber(n, k) {
      var result, i;
      if (!isPositiveInteger2(n) || !isPositiveInteger2(k)) {
        throw new TypeError("Positive integer value expected in function permutations");
      }
      if (k.gt(n)) {
        throw new TypeError("second argument k must be less than or equal to first argument n");
      }
      var one = n.mul(0).add(1);
      result = one;
      for (i = n.minus(k).plus(1); i.lte(n); i = i.plus(1)) {
        result = result.times(i);
      }
      return result;
    }
    // TODO: implement support for collection in permutations
  });
});
function isPositiveInteger2(n) {
  return n.isInteger() && n.gte(0);
}

// node_modules/mathjs/lib/esm/function/probability/util/seededRNG.js
var import_seedrandom = __toESM(require_seedrandom2(), 1);
var singletonRandom = /* @__PURE__ */ (0, import_seedrandom.default)(Date.now());
function createRng(randomSeed) {
  var random3;
  function setSeed(seed) {
    random3 = seed === null ? singletonRandom : (0, import_seedrandom.default)(String(seed));
  }
  setSeed(randomSeed);
  function rng() {
    return random3();
  }
  return rng;
}

// node_modules/mathjs/lib/esm/function/probability/pickRandom.js
var name59 = "pickRandom";
var dependencies57 = ["typed", "config", "?on"];
var createPickRandom = /* @__PURE__ */ factory(name59, dependencies57, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    on
  } = _ref;
  var rng = createRng(config4.randomSeed);
  if (on) {
    on("config", function(curr, prev) {
      if (curr.randomSeed !== prev.randomSeed) {
        rng = createRng(curr.randomSeed);
      }
    });
  }
  return typed3(name59, {
    "Array | Matrix": function Array__Matrix(possibles) {
      return _pickRandom(possibles, {});
    },
    "Array | Matrix, Object": function Array__Matrix_Object(possibles, options) {
      return _pickRandom(possibles, options);
    },
    "Array | Matrix, number": function Array__Matrix_number(possibles, number2) {
      return _pickRandom(possibles, {
        number: number2
      });
    },
    "Array | Matrix, Array | Matrix": function Array__Matrix_Array__Matrix(possibles, weights) {
      return _pickRandom(possibles, {
        weights
      });
    },
    "Array | Matrix, Array | Matrix, number": function Array__Matrix_Array__Matrix_number(possibles, weights, number2) {
      return _pickRandom(possibles, {
        number: number2,
        weights
      });
    },
    "Array | Matrix, number, Array | Matrix": function Array__Matrix_number_Array__Matrix(possibles, number2, weights) {
      return _pickRandom(possibles, {
        number: number2,
        weights
      });
    }
  });
  function _pickRandom(possibles, _ref2) {
    var {
      number: number2,
      weights,
      elementWise = true
    } = _ref2;
    var single = typeof number2 === "undefined";
    if (single) {
      number2 = 1;
    }
    var createMatrix2 = isMatrix(possibles) ? possibles.create : isMatrix(weights) ? weights.create : null;
    possibles = possibles.valueOf();
    if (weights) {
      weights = weights.valueOf();
    }
    if (elementWise === true) {
      possibles = flatten(possibles);
      weights = flatten(weights);
    }
    var totalWeights = 0;
    if (typeof weights !== "undefined") {
      if (weights.length !== possibles.length) {
        throw new Error("Weights must have the same length as possibles");
      }
      for (var i = 0, len = weights.length; i < len; i++) {
        if (!isNumber(weights[i]) || weights[i] < 0) {
          throw new Error("Weights must be an array of positive numbers");
        }
        totalWeights += weights[i];
      }
    }
    var length = possibles.length;
    var result = [];
    var pick;
    while (result.length < number2) {
      if (typeof weights === "undefined") {
        pick = possibles[Math.floor(rng() * length)];
      } else {
        var randKey = rng() * totalWeights;
        for (var _i = 0, _len = possibles.length; _i < _len; _i++) {
          randKey -= weights[_i];
          if (randKey < 0) {
            pick = possibles[_i];
            break;
          }
        }
      }
      result.push(pick);
    }
    return single ? result[0] : createMatrix2 ? createMatrix2(result) : result;
  }
});

// node_modules/mathjs/lib/esm/function/probability/util/randomMatrix.js
function randomMatrix(size2, random3) {
  var data = [];
  size2 = size2.slice(0);
  if (size2.length > 1) {
    for (var i = 0, length = size2.shift(); i < length; i++) {
      data.push(randomMatrix(size2, random3));
    }
  } else {
    for (var _i = 0, _length = size2.shift(); _i < _length; _i++) {
      data.push(random3());
    }
  }
  return data;
}

// node_modules/mathjs/lib/esm/function/probability/random.js
var name60 = "random";
var createRandomNumber = /* @__PURE__ */ factory(name60, ["typed", "config", "?on"], (_ref2) => {
  var {
    typed: typed3,
    config: config4,
    on,
    matrix: matrix2
  } = _ref2;
  var rng = createRng(config4.randomSeed);
  if (on) {
    on("config", function(curr, prev) {
      if (curr.randomSeed !== prev.randomSeed) {
        rng = createRng(curr.randomSeed);
      }
    });
  }
  return typed3(name60, {
    "": () => _random(0, 1),
    number: (max3) => _random(0, max3),
    "number, number": (min3, max3) => _random(min3, max3)
  });
  function _random(min3, max3) {
    return min3 + rng() * (max3 - min3);
  }
});

// node_modules/mathjs/lib/esm/function/probability/randomInt.js
var name61 = "randomInt";
var dependencies58 = ["typed", "config", "log2", "?on"];
var createRandomInt = /* @__PURE__ */ factory(name61, dependencies58, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    log2: log25,
    on
  } = _ref;
  var rng = createRng(config4.randomSeed);
  if (on) {
    on("config", function(curr, prev) {
      if (curr.randomSeed !== prev.randomSeed) {
        rng = createRng(curr.randomSeed);
      }
    });
  }
  return typed3(name61, {
    "": () => _randomInt(0, 2),
    number: (max3) => _randomInt(0, max3),
    "number, number": (min3, max3) => _randomInt(min3, max3),
    bigint: (max3) => _randomBigint(0n, max3),
    "bigint, bigint": _randomBigint,
    "Array | Matrix": (size2) => _randomIntMatrix(size2, 0, 1),
    "Array | Matrix, number": (size2, max3) => _randomIntMatrix(size2, 0, max3),
    "Array | Matrix, number, number": (size2, min3, max3) => _randomIntMatrix(size2, min3, max3)
  });
  function _randomIntMatrix(size2, min3, max3) {
    var res = randomMatrix(size2.valueOf(), () => _randomInt(min3, max3));
    return isMatrix(size2) ? size2.create(res, "number") : res;
  }
  function _randomInt(min3, max3) {
    return Math.floor(min3 + rng() * (max3 - min3));
  }
  function _randomBigint(min3, max3) {
    var simpleCutoff = 2n ** 30n;
    var width = max3 - min3;
    if (width <= simpleCutoff) {
      return min3 + BigInt(_randomInt(0, Number(width)));
    }
    var bits = log25(width);
    var picked = width;
    while (picked >= width) {
      picked = 0n;
      for (var i = 0; i < bits; ++i) {
        picked = 2n * picked + (rng() < 0.5 ? 0n : 1n);
      }
    }
    return min3 + picked;
  }
});

// node_modules/mathjs/lib/esm/function/relational/equalScalar.js
var name62 = "equalScalar";
var createEqualScalarNumber = factory(name62, ["typed", "config"], (_ref2) => {
  var {
    typed: typed3,
    config: config4
  } = _ref2;
  return typed3(name62, {
    "number, number": function number_number(x, y) {
      return nearlyEqual(x, y, config4.relTol, config4.absTol);
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/compare.js
var name63 = "compare";
var createCompareNumber = /* @__PURE__ */ factory(name63, ["typed", "config"], (_ref2) => {
  var {
    typed: typed3,
    config: config4
  } = _ref2;
  return typed3(name63, {
    "number, number": function number_number(x, y) {
      return nearlyEqual(x, y, config4.relTol, config4.absTol) ? 0 : x > y ? 1 : -1;
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/compareNatural.js
var import_javascript_natural_sort = __toESM(require_naturalSort(), 1);
var name64 = "compareNatural";
var dependencies59 = ["typed", "compare"];
var createCompareNatural = /* @__PURE__ */ factory(name64, dependencies59, (_ref) => {
  var {
    typed: typed3,
    compare: compare2
  } = _ref;
  var compareBooleans = compare2.signatures["boolean,boolean"];
  return typed3(name64, {
    "any, any": _compareNatural
  });
  function _compareNatural(x, y) {
    var typeX = typeOf(x);
    var typeY = typeOf(y);
    var c;
    if ((typeX === "number" || typeX === "BigNumber" || typeX === "Fraction" || typeX === "bigint") && (typeY === "number" || typeY === "BigNumber" || typeY === "Fraction" || typeY === "bigint")) {
      c = compare2(x, y);
      if (c.toString() !== "0") {
        return c > 0 ? 1 : -1;
      } else {
        return (0, import_javascript_natural_sort.default)(typeX, typeY);
      }
    }
    var matTypes = ["Array", "DenseMatrix", "SparseMatrix"];
    if (matTypes.includes(typeX) || matTypes.includes(typeY)) {
      c = compareMatricesAndArrays(_compareNatural, x, y);
      if (c !== 0) {
        return c;
      } else {
        return (0, import_javascript_natural_sort.default)(typeX, typeY);
      }
    }
    if (typeX !== typeY) {
      return (0, import_javascript_natural_sort.default)(typeX, typeY);
    }
    if (typeX === "Complex") {
      return compareComplexNumbers(x, y);
    }
    if (typeX === "Unit") {
      if (x.equalBase(y)) {
        return _compareNatural(x.value, y.value);
      }
      return compareArrays(_compareNatural, x.formatUnits(), y.formatUnits());
    }
    if (typeX === "boolean") {
      return compareBooleans(x, y);
    }
    if (typeX === "string") {
      return (0, import_javascript_natural_sort.default)(x, y);
    }
    if (typeX === "Object") {
      return compareObjects(_compareNatural, x, y);
    }
    if (typeX === "null") {
      return 0;
    }
    if (typeX === "undefined") {
      return 0;
    }
    throw new TypeError('Unsupported type of value "' + typeX + '"');
  }
  function compareMatricesAndArrays(compareNatural2, x, y) {
    if (isSparseMatrix(x) && isSparseMatrix(y)) {
      return compareArrays(compareNatural2, x.toJSON().values, y.toJSON().values);
    }
    if (isSparseMatrix(x)) {
      return compareMatricesAndArrays(compareNatural2, x.toArray(), y);
    }
    if (isSparseMatrix(y)) {
      return compareMatricesAndArrays(compareNatural2, x, y.toArray());
    }
    if (isDenseMatrix(x)) {
      return compareMatricesAndArrays(compareNatural2, x.toJSON().data, y);
    }
    if (isDenseMatrix(y)) {
      return compareMatricesAndArrays(compareNatural2, x, y.toJSON().data);
    }
    if (!Array.isArray(x)) {
      return compareMatricesAndArrays(compareNatural2, [x], y);
    }
    if (!Array.isArray(y)) {
      return compareMatricesAndArrays(compareNatural2, x, [y]);
    }
    return compareArrays(compareNatural2, x, y);
  }
  function compareArrays(compareNatural2, x, y) {
    for (var i = 0, ii = Math.min(x.length, y.length); i < ii; i++) {
      var v = compareNatural2(x[i], y[i]);
      if (v !== 0) {
        return v;
      }
    }
    if (x.length > y.length) {
      return 1;
    }
    if (x.length < y.length) {
      return -1;
    }
    return 0;
  }
  function compareObjects(compareNatural2, x, y) {
    var keysX = Object.keys(x);
    var keysY = Object.keys(y);
    keysX.sort(import_javascript_natural_sort.default);
    keysY.sort(import_javascript_natural_sort.default);
    var c = compareArrays(compareNatural2, keysX, keysY);
    if (c !== 0) {
      return c;
    }
    for (var i = 0; i < keysX.length; i++) {
      var v = compareNatural2(x[keysX[i]], y[keysY[i]]);
      if (v !== 0) {
        return v;
      }
    }
    return 0;
  }
});
function compareComplexNumbers(x, y) {
  if (x.re > y.re) {
    return 1;
  }
  if (x.re < y.re) {
    return -1;
  }
  if (x.im > y.im) {
    return 1;
  }
  if (x.im < y.im) {
    return -1;
  }
  return 0;
}

// node_modules/mathjs/lib/esm/function/relational/compareText.js
var name65 = "compareText";
compareText.signature = "any, any";
var createCompareTextNumber = /* @__PURE__ */ factory(name65, ["typed"], (_ref2) => {
  var {
    typed: typed3
  } = _ref2;
  return typed3(name65, compareText);
});

// node_modules/mathjs/lib/esm/function/relational/equal.js
var name66 = "equal";
var createEqualNumber = factory(name66, ["typed", "equalScalar"], (_ref2) => {
  var {
    typed: typed3,
    equalScalar: equalScalar2
  } = _ref2;
  return typed3(name66, {
    "any, any": function any_any(x, y) {
      if (x === null) {
        return y === null;
      }
      if (y === null) {
        return x === null;
      }
      if (x === void 0) {
        return y === void 0;
      }
      if (y === void 0) {
        return x === void 0;
      }
      return equalScalar2(x, y);
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/equalText.js
var name67 = "equalText";
var dependencies60 = ["typed", "compareText", "isZero"];
var createEqualText = /* @__PURE__ */ factory(name67, dependencies60, (_ref) => {
  var {
    typed: typed3,
    compareText: compareText3,
    isZero: isZero2
  } = _ref;
  return typed3(name67, {
    "any, any": function any_any(x, y) {
      return isZero2(compareText3(x, y));
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/smaller.js
var name68 = "smaller";
var createSmallerNumber = /* @__PURE__ */ factory(name68, ["typed", "config"], (_ref2) => {
  var {
    typed: typed3,
    config: config4
  } = _ref2;
  return typed3(name68, {
    "number, number": function number_number(x, y) {
      return x < y && !nearlyEqual(x, y, config4.relTol, config4.absTol);
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/smallerEq.js
var name69 = "smallerEq";
var createSmallerEqNumber = /* @__PURE__ */ factory(name69, ["typed", "config"], (_ref2) => {
  var {
    typed: typed3,
    config: config4
  } = _ref2;
  return typed3(name69, {
    "number, number": function number_number(x, y) {
      return x <= y || nearlyEqual(x, y, config4.relTol, config4.absTol);
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/larger.js
var name70 = "larger";
var createLargerNumber = /* @__PURE__ */ factory(name70, ["typed", "config"], (_ref2) => {
  var {
    typed: typed3,
    config: config4
  } = _ref2;
  return typed3(name70, {
    "number, number": function number_number(x, y) {
      return x > y && !nearlyEqual(x, y, config4.relTol, config4.absTol);
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/largerEq.js
var name71 = "largerEq";
var createLargerEqNumber = /* @__PURE__ */ factory(name71, ["typed", "config"], (_ref2) => {
  var {
    typed: typed3,
    config: config4
  } = _ref2;
  return typed3(name71, {
    "number, number": function number_number(x, y) {
      return x >= y || nearlyEqual(x, y, config4.relTol, config4.absTol);
    }
  });
});

// node_modules/mathjs/lib/esm/function/relational/deepEqual.js
var name72 = "deepEqual";
var dependencies61 = ["typed", "equal"];
var createDeepEqual = /* @__PURE__ */ factory(name72, dependencies61, (_ref) => {
  var {
    typed: typed3,
    equal: equal2
  } = _ref;
  return typed3(name72, {
    "any, any": function any_any(x, y) {
      return _deepEqual(x.valueOf(), y.valueOf());
    }
  });
  function _deepEqual(x, y) {
    if (Array.isArray(x)) {
      if (Array.isArray(y)) {
        var len = x.length;
        if (len !== y.length) {
          return false;
        }
        for (var i = 0; i < len; i++) {
          if (!_deepEqual(x[i], y[i])) {
            return false;
          }
        }
        return true;
      } else {
        return false;
      }
    } else {
      if (Array.isArray(y)) {
        return false;
      } else {
        return equal2(x, y);
      }
    }
  }
});

// node_modules/mathjs/lib/esm/function/relational/unequal.js
var name73 = "unequal";
var createUnequalNumber = factory(name73, ["typed", "equalScalar"], (_ref2) => {
  var {
    typed: typed3,
    equalScalar: equalScalar2
  } = _ref2;
  return typed3(name73, {
    "any, any": function any_any(x, y) {
      if (x === null) {
        return y !== null;
      }
      if (y === null) {
        return x !== null;
      }
      if (x === void 0) {
        return y !== void 0;
      }
      if (y === void 0) {
        return x !== void 0;
      }
      return !equalScalar2(x, y);
    }
  });
});

// node_modules/mathjs/lib/esm/function/special/erf.js
var name74 = "erf";
var dependencies62 = ["typed"];
var createErf = /* @__PURE__ */ factory(name74, dependencies62, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3("name", {
    number: function number2(x) {
      var y = Math.abs(x);
      if (y >= MAX_NUM) {
        return sign(x);
      }
      if (y <= THRESH) {
        return sign(x) * erf1(y);
      }
      if (y <= 4) {
        return sign(x) * (1 - erfc2(y));
      }
      return sign(x) * (1 - erfc3(y));
    },
    "Array | Matrix": typed3.referToSelf((self2) => (n) => deepMap2(n, self2))
    // TODO: For complex numbers, use the approximation for the Faddeeva function
    //  from "More Efficient Computation of the Complex Error Function" (AMS)
  });
  function erf1(y) {
    var ysq = y * y;
    var xnum = P2[0][4] * ysq;
    var xden = ysq;
    var i;
    for (i = 0; i < 3; i += 1) {
      xnum = (xnum + P2[0][i]) * ysq;
      xden = (xden + Q[0][i]) * ysq;
    }
    return y * (xnum + P2[0][3]) / (xden + Q[0][3]);
  }
  function erfc2(y) {
    var xnum = P2[1][8] * y;
    var xden = y;
    var i;
    for (i = 0; i < 7; i += 1) {
      xnum = (xnum + P2[1][i]) * y;
      xden = (xden + Q[1][i]) * y;
    }
    var result = (xnum + P2[1][7]) / (xden + Q[1][7]);
    var ysq = parseInt(y * 16) / 16;
    var del = (y - ysq) * (y + ysq);
    return Math.exp(-ysq * ysq) * Math.exp(-del) * result;
  }
  function erfc3(y) {
    var ysq = 1 / (y * y);
    var xnum = P2[2][5] * ysq;
    var xden = ysq;
    var i;
    for (i = 0; i < 4; i += 1) {
      xnum = (xnum + P2[2][i]) * ysq;
      xden = (xden + Q[2][i]) * ysq;
    }
    var result = ysq * (xnum + P2[2][4]) / (xden + Q[2][4]);
    result = (SQRPI - result) / y;
    ysq = parseInt(y * 16) / 16;
    var del = (y - ysq) * (y + ysq);
    return Math.exp(-ysq * ysq) * Math.exp(-del) * result;
  }
});
var THRESH = 0.46875;
var SQRPI = 0.5641895835477563;
var P2 = [[3.1611237438705655, 113.86415415105016, 377.485237685302, 3209.3775891384694, 0.18577770618460315], [0.5641884969886701, 8.883149794388377, 66.11919063714163, 298.6351381974001, 881.952221241769, 1712.0476126340707, 2051.0783778260716, 1230.3393547979972, 21531153547440383e-24], [0.30532663496123236, 0.36034489994980445, 0.12578172611122926, 0.016083785148742275, 6587491615298378e-19, 0.016315387137302097]];
var Q = [[23.601290952344122, 244.02463793444417, 1282.6165260773723, 2844.236833439171], [15.744926110709835, 117.6939508913125, 537.1811018620099, 1621.3895745666903, 3290.7992357334597, 4362.619090143247, 3439.3676741437216, 1230.3393548037495], [2.568520192289822, 1.8729528499234604, 0.5279051029514285, 0.06051834131244132, 0.0023352049762686918]];
var MAX_NUM = Math.pow(2, 53);

// node_modules/mathjs/lib/esm/function/special/zeta.js
var name75 = "zeta";
var dependencies63 = ["typed", "config", "multiply", "pow", "divide", "factorial", "equal", "smallerEq", "isBounded", "isNegative", "gamma", "sin", "subtract", "add", "?Complex", "?BigNumber", "pi"];
var createZeta = /* @__PURE__ */ factory(name75, dependencies63, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    multiply: multiply2,
    pow: pow3,
    divide: divide3,
    factorial: factorial2,
    equal: equal2,
    smallerEq: smallerEq2,
    isBounded: isBounded2,
    isNegative: isNegative2,
    gamma: gamma3,
    sin: sin3,
    subtract: subtract2,
    add: add3,
    Complex,
    BigNumber: _BigNumber,
    pi: pi3
  } = _ref;
  return typed3(name75, {
    number: (s) => zetaNumeric(s, (value) => value, () => 20),
    BigNumber: (s) => zetaNumeric(s, (value) => new _BigNumber(value), () => {
      return Math.abs(Math.log10(config4.relTol));
    }),
    Complex: zetaComplex
  });
  function zetaNumeric(s, createValue, determineDigits) {
    if (equal2(s, 0)) {
      return createValue(-0.5);
    }
    if (equal2(s, 1)) {
      return createValue(NaN);
    }
    if (!isBounded2(s)) {
      return isNegative2(s) ? createValue(NaN) : createValue(1);
    }
    return zeta2(s, createValue, determineDigits, (s2) => s2);
  }
  function zetaComplex(s) {
    if (s.re === 0 && s.im === 0) {
      return new Complex(-0.5);
    }
    if (s.re === 1) {
      return new Complex(NaN, NaN);
    }
    if (s.re === Infinity && s.im === 0) {
      return new Complex(1);
    }
    if (s.im === Infinity || s.re === -Infinity) {
      return new Complex(NaN, NaN);
    }
    return zeta2(s, (value) => value, (s2) => Math.round(1.3 * 15 + 0.9 * Math.abs(s2.im)), (s2) => s2.re);
  }
  function zeta2(s, createValue, determineDigits, getRe) {
    var n = determineDigits(s);
    if (getRe(s) > -(n - 1) / 2) {
      return f(s, createValue(n), createValue);
    } else {
      var c = multiply2(pow3(2, s), pow3(createValue(pi3), subtract2(s, 1)));
      c = multiply2(c, sin3(multiply2(divide3(createValue(pi3), 2), s)));
      c = multiply2(c, gamma3(subtract2(1, s)));
      return multiply2(c, zeta2(subtract2(1, s), createValue, determineDigits, getRe));
    }
  }
  function d(k, n) {
    var S = k;
    for (var j = k; smallerEq2(j, n); j = add3(j, 1)) {
      var factor = divide3(multiply2(factorial2(add3(n, subtract2(j, 1))), pow3(4, j)), multiply2(factorial2(subtract2(n, j)), factorial2(multiply2(2, j))));
      S = add3(S, factor);
    }
    return multiply2(n, S);
  }
  function f(s, n, createValue) {
    var c = divide3(1, multiply2(d(createValue(0), n), subtract2(1, pow3(2, subtract2(1, s)))));
    var S = createValue(0);
    for (var k = createValue(1); smallerEq2(k, n); k = add3(k, 1)) {
      S = add3(S, divide3(multiply2((-1) ** (k - 1), d(k, n)), pow3(k, s)));
    }
    return multiply2(c, S);
  }
});

// node_modules/mathjs/lib/esm/function/statistics/mode.js
var name76 = "mode";
var dependencies64 = ["typed", "isNaN", "isNumeric"];
var createMode = /* @__PURE__ */ factory(name76, dependencies64, (_ref) => {
  var {
    typed: typed3,
    isNaN: mathIsNaN,
    isNumeric: isNumeric2
  } = _ref;
  return typed3(name76, {
    "Array | Matrix": _mode,
    "...": function _(args) {
      return _mode(args);
    }
  });
  function _mode(values) {
    values = flatten(values.valueOf());
    var num = values.length;
    if (num === 0) {
      throw new Error("Cannot calculate mode of an empty array");
    }
    var count = {};
    var mode2 = [];
    var max3 = 0;
    for (var i = 0; i < values.length; i++) {
      var value = values[i];
      if (isNumeric2(value) && mathIsNaN(value)) {
        throw new Error("Cannot calculate mode of an array containing NaN values");
      }
      if (!(value in count)) {
        count[value] = 0;
      }
      count[value]++;
      if (count[value] === max3) {
        mode2.push(value);
      } else if (count[value] > max3) {
        max3 = count[value];
        mode2 = [value];
      }
    }
    return mode2;
  }
});

// node_modules/mathjs/lib/esm/function/statistics/utils/improveErrorMessage.js
function improveErrorMessage(err, fnName, value) {
  var details;
  if (String(err).includes("Unexpected type")) {
    details = arguments.length > 2 ? " (type: " + typeOf(value) + ", value: " + JSON.stringify(value) + ")" : " (type: " + err.data.actual + ")";
    return new TypeError("Cannot calculate " + fnName + ", unexpected type of argument" + details);
  }
  if (String(err).includes("complex numbers")) {
    details = arguments.length > 2 ? " (type: " + typeOf(value) + ", value: " + JSON.stringify(value) + ")" : "";
    return new TypeError("Cannot calculate " + fnName + ", no ordering relation is defined for complex numbers" + details);
  }
  return err;
}

// node_modules/mathjs/lib/esm/function/statistics/prod.js
var name77 = "prod";
var dependencies65 = ["typed", "config", "multiplyScalar", "numeric"];
var createProd = /* @__PURE__ */ factory(name77, dependencies65, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    multiplyScalar: multiplyScalar2,
    numeric: numeric3
  } = _ref;
  return typed3(name77, {
    // prod([a, b, c, d, ...])
    "Array | Matrix": _prod,
    // prod([a, b, c, d, ...], dim)
    "Array | Matrix, number | BigNumber": function Array__Matrix_number__BigNumber(array, dim) {
      throw new Error("prod(A, dim) is not yet supported");
    },
    // prod(a, b, c, d, ...)
    "...": function _(args) {
      return _prod(args);
    }
  });
  function _prod(array) {
    var prod2;
    deepForEach2(array, function(value) {
      try {
        prod2 = prod2 === void 0 ? value : multiplyScalar2(prod2, value);
      } catch (err) {
        throw improveErrorMessage(err, "prod", value);
      }
    });
    if (typeof prod2 === "string") {
      prod2 = numeric3(prod2, safeNumberType(prod2, config4));
    }
    if (prod2 === void 0) {
      throw new Error("Cannot calculate prod of an empty array");
    }
    return prod2;
  }
});

// node_modules/mathjs/lib/esm/function/statistics/max.js
var name78 = "max";
var dependencies66 = ["typed", "config", "numeric", "larger", "isNaN"];
var createMax = /* @__PURE__ */ factory(name78, dependencies66, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    numeric: numeric3,
    larger: larger2,
    isNaN: mathIsNaN
  } = _ref;
  return typed3(name78, {
    // max([a, b, c, d, ...])
    "Array | Matrix": _max,
    // max([a, b, c, d, ...], dim)
    "Array | Matrix, number | BigNumber": function Array__Matrix_number__BigNumber(array, dim) {
      return reduce(array, dim.valueOf(), _largest);
    },
    // max(a, b, c, d, ...)
    "...": function _(args) {
      if (containsCollections(args)) {
        throw new TypeError("Scalar values expected in function max");
      }
      return _max(args);
    }
  });
  function _largest(x, y) {
    try {
      return larger2(x, y) ? x : y;
    } catch (err) {
      throw improveErrorMessage(err, "max", y);
    }
  }
  function _max(array) {
    var res;
    deepForEach2(array, function(value) {
      try {
        if (mathIsNaN(value)) {
          res = value;
        } else if (res === void 0 || larger2(value, res)) {
          res = value;
        }
      } catch (err) {
        throw improveErrorMessage(err, "max", value);
      }
    });
    if (res === void 0) {
      throw new Error("Cannot calculate max of an empty array");
    }
    if (typeof res === "string") {
      res = numeric3(res, safeNumberType(res, config4));
    }
    return res;
  }
});

// node_modules/mathjs/lib/esm/function/statistics/min.js
var name79 = "min";
var dependencies67 = ["typed", "config", "numeric", "smaller", "isNaN"];
var createMin = /* @__PURE__ */ factory(name79, dependencies67, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    numeric: numeric3,
    smaller: smaller2,
    isNaN: mathIsNaN
  } = _ref;
  return typed3(name79, {
    // min([a, b, c, d, ...])
    "Array | Matrix": _min,
    // min([a, b, c, d, ...], dim)
    "Array | Matrix, number | BigNumber": function Array__Matrix_number__BigNumber(array, dim) {
      return reduce(array, dim.valueOf(), _smallest);
    },
    // min(a, b, c, d, ...)
    "...": function _(args) {
      if (containsCollections(args)) {
        throw new TypeError("Scalar values expected in function min");
      }
      return _min(args);
    }
  });
  function _smallest(x, y) {
    try {
      return smaller2(x, y) ? x : y;
    } catch (err) {
      throw improveErrorMessage(err, "min", y);
    }
  }
  function _min(array) {
    var min3;
    deepForEach2(array, function(value) {
      try {
        if (mathIsNaN(value)) {
          min3 = value;
        } else if (min3 === void 0 || smaller2(value, min3)) {
          min3 = value;
        }
      } catch (err) {
        throw improveErrorMessage(err, "min", value);
      }
    });
    if (min3 === void 0) {
      throw new Error("Cannot calculate min of an empty array");
    }
    if (typeof min3 === "string") {
      min3 = numeric3(min3, safeNumberType(min3, config4));
    }
    return min3;
  }
});

// node_modules/mathjs/lib/esm/function/statistics/sum.js
var name80 = "sum";
var dependencies68 = ["typed", "config", "add", "numeric"];
var createSum = /* @__PURE__ */ factory(name80, dependencies68, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    add: add3,
    numeric: numeric3
  } = _ref;
  return typed3(name80, {
    // sum([a, b, c, d, ...])
    "Array | Matrix": _sum,
    // sum([a, b, c, d, ...], dim)
    "Array | Matrix, number | BigNumber": _nsumDim,
    // sum(a, b, c, d, ...)
    "...": function _(args) {
      if (containsCollections(args)) {
        throw new TypeError("Scalar values expected in function sum");
      }
      return _sum(args);
    }
  });
  function _sum(array) {
    var sum3;
    deepForEach2(array, function(value) {
      try {
        sum3 = sum3 === void 0 ? value : add3(sum3, value);
      } catch (err) {
        throw improveErrorMessage(err, "sum", value);
      }
    });
    if (sum3 === void 0) {
      sum3 = numeric3(0, config4.number);
    }
    if (typeof sum3 === "string") {
      sum3 = numeric3(sum3, safeNumberType(sum3, config4));
    }
    return sum3;
  }
  function _nsumDim(array, dim) {
    try {
      var sum3 = reduce(array, dim, add3);
      return sum3;
    } catch (err) {
      throw improveErrorMessage(err, "sum");
    }
  }
});

// node_modules/mathjs/lib/esm/function/statistics/cumsum.js
var name81 = "cumsum";
var dependencies69 = ["typed", "add", "unaryPlus"];
var createCumSum = /* @__PURE__ */ factory(name81, dependencies69, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    unaryPlus: unaryPlus2
  } = _ref;
  return typed3(name81, {
    // sum([a, b, c, d, ...])
    Array: _cumsum,
    Matrix: function Matrix(matrix2) {
      return matrix2.create(_cumsum(matrix2.valueOf(), matrix2.datatype()));
    },
    // sum([a, b, c, d, ...], dim)
    "Array, number | BigNumber": _ncumSumDim,
    "Matrix, number | BigNumber": function Matrix_number__BigNumber(matrix2, dim) {
      return matrix2.create(_ncumSumDim(matrix2.valueOf(), dim), matrix2.datatype());
    },
    // cumsum(a, b, c, d, ...)
    "...": function _(args) {
      if (containsCollections(args)) {
        throw new TypeError("All values expected to be scalar in function cumsum");
      }
      return _cumsum(args);
    }
  });
  function _cumsum(array) {
    try {
      return _cumsummap(array);
    } catch (err) {
      throw improveErrorMessage(err, name81);
    }
  }
  function _cumsummap(array) {
    if (array.length === 0) {
      return [];
    }
    var sums = [unaryPlus2(array[0])];
    for (var i = 1; i < array.length; ++i) {
      sums.push(add3(sums[i - 1], array[i]));
    }
    return sums;
  }
  function _ncumSumDim(array, dim) {
    var size2 = arraySize(array);
    if (dim < 0 || dim >= size2.length) {
      throw new IndexError(dim, size2.length);
    }
    try {
      return _cumsumDimensional(array, dim);
    } catch (err) {
      throw improveErrorMessage(err, name81);
    }
  }
  function _cumsumDimensional(mat, dim) {
    var i, ret, tran;
    if (dim <= 0) {
      var initialValue = mat[0][0];
      if (!Array.isArray(initialValue)) {
        return _cumsummap(mat);
      } else {
        tran = _switch(mat);
        ret = [];
        for (i = 0; i < tran.length; i++) {
          ret[i] = _cumsumDimensional(tran[i], dim - 1);
        }
        return ret;
      }
    } else {
      ret = [];
      for (i = 0; i < mat.length; i++) {
        ret[i] = _cumsumDimensional(mat[i], dim - 1);
      }
      return ret;
    }
  }
});

// node_modules/mathjs/lib/esm/function/statistics/mean.js
var name82 = "mean";
var dependencies70 = ["typed", "add", "divide"];
var createMean = /* @__PURE__ */ factory(name82, dependencies70, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    divide: divide3
  } = _ref;
  return typed3(name82, {
    // mean([a, b, c, d, ...])
    "Array | Matrix": _mean,
    // mean([a, b, c, d, ...], dim)
    "Array | Matrix, number | BigNumber": _nmeanDim,
    // mean(a, b, c, d, ...)
    "...": function _(args) {
      if (containsCollections(args)) {
        throw new TypeError("Scalar values expected in function mean");
      }
      return _mean(args);
    }
  });
  function _nmeanDim(array, dim) {
    try {
      var sum3 = reduce(array, dim, add3);
      var s = Array.isArray(array) ? arraySize(array) : array.size();
      return divide3(sum3, s[dim]);
    } catch (err) {
      throw improveErrorMessage(err, "mean");
    }
  }
  function _mean(array) {
    var sum3;
    var num = 0;
    deepForEach2(array, function(value) {
      try {
        sum3 = sum3 === void 0 ? value : add3(sum3, value);
        num++;
      } catch (err) {
        throw improveErrorMessage(err, "mean", value);
      }
    });
    if (num === 0) {
      throw new Error("Cannot calculate the mean of an empty array");
    }
    return divide3(sum3, num);
  }
});

// node_modules/mathjs/lib/esm/function/statistics/median.js
var name83 = "median";
var dependencies71 = ["typed", "add", "divide", "compare", "partitionSelect"];
var createMedian = /* @__PURE__ */ factory(name83, dependencies71, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    divide: divide3,
    compare: compare2,
    partitionSelect: partitionSelect2
  } = _ref;
  function _median(array) {
    try {
      array = flatten(array.valueOf());
      var num = array.length;
      if (num === 0) {
        throw new Error("Cannot calculate median of an empty array");
      }
      if (num % 2 === 0) {
        var mid = num / 2 - 1;
        var right = partitionSelect2(array, mid + 1);
        var left = array[mid];
        for (var i = 0; i < mid; ++i) {
          if (compare2(array[i], left) > 0) {
            left = array[i];
          }
        }
        return middle2(left, right);
      } else {
        var m = partitionSelect2(array, (num - 1) / 2);
        return middle(m);
      }
    } catch (err) {
      throw improveErrorMessage(err, "median");
    }
  }
  var middle = typed3({
    "number | BigNumber | Complex | Unit": function number__BigNumber__Complex__Unit(value) {
      return value;
    }
  });
  var middle2 = typed3({
    "number | BigNumber | Complex | Unit, number | BigNumber | Complex | Unit": function number__BigNumber__Complex__Unit_number__BigNumber__Complex__Unit(left, right) {
      return divide3(add3(left, right), 2);
    }
  });
  return typed3(name83, {
    // median([a, b, c, d, ...])
    "Array | Matrix": _median,
    // median([a, b, c, d, ...], dim)
    "Array | Matrix, number | BigNumber": function Array__Matrix_number__BigNumber(array, dim) {
      throw new Error("median(A, dim) is not yet supported");
    },
    // median(a, b, c, d, ...)
    "...": function _(args) {
      if (containsCollections(args)) {
        throw new TypeError("Scalar values expected in function median");
      }
      return _median(args);
    }
  });
});

// node_modules/mathjs/lib/esm/function/statistics/mad.js
var name84 = "mad";
var dependencies72 = ["typed", "abs", "map", "median", "subtract"];
var createMad = /* @__PURE__ */ factory(name84, dependencies72, (_ref) => {
  var {
    typed: typed3,
    abs: abs3,
    map: map3,
    median: median2,
    subtract: subtract2
  } = _ref;
  return typed3(name84, {
    // mad([a, b, c, d, ...])
    "Array | Matrix": _mad,
    // mad(a, b, c, d, ...)
    "...": function _(args) {
      return _mad(args);
    }
  });
  function _mad(array) {
    array = flatten(array.valueOf());
    if (array.length === 0) {
      throw new Error("Cannot calculate median absolute deviation (mad) of an empty array");
    }
    try {
      var med = median2(array);
      return median2(map3(array, function(value) {
        return abs3(subtract2(value, med));
      }));
    } catch (err) {
      if (err instanceof TypeError && err.message.includes("median")) {
        throw new TypeError(err.message.replace("median", "mad"));
      } else {
        throw improveErrorMessage(err, "mad");
      }
    }
  }
});

// node_modules/mathjs/lib/esm/function/statistics/variance.js
var DEFAULT_NORMALIZATION = "unbiased";
var name85 = "variance";
var dependencies73 = ["typed", "add", "subtract", "multiply", "divide", "mapSlices", "isNaN"];
var createVariance = /* @__PURE__ */ factory(name85, dependencies73, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    subtract: subtract2,
    multiply: multiply2,
    divide: divide3,
    mapSlices: mapSlices2,
    isNaN: mathIsNaN
  } = _ref;
  return typed3(name85, {
    // variance([a, b, c, d, ...])
    "Array | Matrix": function Array__Matrix(array) {
      return _var(array, DEFAULT_NORMALIZATION);
    },
    // variance([a, b, c, d, ...], normalization)
    "Array | Matrix, string": _var,
    // variance([a, b, c, c, ...], dim)
    "Array | Matrix, number | BigNumber": function Array__Matrix_number__BigNumber(array, dim) {
      return _varDim(array, dim, DEFAULT_NORMALIZATION);
    },
    // variance([a, b, c, c, ...], dim, normalization)
    "Array | Matrix, number | BigNumber, string": _varDim,
    // variance(a, b, c, d, ...)
    "...": function _(args) {
      return _var(args, DEFAULT_NORMALIZATION);
    }
  });
  function _var(array, normalization) {
    var sum3;
    var num = 0;
    if (array.length === 0) {
      throw new SyntaxError("Function variance requires one or more parameters (0 provided)");
    }
    deepForEach2(array, function(value) {
      try {
        sum3 = sum3 === void 0 ? value : add3(sum3, value);
        num++;
      } catch (err) {
        throw improveErrorMessage(err, "variance", value);
      }
    });
    if (num === 0) throw new Error("Cannot calculate variance of an empty array");
    var mean2 = divide3(sum3, num);
    sum3 = void 0;
    deepForEach2(array, function(value) {
      var diff = subtract2(value, mean2);
      sum3 = sum3 === void 0 ? multiply2(diff, diff) : add3(sum3, multiply2(diff, diff));
    });
    if (mathIsNaN(sum3)) {
      return sum3;
    }
    switch (normalization) {
      case "uncorrected":
        return divide3(sum3, num);
      case "biased":
        return divide3(sum3, num + 1);
      case "unbiased": {
        var zero = isBigNumber(sum3) ? sum3.mul(0) : 0;
        return num === 1 ? zero : divide3(sum3, num - 1);
      }
      default:
        throw new Error('Unknown normalization "' + normalization + '". Choose "unbiased" (default), "uncorrected", or "biased".');
    }
  }
  function _varDim(array, dim, normalization) {
    try {
      if (array.length === 0) {
        throw new SyntaxError("Function variance requires one or more parameters (0 provided)");
      }
      return mapSlices2(array, dim, (x) => _var(x, normalization));
    } catch (err) {
      throw improveErrorMessage(err, "variance");
    }
  }
});

// node_modules/mathjs/lib/esm/function/statistics/quantileSeq.js
var name86 = "quantileSeq";
var dependencies74 = ["typed", "?bignumber", "add", "subtract", "divide", "multiply", "partitionSelect", "compare", "isInteger", "smaller", "smallerEq", "larger", "mapSlices"];
var createQuantileSeq = /* @__PURE__ */ factory(name86, dependencies74, (_ref) => {
  var {
    typed: typed3,
    bignumber,
    add: add3,
    subtract: subtract2,
    divide: divide3,
    multiply: multiply2,
    partitionSelect: partitionSelect2,
    compare: compare2,
    isInteger: isInteger4,
    smaller: smaller2,
    smallerEq: smallerEq2,
    larger: larger2,
    mapSlices: mapSlices2
  } = _ref;
  return typed3(name86, {
    "Array | Matrix, number | BigNumber": (data, p) => _quantileSeqProbNumber(data, p, false),
    "Array | Matrix, number | BigNumber, number": (data, prob, dim) => _quantileSeqDim(data, prob, false, dim, _quantileSeqProbNumber),
    "Array | Matrix, number | BigNumber, boolean": _quantileSeqProbNumber,
    "Array | Matrix, number | BigNumber, boolean, number": (data, prob, sorted, dim) => _quantileSeqDim(data, prob, sorted, dim, _quantileSeqProbNumber),
    "Array | Matrix, Array | Matrix": (data, p) => _quantileSeqProbCollection(data, p, false),
    "Array | Matrix, Array | Matrix, number": (data, prob, dim) => _quantileSeqDim(data, prob, false, dim, _quantileSeqProbCollection),
    "Array | Matrix, Array | Matrix, boolean": _quantileSeqProbCollection,
    "Array | Matrix, Array | Matrix, boolean, number": (data, prob, sorted, dim) => _quantileSeqDim(data, prob, sorted, dim, _quantileSeqProbCollection)
  });
  function _quantileSeqDim(data, prob, sorted, dim, fn) {
    return mapSlices2(data, dim, (x) => fn(x, prob, sorted));
  }
  function _quantileSeqProbNumber(data, probOrN, sorted) {
    var probArr;
    var dataArr = data.valueOf();
    if (smaller2(probOrN, 0)) {
      throw new Error("N/prob must be non-negative");
    }
    if (smallerEq2(probOrN, 1)) {
      return isNumber(probOrN) ? _quantileSeq(dataArr, probOrN, sorted) : bignumber(_quantileSeq(dataArr, probOrN, sorted));
    }
    if (larger2(probOrN, 1)) {
      if (!isInteger4(probOrN)) {
        throw new Error("N must be a positive integer");
      }
      if (larger2(probOrN, 4294967295)) {
        throw new Error("N must be less than or equal to 2^32-1, as that is the maximum length of an Array");
      }
      var nPlusOne = add3(probOrN, 1);
      probArr = [];
      for (var i = 0; smaller2(i, probOrN); i++) {
        var prob = divide3(i + 1, nPlusOne);
        probArr.push(_quantileSeq(dataArr, prob, sorted));
      }
      return isNumber(probOrN) ? probArr : bignumber(probArr);
    }
  }
  function _quantileSeqProbCollection(data, probOrN, sorted) {
    var dataArr = data.valueOf();
    var probOrNArr = probOrN.valueOf();
    var probArr = [];
    for (var i = 0; i < probOrNArr.length; ++i) {
      probArr.push(_quantileSeq(dataArr, probOrNArr[i], sorted));
    }
    return probArr;
  }
  function _quantileSeq(array, prob, sorted) {
    var flat = flatten(array);
    var len = flat.length;
    if (len === 0) {
      throw new Error("Cannot calculate quantile of an empty sequence");
    }
    var index2 = isNumber(prob) ? prob * (len - 1) : prob.times(len - 1);
    var integerPart = isNumber(prob) ? Math.floor(index2) : index2.floor().toNumber();
    var fracPart = isNumber(prob) ? index2 % 1 : index2.minus(integerPart);
    if (isInteger4(index2)) {
      return sorted ? flat[index2] : partitionSelect2(flat, isNumber(prob) ? index2 : index2.valueOf());
    }
    var left;
    var right;
    if (sorted) {
      left = flat[integerPart];
      right = flat[integerPart + 1];
    } else {
      right = partitionSelect2(flat, integerPart + 1);
      left = flat[integerPart];
      for (var i = 0; i < integerPart; ++i) {
        if (compare2(flat[i], left) > 0) {
          left = flat[i];
        }
      }
    }
    return add3(multiply2(left, subtract2(1, fracPart)), multiply2(right, fracPart));
  }
});

// node_modules/mathjs/lib/esm/function/statistics/std.js
var name87 = "std";
var dependencies75 = ["typed", "map", "sqrt", "variance"];
var createStd = /* @__PURE__ */ factory(name87, dependencies75, (_ref) => {
  var {
    typed: typed3,
    map: map3,
    sqrt: sqrt3,
    variance: variance2
  } = _ref;
  return typed3(name87, {
    // std([a, b, c, d, ...])
    "Array | Matrix": _std,
    // std([a, b, c, d, ...], normalization)
    "Array | Matrix, string": _std,
    // std([a, b, c, c, ...], dim)
    "Array | Matrix, number | BigNumber": _std,
    // std([a, b, c, c, ...], dim, normalization)
    "Array | Matrix, number | BigNumber, string": _std,
    // std(a, b, c, d, ...)
    "...": function _(args) {
      return _std(args);
    }
  });
  function _std(array, normalization) {
    if (array.length === 0) {
      throw new SyntaxError("Function std requires one or more parameters (0 provided)");
    }
    try {
      var v = variance2.apply(null, arguments);
      if (isCollection(v)) {
        return map3(v, sqrt3);
      } else {
        return sqrt3(v);
      }
    } catch (err) {
      if (err instanceof TypeError && err.message.includes(" variance")) {
        throw new TypeError(err.message.replace(" variance", " std"));
      } else {
        throw err;
      }
    }
  }
});

// node_modules/mathjs/lib/esm/function/statistics/corr.js
var name88 = "corr";
var dependencies76 = ["typed", "matrix", "mean", "sqrt", "sum", "add", "subtract", "multiply", "pow", "divide"];
var createCorr = /* @__PURE__ */ factory(name88, dependencies76, (_ref) => {
  var {
    typed: typed3,
    matrix: matrix2,
    sqrt: sqrt3,
    sum: sum3,
    add: add3,
    subtract: subtract2,
    multiply: multiply2,
    pow: pow3,
    divide: divide3
  } = _ref;
  return typed3(name88, {
    "Array, Array": function Array_Array(A, B) {
      return _corr(A, B);
    },
    "Matrix, Matrix": function Matrix_Matrix(A, B) {
      var res = _corr(A.toArray(), B.toArray());
      return Array.isArray(res) ? matrix2(res) : res;
    }
  });
  function _corr(A, B) {
    var correlations = [];
    if (Array.isArray(A[0]) && Array.isArray(B[0])) {
      if (A.length !== B.length) {
        throw new SyntaxError("Dimension mismatch. Array A and B must have the same length.");
      }
      for (var i = 0; i < A.length; i++) {
        if (A[i].length !== B[i].length) {
          throw new SyntaxError("Dimension mismatch. Array A and B must have the same number of elements.");
        }
        correlations.push(correlation(A[i], B[i]));
      }
      return correlations;
    } else {
      if (A.length !== B.length) {
        throw new SyntaxError("Dimension mismatch. Array A and B must have the same number of elements.");
      }
      return correlation(A, B);
    }
  }
  function correlation(A, B) {
    var n = A.length;
    var sumX = sum3(A);
    var sumY = sum3(B);
    var sumXY = A.reduce((acc, x, index2) => add3(acc, multiply2(x, B[index2])), 0);
    var sumXSquare = sum3(A.map((x) => pow3(x, 2)));
    var sumYSquare = sum3(B.map((y) => pow3(y, 2)));
    var numerator = subtract2(multiply2(n, sumXY), multiply2(sumX, sumY));
    var denominator = sqrt3(multiply2(subtract2(multiply2(n, sumXSquare), pow3(sumX, 2)), subtract2(multiply2(n, sumYSquare), pow3(sumY, 2))));
    return divide3(numerator, denominator);
  }
});

// node_modules/mathjs/lib/esm/function/string/format.js
var name89 = "format";
var dependencies77 = ["typed"];
var createFormat = /* @__PURE__ */ factory(name89, dependencies77, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name89, {
    any: format3,
    "any, Object | function | number | BigNumber": format3
  });
});

// node_modules/mathjs/lib/esm/utils/print.js
var printTemplate = /\$([\w.]+)/g;

// node_modules/mathjs/lib/esm/function/string/print.js
var name90 = "print";
var dependencies78 = ["typed"];
var createPrint = /* @__PURE__ */ factory(name90, dependencies78, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name90, {
    // note: Matrix will be converted automatically to an Array
    "string, Object | Array": _print,
    "string, Object | Array, number | Object": _print
  });
});
function _print(template, values, options) {
  return template.replace(printTemplate, function(original, key) {
    var keys = key.split(".");
    var value = values[keys.shift()];
    if (value !== void 0 && value.isMatrix) {
      value = value.toArray();
    }
    while (keys.length && value !== void 0) {
      var k = keys.shift();
      value = k ? value[k] : value + ".";
    }
    if (value !== void 0) {
      if (!isString(value)) {
        return format3(value, options);
      } else {
        return value;
      }
    }
    return original;
  });
}

// node_modules/mathjs/lib/esm/expression/transform/mapSlices.transform.js
var import_defineProperty16 = __toESM(require_defineProperty(), 1);
function ownKeys2(e3, r) {
  var t = Object.keys(e3);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e3);
    r && (o = o.filter(function(r2) {
      return Object.getOwnPropertyDescriptor(e3, r2).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread2(e3) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys2(Object(t), true).forEach(function(r2) {
      (0, import_defineProperty16.default)(e3, r2, t[r2]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e3, Object.getOwnPropertyDescriptors(t)) : ownKeys2(Object(t)).forEach(function(r2) {
      Object.defineProperty(e3, r2, Object.getOwnPropertyDescriptor(t, r2));
    });
  }
  return e3;
}
var name91 = "mapSlices";
var dependencies79 = ["typed", "isInteger"];
var createMapSlicesTransform = /* @__PURE__ */ factory(name91, dependencies79, (_ref) => {
  var {
    typed: typed3,
    isInteger: isInteger4
  } = _ref;
  var mapSlices2 = createMapSlices({
    typed: typed3,
    isInteger: isInteger4
  });
  return typed3("mapSlices", {
    "...any": function any(args) {
      var dim = args[1];
      if (isNumber(dim)) {
        args[1] = dim - 1;
      } else if (isBigNumber(dim)) {
        args[1] = dim.minus(1);
      }
      try {
        return mapSlices2.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, _objectSpread2({
  isTransformFunction: true
}, createMapSlices.meta));

// node_modules/mathjs/lib/esm/expression/transform/utils/compileInlineExpression.js
function compileInlineExpression(expression, math2, scope) {
  var symbol = expression.filter(function(node) {
    return isSymbolNode(node) && !(node.name in math2) && !scope.has(node.name);
  })[0];
  if (!symbol) {
    throw new Error('No undefined variable found in inline expression "' + expression + '"');
  }
  var name114 = symbol.name;
  var argsScope = /* @__PURE__ */ new Map();
  var subScope = new PartitionedMap(scope, argsScope, /* @__PURE__ */ new Set([name114]));
  var eq = expression.compile();
  return function inlineExpression(x) {
    argsScope.set(name114, x);
    return eq.evaluate(subScope);
  };
}

// node_modules/mathjs/lib/esm/expression/transform/utils/transformCallback.js
var name92 = "transformCallback";
var dependencies80 = ["typed"];
var createTransformCallback = /* @__PURE__ */ factory(name92, dependencies80, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return function(callback, numberOfArrays) {
    if (typed3.isTypedFunction(callback)) {
      return _transformTypedCallbackFunction(callback, numberOfArrays);
    } else {
      return _transformCallbackFunction(callback, callback.length, numberOfArrays);
    }
  };
  function _transformTypedCallbackFunction(typedFunction2, numberOfArrays) {
    var signatures = Object.fromEntries(Object.entries(typedFunction2.signatures).map((_ref2) => {
      var [signature, callbackFunction] = _ref2;
      var numberOfCallbackInputs = signature.split(",").length;
      if (typed3.isTypedFunction(callbackFunction)) {
        return [signature, _transformTypedCallbackFunction(callbackFunction, numberOfArrays)];
      } else {
        return [signature, _transformCallbackFunction(callbackFunction, numberOfCallbackInputs, numberOfArrays)];
      }
    }));
    if (typeof typedFunction2.name === "string") {
      return typed3(typedFunction2.name, signatures);
    } else {
      return typed3(signatures);
    }
  }
});
function _transformCallbackFunction(callbackFunction, numberOfCallbackInputs, numberOfArrays) {
  if (numberOfCallbackInputs === numberOfArrays) {
    return callbackFunction;
  } else if (numberOfCallbackInputs === numberOfArrays + 1) {
    return function() {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      var vals = args.slice(0, numberOfArrays);
      var idx = _transformDims(args[numberOfArrays]);
      return callbackFunction(...vals, idx);
    };
  } else if (numberOfCallbackInputs > numberOfArrays + 1) {
    return function() {
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      var vals = args.slice(0, numberOfArrays);
      var idx = _transformDims(args[numberOfArrays]);
      var rest = args.slice(numberOfArrays + 1);
      return callbackFunction(...vals, idx, ...rest);
    };
  } else {
    return callbackFunction;
  }
}
function _transformDims(dims) {
  return dims.map((dim) => dim + 1);
}

// node_modules/mathjs/lib/esm/expression/transform/filter.transform.js
var name93 = "filter";
var dependencies81 = ["typed"];
var createFilterTransform = /* @__PURE__ */ factory(name93, dependencies81, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  function filterTransform(args, math2, scope) {
    var filter3 = createFilter({
      typed: typed3
    });
    var transformCallback = createTransformCallback({
      typed: typed3
    });
    if (args.length === 0) {
      return filter3();
    }
    var x = args[0];
    if (args.length === 1) {
      return filter3(x);
    }
    var N = args.length - 1;
    var callback = args[N];
    if (x) {
      x = _compileAndEvaluate(x, scope);
    }
    if (callback) {
      if (isSymbolNode(callback) || isFunctionAssignmentNode(callback)) {
        callback = _compileAndEvaluate(callback, scope);
      } else {
        callback = compileInlineExpression(callback, math2, scope);
      }
    }
    return filter3(x, transformCallback(callback, N));
  }
  filterTransform.rawArgs = true;
  function _compileAndEvaluate(arg, scope) {
    return arg.compile().evaluate(scope);
  }
  return filterTransform;
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/forEach.transform.js
var name94 = "forEach";
var dependencies82 = ["typed"];
var createForEachTransform = /* @__PURE__ */ factory(name94, dependencies82, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  var forEach3 = createForEach({
    typed: typed3
  });
  var transformCallback = createTransformCallback({
    typed: typed3
  });
  function forEachTransform(args, math2, scope) {
    if (args.length === 0) {
      return forEach3();
    }
    var x = args[0];
    if (args.length === 1) {
      return forEach3(x);
    }
    var N = args.length - 1;
    var callback = args[N];
    if (x) {
      x = _compileAndEvaluate(x, scope);
    }
    if (callback) {
      if (isSymbolNode(callback) || isFunctionAssignmentNode(callback)) {
        callback = _compileAndEvaluate(callback, scope);
      } else {
        callback = compileInlineExpression(callback, math2, scope);
      }
    }
    return forEach3(x, transformCallback(callback, N));
  }
  forEachTransform.rawArgs = true;
  function _compileAndEvaluate(arg, scope) {
    return arg.compile().evaluate(scope);
  }
  return forEachTransform;
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/map.transform.js
var name95 = "map";
var dependencies83 = ["typed"];
var createMapTransform = /* @__PURE__ */ factory(name95, dependencies83, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  var map3 = createMap2({
    typed: typed3
  });
  var transformCallback = createTransformCallback({
    typed: typed3
  });
  function mapTransform(args, math2, scope) {
    if (args.length === 0) {
      return map3();
    }
    if (args.length === 1) {
      return map3(args[0]);
    }
    var N = args.length - 1;
    var X = args.slice(0, N);
    var callback = args[N];
    X = X.map((arg) => _compileAndEvaluate(arg, scope));
    if (callback) {
      if (isSymbolNode(callback) || isFunctionAssignmentNode(callback)) {
        callback = _compileAndEvaluate(callback, scope);
      } else {
        callback = compileInlineExpression(callback, math2, scope);
      }
    }
    return map3(...X, transformCallback(callback, N));
    function _compileAndEvaluate(arg, scope2) {
      return arg.compile().evaluate(scope2);
    }
  }
  mapTransform.rawArgs = true;
  return mapTransform;
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/utils/dimToZeroBase.js
function dimToZeroBase(dim) {
  if (isNumber(dim)) {
    return dim - 1;
  } else if (isBigNumber(dim)) {
    return dim.minus(1);
  } else {
    return dim;
  }
}
function isNumberOrBigNumber(n) {
  return isNumber(n) || isBigNumber(n);
}

// node_modules/mathjs/lib/esm/expression/transform/utils/lastDimToZeroBase.js
function lastDimToZeroBase(args) {
  if (args.length === 2 && isCollection(args[0])) {
    args = args.slice();
    var dim = args[1];
    if (isNumberOrBigNumber(dim)) {
      args[1] = dimToZeroBase(dim);
    }
  }
  return args;
}

// node_modules/mathjs/lib/esm/expression/transform/max.transform.js
var name96 = "max";
var dependencies84 = ["typed", "config", "numeric", "larger", "isNaN"];
var createMaxTransform = /* @__PURE__ */ factory(name96, dependencies84, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    numeric: numeric3,
    larger: larger2,
    isNaN: mathIsNaN
  } = _ref;
  var max3 = createMax({
    typed: typed3,
    config: config4,
    numeric: numeric3,
    larger: larger2,
    isNaN: mathIsNaN
  });
  return typed3("max", {
    "...any": function any(args) {
      args = lastDimToZeroBase(args);
      try {
        return max3.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/mean.transform.js
var name97 = "mean";
var dependencies85 = ["typed", "add", "divide"];
var createMeanTransform = /* @__PURE__ */ factory(name97, dependencies85, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    divide: divide3
  } = _ref;
  var mean2 = createMean({
    typed: typed3,
    add: add3,
    divide: divide3
  });
  return typed3("mean", {
    "...any": function any(args) {
      args = lastDimToZeroBase(args);
      try {
        return mean2.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/min.transform.js
var name98 = "min";
var dependencies86 = ["typed", "config", "numeric", "smaller", "isNaN"];
var createMinTransform = /* @__PURE__ */ factory(name98, dependencies86, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    numeric: numeric3,
    smaller: smaller2,
    isNaN: mathIsNaN
  } = _ref;
  var min3 = createMin({
    typed: typed3,
    config: config4,
    numeric: numeric3,
    smaller: smaller2,
    isNaN: mathIsNaN
  });
  return typed3("min", {
    "...any": function any(args) {
      args = lastDimToZeroBase(args);
      try {
        return min3.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/range.transform.js
var name99 = "range";
var dependencies87 = ["typed", "config", "?matrix", "?bignumber", "equal", "smaller", "smallerEq", "larger", "largerEq", "add", "isZero", "isPositive"];
var createRangeTransform = /* @__PURE__ */ factory(name99, dependencies87, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    matrix: matrix2,
    bignumber,
    equal: equal2,
    smaller: smaller2,
    smallerEq: smallerEq2,
    larger: larger2,
    largerEq: largerEq2,
    add: add3,
    isZero: isZero2,
    isPositive: isPositive2
  } = _ref;
  var range2 = createRange({
    typed: typed3,
    config: config4,
    matrix: matrix2,
    bignumber,
    equal: equal2,
    smaller: smaller2,
    smallerEq: smallerEq2,
    larger: larger2,
    largerEq: largerEq2,
    add: add3,
    isZero: isZero2,
    isPositive: isPositive2
  });
  return typed3("range", {
    "...any": function any(args) {
      var lastIndex = args.length - 1;
      var last = args[lastIndex];
      if (typeof last !== "boolean") {
        args.push(true);
      }
      return range2.apply(null, args);
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/std.transform.js
var name100 = "std";
var dependencies88 = ["typed", "map", "sqrt", "variance"];
var createStdTransform = /* @__PURE__ */ factory(name100, dependencies88, (_ref) => {
  var {
    typed: typed3,
    map: map3,
    sqrt: sqrt3,
    variance: variance2
  } = _ref;
  var std2 = createStd({
    typed: typed3,
    map: map3,
    sqrt: sqrt3,
    variance: variance2
  });
  return typed3("std", {
    "...any": function any(args) {
      args = lastDimToZeroBase(args);
      try {
        return std2.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/sum.transform.js
var name101 = "sum";
var dependencies89 = ["typed", "config", "add", "numeric"];
var createSumTransform = /* @__PURE__ */ factory(name101, dependencies89, (_ref) => {
  var {
    typed: typed3,
    config: config4,
    add: add3,
    numeric: numeric3
  } = _ref;
  var sum3 = createSum({
    typed: typed3,
    config: config4,
    add: add3,
    numeric: numeric3
  });
  return typed3(name101, {
    "...any": function any(args) {
      args = lastDimToZeroBase(args);
      try {
        return sum3.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/cumsum.transform.js
var name102 = "cumsum";
var dependencies90 = ["typed", "add", "unaryPlus"];
var createCumSumTransform = /* @__PURE__ */ factory(name102, dependencies90, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    unaryPlus: unaryPlus2
  } = _ref;
  var cumsum2 = createCumSum({
    typed: typed3,
    add: add3,
    unaryPlus: unaryPlus2
  });
  return typed3(name102, {
    "...any": function any(args) {
      if (args.length === 2 && isCollection(args[0])) {
        var dim = args[1];
        if (isNumber(dim)) {
          args[1] = dim - 1;
        } else if (isBigNumber(dim)) {
          args[1] = dim.minus(1);
        }
      }
      try {
        return cumsum2.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/expression/transform/variance.transform.js
var name103 = "variance";
var dependencies91 = ["typed", "add", "subtract", "multiply", "divide", "mapSlices", "isNaN"];
var createVarianceTransform = /* @__PURE__ */ factory(name103, dependencies91, (_ref) => {
  var {
    typed: typed3,
    add: add3,
    subtract: subtract2,
    multiply: multiply2,
    divide: divide3,
    mapSlices: mapSlices2,
    isNaN: mathIsNaN
  } = _ref;
  var variance2 = createVariance({
    typed: typed3,
    add: add3,
    subtract: subtract2,
    multiply: multiply2,
    divide: divide3,
    mapSlices: mapSlices2,
    isNaN: mathIsNaN
  });
  return typed3(name103, {
    "...any": function any(args) {
      args = lastDimToZeroBase(args);
      try {
        return variance2.apply(null, args);
      } catch (err) {
        throw errorTransform(err);
      }
    }
  });
}, {
  isTransformFunction: true
});

// node_modules/mathjs/lib/esm/function/utils/clone.js
var name104 = "clone";
var dependencies92 = ["typed"];
var createClone = /* @__PURE__ */ factory(name104, dependencies92, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name104, {
    any: clone
  });
});

// node_modules/mathjs/lib/esm/function/utils/isNumeric.js
var name105 = "isNumeric";
var dependencies93 = ["typed"];
var createIsNumeric = /* @__PURE__ */ factory(name105, dependencies93, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name105, {
    "number | BigNumber | bigint | Fraction | boolean": () => true,
    "Complex | Unit | string | null | undefined | Node": () => false,
    "Array | Matrix": typed3.referToSelf((self2) => (x) => deepMap2(x, self2))
  });
});

// node_modules/mathjs/lib/esm/function/utils/hasNumericValue.js
var name106 = "hasNumericValue";
var dependencies94 = ["typed", "isNumeric"];
var createHasNumericValue = /* @__PURE__ */ factory(name106, dependencies94, (_ref) => {
  var {
    typed: typed3,
    isNumeric: isNumeric2
  } = _ref;
  return typed3(name106, {
    boolean: () => true,
    string: function string2(x) {
      return x.trim().length > 0 && !isNaN(Number(x));
    },
    any: function any(x) {
      return isNumeric2(x);
    }
  });
});

// node_modules/mathjs/lib/esm/function/utils/isBounded.js
var name107 = "isBounded";
var dependencies95 = ["typed"];
var createIsBounded = /* @__PURE__ */ factory(name107, dependencies95, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name107, {
    number: (n) => Number.isFinite(n),
    "BigNumber | Complex": (x) => x.isFinite(),
    "bigint | Fraction": () => true,
    "null | undefined": () => false,
    Unit: typed3.referToSelf((self2) => (x) => self2(x.value)),
    "Array | Matrix": typed3.referToSelf((self2) => (A) => {
      if (!Array.isArray(A)) A = A.valueOf();
      return A.every((entry) => self2(entry));
    })
  });
});

// node_modules/mathjs/lib/esm/function/utils/isFinite.js
var name108 = "isFinite";
var dependencies96 = ["typed", "isBounded", "map"];
var createIsFinite = /* @__PURE__ */ factory(name108, dependencies96, (_ref) => {
  var {
    typed: typed3,
    isBounded: isBounded2,
    map: map3
  } = _ref;
  return typed3(name108, {
    "Array | Matrix": (A) => map3(A, isBounded2),
    any: (x) => isBounded2(x)
  });
});

// node_modules/mathjs/lib/esm/function/utils/typeOf.js
var name109 = "typeOf";
var dependencies97 = ["typed"];
var createTypeOf = /* @__PURE__ */ factory(name109, dependencies97, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name109, {
    any: typeOf
  });
});

// node_modules/mathjs/lib/esm/function/utils/isPrime.js
var name110 = "isPrime";
var dependencies98 = ["typed"];
var createIsPrime = /* @__PURE__ */ factory(name110, dependencies98, (_ref) => {
  var {
    typed: typed3
  } = _ref;
  return typed3(name110, {
    number: function number2(x) {
      if (x <= 3) {
        return x > 1;
      }
      if (x % 2 === 0 || x % 3 === 0) {
        return false;
      }
      for (var i = 5; i * i <= x; i += 6) {
        if (x % i === 0 || x % (i + 2) === 0) {
          return false;
        }
      }
      return true;
    },
    bigint: function bigint2(x) {
      if (x <= 3n) {
        return x > 1n;
      }
      if (x % 2n === 0n || x % 3n === 0n) {
        return false;
      }
      for (var i = 5n; i * i <= x; i += 6n) {
        if (x % i === 0n || x % (i + 2n) === 0n) {
          return false;
        }
      }
      return true;
    },
    BigNumber: function BigNumber(n) {
      if (n.lte(3)) return n.gt(1);
      if (n.mod(2).eq(0) || n.mod(3).eq(0)) return false;
      if (n.lt(Math.pow(2, 32))) {
        var x = n.toNumber();
        for (var i = 5; i * i <= x; i += 6) {
          if (x % i === 0 || x % (i + 2) === 0) {
            return false;
          }
        }
        return true;
      }
      function modPow(base, exponent, modulus) {
        var accumulator = 1;
        while (!exponent.eq(0)) {
          if (exponent.mod(2).eq(0)) {
            exponent = exponent.div(2);
            base = base.mul(base).mod(modulus);
          } else {
            exponent = exponent.sub(1);
            accumulator = base.mul(accumulator).mod(modulus);
          }
        }
        return accumulator;
      }
      var Decimal2 = n.constructor.clone({
        precision: n.toFixed(0).length * 2
      });
      n = new Decimal2(n);
      var r = 0;
      var d = n.sub(1);
      while (d.mod(2).eq(0)) {
        d = d.div(2);
        r += 1;
      }
      var bases = null;
      if (n.lt("3317044064679887385961981")) {
        bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41].filter((x2) => x2 < n);
      } else {
        var max3 = Math.min(n.toNumber() - 2, Math.floor(2 * Math.pow(n.toFixed(0).length * Math.log(10), 2)));
        bases = [];
        for (var _i = 2; _i <= max3; _i += 1) {
          bases.push(max3);
        }
      }
      for (var _i2 = 0; _i2 < bases.length; _i2 += 1) {
        var a = bases[_i2];
        var adn = modPow(n.sub(n).add(a), d, n);
        if (!adn.eq(1)) {
          for (var _i3 = 0, _x = adn; !_x.eq(n.sub(1)); _i3 += 1, _x = _x.mul(_x).mod(n)) {
            if (_i3 === r - 1) {
              return false;
            }
          }
        }
      }
      return true;
    },
    "Array | Matrix": typed3.referToSelf((self2) => (x) => deepMap2(x, self2))
  });
});

// node_modules/mathjs/lib/esm/function/utils/numeric.js
var name111 = "numeric";
var dependencies99 = ["number", "?bignumber", "?fraction"];
var createNumeric = /* @__PURE__ */ factory(name111, dependencies99, (_ref) => {
  var {
    number: _number,
    bignumber,
    fraction
  } = _ref;
  var validInputTypes = {
    string: true,
    number: true,
    BigNumber: true,
    Fraction: true
  };
  var validOutputTypes = {
    number: (x) => _number(x),
    BigNumber: bignumber ? (x) => bignumber(x) : noBignumber,
    bigint: (x) => BigInt(x),
    Fraction: fraction ? (x) => fraction(x) : noFraction
  };
  return function numeric3(value) {
    var outputType = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "number";
    var check = arguments.length > 2 ? arguments[2] : void 0;
    if (check !== void 0) {
      throw new SyntaxError("numeric() takes one or two arguments");
    }
    var inputType = typeOf(value);
    if (!(inputType in validInputTypes)) {
      throw new TypeError("Cannot convert " + value + ' of type "' + inputType + '"; valid input types are ' + Object.keys(validInputTypes).join(", "));
    }
    if (!(outputType in validOutputTypes)) {
      throw new TypeError("Cannot convert " + value + ' to type "' + outputType + '"; valid output types are ' + Object.keys(validOutputTypes).join(", "));
    }
    if (outputType === inputType) {
      return value;
    } else {
      return validOutputTypes[outputType](value);
    }
  };
});

// node_modules/mathjs/lib/esm/json/reviver.js
var name112 = "reviver";
var dependencies100 = ["classes"];
var createReviver = /* @__PURE__ */ factory(name112, dependencies100, (_ref) => {
  var {
    classes: classes2
  } = _ref;
  return function reviver2(key, value) {
    var constructor = classes2[value && value.mathjs];
    if (constructor && typeof constructor.fromJSON === "function") {
      return constructor.fromJSON(value);
    }
    return value;
  };
});

// node_modules/mathjs/lib/esm/json/replacer.js
var name113 = "replacer";
var dependencies101 = [];
var createReplacer = /* @__PURE__ */ factory(name113, dependencies101, () => {
  return function replacer2(key, value) {
    if (typeof value === "number" && (!Number.isFinite(value) || isNaN(value))) {
      return {
        mathjs: "number",
        value: String(value)
      };
    }
    if (typeof value === "bigint") {
      return {
        mathjs: "bigint",
        value: String(value)
      };
    }
    return value;
  };
});

// node_modules/mathjs/lib/esm/factoriesNumber.js
var createUnaryMinus = /* @__PURE__ */ createNumberFactory("unaryMinus", unaryMinusNumber);
var createUnaryPlus = /* @__PURE__ */ createNumberFactory("unaryPlus", unaryPlusNumber);
var createAbs = /* @__PURE__ */ createNumberFactory("abs", absNumber);
var createAddScalar = /* @__PURE__ */ createNumberFactory("addScalar", addNumber);
var createSubtractScalar = /* @__PURE__ */ createNumberFactory("subtractScalar", subtractNumber);
var createCbrt = /* @__PURE__ */ createNumberFactory("cbrt", cbrtNumber);
var createCube = /* @__PURE__ */ createNumberFactory("cube", cubeNumber);
var createExp = /* @__PURE__ */ createNumberFactory("exp", expNumber);
var createExpm1 = /* @__PURE__ */ createNumberFactory("expm1", expm1Number);
var createGcd = /* @__PURE__ */ createNumberFactory("gcd", gcdNumber);
var createLcm = /* @__PURE__ */ createNumberFactory("lcm", lcmNumber);
var createLog10 = /* @__PURE__ */ createNumberFactory("log10", log10Number);
var createLog2 = /* @__PURE__ */ createNumberFactory("log2", log2Number);
var createMod = /* @__PURE__ */ createNumberFactory("mod", modNumber);
var createMultiplyScalar = /* @__PURE__ */ createNumberFactory("multiplyScalar", multiplyNumber);
var createMultiply = /* @__PURE__ */ createNumberFactory("multiply", multiplyNumber);
var createNthRoot = /* @__PURE__ */ createNumberOptionalSecondArgFactory("nthRoot", nthRootNumber);
var createSign = /* @__PURE__ */ createNumberFactory("sign", signNumber);
var createSqrt = /* @__PURE__ */ createNumberFactory("sqrt", sqrtNumber);
var createSquare = /* @__PURE__ */ createNumberFactory("square", squareNumber);
var createSubtract = /* @__PURE__ */ createNumberFactory("subtract", subtractNumber);
var createXgcd = /* @__PURE__ */ createNumberFactory("xgcd", xgcdNumber);
var createDivideScalar = /* @__PURE__ */ createNumberFactory("divideScalar", divideNumber);
var createPow = /* @__PURE__ */ createNumberFactory("pow", powNumber);
var createRound = /* @__PURE__ */ createNumberOptionalSecondArgFactory("round", roundNumber);
var createLog = /* @__PURE__ */ createNumberOptionalSecondArgFactory("log", logNumber);
var createLog1p = /* @__PURE__ */ createNumberFactory("log1p", log1pNumber);
var createAdd = /* @__PURE__ */ createNumberFactory("add", addNumber);
var createNorm = /* @__PURE__ */ createNumberFactory("norm", normNumber);
var createDivide = /* @__PURE__ */ createNumberFactory("divide", divideNumber);
var createBitAnd = /* @__PURE__ */ createNumberFactory("bitAnd", bitAndNumber);
var createBitNot = /* @__PURE__ */ createNumberFactory("bitNot", bitNotNumber);
var createBitOr = /* @__PURE__ */ createNumberFactory("bitOr", bitOrNumber);
var createBitXor = /* @__PURE__ */ createNumberFactory("bitXor", bitXorNumber);
var createLeftShift = /* @__PURE__ */ createNumberFactory("leftShift", leftShiftNumber);
var createRightArithShift = /* @__PURE__ */ createNumberFactory("rightArithShift", rightArithShiftNumber);
var createRightLogShift = /* @__PURE__ */ createNumberFactory("rightLogShift", rightLogShiftNumber);
var createAnd = /* @__PURE__ */ createNumberFactory("and", andNumber);
var createNot = /* @__PURE__ */ createNumberFactory("not", notNumber);
var createOr = /* @__PURE__ */ createNumberFactory("or", orNumber);
var createXor = /* @__PURE__ */ createNumberFactory("xor", xorNumber);
var createIndex = /* @__PURE__ */ factory("index", [], () => noIndex);
var createMatrix = /* @__PURE__ */ factory("matrix", [], () => noMatrix);
var createSubset = /* @__PURE__ */ factory("subset", [], () => noSubset);
var createCombinations = createNumberFactory("combinations", combinationsNumber);
var createGamma = createNumberFactory("gamma", gammaNumber);
var createLgamma = createNumberFactory("lgamma", lgammaNumber);
var createAcos = /* @__PURE__ */ createNumberFactory("acos", acosNumber);
var createAcosh = /* @__PURE__ */ createNumberFactory("acosh", acoshNumber);
var createAcot = /* @__PURE__ */ createNumberFactory("acot", acotNumber);
var createAcoth = /* @__PURE__ */ createNumberFactory("acoth", acothNumber);
var createAcsc = /* @__PURE__ */ createNumberFactory("acsc", acscNumber);
var createAcsch = /* @__PURE__ */ createNumberFactory("acsch", acschNumber);
var createAsec = /* @__PURE__ */ createNumberFactory("asec", asecNumber);
var createAsech = /* @__PURE__ */ createNumberFactory("asech", asechNumber);
var createAsin = /* @__PURE__ */ createNumberFactory("asin", asinNumber);
var createAsinh = /* @__PURE__ */ createNumberFactory("asinh", asinhNumber);
var createAtan = /* @__PURE__ */ createNumberFactory("atan", atanNumber);
var createAtan2 = /* @__PURE__ */ createNumberFactory("atan2", atan2Number);
var createAtanh = /* @__PURE__ */ createNumberFactory("atanh", atanhNumber);
var createCos = /* @__PURE__ */ createNumberFactory("cos", cosNumber);
var createCosh = /* @__PURE__ */ createNumberFactory("cosh", coshNumber);
var createCot = /* @__PURE__ */ createNumberFactory("cot", cotNumber);
var createCoth = /* @__PURE__ */ createNumberFactory("coth", cothNumber);
var createCsc = /* @__PURE__ */ createNumberFactory("csc", cscNumber);
var createCsch = /* @__PURE__ */ createNumberFactory("csch", cschNumber);
var createSec = /* @__PURE__ */ createNumberFactory("sec", secNumber);
var createSech = /* @__PURE__ */ createNumberFactory("sech", sechNumber);
var createSin = /* @__PURE__ */ createNumberFactory("sin", sinNumber);
var createSinh = /* @__PURE__ */ createNumberFactory("sinh", sinhNumber);
var createTan = /* @__PURE__ */ createNumberFactory("tan", tanNumber);
var createTanh = /* @__PURE__ */ createNumberFactory("tanh", tanhNumber);
var createSubsetTransform = /* @__PURE__ */ factory("subset", [], () => noSubset, {
  isTransformFunction: true
});
var createIsInteger = /* @__PURE__ */ createNumberFactory("isInteger", isIntegerNumber);
var createIsNegative = /* @__PURE__ */ createNumberFactory("isNegative", isNegativeNumber);
var createIsPositive = /* @__PURE__ */ createNumberFactory("isPositive", isPositiveNumber);
var createIsZero = /* @__PURE__ */ createNumberFactory("isZero", isZeroNumber);
var createIsNaN = /* @__PURE__ */ createNumberFactory("isNaN", isNaNNumber);
function createNumberFactory(name114, fn) {
  return factory(name114, ["typed"], (_ref) => {
    var {
      typed: typed3
    } = _ref;
    return typed3(fn);
  });
}
function createNumberOptionalSecondArgFactory(name114, fn) {
  return factory(name114, ["typed"], (_ref2) => {
    var {
      typed: typed3
    } = _ref2;
    return typed3({
      number: fn,
      "number,number": fn
    });
  });
}

// node_modules/mathjs/lib/esm/entry/pureFunctionsNumber.generated.js
var e2 = /* @__PURE__ */ createE({
  config
});
var _false = /* @__PURE__ */ createFalse({});
var index = /* @__PURE__ */ createIndex({});
var _Infinity = /* @__PURE__ */ createInfinity({
  config
});
var LN102 = /* @__PURE__ */ createLN10({
  config
});
var LOG10E = /* @__PURE__ */ createLOG10E({
  config
});
var matrix = /* @__PURE__ */ createMatrix({});
var _NaN = /* @__PURE__ */ createNaN({
  config
});
var _null = /* @__PURE__ */ createNull({});
var phi2 = /* @__PURE__ */ createPhi({
  config
});
var Range = /* @__PURE__ */ createRangeClass({});
var replacer = /* @__PURE__ */ createReplacer({});
var ResultSet = /* @__PURE__ */ createResultSet({});
var SQRT1_2 = /* @__PURE__ */ createSQRT1_2({
  config
});
var subset = /* @__PURE__ */ createSubset({});
var tau2 = /* @__PURE__ */ createTau({
  config
});
var typed2 = /* @__PURE__ */ createTyped({});
var unaryPlus = /* @__PURE__ */ createUnaryPlus({
  typed: typed2
});
var version2 = /* @__PURE__ */ createVersion({});
var xor = /* @__PURE__ */ createXor({
  typed: typed2
});
var abs2 = /* @__PURE__ */ createAbs({
  typed: typed2
});
var acos2 = /* @__PURE__ */ createAcos({
  typed: typed2
});
var acot = /* @__PURE__ */ createAcot({
  typed: typed2
});
var acsc = /* @__PURE__ */ createAcsc({
  typed: typed2
});
var add2 = /* @__PURE__ */ createAdd({
  typed: typed2
});
var and = /* @__PURE__ */ createAnd({
  typed: typed2
});
var asec = /* @__PURE__ */ createAsec({
  typed: typed2
});
var asin2 = /* @__PURE__ */ createAsin({
  typed: typed2
});
var atan3 = /* @__PURE__ */ createAtan({
  typed: typed2
});
var atanh3 = /* @__PURE__ */ createAtanh({
  typed: typed2
});
var bigint = /* @__PURE__ */ createBigint({
  typed: typed2
});
var bitNot = /* @__PURE__ */ createBitNot({
  typed: typed2
});
var bitXor = /* @__PURE__ */ createBitXor({
  typed: typed2
});
var boolean = /* @__PURE__ */ createBoolean({
  typed: typed2
});
var cbrt4 = /* @__PURE__ */ createCbrt({
  typed: typed2
});
var combinations = /* @__PURE__ */ createCombinations({
  typed: typed2
});
var compare = /* @__PURE__ */ createCompareNumber({
  config,
  typed: typed2
});
var compareText2 = /* @__PURE__ */ createCompareTextNumber({
  typed: typed2
});
var cos2 = /* @__PURE__ */ createCos({
  typed: typed2
});
var cot = /* @__PURE__ */ createCot({
  typed: typed2
});
var csc = /* @__PURE__ */ createCsc({
  typed: typed2
});
var cube = /* @__PURE__ */ createCube({
  typed: typed2
});
var divide2 = /* @__PURE__ */ createDivide({
  typed: typed2
});
var equalScalar = /* @__PURE__ */ createEqualScalarNumber({
  config,
  typed: typed2
});
var erf = /* @__PURE__ */ createErf({
  typed: typed2
});
var exp2 = /* @__PURE__ */ createExp({
  typed: typed2
});
var filter2 = /* @__PURE__ */ createFilter({
  typed: typed2
});
var forEach2 = /* @__PURE__ */ createForEach({
  typed: typed2
});
var format4 = /* @__PURE__ */ createFormat({
  typed: typed2
});
var gamma = /* @__PURE__ */ createGamma({
  typed: typed2
});
var isBounded = /* @__PURE__ */ createIsBounded({
  typed: typed2
});
var isInteger3 = /* @__PURE__ */ createIsInteger({
  typed: typed2
});
var isNegative = /* @__PURE__ */ createIsNegative({
  typed: typed2
});
var isPositive = /* @__PURE__ */ createIsPositive({
  typed: typed2
});
var isZero = /* @__PURE__ */ createIsZero({
  typed: typed2
});
var LOG2E = /* @__PURE__ */ createLOG2E({
  config
});
var largerEq = /* @__PURE__ */ createLargerEqNumber({
  config,
  typed: typed2
});
var leftShift = /* @__PURE__ */ createLeftShift({
  typed: typed2
});
var log3 = /* @__PURE__ */ createLog({
  typed: typed2
});
var log1p2 = /* @__PURE__ */ createLog1p({
  typed: typed2
});
var map2 = /* @__PURE__ */ createMap2({
  typed: typed2
});
var mean = /* @__PURE__ */ createMean({
  add: add2,
  divide: divide2,
  typed: typed2
});
var mod2 = /* @__PURE__ */ createMod({
  typed: typed2
});
var multiply = /* @__PURE__ */ createMultiply({
  typed: typed2
});
var not = /* @__PURE__ */ createNot({
  typed: typed2
});
var number = /* @__PURE__ */ createNumber({
  typed: typed2
});
var or = /* @__PURE__ */ createOr({
  typed: typed2
});
var pi2 = /* @__PURE__ */ createPi({
  config
});
var pow2 = /* @__PURE__ */ createPow({
  typed: typed2
});
var random2 = /* @__PURE__ */ createRandomNumber({
  config,
  typed: typed2
});
var rightLogShift = /* @__PURE__ */ createRightLogShift({
  typed: typed2
});
var SQRT2 = /* @__PURE__ */ createSQRT2({
  config
});
var sech = /* @__PURE__ */ createSech({
  typed: typed2
});
var sin2 = /* @__PURE__ */ createSin({
  typed: typed2
});
var size = /* @__PURE__ */ createSize({
  typed: typed2
});
var smallerEq = /* @__PURE__ */ createSmallerEqNumber({
  config,
  typed: typed2
});
var square = /* @__PURE__ */ createSquare({
  typed: typed2
});
var string = /* @__PURE__ */ createString({
  typed: typed2
});
var subtract = /* @__PURE__ */ createSubtract({
  typed: typed2
});
var tanh3 = /* @__PURE__ */ createTanh({
  typed: typed2
});
var typeOf2 = /* @__PURE__ */ createTypeOf({
  typed: typed2
});
var unequal = /* @__PURE__ */ createUnequalNumber({
  equalScalar,
  typed: typed2
});
var xgcd = /* @__PURE__ */ createXgcd({
  typed: typed2
});
var acoth = /* @__PURE__ */ createAcoth({
  typed: typed2
});
var addScalar = /* @__PURE__ */ createAddScalar({
  typed: typed2
});
var asech = /* @__PURE__ */ createAsech({
  typed: typed2
});
var bernoulli = /* @__PURE__ */ createBernoulli({
  config,
  isInteger: isInteger3,
  number,
  typed: typed2
});
var bitOr = /* @__PURE__ */ createBitOr({
  typed: typed2
});
var combinationsWithRep = /* @__PURE__ */ createCombinationsWithRep({
  typed: typed2
});
var cosh3 = /* @__PURE__ */ createCosh({
  typed: typed2
});
var csch = /* @__PURE__ */ createCsch({
  typed: typed2
});
var divideScalar = /* @__PURE__ */ createDivideScalar({
  typed: typed2
});
var equalText = /* @__PURE__ */ createEqualText({
  compareText: compareText2,
  isZero,
  typed: typed2
});
var expm13 = /* @__PURE__ */ createExpm1({
  typed: typed2
});
var isNaN2 = /* @__PURE__ */ createIsNaN({
  typed: typed2
});
var isPrime = /* @__PURE__ */ createIsPrime({
  typed: typed2
});
var larger = /* @__PURE__ */ createLargerNumber({
  config,
  typed: typed2
});
var lgamma = /* @__PURE__ */ createLgamma({
  typed: typed2
});
var log24 = /* @__PURE__ */ createLog2({
  typed: typed2
});
var mapSlices = /* @__PURE__ */ createMapSlices({
  isInteger: isInteger3,
  typed: typed2
});
var multiplyScalar = /* @__PURE__ */ createMultiplyScalar({
  typed: typed2
});
var nthRoot = /* @__PURE__ */ createNthRoot({
  typed: typed2
});
var pickRandom = /* @__PURE__ */ createPickRandom({
  config,
  typed: typed2
});
var randomInt = /* @__PURE__ */ createRandomInt({
  config,
  log2: log24,
  typed: typed2
});
var rightArithShift = /* @__PURE__ */ createRightArithShift({
  typed: typed2
});
var sec = /* @__PURE__ */ createSec({
  typed: typed2
});
var sinh3 = /* @__PURE__ */ createSinh({
  typed: typed2
});
var sqrt2 = /* @__PURE__ */ createSqrt({
  typed: typed2
});
var tan2 = /* @__PURE__ */ createTan({
  typed: typed2
});
var unaryMinus = /* @__PURE__ */ createUnaryMinus({
  typed: typed2
});
var variance = /* @__PURE__ */ createVariance({
  add: add2,
  divide: divide2,
  isNaN: isNaN2,
  mapSlices,
  multiply,
  subtract,
  typed: typed2
});
var acosh3 = /* @__PURE__ */ createAcosh({
  typed: typed2
});
var atan22 = /* @__PURE__ */ createAtan2({
  typed: typed2
});
var bitAnd = /* @__PURE__ */ createBitAnd({
  typed: typed2
});
var catalan = /* @__PURE__ */ createCatalan({
  addScalar,
  combinations,
  divideScalar,
  isInteger: isInteger3,
  isNegative,
  multiplyScalar,
  typed: typed2
});
var clone4 = /* @__PURE__ */ createClone({
  typed: typed2
});
var composition = /* @__PURE__ */ createComposition({
  addScalar,
  combinations,
  isInteger: isInteger3,
  isNegative,
  isPositive,
  larger,
  typed: typed2
});
var coth = /* @__PURE__ */ createCoth({
  typed: typed2
});
var equal = /* @__PURE__ */ createEqualNumber({
  equalScalar,
  typed: typed2
});
var factorial = /* @__PURE__ */ createFactorial({
  gamma,
  typed: typed2
});
var isFinite2 = /* @__PURE__ */ createIsFinite({
  isBounded,
  map: map2,
  typed: typed2
});
var LN2 = /* @__PURE__ */ createLN2({
  config
});
var log104 = /* @__PURE__ */ createLog10({
  typed: typed2
});
var multinomial = /* @__PURE__ */ createMultinomial({
  add: add2,
  divide: divide2,
  factorial,
  isInteger: isInteger3,
  isPositive,
  multiply,
  typed: typed2
});
var numeric2 = /* @__PURE__ */ createNumeric({
  number
});
var permutations = /* @__PURE__ */ createPermutations({
  factorial,
  typed: typed2
});
var prod = /* @__PURE__ */ createProd({
  config,
  multiplyScalar,
  numeric: numeric2,
  typed: typed2
});
var round2 = /* @__PURE__ */ createRound({
  typed: typed2
});
var smaller = /* @__PURE__ */ createSmallerNumber({
  config,
  typed: typed2
});
var subtractScalar = /* @__PURE__ */ createSubtractScalar({
  typed: typed2
});
var zeta = /* @__PURE__ */ createZeta({
  add: add2,
  config,
  divide: divide2,
  equal,
  factorial,
  gamma,
  isBounded,
  isNegative,
  multiply,
  pi: pi2,
  pow: pow2,
  sin: sin2,
  smallerEq,
  subtract,
  typed: typed2
});
var acsch = /* @__PURE__ */ createAcsch({
  typed: typed2
});
var compareNatural = /* @__PURE__ */ createCompareNatural({
  compare,
  typed: typed2
});
var cumsum = /* @__PURE__ */ createCumSum({
  add: add2,
  typed: typed2,
  unaryPlus
});
var floor2 = /* @__PURE__ */ createFloorNumber({
  config,
  round: round2,
  typed: typed2
});
var hypot2 = /* @__PURE__ */ createHypot({
  abs: abs2,
  addScalar,
  divideScalar,
  isPositive,
  multiplyScalar,
  smaller,
  sqrt: sqrt2,
  typed: typed2
});
var lcm = /* @__PURE__ */ createLcm({
  typed: typed2
});
var max2 = /* @__PURE__ */ createMax({
  config,
  isNaN: isNaN2,
  larger,
  numeric: numeric2,
  typed: typed2
});
var min2 = /* @__PURE__ */ createMin({
  config,
  isNaN: isNaN2,
  numeric: numeric2,
  smaller,
  typed: typed2
});
var norm = /* @__PURE__ */ createNorm({
  typed: typed2
});
var print = /* @__PURE__ */ createPrint({
  typed: typed2
});
var range = /* @__PURE__ */ createRange({
  matrix,
  add: add2,
  config,
  equal,
  isPositive,
  isZero,
  larger,
  largerEq,
  smaller,
  smallerEq,
  typed: typed2
});
var sign3 = /* @__PURE__ */ createSign({
  typed: typed2
});
var std = /* @__PURE__ */ createStd({
  map: map2,
  sqrt: sqrt2,
  typed: typed2,
  variance
});
var sum2 = /* @__PURE__ */ createSum({
  add: add2,
  config,
  numeric: numeric2,
  typed: typed2
});
var asinh3 = /* @__PURE__ */ createAsinh({
  typed: typed2
});
var ceil2 = /* @__PURE__ */ createCeilNumber({
  config,
  round: round2,
  typed: typed2
});
var corr = /* @__PURE__ */ createCorr({
  add: add2,
  divide: divide2,
  matrix,
  mean,
  multiply,
  pow: pow2,
  sqrt: sqrt2,
  subtract,
  sum: sum2,
  typed: typed2
});
var fix = /* @__PURE__ */ createFixNumber({
  ceil: ceil2,
  floor: floor2,
  typed: typed2
});
var isNumeric = /* @__PURE__ */ createIsNumeric({
  typed: typed2
});
var partitionSelect = /* @__PURE__ */ createPartitionSelect({
  compare,
  isNaN: isNaN2,
  isNumeric,
  typed: typed2
});
var stirlingS2 = /* @__PURE__ */ createStirlingS2({
  addScalar,
  combinations,
  divideScalar,
  factorial,
  isInteger: isInteger3,
  isNegative,
  larger,
  multiplyScalar,
  number,
  pow: pow2,
  subtractScalar,
  typed: typed2
});
var bellNumbers = /* @__PURE__ */ createBellNumbers({
  addScalar,
  isInteger: isInteger3,
  isNegative,
  stirlingS2,
  typed: typed2
});
var deepEqual = /* @__PURE__ */ createDeepEqual({
  equal,
  typed: typed2
});
var gcd = /* @__PURE__ */ createGcd({
  typed: typed2
});
var median = /* @__PURE__ */ createMedian({
  add: add2,
  compare,
  divide: divide2,
  partitionSelect,
  typed: typed2
});
var quantileSeq = /* @__PURE__ */ createQuantileSeq({
  add: add2,
  compare,
  divide: divide2,
  isInteger: isInteger3,
  larger,
  mapSlices,
  multiply,
  partitionSelect,
  smaller,
  smallerEq,
  subtract,
  typed: typed2
});
var mode = /* @__PURE__ */ createMode({
  isNaN: isNaN2,
  isNumeric,
  typed: typed2
});
var _true = /* @__PURE__ */ createTrue({});
var hasNumericValue = /* @__PURE__ */ createHasNumericValue({
  isNumeric,
  typed: typed2
});
var mad = /* @__PURE__ */ createMad({
  abs: abs2,
  map: map2,
  median,
  subtract,
  typed: typed2
});

// node_modules/mathjs/lib/esm/entry/impureFunctionsNumber.generated.js
var import_extends4 = __toESM(require_extends(), 1);
var math = {};
var mathWithTransform = {};
var classes = {};
var Chain = createChainClass({
  math,
  typed: typed2
});
var Node = createNode({
  mathWithTransform
});
var ObjectNode = createObjectNode({
  Node
});
var RangeNode = createRangeNode({
  Node
});
var RelationalNode = createRelationalNode({
  Node
});
var reviver = createReviver({
  classes
});
var SymbolNode = createSymbolNode({
  Node,
  math
});
var AccessorNode = createAccessorNode({
  Node,
  subset
});
var AssignmentNode = createAssignmentNode({
  matrix,
  Node,
  subset
});
var chain = createChain({
  Chain,
  typed: typed2
});
var ConditionalNode = createConditionalNode({
  Node
});
var FunctionNode = createFunctionNode({
  Node,
  SymbolNode,
  math
});
var IndexNode = createIndexNode({
  Node,
  size
});
var OperatorNode = createOperatorNode({
  Node
});
var ArrayNode = createArrayNode({
  Node
});
var FunctionAssignmentNode = createFunctionAssignmentNode({
  Node,
  typed: typed2
});
var BlockNode = createBlockNode({
  Node,
  ResultSet
});
var ConstantNode = createConstantNode({
  Node,
  isBounded
});
var simplifyConstant = createSimplifyConstant({
  AccessorNode,
  ArrayNode,
  ConstantNode,
  FunctionNode,
  IndexNode,
  ObjectNode,
  OperatorNode,
  SymbolNode,
  config,
  isBounded,
  mathWithTransform,
  matrix,
  typed: typed2
});
var ParenthesisNode = createParenthesisNode({
  Node
});
var parse = createParse({
  AccessorNode,
  ArrayNode,
  AssignmentNode,
  BlockNode,
  ConditionalNode,
  ConstantNode,
  FunctionAssignmentNode,
  FunctionNode,
  IndexNode,
  ObjectNode,
  OperatorNode,
  ParenthesisNode,
  RangeNode,
  RelationalNode,
  SymbolNode,
  config,
  numeric: numeric2,
  typed: typed2
});
var resolve = createResolve({
  ConstantNode,
  FunctionNode,
  OperatorNode,
  ParenthesisNode,
  parse,
  typed: typed2
});
var simplifyCore = createSimplifyCore({
  AccessorNode,
  ArrayNode,
  ConstantNode,
  FunctionNode,
  IndexNode,
  ObjectNode,
  OperatorNode,
  ParenthesisNode,
  SymbolNode,
  add: add2,
  divide: divide2,
  equal,
  isZero,
  multiply,
  parse,
  pow: pow2,
  subtract,
  typed: typed2
});
var compile = createCompile({
  parse,
  typed: typed2
});
var evaluate = createEvaluate({
  parse,
  typed: typed2
});
var Help = createHelpClass({
  evaluate
});
var Parser = createParserClass({
  evaluate,
  parse
});
var simplify = createSimplify({
  AccessorNode,
  ArrayNode,
  ConstantNode,
  FunctionNode,
  IndexNode,
  ObjectNode,
  OperatorNode,
  ParenthesisNode,
  SymbolNode,
  equal,
  parse,
  replacer,
  resolve,
  simplifyConstant,
  simplifyCore,
  typed: typed2
});
var derivative = createDerivative({
  ConstantNode,
  FunctionNode,
  OperatorNode,
  ParenthesisNode,
  SymbolNode,
  config,
  equal,
  isZero,
  numeric: numeric2,
  parse,
  simplify,
  typed: typed2
});
var help = createHelp({
  Help,
  mathWithTransform,
  typed: typed2
});
var parser = createParser({
  Parser,
  typed: typed2
});
var rationalize = createRationalize({
  AccessorNode,
  ArrayNode,
  ConstantNode,
  FunctionNode,
  IndexNode,
  ObjectNode,
  OperatorNode,
  ParenthesisNode,
  SymbolNode,
  add: add2,
  config,
  divide: divide2,
  equal,
  isZero,
  mathWithTransform,
  matrix,
  multiply,
  parse,
  pow: pow2,
  simplify,
  simplifyConstant,
  simplifyCore,
  subtract,
  typed: typed2
});
(0, import_extends4.default)(math, {
  e: e2,
  false: _false,
  index,
  Infinity: _Infinity,
  LN10: LN102,
  LOG10E,
  matrix,
  NaN: _NaN,
  null: _null,
  phi: phi2,
  replacer,
  SQRT1_2,
  subset,
  tau: tau2,
  typed: typed2,
  unaryPlus,
  "E": e2,
  version: version2,
  xor,
  abs: abs2,
  acos: acos2,
  acot,
  acsc,
  add: add2,
  and,
  asec,
  asin: asin2,
  atan: atan3,
  atanh: atanh3,
  bigint,
  bitNot,
  bitXor,
  boolean,
  cbrt: cbrt4,
  combinations,
  compare,
  compareText: compareText2,
  cos: cos2,
  cot,
  csc,
  cube,
  divide: divide2,
  equalScalar,
  erf,
  exp: exp2,
  filter: filter2,
  forEach: forEach2,
  format: format4,
  gamma,
  isBounded,
  isInteger: isInteger3,
  isNegative,
  isPositive,
  isZero,
  LOG2E,
  largerEq,
  leftShift,
  log: log3,
  log1p: log1p2,
  map: map2,
  mean,
  mod: mod2,
  multiply,
  not,
  number,
  or,
  pi: pi2,
  pow: pow2,
  random: random2,
  reviver,
  rightLogShift,
  SQRT2,
  sech,
  sin: sin2,
  size,
  smallerEq,
  square,
  string,
  subtract,
  tanh: tanh3,
  typeOf: typeOf2,
  unequal,
  xgcd,
  acoth,
  addScalar,
  asech,
  bernoulli,
  bitOr,
  chain,
  combinationsWithRep,
  cosh: cosh3,
  csch,
  divideScalar,
  equalText,
  expm1: expm13,
  isNaN: isNaN2,
  isPrime,
  larger,
  lgamma,
  log2: log24,
  mapSlices,
  multiplyScalar,
  nthRoot,
  pickRandom,
  randomInt,
  rightArithShift,
  sec,
  sinh: sinh3,
  sqrt: sqrt2,
  tan: tan2,
  unaryMinus,
  variance,
  acosh: acosh3,
  atan2: atan22,
  bitAnd,
  catalan,
  clone: clone4,
  composition,
  coth,
  equal,
  factorial,
  isFinite: isFinite2,
  LN2,
  log10: log104,
  multinomial,
  numeric: numeric2,
  permutations,
  prod,
  round: round2,
  smaller,
  subtractScalar,
  "PI": pi2,
  zeta,
  acsch,
  compareNatural,
  cumsum,
  floor: floor2,
  hypot: hypot2,
  lcm,
  max: max2,
  min: min2,
  norm,
  print,
  range,
  sign: sign3,
  simplifyConstant,
  std,
  sum: sum2,
  asinh: asinh3,
  ceil: ceil2,
  corr,
  fix,
  isNumeric,
  partitionSelect,
  stirlingS2,
  bellNumbers,
  deepEqual,
  gcd,
  median,
  parse,
  quantileSeq,
  resolve,
  simplifyCore,
  compile,
  evaluate,
  mode,
  simplify,
  derivative,
  help,
  parser,
  true: _true,
  hasNumericValue,
  rationalize,
  mad,
  config
});
(0, import_extends4.default)(mathWithTransform, math, {
  cumsum: createCumSumTransform({
    add: add2,
    typed: typed2,
    unaryPlus
  }),
  mapSlices: createMapSlicesTransform({
    isInteger: isInteger3,
    typed: typed2
  }),
  filter: createFilterTransform({
    typed: typed2
  }),
  forEach: createForEachTransform({
    typed: typed2
  }),
  mean: createMeanTransform({
    add: add2,
    divide: divide2,
    typed: typed2
  }),
  subset: createSubsetTransform({}),
  map: createMapTransform({
    typed: typed2
  }),
  std: createStdTransform({
    map: map2,
    sqrt: sqrt2,
    typed: typed2,
    variance
  }),
  sum: createSumTransform({
    add: add2,
    config,
    numeric: numeric2,
    typed: typed2
  }),
  variance: createVarianceTransform({
    add: add2,
    divide: divide2,
    isNaN: isNaN2,
    mapSlices,
    multiply,
    subtract,
    typed: typed2
  }),
  max: createMaxTransform({
    config,
    isNaN: isNaN2,
    larger,
    numeric: numeric2,
    typed: typed2
  }),
  min: createMinTransform({
    config,
    isNaN: isNaN2,
    numeric: numeric2,
    smaller,
    typed: typed2
  }),
  range: createRangeTransform({
    matrix,
    add: add2,
    config,
    equal,
    isPositive,
    isZero,
    larger,
    largerEq,
    smaller,
    smallerEq,
    typed: typed2
  })
});
(0, import_extends4.default)(classes, {
  Range,
  ResultSet,
  Chain,
  Node,
  ObjectNode,
  RangeNode,
  RelationalNode,
  SymbolNode,
  AccessorNode,
  AssignmentNode,
  ConditionalNode,
  FunctionNode,
  IndexNode,
  OperatorNode,
  ArrayNode,
  FunctionAssignmentNode,
  BlockNode,
  ConstantNode,
  ParenthesisNode,
  Help,
  Parser
});
Chain.createProxy(math);

// base_lib/expression_engine.ts
function isBuiltin(name114) {
  return [
    "sin",
    "cos",
    "tan",
    "asin",
    "acos",
    "atan",
    "sinh",
    "cosh",
    "tanh",
    "asinh",
    "acosh",
    "atanh",
    "exp",
    "log",
    "ln",
    "sqrt",
    "abs",
    "floor",
    "ceil",
    "round",
    "trunc",
    "min",
    "max",
    "clamp",
    "pow",
    "mod",
    "factorial",
    "gamma",
    "derivative",
    "integral",
    "random"
  ].includes(name114);
}
function diagnostic(code, message, extra = {}) {
  return { code, message, ...extra };
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function clone5(value) {
  return structuredClone(value);
}
function finite(value, code, message) {
  if (!Number.isFinite(value))
    throw new ExpressionFailure(diagnostic(code, message));
  return Object.is(value, -0) ? 0 : value;
}
var ExpressionFailure = class extends Error {
  constructor(detail) {
    super(detail.message);
    this.detail = detail;
  }
  detail;
};
function lex(source) {
  const tokens = [];
  let cursor = 0;
  while (cursor < source.length) {
    const char = source[cursor];
    if (/\s/u.test(char)) {
      cursor += 1;
      continue;
    }
    if (/[0-9.]/u.test(char) && (/[0-9]/u.test(char) || /[0-9]/u.test(source[cursor + 1] ?? ""))) {
      const match = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/u.exec(
        source.slice(cursor)
      );
      if (!match)
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_LEX_INVALID_NUMBER", "\u65E0\u6548\u6570\u5B57\u3002", {
            position: cursor
          })
        );
      tokens.push({ kind: "number", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if (/[A-Za-z_]/u.test(char)) {
      const match = /^[A-Za-z_][A-Za-z0-9_]*/u.exec(source.slice(cursor));
      tokens.push({ kind: "identifier", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if ("+-*/%^@".includes(char)) {
      tokens.push({ kind: "operator", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    if ("(),.".includes(char)) {
      tokens.push({ kind: "punctuation", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_LEX_INVALID_CHARACTER",
        `\u4E0D\u652F\u6301\u5B57\u7B26 ${JSON.stringify(char)}\u3002`,
        { position: cursor }
      )
    );
  }
  tokens.push({ kind: "eof", text: "", position: cursor });
  return tokens;
}
var Parser2 = class {
  constructor(tokens, allowSnapshot) {
    this.tokens = tokens;
    this.allowSnapshot = allowSnapshot;
  }
  tokens;
  allowSnapshot;
  index = 0;
  current() {
    return this.tokens[this.index];
  }
  take() {
    return this.tokens[this.index++];
  }
  matches(text) {
    return this.current().text === text;
  }
  expect(text) {
    if (!this.matches(text))
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_EXPECTED", `\u6B64\u5904\u5E94\u4E3A ${text}\u3002`, {
          position: this.current().position
        })
      );
    return this.take();
  }
  parse() {
    const ast = this.additive();
    if (this.current().kind !== "eof")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_TRAILING", "\u8868\u8FBE\u5F0F\u672B\u5C3E\u5B58\u5728\u672A\u89E3\u6790\u5185\u5BB9\u3002", {
          position: this.current().position
        })
      );
    return ast;
  }
  additive() {
    let left = this.multiplicative();
    while (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.multiplicative() };
    }
    return left;
  }
  multiplicative() {
    let left = this.unary();
    while (this.matches("*") || this.matches("/") || this.matches("%")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.unary() };
    }
    return left;
  }
  unary() {
    if (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      return { kind: "unary", op, value: this.unary() };
    }
    return this.power();
  }
  power() {
    const left = this.primary();
    if (this.matches("^")) {
      this.take();
      return { kind: "binary", op: "^", left, right: this.unary() };
    }
    return left;
  }
  primary() {
    if (this.matches("(")) {
      this.take();
      const ast = this.additive();
      this.expect(")");
      return ast;
    }
    if (this.current().kind === "number") {
      const token = this.take();
      return {
        kind: "literal",
        value: finite(
          Number(token.text),
          "ERA_EXPR_NUMBER_NON_FINITE",
          "\u6570\u5B57\u5FC5\u987B\u6709\u9650\u3002"
        )
      };
    }
    let snapshot = false;
    if (this.matches("@")) {
      if (!this.allowSnapshot)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_SNAPSHOT_FORBIDDEN",
            "\u7528\u6237\u539F\u59CB\u8868\u8FBE\u5F0F\u4E0D\u80FD\u4F7F\u7528 @path\u3002",
            { position: this.current().position }
          )
        );
      this.take();
      snapshot = true;
    }
    if (this.current().kind !== "identifier")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_PRIMARY", "\u6B64\u5904\u5E94\u4E3A\u6570\u5B57\u3001\u53D8\u91CF\u6216\u51FD\u6570\u8C03\u7528\u3002", {
          position: this.current().position
        })
      );
    const first = this.take();
    if (this.matches("(")) {
      this.take();
      const args = [];
      if (!this.matches(")")) {
        do {
          args.push(this.additive());
          if (!this.matches(",")) break;
          this.take();
        } while (true);
      }
      this.expect(")");
      return { kind: "call", name: first.text, args, snapshot };
    }
    const path = [first.text];
    while (this.matches(".")) {
      this.take();
      const segment = this.current();
      if (segment.kind !== "identifier")
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_PATH_SEGMENT", "\u8DEF\u5F84\u70B9\u53F7\u540E\u5E94\u4E3A\u6807\u8BC6\u7B26\u3002", {
            position: segment.position
          })
        );
      path.push(this.take().text);
    }
    return { kind: "ref", path, snapshot };
  }
};
function parseExpression(source, allowSnapshot = false) {
  try {
    return {
      ast: new Parser2(lex(source), allowSnapshot).parse(),
      diagnostics: []
    };
  } catch (error) {
    return {
      ast: null,
      diagnostics: [
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PARSE_FAILED", String(error))
      ]
    };
  }
}
function validatePath(value) {
  const parts = value.split(".");
  if (parts.length === 0 || parts.some((part) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(part)))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_PATH_INVALID",
        `\u65E0\u6548\u53D8\u91CF\u8DEF\u5F84 ${JSON.stringify(value)}\u3002`,
        { path: value }
      )
    );
  return parts;
}
function getPath(root, path) {
  let value = root;
  for (const segment of path) {
    if (!isRecord(value) || !(segment in value)) return void 0;
    value = value[segment];
  }
  return value;
}
function setPath(root, path, value) {
  if (!isRecord(root))
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_STATE_ROOT", "\u53D8\u91CF\u72B6\u6001\u6839\u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const next = clone5(root);
  let cursor = next;
  for (const segment of path.slice(0, -1)) {
    const child = cursor[segment];
    if (!isRecord(child)) cursor[segment] = {};
    cursor = cursor[segment];
  }
  cursor[path[path.length - 1]] = value;
  return next;
}
function normaliseRequest(input) {
  const diagnostics = [];
  const request = isRecord(input) ? input : {};
  const initialState = request.initialState;
  if (!isRecord(initialState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_INITIAL_STATE_INVALID",
        "initialState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const snapshotState = request.snapshotState === void 0 ? null : isRecord(request.snapshotState) ? clone5(request.snapshotState) : null;
  if (request.snapshotState !== void 0 && !isRecord(request.snapshotState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_STATE_INVALID",
        "snapshotState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const functionLibrary = isRecord(request.functionLibrary) ? request.functionLibrary : {};
  if (request.functionLibrary !== void 0 && !isRecord(request.functionLibrary))
    diagnostics.push(
      diagnostic("ERA_EXPR_LIBRARY_INVALID", "functionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const snapshotFunctionLibrary = request.snapshotFunctionLibrary === void 0 ? null : isRecord(request.snapshotFunctionLibrary) ? request.snapshotFunctionLibrary : null;
  if (request.snapshotFunctionLibrary !== void 0 && !isRecord(request.snapshotFunctionLibrary))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_LIBRARY_INVALID",
        "snapshotFunctionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002"
      )
    );
  let randomContext = null;
  if (request.randomContext !== void 0) {
    if (!isRecord(request.randomContext) || typeof request.randomContext.sourceKey !== "string" || request.randomContext.sourceKey.length === 0 || !Number.isSafeInteger(request.randomContext.drawOffset) || request.randomContext.drawOffset < 0)
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_RANDOM_CONTEXT_INVALID",
          "randomContext \u9700\u8981\u975E\u7A7A sourceKey \u4E0E\u975E\u8D1F\u5B89\u5168\u6574\u6570 drawOffset\u3002"
        )
      );
    else
      randomContext = {
        sourceKey: request.randomContext.sourceKey,
        drawOffset: request.randomContext.drawOffset
      };
  }
  const rawOperations = Array.isArray(request.operations) ? request.operations : [];
  if (!Array.isArray(request.operations))
    diagnostics.push(
      diagnostic("ERA_EXPR_OPERATIONS_INVALID", "operations \u5FC5\u987B\u662F\u6709\u5E8F\u6570\u7EC4\u3002")
    );
  const operations = [];
  for (const [index2, operation] of rawOperations.entries()) {
    if (!isRecord(operation) || typeof operation.path !== "string" || typeof operation.expr !== "string") {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_OPERATION_SHAPE",
          `operations[${index2}] \u5FC5\u987B\u6709 path \u548C expr \u5B57\u7B26\u4E32\u3002`
        )
      );
      continue;
    }
    operations.push({ path: operation.path, expr: operation.expr });
  }
  return {
    initialState: isRecord(initialState) ? clone5(initialState) : {},
    snapshotState,
    functionLibrary,
    snapshotFunctionLibrary,
    allowSnapshots: request.allowSnapshots === true,
    randomContext,
    operations,
    diagnostics,
    valid: diagnostics.length === 0
  };
}
function parseFunctionDefinitions(request) {
  const parsed = [];
  for (const [name114, raw] of Object.entries(request.functionLibrary)) {
    const definition = isRecord(raw) ? { params: raw.params, expr: raw.expr } : raw;
    const diagnostics = [];
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/u.test(name114))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME",
          `\u51FD\u6570\u540D ${JSON.stringify(name114)} \u65E0\u6548\u3002`,
          { path: name114 }
        )
      );
    if (isBuiltin(name114))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME_CONFLICT",
          `\u51FD\u6570\u540D ${name114} \u4E0E\u5185\u5EFA\u51FD\u6570\u51B2\u7A81\u3002`,
          { path: name114 }
        )
      );
    if (!isRecord(definition) || !Array.isArray(definition.params) || typeof definition.expr !== "string")
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_SHAPE",
          `\u51FD\u6570 ${name114} \u5E94\u5305\u542B params \u6570\u7EC4\u4E0E expr \u5B57\u7B26\u4E32\u3002`,
          { path: name114 }
        )
      );
    const params = isRecord(definition) && Array.isArray(definition.params) ? definition.params.filter((item) => typeof item === "string") : [];
    if (params.length !== new Set(params).size || params.some((param) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(param)))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_PARAMS",
          `\u51FD\u6570 ${name114} \u7684\u5F62\u53C2\u5FC5\u987B\u662F\u4E92\u5F02\u6807\u8BC6\u7B26\u3002`,
          { path: name114 }
        )
      );
    const expr = isRecord(definition) && typeof definition.expr === "string" ? definition.expr : "";
    const result = diagnostics.length === 0 ? parseExpression(expr, false) : { ast: null, diagnostics: [] };
    parsed.push({
      name: name114,
      params,
      expr,
      ast: result.ast,
      diagnostics: [...diagnostics, ...result.diagnostics]
    });
  }
  return parsed;
}
function walk(ast, visitor) {
  visitor(ast);
  if (ast.kind === "unary") walk(ast.value, visitor);
  if (ast.kind === "binary") {
    walk(ast.left, visitor);
    walk(ast.right, visitor);
  }
  if (ast.kind === "call") for (const arg of ast.args) walk(arg, visitor);
}
function extractFunctionDependencies(parsed) {
  const names = new Set(parsed.map((item) => item.name));
  const result = {};
  for (const functionDef of parsed) {
    const dependencies102 = /* @__PURE__ */ new Set();
    if (functionDef.ast)
      walk(functionDef.ast, (item) => {
        if (item.kind === "call" && names.has(item.name))
          dependencies102.add(item.name);
      });
    result[functionDef.name] = [...dependencies102].sort();
  }
  return result;
}
function validateFunctionPurity(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const diagnostics = [];
  for (const functionDef of parsed) {
    diagnostics.push(...functionDef.diagnostics);
    if (!functionDef.ast) continue;
    const params = new Set(functionDef.params);
    walk(functionDef.ast, (item) => {
      if (item.kind === "ref" && (!params.has(item.path[0]) || item.path.length !== 1 || item.snapshot))
        diagnostics.push(
          diagnostic(
            "ERA_EXPR_FUNCTION_IMPURE",
            `\u51FD\u6570 ${functionDef.name} \u53EA\u80FD\u8BFB\u53D6\u81EA\u5DF1\u7684\u5F62\u53C2\u3002`,
            { path: functionDef.name }
          )
        );
      if (item.kind === "call") {
        if (item.name === "random" && item.args.length > 2)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_BUILTIN_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u4E2D\u7684 random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002`,
              { path: functionDef.name }
            )
          );
        if (!isBuiltin(item.name) && !functions.has(item.name))
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528\u4E86\u672A\u77E5\u51FD\u6570 ${item.name}\u3002`,
              { path: functionDef.name }
            )
          );
        const target = functions.get(item.name);
        if (target && item.args.length !== target.params.length)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528 ${item.name} \u7684\u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
              { path: functionDef.name }
            )
          );
      }
    });
  }
  return diagnostics;
}
function rejectRecursiveFunctions(dependencies102) {
  const visited = /* @__PURE__ */ new Set();
  const visiting = [];
  const diagnostics = [];
  const visit = (name114) => {
    const existing = visiting.indexOf(name114);
    if (existing >= 0) {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_RECURSION",
          `\u51FD\u6570\u9012\u5F52\u4E0D\u88AB\u652F\u6301\uFF1A${[...visiting.slice(existing), name114].join(" \u2192 ")}\u3002`,
          { path: name114 }
        )
      );
      return;
    }
    if (visited.has(name114)) return;
    visiting.push(name114);
    for (const dependency of dependencies102[name114] ?? []) visit(dependency);
    visiting.pop();
    visited.add(name114);
  };
  for (const name114 of Object.keys(dependencies102)) visit(name114);
  return diagnostics;
}
function findRandomFunctions(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const memo = /* @__PURE__ */ new Map();
  const visiting = /* @__PURE__ */ new Set();
  const contains = (name114) => {
    const cached = memo.get(name114);
    if (cached !== void 0) return cached;
    if (visiting.has(name114)) return false;
    visiting.add(name114);
    const definition = functions.get(name114);
    let found = false;
    if (definition?.ast)
      walk(definition.ast, (item) => {
        if (item.kind !== "call" || found) return;
        if (item.name === "random") found = true;
        else if (functions.has(item.name) && contains(item.name)) found = true;
      });
    visiting.delete(name114);
    memo.set(name114, found);
    return found;
  };
  return [...functions.keys()].filter(contains).sort();
}
function compileCallableFunctions(parsed, diagnostics) {
  const all = [...diagnostics];
  return {
    functions: Object.fromEntries(
      parsed.filter((item) => item.ast !== null).map((item) => [item.name, item])
    ),
    randomFunctions: findRandomFunctions(parsed),
    diagnostics: all,
    valid: all.length === 0
  };
}
function compileFunctionLibrary(functionLibrary) {
  const request = {
    initialState: {},
    snapshotState: null,
    functionLibrary,
    snapshotFunctionLibrary: null,
    allowSnapshots: false,
    randomContext: null,
    operations: [],
    diagnostics: [],
    valid: true
  };
  const parsed = parseFunctionDefinitions(request);
  const dependencies102 = extractFunctionDependencies(parsed);
  return compileCallableFunctions(parsed, [
    ...validateFunctionPurity(parsed),
    ...rejectRecursiveFunctions(dependencies102)
  ]);
}
function countAutomaticRandomDraws(ast, currentLibrary, snapshotLibrary = currentLibrary) {
  const visiting = /* @__PURE__ */ new Set();
  const count = (item, library) => {
    if (item.kind === "literal" || item.kind === "ref") return 0;
    if (item.kind === "unary") return count(item.value, library);
    if (item.kind === "binary")
      return count(item.left, library) + count(item.right, library);
    let total = item.args.reduce(
      (sum3, arg) => sum3 + count(arg, library),
      0
    );
    if (item.name === "random") return total + (item.args.length < 2 ? 1 : 0);
    if (isBuiltin(item.name)) return total;
    const targetLibrary = item.snapshot ? snapshotLibrary : library;
    const target = targetLibrary.functions[item.name];
    if (target?.ast && !visiting.has(target)) {
      visiting.add(target);
      total += count(target.ast, targetLibrary);
      visiting.delete(target);
    }
    return total;
  };
  return count(ast, currentLibrary);
}
function containsAnyRandomCall(ast, currentLibrary, snapshotLibrary = currentLibrary) {
  const visiting = /* @__PURE__ */ new Set();
  const visit = (item, library) => {
    if (item.kind === "literal" || item.kind === "ref") return false;
    if (item.kind === "unary") return visit(item.value, library);
    if (item.kind === "binary")
      return visit(item.left, library) || visit(item.right, library);
    if (item.args.some((arg) => visit(arg, library))) return true;
    if (item.name === "random") return true;
    if (isBuiltin(item.name)) return false;
    const targetLibrary = item.snapshot ? snapshotLibrary : library;
    const target = targetLibrary.functions[item.name];
    if (!target?.ast || visiting.has(target)) return false;
    visiting.add(target);
    const found = visit(target.ast, targetLibrary);
    visiting.delete(target);
    return found;
  };
  return visit(ast, currentLibrary);
}
function parseOperations(request) {
  return request.operations.map((operation, index2) => {
    const diagnostics = [];
    let path = [];
    try {
      path = validatePath(operation.path);
    } catch (error) {
      diagnostics.push(
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PATH_INVALID", String(error))
      );
    }
    const parsed = diagnostics.length === 0 ? parseExpression(operation.expr, request.allowSnapshots) : { ast: null, diagnostics: [] };
    return {
      index: index2,
      path,
      expr: operation.expr,
      ast: parsed.ast,
      diagnostics: [...diagnostics, ...parsed.diagnostics]
    };
  });
}
function initializeSequenceState(request, compiled, operations, snapshotCompiled = compiled) {
  return {
    startState: clone5(request.snapshotState ?? request.initialState),
    currentState: clone5(request.initialState),
    compiled,
    snapshotCompiled,
    operations,
    cursor: 0,
    randomContext: request.randomContext,
    randomDrawsConsumed: 0,
    diagnostics: [...request.diagnostics, ...compiled.diagnostics]
  };
}
function refValue(ast, state, env, allowState) {
  if (ast.path.length === 1 && ast.path[0] in env) return env[ast.path[0]];
  if (!allowState)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_FUNCTION_IMPURE", "\u51FD\u6570\u4F53\u4E0D\u80FD\u8BFB\u53D6\u5916\u90E8\u53D8\u91CF\u72B6\u6001\u3002", {
        path: ast.path.join(".")
      })
    );
  const source = ast.snapshot ? state.startState : state.currentState;
  const value = getPath(source, ast.path);
  if (typeof value !== "number" || !Number.isFinite(value))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_REFERENCE_NON_NUMERIC",
        `\u53D8\u91CF ${ast.path.join(".")} \u5FC5\u987B\u5DF2\u5B9A\u4E49\u4E3A\u6709\u9650\u6570\u5B57\u3002`,
        { path: ast.path.join(".") }
      )
    );
  return value;
}
function popValues(values, count) {
  if (count === 0) return { values, args: [] };
  if (values.length < count)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_EVALUATION_STACK", "\u8868\u8FBE\u5F0F\u6C42\u503C\u6808\u7F3A\u5C11\u5B50\u8868\u8FBE\u5F0F\u7ED3\u679C\u3002")
    );
  return { values: values.slice(0, -count), args: values.slice(-count) };
}
var UINT64_MASK = (1n << 64n) - 1n;
var FNV64_OFFSET = 0xcbf29ce484222325n;
var FNV64_PRIME = 0x100000001b3n;
var SPLITMIX_GAMMA = 0x9e3779b97f4a7c15n;
var SPLITMIX_MUL_1 = 0xbf58476d1ce4e5b9n;
var SPLITMIX_MUL_2 = 0x94d049bb133111ebn;
var TWO_POW_53 = 9007199254740992;
function fnv1a64(bytes) {
  return bytes.reduce(
    (hash, byte) => (hash ^ BigInt(byte)) * FNV64_PRIME & UINT64_MASK,
    FNV64_OFFSET
  );
}
function randomSeedHash(seed) {
  if (typeof seed === "string") return fnv1a64(new TextEncoder().encode(seed));
  const normalized = Object.is(seed, -0) ? 0 : seed;
  const buffer = new ArrayBuffer(8);
  new DataView(buffer).setFloat64(0, normalized, true);
  return fnv1a64(new Uint8Array(buffer));
}
function deterministicRandomUnit(seed, draw) {
  if (typeof seed === "number" && !Number.isFinite(seed) || !Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 seed \u5FC5\u987B\u6709\u9650\uFF0Cdraw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  const mixed0 = randomSeedHash(seed) + BigInt(draw) + SPLITMIX_GAMMA & UINT64_MASK;
  const mixed1 = (mixed0 ^ mixed0 >> 30n) * SPLITMIX_MUL_1 & UINT64_MASK;
  const mixed2 = (mixed1 ^ mixed1 >> 27n) * SPLITMIX_MUL_2 & UINT64_MASK;
  const mixed3 = mixed2 ^ mixed2 >> 31n;
  return Number((mixed3 & UINT64_MASK) >> 11n) / TWO_POW_53;
}
function calculateRandom(args, context, automaticDraw) {
  if (args.length > 2)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_BUILTIN_ARITY",
        "random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002"
      )
    );
  if (args.length < 2 && !context)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_CONTEXT_REQUIRED",
        "random() \u4E0E random(seed) \u9700\u8981\u6D88\u606F\u968F\u673A\u4E0A\u4E0B\u6587\u3002"
      )
    );
  const seed = args.length === 0 ? context.sourceKey : args[0];
  const draw = args.length === 2 ? args[1] : automaticDraw;
  if (!Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 draw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  return deterministicRandomUnit(seed, draw);
}
function calculateBuiltin(name114, args) {
  const unary = {
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    asin: Math.asin,
    acos: Math.acos,
    atan: Math.atan,
    sinh: Math.sinh,
    cosh: Math.cosh,
    tanh: Math.tanh,
    asinh: Math.asinh,
    acosh: Math.acosh,
    atanh: Math.atanh,
    exp: Math.exp,
    log: Math.log,
    ln: Math.log,
    sqrt: Math.sqrt,
    abs: Math.abs,
    floor: Math.floor,
    ceil: Math.ceil,
    round: Math.round,
    trunc: Math.trunc,
    gamma: import_math_base_special_gamma.default
  };
  if (name114 in unary) {
    if (args.length !== 1)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name114} \u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      unary[name114](args[0]),
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name114} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  if (name114 === "factorial") {
    if (args.length !== 1 || !Number.isSafeInteger(args[0]) || args[0] < 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FACTORIAL_DOMAIN",
          "factorial \u53EA\u63A5\u53D7\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    let result = 1;
    for (let value = 2; value <= args[0]; value += 1)
      result = finite(
        result * value,
        "ERA_EXPR_FACTORIAL_NON_FINITE",
        "factorial \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    return result;
  }
  if (name114 === "min" || name114 === "max") {
    if (args.length === 0)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name114} \u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return name114 === "min" ? Math.min(...args) : Math.max(...args);
  }
  if (name114 === "clamp") {
    if (args.length !== 3)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", "clamp \u9700\u8981\u4E09\u4E2A\u53C2\u6570\u3002")
      );
    return Math.min(Math.max(args[0], args[1]), args[2]);
  }
  if (name114 === "pow" || name114 === "mod") {
    if (args.length !== 2)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name114} \u9700\u8981\u4E24\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      name114 === "pow" ? args[0] ** args[1] : args[0] % args[1],
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name114} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  throw new ExpressionFailure(
    diagnostic("ERA_EXPR_BUILTIN_UNKNOWN", `\u672A\u77E5\u5185\u5EFA\u51FD\u6570 ${name114}\u3002`)
  );
}
function inlineCustomAst(ast, bindings, library) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref") return bindings[ast.path.join(".")] ?? ast;
  if (ast.kind === "unary")
    return { ...ast, value: inlineCustomAst(ast.value, bindings, library) };
  if (ast.kind === "binary")
    return {
      ...ast,
      left: inlineCustomAst(ast.left, bindings, library),
      right: inlineCustomAst(ast.right, bindings, library)
    };
  const target = library.functions[ast.name];
  const args = ast.args.map((arg) => inlineCustomAst(arg, bindings, library));
  if (!target || !target.ast)
    return { kind: "call", name: ast.name, args, snapshot: ast.snapshot };
  const childBindings = Object.fromEntries(
    target.params.map((param, index2) => [param, args[index2]])
  );
  return inlineCustomAst(target.ast, childBindings, library);
}
function mathText(ast) {
  if (ast.kind === "literal")
    return Number.isInteger(ast.value) ? `${ast.value}` : `${ast.value}`;
  if (ast.kind === "ref") return ast.path.join("_");
  if (ast.kind === "unary") return `(${ast.op}${mathText(ast.value)})`;
  if (ast.kind === "binary")
    return `(${mathText(ast.left)} ${ast.op} ${mathText(ast.right)})`;
  const names = {
    ln: "log",
    pow: "pow",
    mod: "mod"
  };
  return `${names[ast.name] ?? ast.name}(${ast.args.map(mathText).join(",")})`;
}
function evaluateFunctionAt(library, name114, input) {
  const target = library.functions[name114];
  if (!target || !target.ast || target.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name114} \u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: name114 }
      )
    );
  const sequence = {
    startState: {},
    currentState: {},
    compiled: library,
    snapshotCompiled: library,
    operations: [],
    cursor: 0,
    randomContext: null,
    randomDrawsConsumed: 0,
    diagnostics: []
  };
  let frame = createAstFrameState(
    sequence,
    target.ast,
    { [target.params[0]]: input },
    false
  );
  while (!frame.done) frame = advanceAstFrame(frame);
  if (frame.diagnostics.length > 0 || frame.result === null)
    throw new ExpressionFailure(
      frame.diagnostics[0] ?? diagnostic("ERA_EXPR_CALCULUS_EVALUATE", `\u51FD\u6570 ${name114} \u65E0\u6CD5\u6C42\u503C\u3002`, {
        path: name114
      })
    );
  return frame.result;
}
function calculateCalculus(name114, target, args, library) {
  const functionDef = library.functions[target];
  if (!functionDef || !functionDef.ast || functionDef.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name114} \u53EA\u63A5\u53D7\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: target }
      )
    );
  if (library.randomFunctions.includes(target))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_RANDOM_FORBIDDEN",
        `${name114} \u4E0D\u80FD\u4EE5\u76F4\u63A5\u6216\u95F4\u63A5\u8C03\u7528 random \u7684\u51FD\u6570\u4E3A\u76EE\u6807\u3002`,
        { path: target }
      )
    );
  if (name114 === "derivative") {
    if (args.length !== 1 && args.length !== 2)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_BUILTIN_ARITY",
          "derivative \u9700\u8981 f\u3001at \u4E0E\u53EF\u9009 order\u3002"
        )
      );
    const order = args.length === 2 ? args[1] : 1;
    if (!Number.isSafeInteger(order) || order <= 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_ORDER",
          "\u5BFC\u6570\u9636\u6570\u5FC5\u987B\u662F\u4EFB\u610F\u6B63\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    const expanded = inlineCustomAst(functionDef.ast, {}, library);
    let derived = mathText(expanded);
    const variable = functionDef.params[0];
    try {
      for (let currentOrder = 0; currentOrder < order; currentOrder += 1) {
        const node = derivative(derived, variable);
        derived = node.toString();
        if (derived === "0") break;
      }
      const value = Number(evaluate(derived, { [variable]: args[0] }));
      return finite(
        value,
        "ERA_EXPR_DERIVATIVE_NON_FINITE",
        "\u5BFC\u6570\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    } catch (error) {
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_UNSUPPORTED",
          `\u65E0\u6CD5\u6784\u9020\u8BE5\u5BFC\u6570\uFF1A${error instanceof Error ? error.message : String(error)}\u3002`,
          { path: target }
        )
      );
    }
  }
  if (args.length !== 2)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_BUILTIN_ARITY", "integral \u9700\u8981 f\u3001start\u3001end\u3002")
    );
  const [start, end] = args;
  if (start === end) return 0;
  const direction = start < end ? 1 : -1;
  const left = Math.min(start, end);
  const right = Math.max(start, end);
  const evaluate2 = (value) => evaluateFunctionAt(library, target, value);
  const simpson = (a, b, fa, fm, fb) => (b - a) / 6 * (fa + 4 * fm + fb);
  const middle = (left + right) / 2;
  const whole = simpson(
    left,
    right,
    evaluate2(left),
    evaluate2(middle),
    evaluate2(right)
  );
  const stack = [
    {
      a: left,
      b: right,
      fa: evaluate2(left),
      fm: evaluate2(middle),
      fb: evaluate2(right),
      whole,
      tolerance: 1e-9
    }
  ];
  let sum3 = 0;
  let processed = 0;
  while (stack.length > 0) {
    const segment = stack.pop();
    processed += 1;
    if (processed > 65536)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_INTEGRAL_CONVERGENCE",
          "\u79EF\u5206\u5728\u786E\u5B9A\u6027 Simpson \u8FED\u4EE3\u5185\u672A\u6536\u655B\u3002",
          { path: target }
        )
      );
    const mid = (segment.a + segment.b) / 2;
    const leftMid = (segment.a + mid) / 2;
    const rightMid = (mid + segment.b) / 2;
    const leftValue = evaluate2(leftMid);
    const rightValue = evaluate2(rightMid);
    const leftArea = simpson(segment.a, mid, segment.fa, leftValue, segment.fm);
    const rightArea = simpson(
      mid,
      segment.b,
      segment.fm,
      rightValue,
      segment.fb
    );
    const delta = leftArea + rightArea - segment.whole;
    if (Math.abs(delta) <= 15 * segment.tolerance) {
      sum3 += leftArea + rightArea + delta / 15;
      continue;
    }
    stack.push({
      a: mid,
      b: segment.b,
      fa: segment.fm,
      fm: rightValue,
      fb: segment.fb,
      whole: rightArea,
      tolerance: segment.tolerance / 2
    });
    stack.push({
      a: segment.a,
      b: mid,
      fa: segment.fa,
      fm: leftValue,
      fb: segment.fm,
      whole: leftArea,
      tolerance: segment.tolerance / 2
    });
  }
  return finite(
    direction * sum3,
    "ERA_EXPR_INTEGRAL_NON_FINITE",
    "\u79EF\u5206\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
  );
}
function createAstFrameState(sequence, ast, env = {}, allowState = true, library = sequence.compiled) {
  return {
    sequence,
    stack: [{ kind: "eval", ast, env, allowState, library }],
    values: [],
    automaticRandomDrawCursor: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    done: false,
    result: null,
    diagnostics: []
  };
}
function complete(state) {
  if (state.stack.length === 0 && state.values.length === 1)
    return { ...state, done: true, result: state.values[0] };
  return { ...state, done: false, result: null };
}
function astFrameRoute(state) {
  const top = state.stack[state.stack.length - 1];
  if (!top) return "return";
  if (top.kind === "eval") {
    if (top.ast.kind === "literal" || top.ast.kind === "ref") return "value";
    if (top.ast.kind === "unary" || top.ast.kind === "binary")
      return "operator";
    if (top.ast.name === "random") return "random";
    if (isBuiltin(top.ast.name)) return "builtin";
    return "custom";
  }
  if (top.kind === "unary" || top.kind === "binary") return "operator";
  if (top.kind === "builtin" || top.kind === "calculus") return "builtin";
  if (top.kind === "random") return "random";
  if (top.kind === "custom") return "custom";
  return "return";
}
function advanceAstFrame(state, expected) {
  if (state.done) return state;
  try {
    const actual = astFrameRoute(state);
    if (expected && actual !== expected)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FRAME_ROUTE",
          `\u8C03\u7528\u5E27\u8DEF\u7531\u4E0D\u5339\u914D\uFF1A\u671F\u671B ${expected}\uFF0C\u5B9E\u9645 ${actual}\u3002`
        )
      );
    const stack = [...state.stack];
    const values = [...state.values];
    let automaticRandomDrawCursor = state.automaticRandomDrawCursor;
    const top = stack.pop();
    if (!top) return complete({ ...state, stack, values });
    if (top.kind === "eval") {
      if (top.ast.kind === "literal") values.push(top.ast.value);
      else if (top.ast.kind === "ref")
        values.push(refValue(top.ast, state.sequence, top.env, top.allowState));
      else if (top.ast.kind === "unary") {
        stack.push(
          { kind: "unary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.value,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "binary") {
        stack.push(
          { kind: "binary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.right,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          },
          {
            kind: "eval",
            ast: top.ast.left,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "call") {
        if (top.ast.name === "derivative" || top.ast.name === "integral") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          const targetAst = top.ast.args[0];
          if (!targetAst || targetAst.kind !== "ref" || targetAst.snapshot || targetAst.path.length !== 1)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_CALCULUS_TARGET",
                `${top.ast.name} \u7684\u9996\u53C2\u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u51FD\u6570\u540D\u3002`
              )
            );
          stack.push({
            kind: "calculus",
            name: top.ast.name,
            target: targetAst.path[0],
            count: top.ast.args.length - 1,
            library: top.library
          });
          for (const arg of [...top.ast.args.slice(1)].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (top.ast.name === "random") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({ kind: "random", count: top.ast.args.length });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (isBuiltin(top.ast.name)) {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({
            kind: "builtin",
            name: top.ast.name,
            count: top.ast.args.length
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else {
          stack.push({
            kind: "custom",
            name: top.ast.name,
            count: top.ast.args.length,
            library: top.ast.snapshot ? state.sequence.snapshotCompiled : top.library
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        }
      }
    } else if (top.kind === "unary") {
      const popped = popValues(values, 1);
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          top.op === "+" ? popped.args[0] : -popped.args[0],
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E00\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "binary") {
      const popped = popValues(values, 2);
      const [left, right] = popped.args;
      const result = top.op === "+" ? left + right : top.op === "-" ? left - right : top.op === "*" ? left * right : top.op === "/" ? left / right : top.op === "%" ? left % right : left ** right;
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          result,
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E8C\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "builtin") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateBuiltin(top.name, popped.args)
      );
    } else if (top.kind === "random") {
      const popped = popValues(values, top.count);
      const draw = automaticRandomDrawCursor;
      if (top.count < 2) automaticRandomDrawCursor += 1;
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateRandom(popped.args, state.sequence.randomContext, draw)
      );
    } else if (top.kind === "calculus") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateCalculus(
          top.name,
          top.target,
          popped.args,
          top.library
        )
      );
    } else {
      const popped = popValues(values, top.count);
      const target = top.library.functions[top.name];
      if (!target || !target.ast)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
            `\u672A\u77E5\u51FD\u6570 ${top.name}\u3002`,
            { path: top.name }
          )
        );
      if (target.params.length !== popped.args.length)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_ARITY",
            `\u51FD\u6570 ${top.name} \u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
            { path: top.name }
          )
        );
      const env = Object.fromEntries(
        target.params.map((param, index2) => [param, popped.args[index2]])
      );
      values.splice(0, values.length, ...popped.values);
      stack.push({
        kind: "eval",
        ast: target.ast,
        env,
        allowState: false,
        library: top.library
      });
    }
    return complete({ ...state, stack, values, automaticRandomDrawCursor });
  } catch (error) {
    const detail = error instanceof ExpressionFailure ? error.detail : diagnostic(
      "ERA_EXPR_EVALUATION_FAILED",
      error instanceof Error ? error.message : String(error)
    );
    return {
      ...state,
      stack: [],
      done: true,
      result: null,
      diagnostics: [...state.diagnostics, detail]
    };
  }
}
function runOperationStep(state) {
  const operation = state.operations[state.cursor];
  if (!operation)
    return {
      sequenceStateNext: state,
      sequenceDone: true,
      operationExecutionResult: {
        finalState: state.currentState,
        diagnostics: state.diagnostics,
        randomDrawsConsumed: state.randomDrawsConsumed
      }
    };
  if (!state.compiled.valid) {
    const next2 = {
      ...state,
      cursor: state.cursor + 1,
      diagnostics: [...state.diagnostics, ...operation.diagnostics]
    };
    return {
      sequenceStateNext: next2,
      sequenceDone: next2.cursor >= next2.operations.length,
      operationExecutionResult: {
        finalState: next2.currentState,
        diagnostics: next2.diagnostics,
        randomDrawsConsumed: next2.randomDrawsConsumed
      }
    };
  }
  if (!operation.ast || operation.diagnostics.length > 0) {
    const next2 = {
      ...state,
      cursor: state.cursor + 1,
      diagnostics: [...state.diagnostics, ...operation.diagnostics]
    };
    return {
      sequenceStateNext: next2,
      sequenceDone: next2.cursor >= next2.operations.length,
      operationExecutionResult: {
        finalState: next2.currentState,
        diagnostics: next2.diagnostics,
        randomDrawsConsumed: next2.randomDrawsConsumed
      }
    };
  }
  const randomDraws = countAutomaticRandomDraws(
    operation.ast,
    state.compiled,
    state.snapshotCompiled
  );
  let frame = createAstFrameState(state, operation.ast);
  while (!frame.done) frame = advanceAstFrame(frame);
  const diagnostics = [...state.diagnostics, ...frame.diagnostics];
  const currentState = frame.result === null ? state.currentState : setPath(state.currentState, operation.path, frame.result);
  const next = {
    ...state,
    currentState,
    cursor: state.cursor + 1,
    randomDrawsConsumed: state.randomDrawsConsumed + randomDraws,
    diagnostics
  };
  return {
    sequenceStateNext: next,
    sequenceDone: next.cursor >= next.operations.length,
    operationExecutionResult: {
      finalState: next.currentState,
      diagnostics: next.diagnostics,
      randomDrawsConsumed: next.randomDrawsConsumed
    }
  };
}
function commitOperationResult(state, value, evaluationDiagnostics) {
  const operation = state.operations[state.cursor];
  if (!operation)
    return {
      sequenceStateNext: state,
      sequenceDone: true,
      operationExecutionResult: {
        finalState: state.currentState,
        diagnostics: state.diagnostics,
        randomDrawsConsumed: state.randomDrawsConsumed
      }
    };
  const diagnostics = [
    ...state.diagnostics,
    ...operation.diagnostics,
    ...evaluationDiagnostics
  ];
  const currentState = state.compiled.valid && operation.ast && operation.diagnostics.length === 0 && value !== null ? setPath(state.currentState, operation.path, value) : state.currentState;
  const randomDraws = state.compiled.valid && operation.ast && operation.diagnostics.length === 0 ? countAutomaticRandomDraws(
    operation.ast,
    state.compiled,
    state.snapshotCompiled
  ) : 0;
  const next = {
    ...state,
    currentState,
    cursor: state.cursor + 1,
    randomDrawsConsumed: state.randomDrawsConsumed + randomDraws,
    diagnostics
  };
  return {
    sequenceStateNext: next,
    sequenceDone: next.cursor >= next.operations.length,
    operationExecutionResult: {
      finalState: next.currentState,
      diagnostics: next.diagnostics,
      randomDrawsConsumed: next.randomDrawsConsumed
    }
  };
}
function substituteSymbolic(ast, state) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref")
    return state[ast.path.join(".")] ?? {
      kind: "ref",
      path: ast.path,
      snapshot: true
    };
  if (ast.kind === "unary")
    return simplify2({
      kind: "unary",
      op: ast.op,
      value: substituteSymbolic(ast.value, state)
    });
  if (ast.kind === "binary")
    return simplify2({
      kind: "binary",
      op: ast.op,
      left: substituteSymbolic(ast.left, state),
      right: substituteSymbolic(ast.right, state)
    });
  return {
    kind: "call",
    name: ast.name,
    args: ast.args.map((arg) => substituteSymbolic(arg, state)),
    snapshot: ast.snapshot
  };
}
function literal(value) {
  return { kind: "literal", value: Object.is(value, -0) ? 0 : value };
}
function literalNumber(ast) {
  return ast.kind === "literal" ? ast.value : void 0;
}
function simplify2(ast) {
  if (ast.kind === "literal" || ast.kind === "ref") return ast;
  if (ast.kind === "call") return { ...ast, args: ast.args.map(simplify2) };
  if (ast.kind === "unary") {
    const value = simplify2(ast.value);
    const number2 = literalNumber(value);
    if (number2 !== void 0) return literal(ast.op === "+" ? number2 : -number2);
    if (ast.op === "+") return value;
    return { ...ast, value };
  }
  const left = simplify2(ast.left);
  const right = simplify2(ast.right);
  const leftNumber = literalNumber(left);
  const rightNumber = literalNumber(right);
  if (leftNumber !== void 0 && rightNumber !== void 0) {
    const result = ast.op === "+" ? leftNumber + rightNumber : ast.op === "-" ? leftNumber - rightNumber : ast.op === "*" ? leftNumber * rightNumber : ast.op === "/" ? leftNumber / rightNumber : ast.op === "%" ? leftNumber % rightNumber : leftNumber ** rightNumber;
    return Number.isFinite(result) ? literal(result) : { ...ast, left, right };
  }
  if (ast.op === "+") {
    if (rightNumber === 0) return left;
    if (leftNumber === 0) return right;
    const nested = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && nested !== void 0 && rightNumber !== void 0)
      return simplify2({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const subtraction = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && subtraction !== void 0 && rightNumber !== void 0)
      return simplify2({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(subtraction - rightNumber)
      });
  }
  if (ast.op === "-") {
    if (rightNumber === 0) return left;
    const nested = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && nested !== void 0 && rightNumber !== void 0)
      return simplify2({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const addition = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && addition !== void 0 && rightNumber !== void 0)
      return simplify2({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(addition - rightNumber)
      });
  }
  if (ast.op === "*") {
    if (leftNumber === 0 || rightNumber === 0) return literal(0);
    if (leftNumber === 1) return right;
    if (rightNumber === 1) return left;
  }
  if (ast.op === "/" && rightNumber === 1) return left;
  return { ...ast, left, right };
}
function operatorPrecedence(op) {
  return op === "+" || op === "-" ? 1 : op === "*" || op === "/" || op === "%" ? 2 : 3;
}
function printAst(ast, parent = 0) {
  if (ast.kind === "literal") return `${ast.value}`;
  if (ast.kind === "ref")
    return `${ast.snapshot ? "@" : ""}${ast.path.join(".")}`;
  if (ast.kind === "call")
    return `${ast.snapshot ? "@" : ""}${ast.name}(${ast.args.map((arg) => printAst(arg)).join(", ")})`;
  if (ast.kind === "unary") {
    const own2 = 4;
    const text2 = `${ast.op}${printAst(ast.value, own2)}`;
    return own2 < parent ? `(${text2})` : text2;
  }
  const own = operatorPrecedence(ast.op);
  const text = `${printAst(ast.left, own)} ${ast.op} ${printAst(ast.right, own + (ast.op === "^" ? 0 : 1))}`;
  return own < parent ? `(${text})` : text;
}
function deriveSymbolicLayer(sequence) {
  const symbols = {};
  const tainted = /* @__PURE__ */ new Set();
  const conflicts = (left, right) => left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
  const referencesTainted = (ast) => {
    let found = false;
    walk(ast, (item) => {
      if (item.kind === "ref" && !item.snapshot && [...tainted].some((path) => conflicts(item.path.join("."), path)))
        found = true;
    });
    return found;
  };
  for (const operation of sequence.operations) {
    if (!operation.ast || operation.diagnostics.length > 0) continue;
    const path = operation.path.join(".");
    if (countAutomaticRandomDraws(
      operation.ast,
      sequence.compiled,
      sequence.snapshotCompiled
    ) > 0 || referencesTainted(operation.ast)) {
      tainted.add(path);
      for (const existing of Object.keys(symbols))
        if (conflicts(existing, path)) delete symbols[existing];
      continue;
    }
    symbols[path] = simplify2(substituteSymbolic(operation.ast, symbols));
  }
  return symbols;
}
function normaliseCompaction(sequence, symbols) {
  const compressed = {};
  for (const [path, ast] of Object.entries(symbols)) {
    const before = getPath(sequence.startState, path.split("."));
    const after = getPath(sequence.currentState, path.split("."));
    if (JSON.stringify(before) !== JSON.stringify(after))
      compressed[path] = { $expr: printAst(simplify2(ast)) };
  }
  return {
    status: sequence.diagnostics.length === 0 ? "ok" : sequence.cursor === 0 ? "invalid" : "partial",
    finalState: sequence.currentState,
    diagnostics: sequence.diagnostics,
    compressed,
    compactedOperations: Object.entries(compressed).map(([path, value]) => ({
      path,
      value
    })),
    randomDrawsConsumed: sequence.randomDrawsConsumed,
    nextDrawOffset: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    containsAutomaticRandom: sequence.operations.some(
      (operation) => operation.ast !== null && operation.diagnostics.length === 0 && countAutomaticRandomDraws(
        operation.ast,
        sequence.compiled,
        sequence.snapshotCompiled
      ) > 0
    )
  };
}
function executeExpressionLayer(input) {
  const normalized = normaliseRequest(input);
  const compiled = compileFunctionLibrary(normalized.functionLibrary);
  const snapshotCompiled = normalized.snapshotFunctionLibrary ? compileFunctionLibrary(normalized.snapshotFunctionLibrary) : compiled;
  const operations = parseOperations(normalized);
  let state = initializeSequenceState(
    normalized,
    compiled,
    operations,
    snapshotCompiled
  );
  while (state.cursor < state.operations.length)
    state = runOperationStep(state).sequenceStateNext;
  return normaliseCompaction(state, deriveSymbolicLayer(state));
}
function nodeInput(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function nodeValue(value) {
  if (value !== null && typeof value === "object" && "value" in value) {
    const item = value;
    return {
      value: typeof item.value === "number" ? item.value : null,
      diagnostics: Array.isArray(item.diagnostics) ? item.diagnostics : []
    };
  }
  return { value: null, diagnostics: [] };
}
function terminalNode() {
  return {};
}
function validateRequestNode(inputs) {
  return {
    normalized_expression_request: normaliseRequest(
      nodeInput(inputs, "era.expression.request")
    )
  };
}
function validateRandomContextNode(inputs) {
  return {
    validated_random_request: nodeInput(
      inputs,
      "era.expression.request.normalized"
    )
  };
}
function parseFunctionDefinitionsNode(inputs) {
  return {
    parsed_function_library: parseFunctionDefinitions(
      nodeInput(inputs, "era.expression.request.normalized")
    )
  };
}
function extractFunctionDependenciesNode(inputs) {
  return {
    function_dependencies: extractFunctionDependencies(
      nodeInput(inputs, "era.expression.function_library.parsed")
    )
  };
}
function validateFunctionPurityNode(inputs) {
  return {
    function_purity_report: {
      diagnostics: validateFunctionPurity(
        nodeInput(
          inputs,
          "era.expression.function_library.parsed"
        )
      )
    }
  };
}
function buildFunctionCallGraphNode(inputs) {
  const dependencies102 = nodeInput(
    inputs,
    "era.expression.function_library.dependencies"
  );
  const purity = nodeInput(
    inputs,
    "era.expression.function_library.purity"
  );
  return {
    function_call_graph: { dependencies: dependencies102, diagnostics: purity.diagnostics }
  };
}
function rejectRecursiveFunctionsNode(inputs) {
  const graph = nodeInput(inputs, "era.expression.function_library.call_graph");
  return {
    acyclic_function_graph: {
      dependencies: graph.dependencies,
      diagnostics: [
        ...graph.diagnostics,
        ...rejectRecursiveFunctions(graph.dependencies)
      ]
    }
  };
}
function compileCallableFunctionsNode(inputs) {
  return {
    compiled_function_library: compileCallableFunctions(
      nodeInput(
        inputs,
        "era.expression.function_library.parsed"
      ),
      nodeInput(
        inputs,
        "era.expression.function_library.acyclic_graph"
      ).diagnostics
    )
  };
}
function parseOperationsNode(inputs) {
  return {
    parsed_operations: parseOperations(
      nodeInput(inputs, "era.expression.request.normalized")
    )
  };
}
function classifyRandomCallsNode(inputs) {
  return {
    random_compiled_function_library: nodeInput(
      inputs,
      "era.expression.function_library.compiled"
    ),
    random_parsed_operations: nodeInput(inputs, "era.expression.operations.parsed")
  };
}
function initializeSequenceStateNode(inputs) {
  const request = nodeInput(
    inputs,
    "era.expression.request.normalized"
  );
  const compiled = nodeInput(
    inputs,
    "era.expression.function_library.compiled"
  );
  const snapshotCompiled = request.snapshotFunctionLibrary ? compileFunctionLibrary(request.snapshotFunctionLibrary) : compiled;
  return {
    sequence_state: initializeSequenceState(
      request,
      compiled,
      nodeInput(inputs, "era.expression.operations.parsed"),
      snapshotCompiled
    )
  };
}
function initializeRandomSequenceStateNode(inputs) {
  return initializeSequenceStateNode(inputs);
}
function selectNextOperationNode(inputs) {
  const sequenceState = nodeInput(
    inputs,
    "era.expression.sequence.state"
  );
  return {
    current_operation: {
      sequenceState,
      operation: sequenceState.operations[sequenceState.cursor] ?? null
    }
  };
}
function initializeAstFramesNode(inputs) {
  const current = nodeInput(inputs, "era.expression.operation.current");
  const ast = current.sequenceState.compiled.valid && current.operation?.ast ? current.operation.ast : { kind: "literal", value: 0 };
  return { ast_frame_state: createAstFrameState(current.sequenceState, ast) };
}
function inspectAstFrameNode(inputs) {
  const state = nodeInput(
    inputs,
    "era.expression.ast_frame.state"
  );
  return {
    ast_frame_current: {
      state,
      frame: state.stack[state.stack.length - 1] ?? null
    }
  };
}
function routeAstFrameNode(inputs) {
  const current = nodeInput(
    inputs,
    "era.expression.ast_frame.current"
  );
  return {
    routed_ast_frame_current: current,
    ast_frame_route: astFrameRoute(current.state)
  };
}
function advanceNode(inputs, expected, key) {
  return {
    [key]: advanceAstFrame(
      nodeInput(
        inputs,
        "era.expression.ast_frame.current"
      ).state,
      expected
    )
  };
}
function resolveValueFrameNode(inputs) {
  return advanceNode(inputs, "value", "frame_transition_value");
}
function evaluateOperatorFrameNode(inputs) {
  return advanceNode(inputs, "operator", "frame_transition_operator");
}
function evaluateBuiltinFrameNode(inputs) {
  return advanceNode(inputs, "builtin", "frame_transition_builtin");
}
function evaluateCounterRandomNode(inputs) {
  return advanceNode(inputs, "random", "ast_frame_transition");
}
function bindCustomFunctionFrameNode(inputs) {
  return advanceNode(inputs, "custom", "frame_transition_custom");
}
function returnChildValueNode(inputs) {
  return advanceNode(inputs, "return", "frame_transition_return");
}
function publishFrameTransitionNode(inputs) {
  const state = nodeInput(
    inputs,
    "era.expression.ast_frame.transition"
  );
  return {
    ast_frame_state_next: state,
    ast_frame_done: state.done,
    evaluated_expression: {
      value: state.result,
      diagnostics: state.diagnostics
    }
  };
}
function commitOperationResultNode(inputs) {
  const current = nodeInput(
    inputs,
    "era.expression.operation.current"
  );
  const evaluated = nodeValue(nodeInput(inputs, "era.expression.value"));
  const outcome = commitOperationResult(
    current.sequenceState,
    evaluated.value,
    evaluated.diagnostics
  );
  return {
    sequence_state_next: outcome.sequenceStateNext,
    sequence_done: outcome.sequenceDone,
    operation_execution_result: outcome.operationExecutionResult
  };
}
function completeNodeState(initial, execution) {
  return {
    ...initial,
    currentState: execution.finalState,
    diagnostics: execution.diagnostics,
    randomDrawsConsumed: execution.randomDrawsConsumed ?? initial.randomDrawsConsumed,
    cursor: initial.operations.length
  };
}
function deriveSymbolicLayerNode(inputs) {
  const sequence = nodeInput(
    inputs,
    "era.expression.sequence.state"
  );
  const execution = nodeInput(inputs, "era.expression.execution.result");
  return {
    symbolic_layer: deriveSymbolicLayer(completeNodeState(sequence, execution))
  };
}
function guardRandomCompactionNode(inputs) {
  return {
    random_guarded_symbolic_layer: nodeInput(
      inputs,
      "era.expression.symbolic.layer"
    )
  };
}
function normalizeCompactionNode(inputs) {
  const sequence = nodeInput(
    inputs,
    "era.expression.sequence.state"
  );
  const execution = nodeInput(inputs, "era.expression.execution.result");
  return {
    expression_response: normaliseCompaction(
      completeNodeState(sequence, execution),
      nodeInput(inputs, "era.expression.symbolic.layer")
    )
  };
}
export {
  advanceAstFrame,
  astFrameRoute,
  bindCustomFunctionFrameNode,
  buildFunctionCallGraphNode,
  classifyRandomCallsNode,
  commitOperationResult,
  commitOperationResultNode,
  compileCallableFunctions,
  compileCallableFunctionsNode,
  compileFunctionLibrary,
  containsAnyRandomCall,
  countAutomaticRandomDraws,
  createAstFrameState,
  deriveSymbolicLayer,
  deriveSymbolicLayerNode,
  deterministicRandomUnit,
  evaluateBuiltinFrameNode,
  evaluateCounterRandomNode,
  evaluateOperatorFrameNode,
  executeExpressionLayer,
  extractFunctionDependencies,
  extractFunctionDependenciesNode,
  guardRandomCompactionNode,
  initializeAstFramesNode,
  initializeRandomSequenceStateNode,
  initializeSequenceState,
  initializeSequenceStateNode,
  inspectAstFrameNode,
  normaliseCompaction,
  normaliseRequest,
  normalizeCompactionNode,
  parseExpression,
  parseFunctionDefinitions,
  parseFunctionDefinitionsNode,
  parseOperations,
  parseOperationsNode,
  printAst,
  publishFrameTransitionNode,
  rejectRecursiveFunctions,
  rejectRecursiveFunctionsNode,
  resolveValueFrameNode,
  returnChildValueNode,
  routeAstFrameNode,
  runOperationStep,
  selectNextOperationNode,
  simplify2 as simplify,
  terminalNode,
  validateFunctionPurity,
  validateFunctionPurityNode,
  validateRandomContextNode,
  validateRequestNode
};
/*! Bundled license information:

@stdlib/math-base-assert-is-nan/lib/main.js:
@stdlib/math-base-assert-is-nan/lib/index.js:
@stdlib/math-base-special-floor/lib/main.js:
@stdlib/math-base-special-floor/lib/index.js:
@stdlib/math-base-assert-is-integer/lib/main.js:
@stdlib/math-base-assert-is-integer/lib/index.js:
@stdlib/number-ctor/lib/main.js:
@stdlib/number-ctor/lib/index.js:
@stdlib/constants-float64-ninf/lib/index.js:
@stdlib/math-base-assert-is-negative-zero/lib/main.js:
@stdlib/math-base-assert-is-negative-zero/lib/index.js:
@stdlib/math-base-special-abs/lib/index.js:
@stdlib/constants-float64-high-word-exponent-mask/lib/index.js:
@stdlib/assert-has-symbol-support/lib/main.js:
@stdlib/assert-has-symbol-support/lib/index.js:
@stdlib/assert-has-tostringtag-support/lib/main.js:
@stdlib/assert-has-tostringtag-support/lib/index.js:
@stdlib/utils-native-class/lib/tostring.js:
@stdlib/utils-native-class/lib/main.js:
@stdlib/assert-has-own-property/lib/main.js:
@stdlib/assert-has-own-property/lib/index.js:
@stdlib/symbol-ctor/lib/main.js:
@stdlib/symbol-ctor/lib/index.js:
@stdlib/utils-native-class/lib/tostringtag.js:
@stdlib/utils-native-class/lib/polyfill.js:
@stdlib/utils-native-class/lib/index.js:
@stdlib/assert-is-uint32array/lib/main.js:
@stdlib/assert-is-uint32array/lib/index.js:
@stdlib/constants-uint32-max/lib/index.js:
@stdlib/assert-has-uint32array-support/lib/uint32array.js:
@stdlib/assert-has-uint32array-support/lib/main.js:
@stdlib/assert-has-uint32array-support/lib/index.js:
@stdlib/array-uint32/lib/main.js:
@stdlib/array-uint32/lib/polyfill.js:
@stdlib/array-uint32/lib/index.js:
@stdlib/assert-is-float64array/lib/main.js:
@stdlib/assert-is-float64array/lib/index.js:
@stdlib/assert-has-float64array-support/lib/float64array.js:
@stdlib/assert-has-float64array-support/lib/main.js:
@stdlib/assert-has-float64array-support/lib/index.js:
@stdlib/array-float64/lib/main.js:
@stdlib/array-float64/lib/polyfill.js:
@stdlib/array-float64/lib/index.js:
@stdlib/assert-is-uint8array/lib/main.js:
@stdlib/assert-is-uint8array/lib/index.js:
@stdlib/constants-uint8-max/lib/index.js:
@stdlib/assert-has-uint8array-support/lib/uint8array.js:
@stdlib/assert-has-uint8array-support/lib/main.js:
@stdlib/assert-has-uint8array-support/lib/index.js:
@stdlib/array-uint8/lib/main.js:
@stdlib/array-uint8/lib/polyfill.js:
@stdlib/array-uint8/lib/index.js:
@stdlib/assert-is-uint16array/lib/main.js:
@stdlib/assert-is-uint16array/lib/index.js:
@stdlib/constants-uint16-max/lib/index.js:
@stdlib/assert-has-uint16array-support/lib/uint16array.js:
@stdlib/assert-has-uint16array-support/lib/main.js:
@stdlib/assert-has-uint16array-support/lib/index.js:
@stdlib/array-uint16/lib/main.js:
@stdlib/array-uint16/lib/polyfill.js:
@stdlib/array-uint16/lib/index.js:
@stdlib/assert-is-little-endian/lib/ctors.js:
@stdlib/assert-is-little-endian/lib/main.js:
@stdlib/assert-is-little-endian/lib/index.js:
@stdlib/number-float64-base-get-high-word/lib/high.js:
@stdlib/number-float64-base-get-high-word/lib/main.js:
@stdlib/number-float64-base-get-high-word/lib/index.js:
@stdlib/math-base-special-kernel-cos/lib/index.js:
@stdlib/math-base-special-kernel-sin/lib/index.js:
@stdlib/constants-float64-high-word-significand-mask/lib/index.js:
@stdlib/number-float64-base-get-low-word/lib/low.js:
@stdlib/number-float64-base-get-low-word/lib/main.js:
@stdlib/number-float64-base-get-low-word/lib/index.js:
@stdlib/number-float64-base-from-words/lib/indices.js:
@stdlib/number-float64-base-from-words/lib/main.js:
@stdlib/number-float64-base-from-words/lib/index.js:
@stdlib/constants-float64-pinf/lib/index.js:
@stdlib/constants-float64-exponent-bias/lib/index.js:
@stdlib/constants-float64-max-base2-exponent/lib/index.js:
@stdlib/constants-float64-max-base2-exponent-subnormal/lib/index.js:
@stdlib/constants-float64-min-base2-exponent-subnormal/lib/index.js:
@stdlib/math-base-assert-is-infinite/lib/main.js:
@stdlib/math-base-assert-is-infinite/lib/index.js:
@stdlib/utils-define-property/lib/builtin.js:
@stdlib/utils-define-property/lib/polyfill.js:
@stdlib/utils-define-property/lib/index.js:
@stdlib/utils-define-nonenumerable-read-only-property/lib/main.js:
@stdlib/utils-define-nonenumerable-read-only-property/lib/index.js:
@stdlib/number-float64-base-to-words/lib/indices.js:
@stdlib/number-float64-base-to-words/lib/assign.js:
@stdlib/number-float64-base-to-words/lib/main.js:
@stdlib/number-float64-base-to-words/lib/index.js:
@stdlib/math-base-special-copysign/lib/main.js:
@stdlib/math-base-special-copysign/lib/index.js:
@stdlib/constants-float64-smallest-normal/lib/index.js:
@stdlib/number-float64-base-normalize/lib/assign.js:
@stdlib/number-float64-base-normalize/lib/main.js:
@stdlib/number-float64-base-normalize/lib/index.js:
@stdlib/number-float64-base-exponent/lib/main.js:
@stdlib/number-float64-base-exponent/lib/index.js:
@stdlib/math-base-special-ldexp/lib/main.js:
@stdlib/math-base-special-ldexp/lib/index.js:
@stdlib/math-base-special-round/lib/main.js:
@stdlib/math-base-special-round/lib/index.js:
@stdlib/math-base-special-rempio2/lib/index.js:
@stdlib/math-base-special-sin/lib/index.js:
@stdlib/constants-float64-pi/lib/index.js:
@stdlib/constants-float64-sqrt-two-pi/lib/index.js:
@stdlib/math-base-assert-is-even/lib/main.js:
@stdlib/math-base-assert-is-even/lib/index.js:
@stdlib/math-base-assert-is-odd/lib/main.js:
@stdlib/math-base-assert-is-odd/lib/index.js:
@stdlib/math-base-special-sqrt/lib/main.js:
@stdlib/math-base-special-sqrt/lib/index.js:
@stdlib/number-float64-base-set-low-word/lib/low.js:
@stdlib/number-float64-base-set-low-word/lib/main.js:
@stdlib/number-float64-base-set-low-word/lib/index.js:
@stdlib/number-uint32-base-to-int32/lib/main.js:
@stdlib/number-uint32-base-to-int32/lib/index.js:
@stdlib/math-base-special-pow/lib/y_is_infinite.js:
@stdlib/number-float64-base-set-high-word/lib/high.js:
@stdlib/number-float64-base-set-high-word/lib/main.js:
@stdlib/number-float64-base-set-high-word/lib/index.js:
@stdlib/constants-float64-ln-two/lib/index.js:
@stdlib/math-base-special-pow/lib/index.js:
@stdlib/math-base-special-ceil/lib/main.js:
@stdlib/math-base-special-ceil/lib/index.js:
@stdlib/math-base-special-trunc/lib/main.js:
@stdlib/math-base-special-trunc/lib/index.js:
@stdlib/math-base-special-exp/lib/index.js:
@stdlib/constants-float64-eulergamma/lib/index.js:
@stdlib/math-base-special-gamma/lib/index.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *)

@stdlib/math-base-special-abs/lib/main.js:
@stdlib/utils-define-property/lib/define_property.js:
@stdlib/utils-define-property/lib/has_define_property_support.js:
@stdlib/array-base-filled/lib/main.js:
@stdlib/array-base-filled/lib/index.js:
@stdlib/array-base-zeros/lib/main.js:
@stdlib/array-base-zeros/lib/index.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2021 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *)

@stdlib/constants-float64-high-word-abs-mask/lib/index.js:
@stdlib/math-base-special-kernel-cos/lib/polyval_c13.js:
@stdlib/math-base-special-kernel-cos/lib/polyval_c46.js:
@stdlib/constants-float64-high-word-sign-mask/lib/index.js:
@stdlib/string-base-format-interpolate/lib/is_number.js:
@stdlib/string-base-format-interpolate/lib/zero_pad.js:
@stdlib/string-base-format-interpolate/lib/format_integer.js:
@stdlib/string-base-format-interpolate/lib/is_string.js:
@stdlib/string-base-format-interpolate/lib/format_double.js:
@stdlib/string-base-format-interpolate/lib/space_pad.js:
@stdlib/string-base-format-interpolate/lib/main.js:
@stdlib/string-base-format-interpolate/lib/index.js:
@stdlib/string-base-format-tokenize/lib/main.js:
@stdlib/string-base-format-tokenize/lib/index.js:
@stdlib/string-format/lib/is_string.js:
@stdlib/string-format/lib/main.js:
@stdlib/string-format/lib/index.js:
@stdlib/math-base-special-exp/lib/polyval_p.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2022 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *)

@stdlib/math-base-special-kernel-cos/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyright, license, and long comment were part of the original implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/12.2.0/lib/msun/src/k_cos.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  * ```
  *)

@stdlib/math-base-special-kernel-sin/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyright, license, and long comment were part of the original implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/9.3.0/lib/msun/src/k_sin.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  * ```
  *)

@stdlib/math-base-special-rempio2/lib/kernel_rempio2.js:
@stdlib/math-base-special-rempio2/lib/rempio2_medium.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyright and license were part of the original implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/9.3.0/lib/msun/src/k_rem_pio2.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  * ```
  *)

@stdlib/math-base-special-rempio2/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyright and license were part of the original implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/9.3.0/lib/msun/src/e_rem_pio2.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  *
  * Optimized by Bruce D. Evans.
  * ```
  *)

@stdlib/math-base-special-sin/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyright, license, and long comment were part of the original implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/9.3.0/lib/msun/src/s_sin.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (C) 1993 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  * ```
  *)

@stdlib/math-base-special-pow/lib/x_is_zero.js:
@stdlib/math-base-special-pow/lib/y_is_huge.js:
@stdlib/math-base-special-pow/lib/log2ax.js:
@stdlib/math-base-special-pow/lib/logx.js:
@stdlib/math-base-special-pow/lib/pow2.js:
@stdlib/math-base-special-pow/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyright and license were part of the original implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/9.3.0/lib/msun/src/s_pow.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (C) 2004 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  * ```
  *)

@stdlib/constants-float64-num-high-word-significand-bits/lib/index.js:
@stdlib/math-base-special-pow/lib/polyval_l.js:
@stdlib/math-base-special-pow/lib/polyval_w.js:
@stdlib/math-base-special-pow/lib/polyval_p.js:
@stdlib/math-base-special-gamma/lib/polyval_s.js:
@stdlib/math-base-special-gamma/lib/rational_pq.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2024 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *)

@stdlib/math-base-special-exp/lib/expmulti.js:
@stdlib/math-base-special-exp/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The following copyrights, licenses, and long comment were part of the original implementation available as part of [Go]{@link https://github.com/golang/go/blob/cb07765045aed5104a3df31507564ac99e6ddce8/src/math/exp.go}, which in turn was based on an implementation available as part of [FreeBSD]{@link https://svnweb.freebsd.org/base/release/9.3.0/lib/msun/src/e_exp.c}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright (c) 2009 The Go Authors. All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without
  * modification, are permitted provided that the following conditions are
  * met:
  *
  *    * Redistributions of source code must retain the above copyright
  * notice, this list of conditions and the following disclaimer.
  *    * Redistributions in binary form must reproduce the above
  * copyright notice, this list of conditions and the following disclaimer
  * in the documentation and/or other materials provided with the
  * distribution.
  *    * Neither the name of Google Inc. nor the names of its
  * contributors may be used to endorse or promote products derived from
  * this software without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  * ```
  *
  * ```text
  * Copyright (C) 2004 by Sun Microsystems, Inc. All rights reserved.
  *
  * Developed at SunPro, a Sun Microsystems, Inc. business.
  * Permission to use, copy, modify, and distribute this
  * software is freely granted, provided that this notice
  * is preserved.
  * ```
  *)

@stdlib/math-base-special-gamma/lib/stirling_approximation.js:
@stdlib/math-base-special-gamma/lib/small_approximation.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The original C code, copyright, license, and constants are from [Cephes]{@link http://www.netlib.org/cephes}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright 1984, 1987, 1989, 1992, 2000 by Stephen L. Moshier
  *
  * Some software in this archive may be from the book _Methods and Programs for Mathematical Functions_ (Prentice-Hall or Simon & Schuster International, 1989) or from the Cephes Mathematical Library, a commercial product. In either event, it is copyrighted by the author. What you see here may be used freely but it comes with no support or guarantee.
  *
  * Stephen L. Moshier
  * moshier@na-net.ornl.gov
  * ```
  *)

@stdlib/math-base-special-gamma/lib/main.js:
  (**
  * @license Apache-2.0
  *
  * Copyright (c) 2018 The Stdlib Authors.
  *
  * Licensed under the Apache License, Version 2.0 (the "License");
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  *
  *    http://www.apache.org/licenses/LICENSE-2.0
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  *
  * ## Notice
  *
  * The original C code, long comment, copyright, license, and constants are from [Cephes]{@link http://www.netlib.org/cephes}. The implementation follows the original, but has been modified for JavaScript.
  *
  * ```text
  * Copyright 1984, 1987, 1989, 1992, 2000 by Stephen L. Moshier
  *
  * Some software in this archive may be from the book _Methods and Programs for Mathematical Functions_ (Prentice-Hall or Simon & Schuster International, 1989) or from the Cephes Mathematical Library, a commercial product. In either event, it is copyrighted by the author. What you see here may be used freely but it comes with no support or guarantee.
  *
  * Stephen L. Moshier
  * moshier@na-net.ornl.gov
  * ```
  *)

decimal.js/decimal.mjs:
  (*!
   *  decimal.js v10.6.0
   *  An arbitrary-precision Decimal type for JavaScript.
   *  https://github.com/MikeMcl/decimal.js
   *  Copyright (c) 2025 Michael Mclaughlin <M8ch88l@gmail.com>
   *  MIT Licence
   *)
*/
