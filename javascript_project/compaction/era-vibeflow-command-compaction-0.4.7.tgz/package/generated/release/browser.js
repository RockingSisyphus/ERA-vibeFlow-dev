// ../../reports/.compaction-package-y2cODw/browser/workflow.js
import { compileFunctionLibrary, countAutomaticRandomDraws, parseExpression } from "@era/vibeflow-expression/engine";
function run() {
  return {};
}
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value) ? value : void 0;
}
function own(value, key) {
  return value !== null && typeof value === "object" && Object.hasOwn(value, key) ? value[key] : void 0;
}
function define(target, key, value) {
  Object.defineProperty(target, key, { value, writable: true, enumerable: true, configurable: true });
}
function readVariablePath(tree, path) {
  let value = tree;
  for (const key of path) {
    if (Array.isArray(value) ? typeof key !== "number" : typeof key !== "string") return void 0;
    value = own(value, key);
  }
  return value;
}
function arrayOperations(payload, op) {
  const root = record(payload);
  if (!root || !Object.hasOwn(root, "$arrayOps")) return void 0;
  if (Object.keys(root).length !== 1 || !Array.isArray(root.$arrayOps)) return [];
  return root.$arrayOps.flatMap((entry) => {
    const fields = record(entry);
    const path = fields && own(fields, "path");
    if (!fields || !Array.isArray(path) || !path.length || !path.every((key) => typeof key === "string" || Number.isSafeInteger(key) && key >= 0) || !path.some((key) => typeof key === "number") || Object.keys(fields).length !== (op === "delete" ? 1 : 2) || op !== "delete" && !Object.hasOwn(fields, "value")) return [];
    return [{ path, value: fields.value }];
  });
}
function nextRule(rule, parent, key, inArray = false) {
  return typeof key === "number" ? own(rule, "items") : inArray ? own(own(rule, "fields"), key) : own(own(own(parent, "$meta"), "fields"), key);
}
function variableRuleSource(tree, path) {
  let rule = own(tree, "$meta");
  let source = ["$meta"];
  let value = tree;
  let inArray = false;
  for (const [index, key] of path.entries()) {
    if (typeof key === "number") {
      source = [...source, "items"];
    } else if (inArray) {
      source = [...source, "fields", key];
    } else {
      source = [...path.slice(0, index), "$meta", "fields", key];
    }
    inArray ||= typeof key === "number";
    rule = nextRule(rule, value, key, inArray);
    value = own(value, key);
  }
  return { rule: record(rule), path: source };
}
function variableRuleAt(tree, path) {
  return variableRuleSource(tree, path).rule;
}
function canDescend(rule, child, key, op, terminal) {
  if (key === "$meta") return true;
  if (op === "edit") return own(rule, "updatable") !== false;
  if (op === "insert") {
    const locked = own(rule, "unInsertAble");
    return locked !== "all" && (locked !== "self" || child !== void 0 || !terminal);
  }
  const necessary = own(rule, "necessary");
  return necessary !== "all" && (necessary !== "children" || !terminal);
}
function applyItemDefaults(template, value) {
  const defaults = record(template), fields = record(value);
  if (!defaults || !fields) return value;
  const result = {};
  for (const key of /* @__PURE__ */ new Set([...Object.keys(defaults), ...Object.keys(fields)])) {
    define(result, key, Object.hasOwn(fields, key) ? applyItemDefaults(own(defaults, key), own(fields, key)) : own(defaults, key));
  }
  return result;
}
function sameValue(before, after) {
  if (before === after) return true;
  if (Array.isArray(before) && Array.isArray(after))
    return before.length === after.length && before.every((value, index) => sameValue(value, after[index]));
  const left = record(before), right = record(after);
  if (!left || !right) return false;
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length && keys.every((key) => Object.hasOwn(right, key) && sameValue(left[key], right[key]));
}
function containsArray(value) {
  return Array.isArray(value) || record(value) !== void 0 && Object.entries(value).some(([key, child]) => key !== "$meta" && key !== "$template" && containsArray(child));
}
function acceptsRuleSetting(path, op, value) {
  const start = path.indexOf("$meta");
  if (op === "delete" || start < 0 || path.includes("$template")) return true;
  for (let index = start + 1; index < path.length - 1; index++) {
    if (path[index] === "fields") index++;
    else if (path[index] !== "items") return true;
  }
  const field = path.at(-1);
  if (field === "updatable") return typeof value === "boolean";
  if (field === "min" || field === "max") return typeof value === "number" && Number.isFinite(value);
  return true;
}
function checkChange(before, proposed, rule, op, inArray = false, useTemplate = false) {
  if (op === "edit" && own(rule, "updatable") === false) return void 0;
  if (op === "delete" && ["self", "all"].includes(String(own(rule, "necessary")))) return void 0;
  const min = own(rule, "min"), max = own(rule, "max");
  if (op !== "delete" && (min !== void 0 || max !== void 0)) {
    if (typeof proposed !== "number" || !Number.isFinite(proposed) || min !== void 0 && (typeof min !== "number" || !Number.isFinite(min) || proposed < min) || max !== void 0 && (typeof max !== "number" || !Number.isFinite(max) || proposed > max)) return void 0;
  }
  const value = useTemplate ? applyItemDefaults(own(rule, "$template"), proposed) : proposed;
  if (op === "delete" && !inArray && !containsArray(before)) return { value };
  if (Array.isArray(before) || Array.isArray(value)) {
    const previous2 = Array.isArray(before) ? before : [];
    const candidate2 = Array.isArray(value) ? value : [];
    const items = [];
    for (let index = 0; index < Math.max(previous2.length, candidate2.length); index++) {
      const childOp = index >= previous2.length ? "insert" : index >= candidate2.length ? "delete" : "edit";
      if (childOp !== "delete" && !Object.hasOwn(candidate2, index)) return void 0;
      if (childOp === "edit" && sameValue(previous2[index], candidate2[index])) {
        items.push(candidate2[index]);
        continue;
      }
      if (op !== "insert" && !canDescend(rule, previous2[index], index, childOp, true)) return void 0;
      const child = checkChange(previous2[index], candidate2[index], own(rule, "items"), childOp, true, childOp === "insert");
      if (!child) return void 0;
      if (childOp !== "delete") items.push(child.value);
    }
    if (Array.isArray(value)) return { value: items };
  }
  const previous = record(before), candidate = record(value);
  if (!previous && !candidate) return { value };
  const result = {};
  const keys = /* @__PURE__ */ new Set([...Object.keys(previous ?? {}), ...Object.keys(candidate ?? {})]);
  for (const key of keys) {
    const oldValue = own(previous, key), newValue = own(candidate, key);
    if (key === "$meta" || key === "$template") {
      if (newValue !== void 0) define(result, key, newValue);
      continue;
    }
    const childOp = oldValue === void 0 ? "insert" : newValue === void 0 ? "delete" : "edit";
    if (childOp === "edit" && sameValue(oldValue, newValue)) {
      define(result, key, newValue);
      continue;
    }
    if (op !== "insert" && !canDescend(rule, oldValue, key, childOp, true)) return void 0;
    const child = checkChange(oldValue, newValue, nextRule(rule, previous ?? candidate, key, inArray), childOp, inArray);
    if (!child) return void 0;
    if (childOp !== "delete") define(result, key, child.value);
  }
  return { value: candidate ? result : value };
}
function planVariableWrite(tree, path, op, value) {
  if (!path.length || !acceptsRuleSetting(path, op, value)) return void 0;
  let current = tree;
  let rule = own(tree, "$meta");
  let arrayPath;
  for (const [index, key] of path.entries()) {
    const terminal = index === path.length - 1;
    if (Array.isArray(current)) {
      if (typeof key !== "number" || !Number.isSafeInteger(key) || key < 0) return void 0;
      arrayPath ??= path.slice(0, index);
      if (terminal && op === "insert" && key !== current.length) return void 0;
    } else if (!record(current) || typeof key !== "string") return void 0;
    const child = own(current, key);
    if (!canDescend(rule, child, key, op, terminal)) return void 0;
    rule = nextRule(rule, current, key, arrayPath !== void 0);
    current = child;
  }
  if (op === "insert" !== (current === void 0)) return void 0;
  const checked = checkChange(current, value, rule, op, arrayPath !== void 0, op === "insert" && typeof path.at(-1) === "number");
  if (!checked) return void 0;
  if (containsArray(current) || containsArray(checked.value)) arrayPath ??= path;
  return { path, value: checked.value, op, arrayPath };
}
function applyVariableWrite(tree, write) {
  const parent = readVariablePath(tree, write.path.slice(0, -1));
  const key = write.path[write.path.length - 1];
  if (write.op !== "delete") define(parent, key, structuredClone(write.value));
  else if (Array.isArray(parent)) parent.splice(key, 1);
  else delete parent[key];
}
function tokenize(source) {
  const punctuation = {
    "\uFF1A": ":",
    "\uFF0C": ",",
    "\uFF3B": "[",
    "\uFF3D": "]",
    "\uFF5B": "{",
    "\uFF5D": "}"
  };
  const token = /\s+|\/\/[^\r\n]*|\/\*[\s\S]*?\*\/|<!--[\s\S]*?-->|"(?:\\[\s\S]|[^"\\])*"|'(?:\\[\s\S]|[^'\\])*'|[{}\[\]:,：，［］｛｝]|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?|[$_\p{ID_Start}][$\u200c\u200d\p{ID_Continue}]*/uy;
  const parts = [];
  while (token.lastIndex < source.length) {
    const match = token.exec(source);
    if (!match) throw new SyntaxError("\u6307\u4EE4\u4E2D\u6709\u65E0\u6CD5\u8BC6\u522B\u7684 JSON \u6587\u672C\u3002");
    const value = match[0];
    if (/^\s/u.test(value) || /^\/[/\*]|^<!--/u.test(value)) continue;
    parts.push(Object.hasOwn(punctuation, value) ? punctuation[value] : value);
  }
  return parts;
}
function normalize(parts) {
  return parts.flatMap((part, index) => {
    const next = parts[index + 1];
    const previous = parts[index - 1];
    if (part === "," && (next === "]" || next === "}") && previous !== "[" && previous !== "{" && previous !== ",") return [];
    if (part.startsWith("'")) {
      const inside = part.slice(1, -1).replace(/\\[\s\S]|"/gu, (item) => {
        if (item === "\\'") return "'";
        return item === '"' ? '\\"' : item;
      });
      return [`"${inside}"`];
    }
    return [next === ":" && /^[$_\p{ID_Start}]/u.test(part) ? JSON.stringify(part) : part];
  }).join(" ");
}
function parsePayload(text) {
  try {
    const value = JSON.parse(text);
    return Array.isArray(value) ? value : [value];
  } catch {
    const parts = tokenize(text);
    try {
      const value = JSON.parse(normalize(parts));
      return Array.isArray(value) ? value : [value];
    } catch {
      const values = [];
      let depth = 0, start = 0;
      for (const [index, part] of parts.entries()) {
        if (depth === 0) {
          if (part !== "{") throw new SyntaxError("\u6307\u4EE4\u9700\u8981\u5B8C\u6574\u7684 JSON \u5BF9\u8C61\u3002");
          start = index;
        }
        if (part === "{" || part === "[") depth += 1;
        if (part === "}" || part === "]") depth -= 1;
        if (depth === 0) values.push(JSON.parse(normalize(parts.slice(start, index + 1))));
      }
      if (depth !== 0 || values.length === 0) throw new SyntaxError("\u6307\u4EE4 JSON \u672A\u95ED\u5408\u6216\u4E3A\u7A7A\u3002");
      return values;
    }
  }
}
function hasFiniteNumbers(value) {
  if (typeof value === "number") return Number.isFinite(value);
  return value === null || typeof value !== "object" || Object.values(value).every(hasFiniteNumbers);
}
function readObjectLine(line) {
  if (!/^[{｛].*[}｝]$/u.test(line)) return [];
  try {
    return parsePayload(line).filter(hasFiniteNumbers);
  } catch {
    return [];
  }
}
function parseEraCommandPayload(source) {
  const text = source.trim().replace(/^(?:```|~~~)[a-zA-Z0-9_-]*[^\S\r\n]*\r?\n/u, "").replace(/\r?\n(?:```|~~~)[^\S\r\n]*$/u, "");
  try {
    const values = parsePayload(text);
    if (!values.every(hasFiniteNumbers)) throw new SyntaxError("\u53D8\u91CF JSON \u53EA\u80FD\u5305\u542B\u6709\u9650\u6570\u503C\u3002");
    return { values, skipped: false };
  } catch (error) {
    const lines = text.split(/\r?\n/u).map((line) => line.trim()).filter(Boolean);
    if (lines.length < 3 || !readObjectLine(lines[0]).length || !readObjectLine(lines.at(-1)).length)
      throw error;
    return { values: lines.flatMap(readObjectLine), skipped: true };
  }
}
function commandTagPattern() {
  return /<((?:Variable|Function)(?:Insert|Edit|Delete))>\s*((?:(?!<(?:era_data|Variable(?:Think|Insert|Edit|Delete)|Function(?:Insert|Edit|Delete))>|<\/\1>)[\s\S])*?)\s*<\/\1>/giu;
}
function tagInfo(value) {
  if (value === "variableinsert")
    return { kind: "insert", tag: "VariableInsert" };
  if (value === "variableedit")
    return { kind: "edit", tag: "VariableEdit" };
  if (value === "variabledelete")
    return { kind: "delete", tag: "VariableDelete" };
  if (value === "functioninsert")
    return { kind: "function-insert", tag: "FunctionInsert" };
  if (value === "functionedit")
    return { kind: "function-edit", tag: "FunctionEdit" };
  if (value === "functiondelete")
    return { kind: "function-delete", tag: "FunctionDelete" };
  return null;
}
function record2(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function plain(value) {
  if (!record2(value))
    return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
function clone(value) {
  return structuredClone(value);
}
function equal(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function diagnostic(code, message, commandIndex, path) {
  return { code, message, ...commandIndex === void 0 ? {} : { commandIndex }, ...path === void 0 ? {} : { path } };
}
function parseData(text, commandIndex) {
  try {
    const { values, skipped } = parseEraCommandPayload(text);
    if (!values.every(plain)) {
      return { data: [], diagnostic: diagnostic("ERA_COMPACT_COMMAND_DATA_INVALID", "\u6307\u4EE4\u5185\u5BB9\u5FC5\u987B\u662F JSON \u5BF9\u8C61\u6216\u5BF9\u8C61\u6570\u7EC4\u3002", commandIndex) };
    }
    return {
      data: values,
      ...skipped ? { diagnostic: diagnostic("ERA_COMPACT_COMMAND_JSON_INVALID", "\u90E8\u5206 JSONL \u8F93\u5165\u65E0\u6548\uFF0C\u4FDD\u7559\u539F\u6587\u3002", commandIndex) } : {}
    };
  } catch (error) {
    return { data: [], diagnostic: diagnostic("ERA_COMPACT_COMMAND_JSON_INVALID", `\u6307\u4EE4 JSON \u65E0\u6CD5\u89E3\u6790\uFF1A${error instanceof Error ? error.message : String(error)}`, commandIndex) };
  }
}
function parseCommandLayer(input) {
  const source = record2(input) ? input : {};
  const request = {
    content: typeof source.content === "string" ? source.content : "",
    initialStatData: plain(source.initialStatData) ? clone(source.initialStatData) : {},
    initialStatFunc: plain(source.initialStatFunc) ? clone(source.initialStatFunc) : {},
    snapshotStatData: plain(source.snapshotStatData) ? clone(source.snapshotStatData) : plain(source.initialStatData) ? clone(source.initialStatData) : {},
    snapshotStatFunc: plain(source.snapshotStatFunc) ? clone(source.snapshotStatFunc) : plain(source.initialStatFunc) ? clone(source.initialStatFunc) : {},
    eraMeta: plain(source.eraMeta) ? clone(source.eraMeta) : {},
    templateContext: plain(source.templateContext) ? clone(source.templateContext) : {},
    randomContext: plain(source.randomContext) && typeof source.randomContext.sourceKey === "string" && source.randomContext.sourceKey.length > 0 && Number.isSafeInteger(source.randomContext.drawOffset) && source.randomContext.drawOffset >= 0 ? {
      sourceKey: source.randomContext.sourceKey,
      drawOffset: source.randomContext.drawOffset
    } : void 0
  };
  const commands = [];
  const diagnostics = [];
  const pattern = commandTagPattern();
  let match;
  while ((match = pattern.exec(request.content)) !== null) {
    const info = tagInfo((match[1] ?? "").toLowerCase());
    if (!info)
      continue;
    const index = commands.length;
    const parsed = parseData(match[2] ?? "", index);
    if (parsed.diagnostic)
      diagnostics.push(parsed.diagnostic);
    commands.push({
      index,
      kind: info.kind,
      tag: info.tag,
      data: parsed.data,
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0]
    });
  }
  return { request, commands, diagnostics };
}
function getAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record2(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment))
      return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function hasAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record2(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment))
      return false;
    cursor = cursor[segment];
  }
  return true;
}
function writeVariable(stat, path, op, value) {
  const write = planVariableWrite(stat, path, op, value);
  if (write) applyVariableWrite(stat, write);
}
function applyArrayOperations(stat, op, patch) {
  const operations = arrayOperations(patch, op);
  if (!operations) return false;
  for (const { path, value } of operations) writeVariable(stat, path, op, value);
  return true;
}
function metaValue(value, key) {
  return plain(value) && plain(value.$meta) ? value.$meta[key] : void 0;
}
function merge(left, right) {
  if (!plain(left) || !plain(right))
    return clone(right);
  const output = clone(left);
  for (const [key, value] of Object.entries(right)) {
    output[key] = Object.prototype.hasOwnProperty.call(output, key) ? merge(output[key], value) : clone(value);
  }
  return output;
}
function inheritedTemplateContent(parentTemplate, key) {
  if (!plain(parentTemplate))
    return void 0;
  const general = parentTemplate.$template;
  const specific = parentTemplate[key];
  if (plain(general) && plain(specific))
    return merge(general, specific);
  return plain(specific) ? specific : plain(general) ? general : void 0;
}
function resolvedTemplate(inherited, parentData) {
  const own2 = plain(parentData) ? parentData.$template : void 0;
  const result = merge(plain(inherited) ? inherited : {}, plain(own2) ? own2 : {});
  return plain(result) && Object.keys(result).length > 0 ? result : void 0;
}
function applyTemplate(template, patch) {
  if (!plain(patch) || !plain(template))
    return clone(patch);
  return Object.keys(patch).length === 0 ? clone(template) : merge(template, patch);
}
function applyInsertAt(stat, segments, patch, inheritedTemplate = void 0, parentData = void 0) {
  if (segments.length === 0 && applyArrayOperations(stat, "insert", patch)) return;
  const current = getAt(stat, segments);
  const localTemplate = resolvedTemplate(inheritedTemplate, parentData);
  if (segments.length > 0 && current === void 0) {
    writeVariable(stat, segments, "insert", applyTemplate(localTemplate, patch));
    return;
  }
  if (!plain(current) || !plain(patch))
    return;
  for (const key of Object.keys(patch)) {
    applyInsertAt(stat, [...segments, key], patch[key], inheritedTemplateContent(localTemplate, key), current);
  }
}
function* expressionValueProgress(stat, layerStart, statFunc, startFunc, path, expr, randomCursor) {
  const request = {
    initialState: stat,
    snapshotState: layerStart,
    functionLibrary: statFunc,
    snapshotFunctionLibrary: startFunc,
    allowSnapshots: true,
    operations: [{ path: path.join("."), expr }],
    ...randomCursor ? { randomContext: randomCursor } : {}
  };
  const response = yield { kind: "expression", input: request };
  if (randomCursor)
    randomCursor.drawOffset = response.nextDrawOffset;
  const value = getAt(response.finalState, path);
  const issue = response.diagnostics[0];
  if (issue || typeof value !== "number" || !Number.isFinite(value)) {
    return { diagnostic: diagnostic(issue?.code ?? "ERA_COMPACT_EXPR_NON_FINITE", issue?.message ?? "$expr \u5FC5\u987B\u5F97\u5230\u6709\u9650\u6570\u503C\u3002", void 0, path.join(".")) };
  }
  return { value };
}
function* applyEditAtProgress(stat, layerStart, statFunc, startFunc, segments, patch, diagnostics, commandIndex, randomCursor) {
  if (segments.length === 0 && applyArrayOperations(stat, "edit", patch)) return;
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  if (plain(patch) && Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (segments.length === 0 || !hasAt(stat, segments) || segments.some((_, index) => variableRuleAt(stat, segments.slice(0, index))?.updatable === false) || variableRuleAt(stat, segments)?.updatable === false)
      return;
    const resolved = yield* expressionValueProgress(stat, layerStart, statFunc, startFunc, segments, patch.$expr, randomCursor);
    if (resolved.diagnostic)
      diagnostics.push({ ...resolved.diagnostic, commandIndex });
    else
      writeVariable(stat, segments, "edit", resolved.value);
    return;
  }
  if (!plain(patch)) {
    if (segments.length > 0 && hasAt(stat, segments))
      writeVariable(stat, segments, "edit", patch);
    return;
  }
  for (const [key, value] of Object.entries(patch)) {
    yield* applyEditAtProgress(stat, layerStart, statFunc, startFunc, [...segments, key], value, diagnostics, commandIndex, randomCursor);
  }
}
function applyDeleteAt(stat, segments, patch) {
  if (segments.length === 0 && applyArrayOperations(stat, "delete", patch)) return;
  if (segments.length > 0 && getAt(stat, segments) === void 0) return;
  if (plain(patch) && Object.keys(patch).length > 0) {
    for (const [key, value] of Object.entries(patch)) applyDeleteAt(stat, [...segments, key], value);
    return;
  }
  if (segments.length > 0) writeVariable(stat, segments, "delete");
}
function functionDiagnostic(code, message, commandIndex, name) {
  return diagnostic(code, message, commandIndex, name);
}
function functionMetaInvalid(value) {
  const meta = plain(value) && plain(value.$meta) ? value.$meta : null;
  if (!meta)
    return null;
  if (Object.prototype.hasOwnProperty.call(meta, "unInsertAble"))
    return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.unInsertAble\u3002";
  if (meta.necessary === "children")
    return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.necessary: children\u3002";
  return null;
}
function* validateFunctionsProgress(library) {
  const result = yield { kind: "expression", input: { initialState: {}, functionLibrary: library, operations: [] } };
  const issue = result.diagnostics[0];
  return issue ? diagnostic(issue.code, issue.message, void 0, "<library>") : null;
}
function editFunction(current, patch) {
  if (!plain(current) || !plain(patch))
    return clone(patch);
  const patchMeta = plain(patch.$meta) ? patch.$meta : null;
  if (Object.keys(patch).length === 1 && patchMeta) {
    const next2 = clone(current);
    next2.$meta = merge(current.$meta, patchMeta);
    return next2;
  }
  const next = clone(patch);
  if (!Object.prototype.hasOwnProperty.call(patch, "$meta") && Object.prototype.hasOwnProperty.call(current, "$meta"))
    next.$meta = clone(current.$meta);
  else if (patchMeta)
    next.$meta = merge(current.$meta, patchMeta);
  return next;
}
function* applyFunctionProgress(library, type, data, diagnostics, commandIndex) {
  let current = clone(library);
  for (const root of data) {
    if (Object.keys(root).length === 0) {
      diagnostics.push(functionDiagnostic("ERA_FUNCTION_COMMAND_INVALID", "\u51FD\u6570\u6307\u4EE4\u5FC5\u987B\u662F\u975E\u7A7A\u5BF9\u8C61\u3002", commandIndex));
      continue;
    }
    const candidate = clone(current);
    const issues = [];
    for (const [name, patch] of Object.entries(root)) {
      const exists = Object.prototype.hasOwnProperty.call(current, name);
      if (type === "function-insert") {
        if (exists) {
          issues.push(functionDiagnostic("ERA_FUNCTION_ALREADY_EXISTS", "FunctionInsert \u53EA\u80FD\u65B0\u589E\u4E0D\u5B58\u5728\u7684\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        const invalid2 = functionMetaInvalid(patch);
        if (invalid2) {
          issues.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = clone(patch);
      } else if (type === "function-edit") {
        if (!exists) {
          issues.push(functionDiagnostic("ERA_FUNCTION_NOT_FOUND", "FunctionEdit \u53EA\u80FD\u4FEE\u6539\u65E2\u6709\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        if (metaValue(current[name], "updatable") === false && !(plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true))
          continue;
        const next = editFunction(current[name], patch);
        const invalid2 = functionMetaInvalid(next);
        if (invalid2) {
          issues.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = next;
      } else {
        if (!plain(patch)) {
          issues.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
          continue;
        }
        if (Object.keys(patch).length === 0) {
          if (exists && !["self", "all"].includes(String(metaValue(current[name], "necessary"))))
            delete candidate[name];
        } else if (Object.keys(patch).length === 1 && plain(patch.$meta) && exists) {
          const next = clone(current[name]);
          const metaPatch = patch.$meta;
          if (plain(next.$meta)) {
            for (const key of Object.keys(metaPatch))
              delete next.$meta[key];
          }
          candidate[name] = next;
        } else
          issues.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
      }
    }
    if (issues.length > 0) {
      diagnostics.push(...issues);
      continue;
    }
    const invalid = yield* validateFunctionsProgress(candidate);
    if (invalid) {
      diagnostics.push({ ...invalid, commandIndex });
      continue;
    }
    current = candidate;
  }
  return current;
}
function* replayCommandProgress(command, state) {
  if (command.kind === "insert") {
    for (const patch of command.data)
      applyInsertAt(state.stat, [], patch);
  } else if (command.kind === "edit") {
    for (const patch of command.data)
      yield* applyEditAtProgress(state.stat, state.start, state.functions, state.startFunctions, [], patch, state.diagnostics, command.index, state.randomCursor);
  } else if (command.kind === "delete") {
    for (const patch of command.data)
      applyDeleteAt(state.stat, [], patch);
  } else {
    return yield* applyFunctionProgress(state.functions, command.kind, command.data, state.diagnostics, command.index);
  }
  return state.functions;
}
function* executeOriginalSemanticsProgress(parsed) {
  const stat = clone(parsed.request.initialStatData);
  const start = clone(parsed.request.snapshotStatData ?? parsed.request.initialStatData);
  let functions = clone(parsed.request.initialStatFunc ?? {});
  const startFunctions = clone(parsed.request.snapshotStatFunc ?? parsed.request.initialStatFunc ?? {});
  const diagnostics = [...parsed.diagnostics];
  const randomCursor = parsed.request.randomContext ? { ...parsed.request.randomContext } : null;
  for (const command of parsed.commands) {
    if (command.data.length === 0)
      continue;
    functions = yield* replayCommandProgress(command, { stat, start, functions, startFunctions, diagnostics, randomCursor });
  }
  return {
    ...parsed,
    finalStatData: stat,
    finalStatFunc: functions,
    diagnostics,
    nextRandomDrawOffset: randomCursor?.drawOffset ?? parsed.request.randomContext?.drawOffset ?? 0
  };
}
function hasMeta(value) {
  if (!plain(value))
    return false;
  if (Object.prototype.hasOwnProperty.call(value, "$meta") || Object.prototype.hasOwnProperty.call(value, "$template") || Object.hasOwn(value, "$arrayOps"))
    return true;
  return Object.values(value).some(hasMeta);
}
function flattenNumericEdits(patch, prefix = [], output = []) {
  if (!plain(patch))
    return false;
  if (Object.hasOwn(patch, "$meta") || Object.hasOwn(patch, "$template") || Object.hasOwn(patch, "$arrayOps"))
    return false;
  if (Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (prefix.length === 0)
      return false;
    output.push({ path: prefix.join("."), expr: patch.$expr, source: "expr" });
    return true;
  }
  for (const [key, value] of Object.entries(patch)) {
    if (plain(value)) {
      if (!flattenNumericEdits(value, [...prefix, key], output))
        return false;
    } else if (typeof value === "number" && Number.isFinite(value))
      output.push({ path: [...prefix, key].join("."), expr: JSON.stringify(value), source: "literal", literal: value });
    else
      return false;
  }
  return output.length > 0;
}
function nestingRecord(paths) {
  const result = {};
  for (const item of paths) {
    const parts = item.path.split(".");
    if (parts.some((part) => ["__proto__", "constructor", "prototype"].includes(part))) return null;
    let cursor = result;
    for (const part of parts.slice(0, -1)) {
      if (Object.prototype.hasOwnProperty.call(cursor, part) && !plain(cursor[part]))
        return null;
      cursor[part] ??= {};
      cursor = cursor[part];
    }
    const leaf = parts[parts.length - 1];
    if (plain(cursor[leaf]))
      return null;
    cursor[leaf] = item.value;
  }
  return result;
}
function renderTag(tag, data) {
  return `<${tag}>
${JSON.stringify(data)}
</${tag}>`;
}
function mergeInsertPatch(left, right) {
  if (!plain(left) || !plain(right) || hasMeta(left) || hasMeta(right))
    return null;
  const output = clone(left);
  for (const [key, value] of Object.entries(right)) {
    if (!Object.prototype.hasOwnProperty.call(output, key)) {
      Object.defineProperty(output, key, { value: clone(value), configurable: true, enumerable: true, writable: true });
      continue;
    }
    if (!plain(value))
      continue;
    if (!plain(output[key])) {
      return null;
    }
    const merged = mergeInsertPatch(output[key], value);
    if (merged === null)
      return null;
    output[key] = merged;
  }
  return output;
}
function allCommandData(command) {
  if (command.data.length !== 1)
    return null;
  return command.data[0] ?? null;
}
function renderCompactedEdits(operations, compacted) {
  const sourceByPath = /* @__PURE__ */ new Map();
  const lastLiteralByPath = /* @__PURE__ */ new Map();
  for (const operation of operations) {
    const prior = sourceByPath.get(operation.path);
    sourceByPath.set(operation.path, prior === void 0 || prior === operation.source ? operation.source : "mixed");
    if (operation.source === "literal")
      lastLiteralByPath.set(operation.path, operation.literal);
  }
  if ([...sourceByPath.values()].includes("mixed"))
    return null;
  const output = nestingRecord(compacted.map((item) => {
    const source = sourceByPath.get(item.path);
    return source === "literal" ? { path: item.path, value: lastLiteralByPath.get(item.path) } : { path: item.path, value: { $expr: item.value.$expr } };
  }));
  return output && Object.keys(output).length > 0 ? renderTag("VariableEdit", output) : "";
}
function* compactEditRunProgress(trace, commands) {
  const operations = [];
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data || !flattenNumericEdits(data, [], operations))
      return null;
  }
  const response = yield { kind: "expression", input: {
    initialState: trace.request.initialStatData,
    snapshotState: trace.request.snapshotStatData ?? trace.request.initialStatData,
    functionLibrary: trace.request.initialStatFunc ?? {},
    snapshotFunctionLibrary: trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {},
    allowSnapshots: true,
    operations,
    ...trace.request.randomContext ? { randomContext: trace.request.randomContext } : {}
  } };
  if (response.diagnostics.length > 0)
    return null;
  return renderCompactedEdits(operations, response.compactedOperations);
}
function pathConflict(left, right) {
  return left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
}
function operationRefs(ast) {
  const refs = /* @__PURE__ */ new Set();
  const visit = (item) => {
    if (item.kind === "ref") {
      if (!item.snapshot)
        refs.add(item.path.join("."));
      return;
    }
    if (item.kind === "unary")
      visit(item.value);
    else if (item.kind === "binary") {
      visit(item.left);
      visit(item.right);
    } else if (item.kind === "call")
      for (const arg of item.args)
        visit(arg);
  };
  visit(ast);
  return [...refs];
}
function commandExpressionFacts(trace, command) {
  const operations = [];
  const data = allCommandData(command);
  if (!data || !flattenNumericEdits(data, [], operations))
    return { automaticRandom: false, paths: [], refs: [], flattenable: false };
  const current = compileFunctionLibrary(trace.request.initialStatFunc ?? {});
  const snapshot = compileFunctionLibrary(trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {});
  const refs = /* @__PURE__ */ new Set();
  let automaticRandom = false;
  for (const operation of operations) {
    const parsed = parseExpression(operation.expr, true);
    if (!parsed.ast)
      continue;
    if (countAutomaticRandomDraws(parsed.ast, current, snapshot) > 0)
      automaticRandom = true;
    for (const ref of operationRefs(parsed.ast))
      refs.add(ref);
  }
  return {
    automaticRandom,
    paths: operations.map((operation) => operation.path),
    refs: [...refs],
    flattenable: true
  };
}
function segmentDoesNotDependOnPriorChanges(facts, priorPaths) {
  return facts.every((fact) => fact.refs.every((ref) => ![...priorPaths].some((path) => pathConflict(ref, path))));
}
function compactInsertRun(commands) {
  let merged = {};
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data)
      return null;
    const next = mergeInsertPatch(merged, data);
    if (next === null)
      return null;
    merged = next;
  }
  return plain(merged) && Object.keys(merged).length > 0 ? renderTag("VariableInsert", merged) : null;
}
function* candidateForProgress(analysis) {
  const { trace } = analysis;
  const replacements = /* @__PURE__ */ new Map();
  const reasons = [];
  if (trace.diagnostics.length > 0)
    return { ...trace, replacements, reasons: ["\u539F\u547D\u4EE4\u542B\u8BCA\u65AD\uFF0C\u4FDD\u7559\u5168\u90E8\u6807\u7B7E\u3002"] };
  let cursor = 0;
  while (cursor < trace.commands.length) {
    const kind = trace.commands[cursor].kind;
    let end = cursor + 1;
    while (end < trace.commands.length && trace.commands[end].kind === kind)
      end += 1;
    const run8 = trace.commands.slice(cursor, end);
    let replacement = null;
    if (kind === "edit") {
      if (cursor === 0) {
        const facts = run8.map((command) => analysis.facts[command.index]);
        const priorPaths = /* @__PURE__ */ new Set();
        let segmentStart = 0;
        const compactSegment = function* (segmentEnd) {
          if (segmentEnd <= segmentStart)
            return;
          const segment = run8.slice(segmentStart, segmentEnd);
          const segmentFacts = facts.slice(segmentStart, segmentEnd);
          if (segmentFacts.every((fact) => fact.flattenable) && segmentDoesNotDependOnPriorChanges(segmentFacts, priorPaths)) {
            const compacted = yield* compactEditRunProgress(trace, segment);
            if (compacted !== null && (segment.length > 1 || compacted !== segment[0].raw)) {
              replacements.set(segment[0].index, compacted);
              for (const command of segment.slice(1))
                replacements.set(command.index, "");
            }
          } else {
            reasons.push(`${segment.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u4F9D\u8D56\u968F\u673A\u5C4F\u969C\u6216\u66F4\u65E9\u547D\u4EE4\u6539\u53D8\u7684\u8DEF\u5F84\u3002`);
          }
          for (const fact of segmentFacts)
            for (const path of fact.paths)
              priorPaths.add(path);
        };
        for (let index = 0; index < run8.length; index += 1) {
          if (!facts[index].automaticRandom)
            continue;
          yield* compactSegment(index);
          for (const path of facts[index].paths)
            priorPaths.add(path);
          reasons.push(`${run8[index].tag} \u4FDD\u7559\uFF1A\u5305\u542B\u81EA\u52A8 random \u8C03\u7528\u3002`);
          segmentStart = index + 1;
        }
        yield* compactSegment(run8.length);
        replacement = null;
      } else
        reasons.push(`${run8.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u524D\u5E8F\u547D\u4EE4\u4F1A\u6539\u53D8\u8BE5\u533A\u95F4\u7684\u5C42\u8D77\u59CB\u8BED\u4E49\u3002`);
    } else if (kind === "insert")
      replacement = compactInsertRun(run8);
    else
      reasons.push(`${run8.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u5C1A\u65E0\u53EF\u8BC1\u660E\u7684\u901A\u7528\u91CD\u5199\u89C4\u5219\u3002`);
    if (replacement !== null && (run8.length > 1 || replacement !== run8[0].raw)) {
      replacements.set(run8[0].index, replacement);
      for (const command of run8.slice(1))
        replacements.set(command.index, "");
    }
    cursor = end;
  }
  return { ...trace, replacements, reasons };
}
function render(trace, replacements) {
  let content = trace.request.content;
  for (const command of [...trace.commands].sort((left, right) => right.start - left.start)) {
    const replacement = replacements.get(command.index);
    if (replacement !== void 0)
      content = `${content.slice(0, command.start)}${replacement}${content.slice(command.end)}`;
  }
  return content;
}
function* equivalentProgress(trace, content) {
  const replay = yield* executeOriginalSemanticsProgress(parseCommandLayer({ ...trace.request, content }));
  const sameDiagnostics = replay.diagnostics.length === trace.diagnostics.length && replay.diagnostics.every((issue, index) => {
    const expected = trace.diagnostics[index];
    return expected !== void 0 && issue.code === expected.code && issue.path === expected.path;
  });
  return sameDiagnostics && equal(replay.finalStatData, trace.finalStatData) && equal(replay.finalStatFunc, trace.finalStatFunc) && replay.nextRandomDrawOffset === trace.nextRandomDrawOffset;
}
function analyzeDependencies(trace) {
  const facts = {};
  if (trace.diagnostics.length === 0) {
    for (const command of trace.commands) {
      if (command.kind !== "edit")
        break;
      facts[command.index] = commandExpressionFacts(trace, command);
    }
  }
  return { trace, facts };
}
function scopedTransactions(content) {
  const result = [];
  const pattern = /<era_tx\b([^>]*)>([\s\S]*?)<\/era_tx>/giu;
  let match;
  while ((match = pattern.exec(content)) !== null) {
    const scopeMatch = /\bs\s*=\s*["']([^"']+)["']/iu.exec(match[1] ?? "");
    const rawScope = scopeMatch?.[1] ?? "";
    result.push({
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0],
      body: match[2] ?? "",
      scope: rawScope === "m" || rawScope === "b" || rawScope === "a" ? rawScope : null
    });
  }
  return result;
}
function withStartState(request, content, statData, statFunc) {
  return {
    ...request,
    content,
    initialStatData: statData,
    initialStatFunc: statFunc
  };
}
function groupedTransaction(transactions, content, index) {
  const current = transactions[index];
  let endIndex = index;
  let text = current.body;
  let raw = current.raw;
  if (current.scope === null)
    return { endIndex, text, raw };
  while (endIndex + 1 < transactions.length) {
    const next = transactions[endIndex + 1];
    const between = content.slice(transactions[endIndex].end, next.start);
    if (next.scope !== current.scope || between.trim().length > 0)
      break;
    text += `${between}${next.body}`;
    raw += `${between}${next.raw}`;
    endIndex += 1;
  }
  return { endIndex, text, raw };
}
function parseLayer(input) {
  const parsed = parseCommandLayer(input);
  const transactions = scopedTransactions(parsed.request.content);
  if (transactions.length === 0)
    return {
      ...parsed,
      scoped: false,
      segments: [
        {
          text: parsed.request.content,
          raw: parsed.request.content,
          scope: null,
          allowRewrite: true
        }
      ]
    };
  const segments = [];
  let cursor = 0;
  for (let index = 0; index < transactions.length; ) {
    const current = transactions[index];
    const prefix = parsed.request.content.slice(cursor, current.start);
    segments.push({
      text: prefix,
      raw: prefix,
      scope: null,
      allowRewrite: true
    });
    const { endIndex, text, raw } = groupedTransaction(transactions, parsed.request.content, index);
    segments.push({
      text,
      raw,
      scope: current.scope,
      allowRewrite: current.scope !== null && endIndex > index
    });
    cursor = transactions[endIndex].end;
    index = endIndex + 1;
  }
  const tail = parsed.request.content.slice(cursor);
  segments.push({ text: tail, raw: tail, scope: null, allowRewrite: true });
  return { ...parsed, segments, scoped: true };
}
function initializeSegments(parsed) {
  return {
    cursor: 0,
    segments: parsed.segments,
    request: parsed.request,
    parsed,
    statData: clone(parsed.request.initialStatData),
    statFunc: clone(parsed.request.initialStatFunc ?? {}),
    drawOffset: parsed.request.randomContext?.drawOffset ?? 0,
    parts: [],
    diagnostics: [],
    reasons: [],
    changed: false,
    commandSegments: 0,
    rewrittenSegments: 0,
    lastResult: null
  };
}
function selectSegment(state) {
  const segment = state.segments[state.cursor];
  if (!state.parsed.scoped)
    return parseCommandLayer(state.request);
  const request = {
    ...state.request,
    ...state.request.randomContext ? {
      randomContext: {
        sourceKey: state.request.randomContext.sourceKey,
        drawOffset: state.drawOffset
      }
    } : {}
  };
  return parseCommandLayer(withStartState(request, segment.text, state.statData, state.statFunc));
}
function* rewriteSegmentProgress(analysis) {
  const candidate = yield* candidateForProgress(analysis);
  return { ...candidate, replacements: [...candidate.replacements] };
}
function* verifySegmentProgress(candidate) {
  const replacements = new Map(candidate.replacements);
  const base = {
    content: candidate.request.content,
    finalStatData: candidate.finalStatData,
    finalStatFunc: candidate.finalStatFunc,
    diagnostics: candidate.diagnostics,
    parsedCommands: candidate.commands,
    nextRandomDrawOffset: candidate.nextRandomDrawOffset
  };
  if (parseCommandLayer(candidate.request).diagnostics.length > 0)
    return {
      ...base,
      status: "invalid",
      reasons: ["\u6807\u7B7E JSON \u65E0\u6548\uFF0C\u672A\u6539\u5199\u6D88\u606F\u3002"]
    };
  if (replacements.size === 0)
    return {
      ...base,
      status: "unchanged",
      reasons: candidate.reasons.length ? candidate.reasons : ["\u6CA1\u6709\u53EF\u8BC1\u660E\u5B89\u5168\u7684\u7F29\u5199\u3002"]
    };
  const content = render(candidate, replacements);
  if (!(yield* equivalentProgress(candidate, content)))
    return {
      ...base,
      status: "unchanged",
      reasons: [
        ...candidate.reasons,
        "\u5019\u9009\u672A\u901A\u8FC7\u540C\u4E00\u8D77\u70B9\u771F\u5B9E\u91CD\u653E\uFF0C\u5DF2\u9000\u56DE\u539F\u547D\u4EE4\u3002"
      ]
    };
  return {
    ...base,
    content,
    status: candidate.commands.every((command) => replacements.has(command.index)) ? "compacted" : "partial",
    reasons: candidate.reasons
  };
}
function advanceSegment(state, result) {
  const segment = state.segments[state.cursor];
  const hasCommands = result.parsedCommands.length > 0;
  const changed = hasCommands && segment.allowRewrite && result.content !== segment.text && result.diagnostics.length === 0;
  const text = changed ? segment.scope === null ? result.content : `<era_tx s="${segment.scope}">${result.content}</era_tx>` : segment.raw;
  return {
    ...state,
    cursor: state.cursor + 1,
    statData: clone(result.finalStatData),
    statFunc: clone(result.finalStatFunc),
    drawOffset: result.nextRandomDrawOffset,
    parts: [...state.parts, text],
    diagnostics: [...state.diagnostics, ...result.diagnostics],
    reasons: [...state.reasons, ...result.reasons],
    changed: state.changed || changed,
    commandSegments: state.commandSegments + Number(hasCommands),
    rewrittenSegments: state.rewrittenSegments + Number(changed),
    lastResult: result
  };
}
function* verifyLayerProgress(state) {
  if (!state.parsed.scoped)
    return state.lastResult;
  const originalTrace = yield* executeOriginalSemanticsProgress(state.parsed);
  const content = state.parts.join("");
  const replay = yield* executeOriginalSemanticsProgress(parseCommandLayer({ ...state.request, content }));
  const equivalentResult = equal(originalTrace.finalStatData, replay.finalStatData) && equal(originalTrace.finalStatFunc, replay.finalStatFunc) && originalTrace.nextRandomDrawOffset === replay.nextRandomDrawOffset && originalTrace.diagnostics.length === replay.diagnostics.length && originalTrace.diagnostics.every((issue, index) => issue.code === replay.diagnostics[index]?.code && issue.path === replay.diagnostics[index]?.path);
  const base = {
    finalStatData: originalTrace.finalStatData,
    finalStatFunc: originalTrace.finalStatFunc,
    diagnostics: originalTrace.diagnostics,
    parsedCommands: state.parsed.commands,
    nextRandomDrawOffset: originalTrace.nextRandomDrawOffset
  };
  if (!state.changed || !equivalentResult)
    return {
      ...base,
      status: state.diagnostics.length > 0 ? "invalid" : "unchanged",
      content: state.request.content,
      reasons: equivalentResult ? state.reasons : [
        ...state.reasons,
        "\u540C scope \u5206\u6BB5\u5019\u9009\u672A\u901A\u8FC7\u6574\u5C42\u771F\u5B9E\u91CD\u653E\uFF0C\u5DF2\u4FDD\u7559\u539F\u4E8B\u52A1\u3002"
      ]
    };
  return {
    ...base,
    status: state.rewrittenSegments === state.commandSegments ? "compacted" : "partial",
    content,
    reasons: state.reasons
  };
}
function run2(inputs) {
  return { parsed: parseLayer(inputs["era.command_compaction.request"].value) };
}
function run3(inputs) {
  return {
    segment_state: initializeSegments(
      inputs["era.command_compaction.parsed"].value
    )
  };
}
function run4(inputs) {
  const state = inputs["era.command_compaction.segment.state"].value;
  return { parsed: selectSegment(state), segment_state_before: state };
}
function* runProgress(inputs) {
  return {
    trace: yield* executeOriginalSemanticsProgress(inputs["era.command_compaction.parsed"].value)
  };
}
function createProgress(factory, inputs, params) {
  const environment = { signal: void 0 };
  return { iterator: factory(inputs, params, environment), environment, request: null, result: void 0, done: false };
}
function settle(state, step) {
  state.done = step.done === true;
  if (state.done) {
    state.result = step.value;
    state.request = null;
  } else state.request = step.value;
  return state;
}
function advanceSync(state, value, failure, signal) {
  state.environment.signal = signal;
  try {
    const step = failure === void 0 ? state.iterator.next(value) : state.iterator.throw(failure);
    if (!step.done && step.value?.kind === "local_wait") throw new TypeError("\u540C\u6B65\u4E1A\u52A1\u6B65\u9AA4\u8FD4\u56DE\u4E86\u9700\u8981\u7B49\u5F85\u7684\u8BA1\u7B97\u3002");
    return settle(state, step);
  } finally {
    state.environment.signal = void 0;
  }
}
function Prepare(inputs, params, context) {
  const state = advanceSync(createProgress(runProgress, inputs, params), void 0, void 0, context.signal);
  return { state, needs_call: !state.done };
}
function Skip(inputs) {
  return { skipped_state: inputs["era.migration.compaction.execute.state"].value };
}
function Finish(inputs) {
  return inputs["era.migration.compaction.execute.final"].value.result;
}
function Request(inputs) {
  const state = inputs["era.migration.compaction.execute.state"].value;
  return { payload: { expression_request: state.request.input }, retained_state: state };
}
function Accept(inputs, _params, context) {
  const state = inputs["era.migration.compaction.execute.state.pending"].value, outputs = inputs["era.workflow.outputs"].value;
  advanceSync(state, outputs["expressionResponse"], outputs.workflowFailure, context.signal);
  return { next_state: state, done: state.done };
}
var FORMAT = "era-values-v1";
function encodePacket(value) {
  const ancestors = /* @__PURE__ */ new Set();
  function encode(item) {
    if (item === null) return ["null"];
    switch (typeof item) {
      case "undefined":
        return ["undefined"];
      case "string":
        return ["string", item];
      case "boolean":
        return ["boolean", item];
      case "number":
        return ["number", Object.is(item, -0) ? "-0" : String(item)];
      case "bigint":
        return ["bigint", String(item)];
      case "object":
        break;
      default:
        throw new TypeError("\u5DE5\u4F5C\u6D41\u4E1A\u52A1\u6D88\u606F\u4E0D\u80FD\u5305\u542B\u51FD\u6570\u6216\u7B26\u53F7\uFF1B\u8FD0\u884C\u8D44\u6E90\u987B\u4F7F\u7528\u6240\u5C5E\u5B9E\u4F8B\u7684\u8D44\u6E90\u7F16\u53F7\u3002");
    }
    const array = Array.isArray(item), proto = Object.getPrototypeOf(item);
    const ordinary = proto === null || proto === Object.prototype || Object.getPrototypeOf(proto) === null && Object.getOwnPropertyDescriptor(proto, "constructor")?.value?.name === "Object";
    if (!array && !ordinary)
      throw new TypeError("\u5DE5\u4F5C\u6D41\u4E1A\u52A1\u6D88\u606F\u53EA\u63A5\u53D7\u666E\u901A\u5BF9\u8C61\u548C\u6570\u7EC4\uFF1B\u9875\u9762\u8D44\u6E90\u987B\u4F7F\u7528\u8D44\u6E90\u7F16\u53F7\u3002");
    if (ancestors.has(item)) throw new TypeError("\u5DE5\u4F5C\u6D41\u4E1A\u52A1\u6D88\u606F\u4E0D\u80FD\u5305\u542B\u5FAA\u73AF\u5F15\u7528\u3002");
    ancestors.add(item);
    try {
      const entries = Object.keys(item).map((key) => [key, encode(item[key])]);
      return array ? ["array", item.length, entries] : ["object", proto === null, entries];
    } finally {
      ancestors.delete(item);
    }
  }
  return { encoding: FORMAT, payload: JSON.stringify(encode(value)) };
}
function decodePacket(packet) {
  if (packet?.encoding !== FORMAT || typeof packet.payload !== "string")
    throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u636E\u5C01\u88C5\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  function decode(node) {
    if (!Array.isArray(node)) throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u503C\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
    const [kind, value, entries] = node;
    switch (kind) {
      case "null":
        return null;
      case "undefined":
        return void 0;
      case "string":
        if (typeof value !== "string") throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5B57\u7B26\u4E32\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        return value;
      case "boolean":
        if (typeof value !== "boolean") throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5E03\u5C14\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        return value;
      case "number": {
        if (typeof value !== "string") throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u503C\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        if (value === "NaN") return NaN;
        if (value === "Infinity") return Infinity;
        if (value === "-Infinity") return -Infinity;
        if (value === "-0") return -0;
        const number = Number(value);
        if (!Number.isFinite(number) || String(number) !== value)
          throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u503C\u6587\u5B57\u4E0D\u6B63\u786E\u3002");
        return number;
      }
      case "bigint":
        return BigInt(value);
      case "object":
      case "array": {
        if (!Array.isArray(entries)) throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5BF9\u8C61\u5B57\u6BB5\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        if (kind === "array" && (!Number.isInteger(value) || value < 0 || value > 4294967295))
          throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u7EC4\u957F\u5EA6\u4E0D\u6B63\u786E\u3002");
        if (kind === "object" && typeof value !== "boolean")
          throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5BF9\u8C61\u7C7B\u578B\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        const result = kind === "array" ? new Array(value) : Object.create(value ? null : Object.prototype);
        for (const entry of entries) {
          if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string")
            throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5B57\u6BB5\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
          const [key, encoded] = entry;
          if (Object.hasOwn(result, key)) throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u5305\u542B\u91CD\u590D\u5B57\u6BB5\u3002");
          if (kind === "array" && /^(0|[1-9][0-9]*)$/u.test(key) && Number(key) < 4294967295 && Number(key) >= value)
            throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u7EC4\u4F4D\u7F6E\u8D85\u8FC7\u5DF2\u58F0\u660E\u957F\u5EA6\u3002");
          Object.defineProperty(result, key, { value: decode(encoded), enumerable: true, configurable: true, writable: true });
        }
        return result;
      }
      default:
        throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u5305\u542B\u672A\u77E5\u7684\u503C\u8BB0\u5F55\u3002");
    }
  }
  return decode(JSON.parse(packet.payload));
}
function EncodeRequest(inputs) {
  return { wire_inputs: { wire_request: encodePacket(inputs["era.workflow.inputs"].value) } };
}
function DecodeOutputs(inputs) {
  const value = inputs["era.workflow.wire_outputs"].value;
  return { outputs: value.workflowFailure !== void 0 ? { workflowFailure: value.workflowFailure } : decodePacket(value.wireResponse) };
}
function InvokeSync(inputs, params, context) {
  const api = context.workflow;
  try {
    return { wire_outputs: api.invoke_sync({ workflow: params.workflow, inputs: inputs["era.workflow.wire_inputs"].value }) };
  } catch (error) {
    return { wire_outputs: { workflowFailure: error } };
  }
}
function run5(inputs) {
  return {
    symbols: analyzeDependencies(
      inputs["era.command_compaction.semantic_trace"].value
    )
  };
}
function* runProgress2(inputs) {
  return {
    candidate: yield* rewriteSegmentProgress(inputs["era.command_compaction.symbols"].value)
  };
}
function Prepare2(inputs, params, context) {
  const state = advanceSync(createProgress(runProgress2, inputs, params), void 0, void 0, context.signal);
  return { state, needs_call: !state.done };
}
function Skip2(inputs) {
  return { skipped_state: inputs["era.migration.compaction.rewrite.state"].value };
}
function Finish2(inputs) {
  return inputs["era.migration.compaction.rewrite.final"].value.result;
}
function Request2(inputs) {
  const state = inputs["era.migration.compaction.rewrite.state"].value;
  return { payload: { expression_request: state.request.input }, retained_state: state };
}
function Accept2(inputs, _params, context) {
  const state = inputs["era.migration.compaction.rewrite.state.pending"].value, outputs = inputs["era.workflow.outputs"].value;
  advanceSync(state, outputs["expressionResponse"], outputs.workflowFailure, context.signal);
  return { next_state: state, done: state.done };
}
function* runProgress3(inputs) {
  return {
    verified: yield* verifySegmentProgress(inputs["era.command_compaction.candidate"].value)
  };
}
function Prepare3(inputs, params, context) {
  const state = advanceSync(createProgress(runProgress3, inputs, params), void 0, void 0, context.signal);
  return { state, needs_call: !state.done };
}
function Skip3(inputs) {
  return { skipped_state: inputs["era.migration.compaction.verify.state"].value };
}
function Finish3(inputs) {
  return inputs["era.migration.compaction.verify.final"].value.result;
}
function Request3(inputs) {
  const state = inputs["era.migration.compaction.verify.state"].value;
  return { payload: { expression_request: state.request.input }, retained_state: state };
}
function Accept3(inputs, _params, context) {
  const state = inputs["era.migration.compaction.verify.state.pending"].value, outputs = inputs["era.workflow.outputs"].value;
  advanceSync(state, outputs["expressionResponse"], outputs.workflowFailure, context.signal);
  return { next_state: state, done: state.done };
}
function run6(inputs) {
  const next = advanceSegment(
    inputs["era.command_compaction.segment.state.before"].value,
    inputs["era.command_compaction.verified"].value
  );
  return {
    segment_state_next: next,
    segment_done: next.cursor >= next.segments.length
  };
}
function* runProgress4(inputs) {
  return {
    verified: yield* verifyLayerProgress(inputs["era.command_compaction.segment.state"].value)
  };
}
function Prepare4(inputs, params, context) {
  const state = advanceSync(createProgress(runProgress4, inputs, params), void 0, void 0, context.signal);
  return { state, needs_call: !state.done };
}
function Skip4(inputs) {
  return { skipped_state: inputs["era.migration.compaction.verify_layer.state"].value };
}
function Finish4(inputs) {
  return inputs["era.migration.compaction.verify_layer.final"].value.result;
}
function Request4(inputs) {
  const state = inputs["era.migration.compaction.verify_layer.state"].value;
  return { payload: { expression_request: state.request.input }, retained_state: state };
}
function Accept4(inputs, _params, context) {
  const state = inputs["era.migration.compaction.verify_layer.state.pending"].value, outputs = inputs["era.workflow.outputs"].value;
  advanceSync(state, outputs["expressionResponse"], outputs.workflowFailure, context.signal);
  return { next_state: state, done: state.done };
}
function run7(inputs) {
  return {
    compaction_response: inputs["era.command_compaction.verified"].value
  };
}
function Decode(inputs) {
  return { request: decodePacket(inputs["era.workflow.packet"].value).compaction_request, entry_return: (
    /** @type {"protocol"} */
    "protocol"
  ) };
}
function Encode(inputs) {
  return { packet: encodePacket({ compactionResponse: inputs["era.command_compaction.response"].value }) };
}
function PrepareDirectRequest(inputs) {
  return { prepared_request: inputs["era.command_compaction.request"].value, entry_return: (
    /** @type {"direct"} */
    "direct"
  ) };
}
function SelectEntryReturn(inputs) {
  return { return_route: inputs["era.workflow.entry_return"].value };
}
var VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v12";
var VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v5";
var VibeFlowWorkflowError = class extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === void 0 ? void 0 : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
    if (details.sourceLocation) this.sourceLocation = details.sourceLocation;
  }
};
function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details
  });
}
function throwIfAborted(signal, workflow, nodePath2 = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath: nodePath2,
    blockPath,
    cause: signal.reason
  });
}
async function awaitWithAbort(value, signal, workflow, nodePath2 = "", blockPath = "") {
  return await value;
}
function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}
function dictionary() {
  return /* @__PURE__ */ Object.create(null);
}
function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true
  });
  return target;
}
function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string" && !new RegExp(schema.pattern).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}
function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every(
    (key, index) => key === rightKeys[index] && jsonEquals(left[key], right[key])
  );
}
function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}
function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}
function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}
function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}
function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}
function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details
  });
  root.kernelLog?.(event);
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause }
    );
  }
}
function normalizeOptions(workflow, options) {
  const raw = options === void 0 ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  if (Object.hasOwn(raw, "detachedTimeoutMs")) throw vfError("VF_ASYNC_MIGRATION", "detachedTimeoutMs was removed; workflow waits for actual Node cleanup", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== void 0 && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    statusStopping: raw.__vfStatusStopping,
    statusUpdate: raw.__vfStatusUpdate,
    kernelLog: raw.__vfKernelLog,
    workflowSession: raw.workflowSession,
    workflowInstanceId: raw.workflowInstanceId
  };
}
function inputValues(workflow, inputs, input) {
  const values = inputs[__vfMultipleInputs]?.get(input.key);
  if (values) return values;
  return [inputs[input.key]];
}
function validatePublicInputs(workflow, inputs, schemas) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input.key);
    if (input.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = inputValues(workflow, inputs, input).map((value) => validateJsonSchema(
      value,
      input.schema || schemas[input.type]
    )).find(Boolean);
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input.key}' failed schema validation: ${failure}`,
        workflow
      );
    }
  }
}
function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}
function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial, root.schemas);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: /* @__PURE__ */ new Map(),
    activeEdges: /* @__PURE__ */ new Set(),
    lastInputs: /* @__PURE__ */ new Map(),
    nodeRuns: /* @__PURE__ */ new Map(),
    stepCount: 0,
    initial
  };
}
function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}
function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input of state.workflow.inputs) {
    if (!accepted.has(input.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input.key)) continue;
    for (const value of inputValues(state.workflow, state.initial, input)) {
      state.inboxes[nodeId].push(createEnvelope(input.key, input.type, value, "pipeline.input"));
    }
  }
}
function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type).sort((a, b) => state.workflow.node_order.indexOf(a.source_node) - state.workflow.node_order.indexOf(b.source_node));
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}
function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}
function conditionMatches(condition, values) {
  if (!condition) return true;
  const equal2 = Object.is(values[condition.key], condition.literal);
  return condition.operator === "==" ? equal2 : !equal2;
}
function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}
function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  if (outputs && typeof outputs.then === "function") throw vfError("VF_COMPLETION_MISMATCH", "immediate node returned pending work", state.workflow);
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  for (const provider of node.provides) {
    const schema = state.root.schemas[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
  }
  return outputs;
}
function outputEnvelopes(node, outputs) {
  return node.provides.map(
    (provider) => createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}
function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node)
    );
    state.inboxes[targetId].push(envelope);
  }
}
function nodeContext(node, state, execution) {
  return Object.freeze({
    signal: execution?.signal || state.root.signal,
    workflow: nodeWorkflow(state, node, execution),
    updateInfo(info) {
      state.root.statusUpdate?.(info);
    },
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details
      });
    }
  });
}
function invokeStaticImplementationSync(implementation, node, params, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const execution = new NodeExecution(state.root.signal);
  try {
    const outputs = implementation(inputs, params, nodeContext(node, state, execution));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      cause.sourceLocation ||= { path: node.source?.ref || "", symbol: node.source?.export || "" };
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted && (cause?.name === "AbortError" || cause === state.root.signal.reason)) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause }
    );
  } finally {
    execution.exitSync();
  }
}
function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.definition_id
  });
  return inputs;
}
function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.definition_id
  });
}
function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}
function rawInputsForChild(inputSpecs, inputs, workflow, nodeId) {
  const items = [];
  for (const value of Object.values(inputs)) {
    if (Array.isArray(value)) items.push(...value);
    else if (value) items.push(value);
  }
  const initial = dictionary();
  const multiple = /* @__PURE__ */ new Map();
  for (const input of inputSpecs) {
    const matches = items.filter((item) => item?.type === input.type);
    if (matches.length) {
      setOwn(initial, input.key, matches[0].value);
      multiple.set(input.key, matches.map((item) => item.value));
    } else if (input.required) {
      throw vfError(
        "VF_INPUT_REQUIRED",
        `composite node '${nodeId}' cannot supply required body input '${input.key}'`,
        workflow
      );
    }
  }
  Object.defineProperty(initial, __vfMultipleInputs, { value: multiple });
  return initial;
}
function outputsFromChild(node, mappings, childResult, state) {
  const outputs = dictionary();
  for (const mapping of mappings) {
    if (!Object.prototype.hasOwnProperty.call(childResult.publicOutputs, mapping.alias)) {
      throw vfError(
        "VF_OUTPUT_CARDINALITY",
        `composite node '${node.id}' body omitted optional output '${mapping.alias}' required by provider '${mapping.provider}'`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
    setOwn(outputs, mapping.provider, childResult.publicOutputs[mapping.alias]);
  }
  return validateNodeOutputs(node, outputs, state);
}
function valueFromEnvelope(value) {
  if (value && typeof value === "object" && "value" in value && "type" in value) {
    return value.value;
  }
  return value;
}
function resultValues(child) {
  const values = dictionary();
  for (const [key, value] of Object.entries(child.publicOutputs)) setOwn(values, key, value);
  for (const [type, candidates] of child.candidates) {
    if (candidates.length === 1) setOwn(values, type, candidates[0].value);
  }
  return values;
}
function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = [...state.candidates.get(spec.type) || []].sort((a, b) => state.workflow.node_order.indexOf(a.source_node) - state.workflow.node_order.indexOf(b.source_node));
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.root.schemas[spec.type];
    const values = spec.cardinality === "all" ? matches.map((item) => item.value) : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow
        );
      }
    }
  }
  return output;
}
function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
function nodeWorkflow(state, node, execution) {
  const signal = execution?.signal || state.root.signal;
  const session = state.root.workflowSession;
  const location = { nodePath: nodePath(state, node.id), blockPath: formatBlockPath(state.path) };
  function operation(name, request = {}) {
    if (execution && !execution.active) throw vfError("VF_NODE_CONTEXT_EXITED", "Node invocation has exited", state.workflow, location);
    if (name !== "send" && name !== "invoke_sync") throwIfAborted(signal, state.workflow, location.nodePath, location.blockPath);
    if (typeof session?.[name] !== "function") throw vfError(session == null ? "VF_WORKFLOW_UNCONNECTED" : "VF_WORKFLOW_UNSUPPORTED", `workflow session does not provide ${name}`, state.workflow, location);
    return session[name](request, { signal });
  }
  function immediate(name, request) {
    const value = operation(name, request);
    if (value && typeof value.then === "function") throw vfError("VF_COMPLETION_MISMATCH", `workflow ${name} returned pending work`, state.workflow, location);
    return value;
  }
  function suspended(name, request) {
    const promise = (async () => {
      try {
        return await awaitWithAbort(operation(name, request), signal, state.workflow, location.nodePath, location.blockPath);
      } catch (error) {
        if (signal?.aborted) throwIfAborted(signal, state.workflow, location.nodePath, location.blockPath);
        throw error;
      }
    })();
    return execution ? execution.own(promise) : promise;
  }
  return Object.freeze({
    self: () => state.root.identity.self(),
    invoke_sync: (request) => immediate("invoke_sync", request),
    send: (request) => immediate("send", request),
    call: (request) => suspended("call", request),
    wait: (request) => suspended("wait", request),
    receive: (request) => suspended("receive", request),
    kill: (request) => suspended("kill", request)
  });
}
var __vfMultipleInputs = /* @__PURE__ */ Symbol("native input envelopes");
function runtimePluginError(code, descriptor, hook, cause, workflow, location = {}) {
  const suffix = hook ? ` hook '${hook}'` : "";
  return vfError(
    code,
    `runtime plugin '${descriptor.id}'${suffix} failed`,
    workflow,
    {
      nodePath: location.nodePath || "",
      blockPath: location.blockPath || "/",
      cause
    }
  );
}
function runtimePluginContext(workflow, descriptor, root) {
  return Object.freeze({
    abiVersion: VIBEFLOW_PLUGIN_ABI,
    pluginId: descriptor.id,
    pluginType: "runtime",
    target: descriptor.target,
    workflowId: workflow.workflow_id,
    config: deepFreeze(descriptor.config || {}),
    signal: root.signal
  });
}
function runtimePluginSummary(root, details = {}) {
  return deepFreeze({
    workflowId: root.workflowId,
    entryMode: root.workflow.entry_mode,
    ...details
  });
}
function createRuntimePluginsSync(workflow, descriptors, factories, root) {
  const records = [];
  try {
    for (const descriptor of descriptors) {
      const factory = factories[descriptor.factory_index];
      if (typeof factory !== "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("plugin module does not export createPlugin()"),
          workflow
        );
      }
      let instance;
      try {
        instance = factory(runtimePluginContext(workflow, descriptor, root));
      } catch (cause) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          cause,
          workflow
        );
      }
      if (!instance || typeof instance !== "object" || Array.isArray(instance) || typeof instance.then === "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("createPlugin() must return a RuntimePlugin object"),
          workflow
        );
      }
      records.push({ descriptor, instance });
    }
    return records;
  } catch (failure) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      try {
        const returned = records[index].instance.dispose?.();
        if (returned && typeof returned.then === "function") throw new TypeError("sync runtime disposal returned pending work");
      } catch (error) {
        (failure.cleanupErrors ||= []).push(runtimePluginError("VF_RUNTIME_PLUGIN_DISPOSE", records[index].descriptor, "dispose", error, workflow));
      }
    }
    throw failure;
  }
}
function invokeRuntimeHookSync(root, hook, details = {}, preserveFailure = false) {
  const summary = runtimePluginSummary(root, details);
  for (const record3 of root.runtimePlugins) {
    const callback = record3.instance[hook];
    if (typeof callback !== "function") continue;
    try {
      const returned = callback(summary);
      if (returned && typeof returned.then === "function") throw new TypeError("sync runtime hook returned pending work");
    } catch (cause) {
      if (preserveFailure) {
        (root.cleanupErrors ||= []).push(runtimePluginError("VF_RUNTIME_PLUGIN_HOOK", record3.descriptor, hook, cause, root.workflow, summary));
        continue;
      }
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_HOOK",
        record3.descriptor,
        hook,
        cause,
        root.workflow,
        summary
      );
    }
  }
}
function disposeRuntimePluginsSync(root, preserveFailure = false) {
  let firstFailure;
  for (let index = root.runtimePlugins.length - 1; index >= 0; index--) {
    const record3 = root.runtimePlugins[index];
    try {
      const returned = record3.instance.dispose?.();
      if (returned && typeof returned.then === "function") throw new TypeError("sync runtime disposal returned pending work");
    } catch (cause) {
      const error = runtimePluginError("VF_RUNTIME_PLUGIN_DISPOSE", record3.descriptor, "dispose", cause, root.workflow);
      if (preserveFailure) (root.cleanupErrors ||= []).push(error);
      else if (firstFailure) (firstFailure.cleanupErrors ||= []).push(error);
      else firstFailure = error;
    }
  }
  root.runtimePlugins.length = 0;
  if (firstFailure) throw firstFailure;
}
function createRoot(workflow, schemas, normalized) {
  const instanceId = normalized.workflowInstanceId ?? Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)), (value) => value.toString(16).padStart(2, "0")).join("");
  const controller = new AbortController();
  const parentSignal = normalized.signal;
  const propagate = () => controller.abort(parentSignal.reason);
  parentSignal?.addEventListener("abort", propagate, { once: true });
  if (parentSignal?.aborted) propagate();
  const root = {
    workflow,
    schemas,
    workflowId: workflow.workflow_id,
    identity: Object.freeze({ self: () => ({ id: instanceId }) }),
    signal: controller.signal,
    traceMode: normalized.traceMode,
    onTrace: normalized.onTrace,
    statusStopping: normalized.statusStopping,
    statusUpdate: normalized.statusUpdate,
    kernelLog: normalized.kernelLog,
    workflowSession: normalized.workflowSession,
    controller,
    runtimePlugins: []
  };
  const onAbort = () => {
    try {
      root.statusStopping?.();
    } catch (error) {
      root.observationFailure ||= error;
    }
  };
  root.signal.addEventListener("abort", onAbort, { once: true });
  root.unsubscribeSignal = () => {
    root.signal.removeEventListener("abort", onAbort);
    parentSignal?.removeEventListener("abort", propagate);
  };
  return root;
}
function prepareWorkflowInvocation(workflow, schemas, options, entryMode) {
  let normalized;
  try {
    normalized = normalizeOptions(workflow, options);
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
  const root = createRoot(workflow, schemas, normalized);
  try {
    throwIfAborted(root.signal, workflow);
    emitTrace(root, "run_start", {}, true);
    return root;
  } catch (cause) {
    root.unsubscribeSignal();
    throw ensureErrorLocation(cause, workflow, []);
  }
}
function assertWorkflowAbi(workflow) {
  if (workflow.abi_version !== VIBEFLOW_WORKFLOW_ABI) {
    throw vfError(
      "VF_INTERNAL",
      `generated workflow ABI '${workflow.abi_version}' is unsupported`,
      workflow
    );
  }
}
function createStaticWorkflowSync(workflowMetadata, schemaCatalog, runtimePluginDescriptors, runtimePluginFactories, executeRoot) {
  const workflow = deepFreeze(workflowMetadata);
  const plugins = deepFreeze(runtimePluginDescriptors);
  assertWorkflowAbi(workflow);
  return function invokeWorkflow(inputs, options) {
    const root = prepareWorkflowInvocation(
      workflow,
      schemaCatalog,
      options,
      "sync"
    );
    let failed = false;
    let primaryFailure;
    try {
      root.runtimePlugins = createRuntimePluginsSync(
        workflow,
        plugins,
        runtimePluginFactories,
        root
      );
      invokeRuntimeHookSync(root, "beforeRun", {
        inputKeys: Object.keys(inputs || {}).sort()
      });
      const result = executeRoot(inputs, root, []);
      throwIfAborted(root.signal, workflow);
      invokeRuntimeHookSync(root, "afterRun", {
        outputKeys: Object.keys(result.publicOutputs || {}).sort()
      });
      emitTrace(root, "run_end", {}, true);
      return result.publicOutputs;
    } catch (cause) {
      failed = true;
      const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
      primaryFailure = failure;
      if (failure.code !== "VF_TRACE_SINK_FAILED") {
        try {
          emitTrace(root, "run_failed", {
            code: failure.code,
            message: failure.message
          }, true);
        } catch {
        }
      }
      invokeRuntimeHookSync(root, "runFailed", {
        code: failure.code,
        message: failure.message
      }, true);
      throw ensureErrorLocation(failure, workflow, []);
    } finally {
      try {
        disposeRuntimePluginsSync(root, failed);
      } finally {
        if (primaryFailure && root.cleanupErrors?.length) (primaryFailure.cleanupErrors ||= []).push(...root.cleanupErrors);
        root.unsubscribeSignal();
      }
    }
  };
}
function __vfSnapshotInfo(info) {
  const active = /* @__PURE__ */ new Set();
  function copy(value) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || active.has(value)) throw new TypeError("run info must contain JSON values");
    const array = Array.isArray(value);
    if (!array && ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
      throw new TypeError("run info must contain plain JSON objects");
    }
    active.add(value);
    let result;
    if (array) {
      result = Array.from(value, (item) => copy(item));
    } else {
      result = Object.fromEntries(Object.entries(value).map(([key, item]) => [key, copy(item)]));
    }
    active.delete(value);
    return Object.freeze(result);
  }
  if (!Array.isArray(info) || info.some((item) => !item || typeof item !== "object" || Array.isArray(item))) {
    throw new TypeError("run info must be an array of JSON objects");
  }
  return copy(info);
}
function __vfObservation(options) {
  const raw = options ?? {};
  const interval = raw.statusIntervalMs ?? 6e4;
  if (!Number.isFinite(interval) || interval <= 0) throw new TypeError("statusIntervalMs must be positive finite milliseconds");
  if (raw.onStatus !== void 0 && typeof raw.onStatus !== "function") throw new TypeError("onStatus must be a function");
  let info = Object.freeze([]);
  let state = "starting";
  let error = null;
  let closed = false;
  let timer;
  let sink;
  const record3 = () => Object.freeze({ state, error, updated_at: (/* @__PURE__ */ new Date()).toISOString(), info });
  const publish = () => {
    const snapshot = record3();
    sink?.publish(snapshot);
    raw.onStatus?.(snapshot);
  };
  const observer = {
    updateInfo(value) {
      if (closed) throw new Error("cannot update info after the run has finished");
      info = __vfSnapshotInfo(value);
      sink?.cache(record3());
    },
    kernel(event) {
      sink?.kernel(JSON.stringify(event));
    },
    run(callback) {
      return sink ? sink.run(callback) : callback();
    },
    stopping() {
      if (closed || state === "stopping") return;
      state = "stopping";
      publish();
    },
    start() {
      if (typeof __vfCreateFileObservation === "function") {
        sink = __vfCreateFileObservation(raw, record3(), interval);
      }
      publish();
      state = "running";
      publish();
      if (raw.onStatus) {
        timer = setInterval(() => {
          try {
            raw.onStatus(record3());
          } catch (failure) {
            try {
              observer.finish(failure);
            } catch {
            }
            throw failure;
          }
        }, interval);
        timer.unref?.();
      }
    },
    finish(failure) {
      if (closed) return;
      if (timer) clearInterval(timer);
      state = failure ? "failed" : "succeeded";
      if (failure) {
        const messages = [];
        const seen = /* @__PURE__ */ new Set();
        for (let cause = failure; cause && !seen.has(cause); cause = cause.cause) {
          seen.add(cause);
          messages.push(String(cause.message || cause));
        }
        error = messages.join(": ");
      } else error = null;
      if (failure) sink?.kernel(String(failure.stack || failure));
      closed = true;
      try {
        sink?.finish(record3());
        raw.onStatus?.(record3());
      } catch (cause) {
        if (!failure) {
          state = "failed";
          error = String(cause?.message || cause);
          try {
            sink?.finish(record3());
          } catch {
          }
        }
        throw cause;
      } finally {
        sink?.close();
      }
    }
  };
  return observer;
}
function __vfObservedOptions(options, observer) {
  return {
    ...options ?? {},
    __vfStatusUpdate: (info) => observer.updateInfo(info),
    __vfKernelLog: (event) => observer.kernel(event),
    __vfStatusStopping: () => observer.stopping()
  };
}
function __vfObserveSync(invoke, inputs, options) {
  if (options !== void 0 && (!options || typeof options !== "object" || Array.isArray(options))) return invoke(inputs, options);
  const observer = __vfObservation(options);
  try {
    observer.start();
    const outputs = observer.run(() => invoke(inputs, __vfObservedOptions(options, observer)));
    observer.finish(null);
    return outputs;
  } catch (error) {
    try {
      observer.finish(error);
    } catch {
    }
    throw error;
  }
}
var NodeExecution = class {
  constructor(parentSignal) {
    this.controller = new AbortController();
    this.signal = this.controller.signal;
    this.operations = /* @__PURE__ */ new Set();
    this.active = true;
    this.stopping = false;
    this.parentSignal = parentSignal;
    this.abort = () => this.controller.abort(parentSignal.reason);
    parentSignal.addEventListener("abort", this.abort, { once: true });
    if (parentSignal.aborted) this.abort();
  }
  own(promise) {
    this.operations.add(promise);
    promise.then(() => this.operations.delete(promise), () => this.operations.delete(promise));
    return promise;
  }
  exitSync() {
    this.stopping = true;
    this.controller.abort("Node exiting");
    this.active = false;
    this.parentSignal.removeEventListener("abort", this.abort);
  }
  async exit() {
    this.stopping = true;
    this.controller.abort("Node exiting");
    const failures = [];
    try {
      while (this.operations.size) {
        const outcomes = await Promise.allSettled([...this.operations]);
        for (const outcome of outcomes) {
          if (outcome.status === "rejected" && (outcome.reason?.code !== "VF_ABORTED" || outcome.reason?.cleanupErrors?.length))
            failures.push(outcome.reason);
        }
      }
    } finally {
      this.active = false;
      this.parentSignal.removeEventListener("abort", this.abort);
      this.operations.clear();
    }
    if (failures.length) {
      const first = failures[0];
      if (failures.length > 1) (first.cleanupErrors ||= []).push(...failures.slice(1));
      throw first;
    }
  }
};
function openStaticBlock(program, callIndex, initial, root, path, entry, workflow) {
  const [blockIndex, , params, children] = program.calls[callIndex];
  const [, nodes, variants] = program.blocks[blockIndex];
  const [starts, checks] = variants[entry ?? 0];
  const state = createStaticState(workflow, initial, root, path);
  for (let index = 0; index < nodes.length; index += 1) {
    const node = nodes[index][0];
    initializeInbox(state, node.id);
    const seed = checks[index]?.[0];
    if (seed !== null && seed !== void 0) seedInbox(state, node.id, seed);
  }
  return {
    nodes,
    params,
    children,
    checks,
    state,
    ready: [...starts],
    queued: new Set(starts),
    pendingDispatches: /* @__PURE__ */ new Map(),
    activeDispatches: /* @__PURE__ */ new Map(),
    completed: false
  };
}
function staticNodeAvailable(block, index) {
  const check = block.checks[index];
  if (check === void 0) return false;
  const [, policy, edges, required] = check;
  const { state } = block;
  if (policy === "all" && !edges.every((edge) => state.activeEdges.has(edge))) return false;
  if (policy === "any_active" && !edges.some((edge) => state.activeEdges.has(edge))) return false;
  const inbox = state.inboxes[block.nodes[index][0].id];
  return required.every((type) => inbox.some((item) => item.type === type));
}
function startStaticNode(block, index, node) {
  const { state, pendingDispatches, activeDispatches } = block;
  const dispatches = pendingDispatches.get(index);
  pendingDispatches.delete(index);
  if (dispatches) {
    for (const dispatch of dispatches) dispatch.active += 1;
    activeDispatches.set(index, dispatches);
  }
  if (state.stepCount >= state.workflow.max_steps) {
    throw vfError("VF_MAX_STEPS", "workflow exceeded max_steps", state.workflow);
  }
  state.stepCount += 1;
  const inputs = prepareStaticNode(node, state);
  const [, policy, edges] = block.checks[index];
  if (policy === "all") {
    for (const edge of edges) state.activeEdges.delete(edge);
  }
  return inputs;
}
function releaseStaticDispatch(block, index) {
  for (const dispatch of block.activeDispatches.get(index) || []) dispatch.active -= 1;
  block.activeDispatches.delete(index);
}
function activateStaticRoutes(block, index, outputs, inputs) {
  const [node, , routes, terminal, limit] = block.nodes[index];
  const { state, pendingDispatches, ready, queued } = block;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(node, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  const targets = [];
  for (const [target, edge, accepts, condition] of routes) {
    if (condition !== null && !conditionMatches(condition, values)) continue;
    const targetId = block.nodes[target][0].id;
    if (edge !== null) {
      state.activeEdges.add(edge);
      targets.push(target);
      emitTrace(state.root, "edge_activated", { source: node.id, target: targetId, path: state.path });
    }
    if (accepts !== null) deliverStatic(envelopes, state, targetId, accepts);
  }
  if (terminal) {
    block.completed = true;
    return;
  }
  if (limit !== null) {
    const dispatch = { limit, active: 0 };
    for (const target of targets) {
      if (!pendingDispatches.has(target)) pendingDispatches.set(target, /* @__PURE__ */ new Set());
      pendingDispatches.get(target).add(dispatch);
    }
  }
  enqueueStaticTargets(targets, ready, queued);
}
function staticNodeLocation(node, state) {
  return { nodeId: node.id, nodePath: nodePath(state, node.id), blockPath: formatBlockPath(state.path) };
}
function staticFailureDetails(location, failure) {
  return { ...location, code: failure.code, message: failure.message };
}
function executeStaticBlockSync(program, call, initial, root, path, entry) {
  const location = { blockPath: formatBlockPath(path), path: [...path] };
  const workflow = staticBlockMetadata(program, call, root, entry);
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { ...location, path: [...path] });
    const block = openStaticBlock(program, call, initial, root, path, entry, workflow);
    const { state, ready, queued, nodes } = block;
    while (ready.length) {
      const index = ready.shift();
      queued.delete(index);
      if (staticNodeAvailable(block, index)) {
        const [node, [execute, target]] = nodes[index];
        const event = { ...staticNodeLocation(node, state), type: node.definition_id };
        try {
          const inputs = startStaticNode(block, index, node);
          invokeRuntimeHookSync(root, "beforeNode", event);
          const outputs = execute(program, block, index, node, target, inputs);
          finishStaticNode(node, state);
          invokeRuntimeHookSync(root, "afterNode", { ...event, outputKeys: Object.keys(outputs || {}).sort() });
          activateStaticRoutes(block, index, outputs, inputs);
        } catch (cause) {
          const failure = ensureErrorLocation(cause, workflow, path, node.id);
          invokeRuntimeHookSync(root, "nodeFailed", staticFailureDetails(staticNodeLocation(node, state), failure), true);
          throw failure;
        }
      }
      releaseStaticDispatch(block, index);
    }
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", location);
    return { publicOutputs, candidates: state.candidates, completed: block.completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, workflow, path);
    invokeRuntimeHookSync(root, "blockFailed", staticFailureDetails(location, failure), true);
    throw failure;
  }
}
function staticBlockMetadata(program, call, root, entry) {
  if (entry !== void 0) return root.workflow;
  const [block, workflowId] = program.calls[call];
  return { ...program.blocks[block][0], workflow_id: workflowId };
}
function executeStaticNodeSync(_program, block, index, node, implementation, inputs) {
  return invokeStaticImplementationSync(implementation, node, block.params[index], inputs, block.state);
}
function staticNodesetInputs(program, child, outputs, inputs, state, event) {
  emitTrace(state.root, "nodeset_enter", { nodeId: event.nodeId, nodePath: event.nodePath }, true);
  if (typeof outputs === "string") {
    throw vfError("VF_OUTPUT_CARDINALITY", outputs, state.workflow, { nodePath: event.nodePath });
  }
  const metadata = program.blocks[program.calls[child][0]][0];
  return rawInputsForChild(metadata.inputs, inputs, state.workflow, event.nodeId);
}
function staticNodesetOutputs(node, mapping, child, state, event) {
  const outputs = outputsFromChild(node, mapping, child, state);
  emitTrace(state.root, "nodeset_exit", { nodeId: event.nodeId, nodePath: event.nodePath }, true);
  return outputs;
}
function executeStaticNodesetSync(program, block, index, node, mapping, inputs) {
  const { state } = block;
  const child = block.children[index];
  const event = staticNodeLocation(node, state);
  try {
    invokeRuntimeHookSync(state.root, "beforeNodeset", event);
    const initial = staticNodesetInputs(program, child, mapping, inputs, state, event);
    const result = executeStaticBlockSync(program, child, initial, state.root, [...state.path, node.id]);
    const outputs = staticNodesetOutputs(node, mapping, result, state, event);
    invokeRuntimeHookSync(state.root, "afterNodeset", event);
    return outputs;
  } catch (cause) {
    const failure = ensureErrorLocation(cause, state.workflow, state.path, node.id);
    invokeRuntimeHookSync(state.root, "nodesetFailed", staticFailureDetails(event, failure), true);
    throw failure;
  }
}
function staticLoopValue(values, key, label, code, state, event) {
  if (!Object.prototype.hasOwnProperty.call(values, key)) {
    throw vfError(code, `${label} '${key}' is unavailable`, state.workflow, { nodePath: event.nodePath });
  }
  return values[key];
}
function openStaticLoop(node, spec, inputs, state) {
  const event = { nodeId: node.id, nodePath: nodePath(state, node.id) };
  emitTrace(state.root, "loop_enter", event, true);
  const values = dictionary();
  for (const [type, input] of Object.entries(inputs)) {
    setOwn(values, type, Array.isArray(input) ? input.map(valueFromEnvelope) : valueFromEnvelope(input));
    for (const item of Array.isArray(input) ? input : [input]) {
      if (item?.key) setOwn(values, item.key, item.value);
      if (item?.type) setOwn(values, item.type, item.value);
    }
  }
  for (const carry of spec.carry) {
    setOwn(values, carry.as, staticLoopValue(values, carry.from, "loop carry source", "VF_INPUT_REQUIRED", state, event));
  }
  return { event, values, spec, state, stopped: false };
}
function staticLoopInputs(loop, iteration) {
  const { event, values, spec, state } = loop;
  throwIfAborted(state.root.signal, state.workflow, event.nodePath);
  const initial = dictionary();
  for (const carry of spec.carry) setOwn(initial, carry.as, values[carry.as]);
  emitTrace(state.root, "loop_iteration", { ...event, iteration });
  return initial;
}
function updateStaticLoop(loop, child, iteration) {
  const { event, values, spec, state } = loop;
  for (const [key, value] of Object.entries(resultValues(child))) setOwn(values, key, value);
  for (const carry of spec.carry) {
    setOwn(values, carry.as, staticLoopValue(values, carry.update, "loop carry update", "VF_OUTPUT_KEYS", state, event));
  }
  for (const collect of spec.collect) {
    if (collect.mode !== "all") throw vfError("VF_INTERNAL", `unsupported loop collect mode '${collect.mode}'`, state.workflow);
    const value = staticLoopValue(values, collect.from, "loop collect source", "VF_OUTPUT_KEYS", state, event);
    if (!Array.isArray(values[collect.as])) setOwn(values, collect.as, []);
    values[collect.as].push(value);
  }
  const count = iteration + 1;
  setOwn(values, "loop.iterations", count);
  loop.stopped = count >= (spec.stop_after ?? Infinity);
  if (spec.stop_when) {
    const key = spec.stop_when.from;
    const value = staticLoopValue(values, key, "loop stop source", "VF_OUTPUT_KEYS", state, event);
    if (typeof value !== "boolean") {
      throw vfError("VF_OUTPUT_SCHEMA", `loop stop source '${key}' must be boolean`, state.workflow, { nodePath: event.nodePath });
    }
    loop.stopped ||= value === spec.stop_when.equals;
  }
}
function finishStaticLoop(loop, node) {
  const { event, values, spec, state, stopped } = loop;
  if (!stopped && spec.max_iterations !== null && (spec.stop_after || spec.stop_when)) {
    throw vfError(
      "VF_MAX_STEPS",
      `loop node '${node.id}' exceeded max_iterations=${spec.max_iterations}`,
      state.workflow,
      { nodePath: event.nodePath }
    );
  }
  const outputs = dictionary();
  for (const output of spec.outputs) {
    setOwn(outputs, output.as, staticLoopValue(values, output.from, "loop output source", "VF_OUTPUT_KEYS", state, event));
  }
  emitTrace(state.root, "loop_exit", event, true);
  return validateNodeOutputs(node, outputs, state);
}
function executeStaticLoopSync(program, block, index, node, spec, inputs) {
  const { state } = block;
  const child = block.children[index];
  const loop = openStaticLoop(node, spec, inputs, state);
  for (let i = 0; i < (spec.max_iterations ?? Infinity) && !loop.stopped; i += 1) {
    const initial = staticLoopInputs(loop, i);
    const result = executeStaticBlockSync(program, child, initial, state.root, [...state.path, node.id, `iter_${i}`]);
    updateStaticLoop(loop, result, i);
  }
  return finishStaticLoop(loop, node);
}
var __vfRuntimePluginDescriptors = [];
var __vfRuntimePluginFactories = [];
var __vfData = deepFreeze([{ "$schema": "https://json-schema.org/draft/2020-12/schema", "type": "object" }, { "$schema": "https://json-schema.org/draft/2020-12/schema", "type": "boolean" }, { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/terminal.ts" }, ["era.migration.compaction.execute.state"], [{ "cardinality": "exactly_one", "type": "era.migration.compaction.execute.state" }], ["era.workflow.inputs"], ["era.migration.compaction.execute.state.pending", "era.workflow.outputs"], [{ "cardinality": "exactly_one", "type": "era.workflow.inputs" }], [{ "key": "wire_inputs", "type": "era.workflow.wire_inputs" }], { "completion": "immediate", "export": "EncodeRequest", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/values.mjs" }, ["era.workflow.wire_inputs"], [{ "cardinality": "exactly_one", "type": "era.workflow.wire_inputs" }], [{ "key": "wire_outputs", "type": "era.workflow.wire_outputs" }], { "completion": "immediate", "export": "InvokeSync", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/protocol.mjs" }, ["era.workflow.wire_outputs"], [{ "cardinality": "exactly_one", "type": "era.workflow.wire_outputs" }], [{ "key": "outputs", "type": "era.workflow.outputs" }], { "completion": "immediate", "export": "DecodeOutputs", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/values.mjs" }, { "$schema": "https://json-schema.org/draft/2020-12/schema", "additionalProperties": true, "type": "object" }, ["era.command_compaction.parsed"], [{ "cardinality": "exactly_one", "type": "era.command_compaction.parsed" }], { "key": "needs_call", "literal": true, "operator": "==" }, { "key": "needs_call", "literal": false, "operator": "==" }, ["era.migration.compaction.execute.final"], [{ "key": "trace", "type": "era.command_compaction.semantic_trace" }], ["era.migration.compaction.rewrite.state"], [{ "cardinality": "exactly_one", "type": "era.migration.compaction.rewrite.state" }], ["era.migration.compaction.rewrite.state.pending", "era.workflow.outputs"], ["era.command_compaction.symbols"], [{ "cardinality": "exactly_one", "type": "era.command_compaction.symbols" }], ["era.migration.compaction.rewrite.final"], [{ "key": "candidate", "type": "era.command_compaction.candidate" }], ["era.migration.compaction.verify.state"], [{ "cardinality": "exactly_one", "type": "era.migration.compaction.verify.state" }], ["era.migration.compaction.verify.state.pending", "era.workflow.outputs"], ["era.command_compaction.candidate"], [{ "cardinality": "exactly_one", "type": "era.command_compaction.candidate" }], ["era.migration.compaction.verify.final"], [{ "key": "verified", "type": "era.command_compaction.verified" }], { "$schema": "https://json-schema.org/draft/2020-12/schema", "additionalProperties": true, "properties": { "cursor": { "type": "integer" }, "diagnostics": { "type": "array" }, "drawOffset": { "type": "integer" }, "parts": { "type": "array" }, "reasons": { "type": "array" }, "request": { "type": "object" }, "segments": { "type": "array" }, "statData": { "type": "object" }, "statFunc": { "type": "object" } }, "required": ["cursor", "segments", "request", "statData", "statFunc", "drawOffset", "parts", "diagnostics", "reasons"], "type": "object" }, ["era.command_compaction.segment.state"], [{ "cardinality": "exactly_one", "type": "era.command_compaction.segment.state" }], ["era.command_compaction.segment.state.before", "era.command_compaction.verified"], ["era.command_compaction.semantic_trace"], [{ "alias": "verified", "provider": "verified" }], ["era.migration.compaction.verify_layer.state"], [{ "cardinality": "exactly_one", "type": "era.migration.compaction.verify_layer.state" }], ["era.migration.compaction.verify_layer.state.pending", "era.workflow.outputs"], ["era.migration.compaction.verify_layer.final"], ["era.command_compaction.request"], [{ "cardinality": "exactly_one", "type": "era.command_compaction.request" }], ["era.command_compaction.verified"], [{ "key": "compaction_response", "type": "era.command_compaction.response" }], ["era.command_compaction.response"], ["era.workflow.packet"], ["era.workflow.entry_return"], { "$schema": "https://json-schema.org/draft/2020-12/schema", "additionalProperties": false, "properties": { "encoding": { "const": "era-values-v1" }, "payload": { "type": "string" } }, "required": ["encoding", "payload"], "type": "object" }]);
var __vfSchemaCatalog = deepFreeze({ "era.command_compaction.candidate": __vfData[18], "era.command_compaction.parsed": __vfData[18], "era.command_compaction.request": __vfData[18], "era.command_compaction.response": __vfData[18], "era.command_compaction.segment.done": __vfData[1], "era.command_compaction.segment.state": __vfData[39], "era.command_compaction.segment.state.before": __vfData[39], "era.command_compaction.semantic_trace": __vfData[18], "era.command_compaction.symbols": __vfData[18], "era.command_compaction.verified": __vfData[18], "era.migration.compaction.execute.done": __vfData[1], "era.migration.compaction.execute.final": __vfData[0], "era.migration.compaction.execute.route": __vfData[1], "era.migration.compaction.execute.state": __vfData[0], "era.migration.compaction.execute.state.pending": __vfData[0], "era.migration.compaction.rewrite.done": __vfData[1], "era.migration.compaction.rewrite.final": __vfData[0], "era.migration.compaction.rewrite.route": __vfData[1], "era.migration.compaction.rewrite.state": __vfData[0], "era.migration.compaction.rewrite.state.pending": __vfData[0], "era.migration.compaction.verify.done": __vfData[1], "era.migration.compaction.verify.final": __vfData[0], "era.migration.compaction.verify.route": __vfData[1], "era.migration.compaction.verify.state": __vfData[0], "era.migration.compaction.verify.state.pending": __vfData[0], "era.migration.compaction.verify_layer.done": __vfData[1], "era.migration.compaction.verify_layer.final": __vfData[0], "era.migration.compaction.verify_layer.route": __vfData[1], "era.migration.compaction.verify_layer.state": __vfData[0], "era.migration.compaction.verify_layer.state.pending": __vfData[0], "era.workflow.entry_return": { "$schema": "https://json-schema.org/draft/2020-12/schema", "enum": ["direct", "protocol"], "type": "string" }, "era.workflow.inputs": __vfData[0], "era.workflow.outputs": __vfData[0], "era.workflow.packet": __vfData[56], "era.workflow.wire_inputs": __vfData[0], "era.workflow.wire_outputs": __vfData[0] });
var __vfProgram = { blocks: [[{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare_request", "encode_request", "invoke_sync", "decode_outputs", "accept_response", "end"], "inputs": [{ "key": "state", "type": "era.migration.compaction.execute.state", "required": true, "schema": __vfData[0] }], "outputs": [{ "type": "era.migration.compaction.execute.state", "cardinality": "exactly_one", "as": "next_state", "schema": __vfData[0] }, { "type": "era.migration.compaction.execute.done", "cardinality": "exactly_one", "as": "done", "schema": __vfData[1] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[3], null]], false, null], [{ "id": "prepare_request", "definition_id": "era.migration.compaction.execute.workflow.prepare_request", "requires": __vfData[4], "provides": [{ "key": "payload", "type": "era.workflow.inputs" }, { "key": "retained_state", "type": "era.migration.compaction.execute.state.pending" }], "source": { "completion": "immediate", "export": "Request", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_execute.ts" } }, [executeStaticNodeSync, Request], [[2, 1, __vfData[5], null], [5, null, __vfData[6], null]], false, null], [{ "id": "encode_request", "definition_id": "era.workflow.encode_request", "requires": __vfData[7], "provides": __vfData[8], "source": __vfData[9] }, [executeStaticNodeSync, EncodeRequest], [[3, 4, __vfData[10], null]], false, null], [{ "id": "invoke_sync", "definition_id": "era.workflow.invoke_sync", "requires": __vfData[11], "provides": __vfData[12], "source": __vfData[13] }, [executeStaticNodeSync, InvokeSync], [[4, 5, __vfData[14], null]], false, null], [{ "id": "decode_outputs", "definition_id": "era.workflow.decode_outputs", "requires": __vfData[15], "provides": __vfData[16], "source": __vfData[17] }, [executeStaticNodeSync, DecodeOutputs], [[5, 2, __vfData[6], null]], false, null], [{ "id": "accept_response", "definition_id": "era.migration.compaction.execute.workflow.accept_response", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.execute.state.pending" }, { "cardinality": "exactly_one", "type": "era.workflow.outputs" }], "provides": [{ "key": "next_state", "type": "era.migration.compaction.execute.state" }, { "key": "done", "type": "era.migration.compaction.execute.done" }], "source": { "completion": "immediate", "export": "Accept", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_execute.ts" } }, [executeStaticNodeSync, Accept], [[6, 3, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[3], null, [], __vfData[3]], [null, null, [], __vfData[5]], [null, null, [], __vfData[10]], [null, null, [], __vfData[14]], [null, null, [], __vfData[6]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare", "invoke_loop", "skip_call", "finish", "end"], "inputs": [{ "key": "input0", "type": "era.command_compaction.parsed", "required": true, "schema": __vfData[18] }], "outputs": [{ "type": "era.command_compaction.semantic_trace", "cardinality": "exactly_one", "as": "trace", "schema": __vfData[18] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[19], null]], false, null], [{ "id": "prepare", "definition_id": "era.migration.compaction.execute.workflow.prepare", "requires": __vfData[20], "provides": [{ "key": "state", "type": "era.migration.compaction.execute.state" }, { "key": "needs_call", "type": "era.migration.compaction.execute.route" }], "source": { "completion": "immediate", "export": "Prepare", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_execute.ts" } }, [executeStaticNodeSync, Prepare], [[2, 1, __vfData[3], __vfData[21]], [3, 2, __vfData[3], __vfData[22]]], false, 8], [{ "id": "invoke_loop", "definition_id": "vibeflow.loop.while", "requires": __vfData[4], "provides": [{ "key": "final_state", "type": "era.migration.compaction.execute.final" }] }, [executeStaticLoopSync, { "carry": [{ "as": "state", "from": "era.migration.compaction.execute.state", "update": "next_state" }], "collect": [], "max_iterations": null, "outputs": [{ "as": "final_state", "from": "next_state" }], "stop_when": { "equals": true, "from": "done" } }], [[4, 3, __vfData[23], null]], false, null], [{ "id": "skip_call", "definition_id": "era.migration.compaction.execute.workflow.skip_call", "requires": __vfData[4], "provides": [{ "key": "skipped_state", "type": "era.migration.compaction.execute.final" }], "source": { "completion": "immediate", "export": "Skip", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_execute.ts" } }, [executeStaticNodeSync, Skip], [[4, 4, __vfData[23], null]], false, null], [{ "id": "finish", "definition_id": "era.migration.compaction.execute.workflow.finish", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.execute.final" }], "provides": __vfData[24], "source": { "completion": "immediate", "export": "Finish", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_execute.ts" } }, [executeStaticNodeSync, Finish], [[5, 5, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[19], null, [], __vfData[19]], [null, "any_active", [1], __vfData[3]], [null, "any_active", [2], __vfData[3]], [null, null, [], __vfData[23]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare_request", "encode_request", "invoke_sync", "decode_outputs", "accept_response", "end"], "inputs": [{ "key": "state", "type": "era.migration.compaction.rewrite.state", "required": true, "schema": __vfData[0] }], "outputs": [{ "type": "era.migration.compaction.rewrite.state", "cardinality": "exactly_one", "as": "next_state", "schema": __vfData[0] }, { "type": "era.migration.compaction.rewrite.done", "cardinality": "exactly_one", "as": "done", "schema": __vfData[1] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[25], null]], false, null], [{ "id": "prepare_request", "definition_id": "era.migration.compaction.rewrite.workflow.prepare_request", "requires": __vfData[26], "provides": [{ "key": "payload", "type": "era.workflow.inputs" }, { "key": "retained_state", "type": "era.migration.compaction.rewrite.state.pending" }], "source": { "completion": "immediate", "export": "Request", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_rewrite.ts" } }, [executeStaticNodeSync, Request2], [[2, 1, __vfData[5], null], [5, null, __vfData[27], null]], false, null], [{ "id": "encode_request", "definition_id": "era.workflow.encode_request", "requires": __vfData[7], "provides": __vfData[8], "source": __vfData[9] }, [executeStaticNodeSync, EncodeRequest], [[3, 4, __vfData[10], null]], false, null], [{ "id": "invoke_sync", "definition_id": "era.workflow.invoke_sync", "requires": __vfData[11], "provides": __vfData[12], "source": __vfData[13] }, [executeStaticNodeSync, InvokeSync], [[4, 5, __vfData[14], null]], false, null], [{ "id": "decode_outputs", "definition_id": "era.workflow.decode_outputs", "requires": __vfData[15], "provides": __vfData[16], "source": __vfData[17] }, [executeStaticNodeSync, DecodeOutputs], [[5, 2, __vfData[27], null]], false, null], [{ "id": "accept_response", "definition_id": "era.migration.compaction.rewrite.workflow.accept_response", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.rewrite.state.pending" }, { "cardinality": "exactly_one", "type": "era.workflow.outputs" }], "provides": [{ "key": "next_state", "type": "era.migration.compaction.rewrite.state" }, { "key": "done", "type": "era.migration.compaction.rewrite.done" }], "source": { "completion": "immediate", "export": "Accept", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_rewrite.ts" } }, [executeStaticNodeSync, Accept2], [[6, 3, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[25], null, [], __vfData[25]], [null, null, [], __vfData[5]], [null, null, [], __vfData[10]], [null, null, [], __vfData[14]], [null, null, [], __vfData[27]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare", "invoke_loop", "skip_call", "finish", "end"], "inputs": [{ "key": "input0", "type": "era.command_compaction.symbols", "required": true, "schema": __vfData[18] }], "outputs": [{ "type": "era.command_compaction.candidate", "cardinality": "exactly_one", "as": "candidate", "schema": __vfData[18] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[28], null]], false, null], [{ "id": "prepare", "definition_id": "era.migration.compaction.rewrite.workflow.prepare", "requires": __vfData[29], "provides": [{ "key": "state", "type": "era.migration.compaction.rewrite.state" }, { "key": "needs_call", "type": "era.migration.compaction.rewrite.route" }], "source": { "completion": "immediate", "export": "Prepare", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_rewrite.ts" } }, [executeStaticNodeSync, Prepare2], [[2, 1, __vfData[25], __vfData[21]], [3, 2, __vfData[25], __vfData[22]]], false, 8], [{ "id": "invoke_loop", "definition_id": "vibeflow.loop.while", "requires": __vfData[26], "provides": [{ "key": "final_state", "type": "era.migration.compaction.rewrite.final" }] }, [executeStaticLoopSync, { "carry": [{ "as": "state", "from": "era.migration.compaction.rewrite.state", "update": "next_state" }], "collect": [], "max_iterations": null, "outputs": [{ "as": "final_state", "from": "next_state" }], "stop_when": { "equals": true, "from": "done" } }], [[4, 3, __vfData[30], null]], false, null], [{ "id": "skip_call", "definition_id": "era.migration.compaction.rewrite.workflow.skip_call", "requires": __vfData[26], "provides": [{ "key": "skipped_state", "type": "era.migration.compaction.rewrite.final" }], "source": { "completion": "immediate", "export": "Skip", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_rewrite.ts" } }, [executeStaticNodeSync, Skip2], [[4, 4, __vfData[30], null]], false, null], [{ "id": "finish", "definition_id": "era.migration.compaction.rewrite.workflow.finish", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.rewrite.final" }], "provides": __vfData[31], "source": { "completion": "immediate", "export": "Finish", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_rewrite.ts" } }, [executeStaticNodeSync, Finish2], [[5, 5, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[28], null, [], __vfData[28]], [null, "any_active", [1], __vfData[25]], [null, "any_active", [2], __vfData[25]], [null, null, [], __vfData[30]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare_request", "encode_request", "invoke_sync", "decode_outputs", "accept_response", "end"], "inputs": [{ "key": "state", "type": "era.migration.compaction.verify.state", "required": true, "schema": __vfData[0] }], "outputs": [{ "type": "era.migration.compaction.verify.state", "cardinality": "exactly_one", "as": "next_state", "schema": __vfData[0] }, { "type": "era.migration.compaction.verify.done", "cardinality": "exactly_one", "as": "done", "schema": __vfData[1] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[32], null]], false, null], [{ "id": "prepare_request", "definition_id": "era.migration.compaction.verify.workflow.prepare_request", "requires": __vfData[33], "provides": [{ "key": "payload", "type": "era.workflow.inputs" }, { "key": "retained_state", "type": "era.migration.compaction.verify.state.pending" }], "source": { "completion": "immediate", "export": "Request", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify.ts" } }, [executeStaticNodeSync, Request3], [[2, 1, __vfData[5], null], [5, null, __vfData[34], null]], false, null], [{ "id": "encode_request", "definition_id": "era.workflow.encode_request", "requires": __vfData[7], "provides": __vfData[8], "source": __vfData[9] }, [executeStaticNodeSync, EncodeRequest], [[3, 4, __vfData[10], null]], false, null], [{ "id": "invoke_sync", "definition_id": "era.workflow.invoke_sync", "requires": __vfData[11], "provides": __vfData[12], "source": __vfData[13] }, [executeStaticNodeSync, InvokeSync], [[4, 5, __vfData[14], null]], false, null], [{ "id": "decode_outputs", "definition_id": "era.workflow.decode_outputs", "requires": __vfData[15], "provides": __vfData[16], "source": __vfData[17] }, [executeStaticNodeSync, DecodeOutputs], [[5, 2, __vfData[34], null]], false, null], [{ "id": "accept_response", "definition_id": "era.migration.compaction.verify.workflow.accept_response", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.verify.state.pending" }, { "cardinality": "exactly_one", "type": "era.workflow.outputs" }], "provides": [{ "key": "next_state", "type": "era.migration.compaction.verify.state" }, { "key": "done", "type": "era.migration.compaction.verify.done" }], "source": { "completion": "immediate", "export": "Accept", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify.ts" } }, [executeStaticNodeSync, Accept3], [[6, 3, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[32], null, [], __vfData[32]], [null, null, [], __vfData[5]], [null, null, [], __vfData[10]], [null, null, [], __vfData[14]], [null, null, [], __vfData[34]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare", "invoke_loop", "skip_call", "finish", "end"], "inputs": [{ "key": "input0", "type": "era.command_compaction.candidate", "required": true, "schema": __vfData[18] }], "outputs": [{ "type": "era.command_compaction.verified", "cardinality": "exactly_one", "as": "verified", "schema": __vfData[18] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[35], null]], false, null], [{ "id": "prepare", "definition_id": "era.migration.compaction.verify.workflow.prepare", "requires": __vfData[36], "provides": [{ "key": "state", "type": "era.migration.compaction.verify.state" }, { "key": "needs_call", "type": "era.migration.compaction.verify.route" }], "source": { "completion": "immediate", "export": "Prepare", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify.ts" } }, [executeStaticNodeSync, Prepare3], [[2, 1, __vfData[32], __vfData[21]], [3, 2, __vfData[32], __vfData[22]]], false, 8], [{ "id": "invoke_loop", "definition_id": "vibeflow.loop.while", "requires": __vfData[33], "provides": [{ "key": "final_state", "type": "era.migration.compaction.verify.final" }] }, [executeStaticLoopSync, { "carry": [{ "as": "state", "from": "era.migration.compaction.verify.state", "update": "next_state" }], "collect": [], "max_iterations": null, "outputs": [{ "as": "final_state", "from": "next_state" }], "stop_when": { "equals": true, "from": "done" } }], [[4, 3, __vfData[37], null]], false, null], [{ "id": "skip_call", "definition_id": "era.migration.compaction.verify.workflow.skip_call", "requires": __vfData[33], "provides": [{ "key": "skipped_state", "type": "era.migration.compaction.verify.final" }], "source": { "completion": "immediate", "export": "Skip", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify.ts" } }, [executeStaticNodeSync, Skip3], [[4, 4, __vfData[37], null]], false, null], [{ "id": "finish", "definition_id": "era.migration.compaction.verify.workflow.finish", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.verify.final" }], "provides": __vfData[38], "source": { "completion": "immediate", "export": "Finish", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify.ts" } }, [executeStaticNodeSync, Finish3], [[5, 5, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[35], null, [], __vfData[35]], [null, "any_active", [1], __vfData[32]], [null, "any_active", [2], __vfData[32]], [null, null, [], __vfData[37]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "select_segment", "execute", "analyze_dependencies", "rewrite", "verify", "advance_segment", "end"], "inputs": [{ "key": "segment_state", "type": "era.command_compaction.segment.state", "required": true, "schema": __vfData[39] }], "outputs": [{ "type": "era.command_compaction.segment.state", "cardinality": "exactly_one", "as": "segmentStateNext", "schema": __vfData[39] }, { "type": "era.command_compaction.segment.done", "cardinality": "exactly_one", "as": "segmentDone", "schema": __vfData[1] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[40], null]], false, null], [{ "id": "select_segment", "definition_id": "era.command_compaction.select_segment", "requires": __vfData[41], "provides": [{ "key": "parsed", "type": "era.command_compaction.parsed" }, { "key": "segment_state_before", "type": "era.command_compaction.segment.state.before" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/select_segment.ts" } }, [executeStaticNodeSync, run4], [[2, 1, __vfData[19], null], [6, null, __vfData[42], null]], false, null], [{ "id": "execute", "definition_id": "era.migration.compaction.execute.workflow", "requires": __vfData[20], "provides": __vfData[24] }, [executeStaticNodesetSync, [{ "alias": "trace", "provider": "trace" }]], [[3, 2, __vfData[43], null]], false, null], [{ "id": "analyze_dependencies", "definition_id": "era.command_compaction.analyze_dependencies", "requires": [{ "cardinality": "exactly_one", "type": "era.command_compaction.semantic_trace" }], "provides": [{ "key": "symbols", "type": "era.command_compaction.symbols" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/analyze_dependencies.ts" } }, [executeStaticNodeSync, run5], [[4, 3, __vfData[28], null]], false, null], [{ "id": "rewrite", "definition_id": "era.migration.compaction.rewrite.workflow", "requires": __vfData[29], "provides": __vfData[31] }, [executeStaticNodesetSync, [{ "alias": "candidate", "provider": "candidate" }]], [[5, 4, __vfData[35], null]], false, null], [{ "id": "verify", "definition_id": "era.migration.compaction.verify.workflow", "requires": __vfData[36], "provides": __vfData[38] }, [executeStaticNodesetSync, __vfData[44]], [[6, 5, __vfData[42], null]], false, null], [{ "id": "advance_segment", "definition_id": "era.command_compaction.advance_segment", "requires": [{ "cardinality": "exactly_one", "type": "era.command_compaction.segment.state.before" }, { "cardinality": "exactly_one", "type": "era.command_compaction.verified" }], "provides": [{ "key": "segment_state_next", "type": "era.command_compaction.segment.state" }, { "key": "segment_done", "type": "era.command_compaction.segment.done" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/advance_segment.ts" } }, [executeStaticNodeSync, run6], [[7, 6, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[40], null, [], __vfData[40]], [null, null, [], __vfData[19]], [null, null, [], __vfData[43]], [null, null, [], __vfData[28]], [null, null, [], __vfData[35]], [null, null, [], __vfData[42]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare_request", "encode_request", "invoke_sync", "decode_outputs", "accept_response", "end"], "inputs": [{ "key": "state", "type": "era.migration.compaction.verify_layer.state", "required": true, "schema": __vfData[0] }], "outputs": [{ "type": "era.migration.compaction.verify_layer.state", "cardinality": "exactly_one", "as": "next_state", "schema": __vfData[0] }, { "type": "era.migration.compaction.verify_layer.done", "cardinality": "exactly_one", "as": "done", "schema": __vfData[1] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[45], null]], false, null], [{ "id": "prepare_request", "definition_id": "era.migration.compaction.verify_layer.workflow.prepare_request", "requires": __vfData[46], "provides": [{ "key": "payload", "type": "era.workflow.inputs" }, { "key": "retained_state", "type": "era.migration.compaction.verify_layer.state.pending" }], "source": { "completion": "immediate", "export": "Request", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify_layer.ts" } }, [executeStaticNodeSync, Request4], [[2, 1, __vfData[5], null], [5, null, __vfData[47], null]], false, null], [{ "id": "encode_request", "definition_id": "era.workflow.encode_request", "requires": __vfData[7], "provides": __vfData[8], "source": __vfData[9] }, [executeStaticNodeSync, EncodeRequest], [[3, 4, __vfData[10], null]], false, null], [{ "id": "invoke_sync", "definition_id": "era.workflow.invoke_sync", "requires": __vfData[11], "provides": __vfData[12], "source": __vfData[13] }, [executeStaticNodeSync, InvokeSync], [[4, 5, __vfData[14], null]], false, null], [{ "id": "decode_outputs", "definition_id": "era.workflow.decode_outputs", "requires": __vfData[15], "provides": __vfData[16], "source": __vfData[17] }, [executeStaticNodeSync, DecodeOutputs], [[5, 2, __vfData[47], null]], false, null], [{ "id": "accept_response", "definition_id": "era.migration.compaction.verify_layer.workflow.accept_response", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.verify_layer.state.pending" }, { "cardinality": "exactly_one", "type": "era.workflow.outputs" }], "provides": [{ "key": "next_state", "type": "era.migration.compaction.verify_layer.state" }, { "key": "done", "type": "era.migration.compaction.verify_layer.done" }], "source": { "completion": "immediate", "export": "Accept", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify_layer.ts" } }, [executeStaticNodeSync, Accept4], [[6, 3, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[45], null, [], __vfData[45]], [null, null, [], __vfData[5]], [null, null, [], __vfData[10]], [null, null, [], __vfData[14]], [null, null, [], __vfData[47]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "prepare", "invoke_loop", "skip_call", "finish", "end"], "inputs": [{ "key": "input0", "type": "era.command_compaction.segment.state", "required": true, "schema": __vfData[39] }], "outputs": [{ "type": "era.command_compaction.verified", "cardinality": "exactly_one", "as": "verified", "schema": __vfData[18] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[40], null]], false, null], [{ "id": "prepare", "definition_id": "era.migration.compaction.verify_layer.workflow.prepare", "requires": __vfData[41], "provides": [{ "key": "state", "type": "era.migration.compaction.verify_layer.state" }, { "key": "needs_call", "type": "era.migration.compaction.verify_layer.route" }], "source": { "completion": "immediate", "export": "Prepare", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify_layer.ts" } }, [executeStaticNodeSync, Prepare4], [[2, 1, __vfData[45], __vfData[21]], [3, 2, __vfData[45], __vfData[22]]], false, 8], [{ "id": "invoke_loop", "definition_id": "vibeflow.loop.while", "requires": __vfData[46], "provides": [{ "key": "final_state", "type": "era.migration.compaction.verify_layer.final" }] }, [executeStaticLoopSync, { "carry": [{ "as": "state", "from": "era.migration.compaction.verify_layer.state", "update": "next_state" }], "collect": [], "max_iterations": null, "outputs": [{ "as": "final_state", "from": "next_state" }], "stop_when": { "equals": true, "from": "done" } }], [[4, 3, __vfData[48], null]], false, null], [{ "id": "skip_call", "definition_id": "era.migration.compaction.verify_layer.workflow.skip_call", "requires": __vfData[46], "provides": [{ "key": "skipped_state", "type": "era.migration.compaction.verify_layer.final" }], "source": { "completion": "immediate", "export": "Skip", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify_layer.ts" } }, [executeStaticNodeSync, Skip4], [[4, 4, __vfData[48], null]], false, null], [{ "id": "finish", "definition_id": "era.migration.compaction.verify_layer.workflow.finish", "requires": [{ "cardinality": "exactly_one", "type": "era.migration.compaction.verify_layer.final" }], "provides": __vfData[38], "source": { "completion": "immediate", "export": "Finish", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/compute_verify_layer.ts" } }, [executeStaticNodeSync, Finish4], [[5, 5, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[40], null, [], __vfData[40]], [null, "any_active", [1], __vfData[45]], [null, "any_active", [2], __vfData[45]], [null, null, [], __vfData[48]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "parse", "initialize_segments", "segment_loop", "verify_layer", "render", "end"], "inputs": [{ "key": "compaction_request", "type": "era.command_compaction.request", "required": true, "schema": __vfData[18] }], "outputs": [{ "type": "era.command_compaction.response", "cardinality": "exactly_one", "as": "compactionResponse", "schema": __vfData[18] }], "max_steps": 7, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[1, 0, __vfData[49], null]], false, null], [{ "id": "parse", "definition_id": "era.command_compaction.parse_command_blocks", "requires": __vfData[50], "provides": [{ "key": "parsed", "type": "era.command_compaction.parsed" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/parse_command_blocks.ts" } }, [executeStaticNodeSync, run2], [[2, 1, __vfData[19], null]], false, null], [{ "id": "initialize_segments", "definition_id": "era.command_compaction.initialize_segments", "requires": __vfData[20], "provides": [{ "key": "segment_state", "type": "era.command_compaction.segment.state" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/initialize_segments.ts" } }, [executeStaticNodeSync, run3], [[3, 2, __vfData[40], null]], false, null], [{ "id": "segment_loop", "definition_id": "vibeflow.loop.while", "requires": __vfData[41], "provides": [{ "key": "segment_state_final", "type": "era.command_compaction.segment.state" }] }, [executeStaticLoopSync, { "carry": [{ "as": "segment_state", "from": "era.command_compaction.segment.state", "update": "segmentStateNext" }], "collect": [], "max_iterations": null, "outputs": [{ "as": "segment_state_final", "from": "segmentStateNext" }], "stop_when": { "equals": true, "from": "segmentDone" } }], [[4, 3, __vfData[40], null]], false, null], [{ "id": "verify_layer", "definition_id": "era.migration.compaction.verify_layer.workflow", "requires": __vfData[41], "provides": __vfData[38] }, [executeStaticNodesetSync, __vfData[44]], [[5, 4, __vfData[51], null]], false, null], [{ "id": "render", "definition_id": "era.command_compaction.render_compaction_result", "requires": [{ "cardinality": "exactly_one", "type": "era.command_compaction.verified" }], "provides": __vfData[52], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/render_compaction_result.ts" } }, [executeStaticNodeSync, run7], [[6, 5, [], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null]], [[[0], [[null, null, [], []], [__vfData[49], null, [], __vfData[49]], [null, null, [], __vfData[19]], [null, null, [], __vfData[40]], [null, null, [], __vfData[40]], [null, null, [], __vfData[51]], [null, null, [], []]]]]], [null, [[{ "id": "start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[7, 3, __vfData[49], null]], false, null], [{ "id": "compact_layer", "definition_id": "era.command_compaction.compact_layer", "requires": __vfData[50], "provides": __vfData[52] }, [executeStaticNodesetSync, [{ "alias": "compactionResponse", "provider": "compaction_response" }]], [[8, 5, null, null], [5, null, __vfData[53], null]], false, null], [{ "id": "end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null], [{ "id": "protocol_start", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [[4, 0, __vfData[54], null]], false, null], [{ "id": "decode_request", "definition_id": "era.workflow.decode_compaction", "requires": [{ "cardinality": "exactly_one", "type": "era.workflow.packet" }], "provides": [{ "key": "request", "type": "era.command_compaction.request" }, { "key": "entry_return", "type": "era.workflow.entry_return" }], "source": { "completion": "immediate", "export": "Decode", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, Decode], [[1, 1, __vfData[49], null], [8, null, __vfData[55], null]], false, null], [{ "id": "encode_response", "definition_id": "era.workflow.encode_compaction", "requires": [{ "cardinality": "exactly_one", "type": "era.command_compaction.response" }], "provides": [{ "key": "packet", "type": "era.workflow.packet" }], "source": { "completion": "immediate", "export": "Encode", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, Encode], [[6, 2, [], null]], false, null], [{ "id": "protocol_end", "definition_id": "era.command_compaction.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, run], [], true, null], [{ "id": "prepare_direct_request", "definition_id": "era.compaction.boundary.PrepareDirectRequest", "requires": __vfData[50], "provides": [{ "key": "prepared_request", "type": "era.command_compaction.request" }, { "key": "entry_return", "type": "era.workflow.entry_return" }], "source": { "completion": "immediate", "export": "PrepareDirectRequest", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, PrepareDirectRequest], [[1, 4, __vfData[49], null], [8, null, __vfData[55], null]], false, null], [{ "id": "select_entry_return", "definition_id": "era.compaction.boundary.SelectEntryReturn", "requires": [{ "cardinality": "exactly_one", "type": "era.workflow.entry_return" }], "provides": [{ "key": "return_route", "type": "era.workflow.entry_return" }], "source": { "completion": "immediate", "export": "SelectEntryReturn", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/compaction/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, SelectEntryReturn], [[2, 6, null, { "key": "return_route", "literal": "direct", "operator": "==" }], [5, 7, null, { "key": "return_route", "literal": "protocol", "operator": "==" }]], false, 8]], [[[0], { "0": [null, null, [], []], "1": [null, null, [], __vfData[49]], "2": [null, "any_active", [6], []], "5": [null, "any_active", [7], __vfData[53]], "6": [null, null, [], []], "7": [__vfData[49], null, [], __vfData[49]], "8": [null, null, [], __vfData[55]] }], [[3], { "1": [null, null, [], __vfData[49]], "2": [null, "any_active", [6], []], "3": [null, null, [], []], "4": [__vfData[54], null, [], __vfData[54]], "5": [null, "any_active", [7], __vfData[53]], "6": [null, null, [], []], "8": [null, null, [], __vfData[55]] }]]]], calls: [[0, "era.command_compaction.compact_layer.segment_loop.execute.invoke_loop", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {}, "workflow": { "entry": "protocol", "path": "configs/era.expression.jsonc", "root": "era-expression" } }, { "_global": {} }, { "_global": {} }, { "_global": {} }], {}], [1, "era.command_compaction.compact_layer.segment_loop.execute", [{ "_global": {} }, { "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "2": 0 }], [2, "era.command_compaction.compact_layer.segment_loop.rewrite.invoke_loop", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {}, "workflow": { "entry": "protocol", "path": "configs/era.expression.jsonc", "root": "era-expression" } }, { "_global": {} }, { "_global": {} }, { "_global": {} }], {}], [3, "era.command_compaction.compact_layer.segment_loop.rewrite", [{ "_global": {} }, { "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "2": 2 }], [4, "era.command_compaction.compact_layer.segment_loop.verify.invoke_loop", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {}, "workflow": { "entry": "protocol", "path": "configs/era.expression.jsonc", "root": "era-expression" } }, { "_global": {} }, { "_global": {} }, { "_global": {} }], {}], [5, "era.command_compaction.compact_layer.segment_loop.verify", [{ "_global": {} }, { "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "2": 4 }], [6, "era.command_compaction.compact_layer.segment_loop", [{ "_global": {} }, { "_global": {} }, {}, { "_global": {} }, {}, {}, { "_global": {} }, { "_global": {} }], { "2": 1, "4": 3, "5": 5 }], [7, "era.command_compaction.compact_layer.verify_layer.invoke_loop", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {}, "workflow": { "entry": "protocol", "path": "configs/era.expression.jsonc", "root": "era-expression" } }, { "_global": {} }, { "_global": {} }, { "_global": {} }], {}], [8, "era.command_compaction.compact_layer.verify_layer", [{ "_global": {} }, { "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "2": 7 }], [9, "era.command_compaction.compact_layer", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, {}, {}, { "_global": {} }, { "_global": {} }], { "3": 6, "4": 8 }], [10, "era.command_compaction", [{ "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "1": 9 }]] };
var __vfEntryInvoke_0 = createStaticWorkflowSync({ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "compact_layer", "end", "encode_response", "protocol_end", "prepare_direct_request", "select_entry_return"], "inputs": [{ "key": "compaction_request", "type": "era.command_compaction.request", "required": true, "schema": __vfData[18] }], "outputs": [{ "type": "era.command_compaction.response", "cardinality": "exactly_one", "as": "compactionResponse", "schema": __vfData[18] }], "max_steps": 9, "entry_mode": "sync", "workflow_id": "era.command_compaction" }, __vfSchemaCatalog, __vfRuntimePluginDescriptors, __vfRuntimePluginFactories, (inputs, root, path) => executeStaticBlockSync(__vfProgram, 10, inputs, root, path, 0));
var __vfEntryInvoke_1 = createStaticWorkflowSync({ "abi_version": "vibeflow.workflow.v12", "node_order": ["compact_layer", "end", "protocol_start", "decode_request", "encode_response", "protocol_end", "select_entry_return"], "inputs": [{ "key": "wire_request", "type": "era.workflow.packet", "required": true, "schema": __vfData[56] }], "outputs": [{ "type": "era.workflow.packet", "cardinality": "exactly_one", "as": "wireResponse", "schema": __vfData[56] }], "max_steps": 9, "entry_mode": "sync", "workflow_id": "era.command_compaction" }, __vfSchemaCatalog, __vfRuntimePluginDescriptors, __vfRuntimePluginFactories, (inputs, root, path) => executeStaticBlockSync(__vfProgram, 10, inputs, root, path, 1));
var __vfEntryInvocations = /* @__PURE__ */ new Map([["main", __vfEntryInvoke_0], ["protocol", __vfEntryInvoke_1]]);
function __vfInvokeWorkflow(inputs, options = {}) {
  const invoke = __vfEntryInvocations.get(options.entry ?? "main");
  if (!invoke) throw new Error("select a workflow entry: " + [...__vfEntryInvocations.keys()].join(", "));
  return invoke(inputs, options);
}
function runWorkflow(inputs, options) {
  return __vfObserveSync(__vfInvokeWorkflow, inputs, options);
}
var workflowDescriptor = deepFreeze({ "workflow": { "root": "era-command-compaction", "path": "configs/era.command_compaction.jsonc" }, "entry_mode": "sync", "calls": [{ "operation": "invoke_sync", "workflow": { "root": "era-expression", "path": "configs/era.expression.jsonc", "entry": "protocol" } }, { "operation": "invoke_sync", "workflow": { "root": "era-expression", "path": "configs/era.expression.jsonc", "entry": "protocol" } }, { "operation": "invoke_sync", "workflow": { "root": "era-expression", "path": "configs/era.expression.jsonc", "entry": "protocol" } }, { "operation": "invoke_sync", "workflow": { "root": "era-expression", "path": "configs/era.expression.jsonc", "entry": "protocol" } }], "entries": { "main": { "inputs": [{ "key": "compaction_request", "type": "era.command_compaction.request", "required": true, "display_name": "\u539F\u6D88\u606F\u3001\u53D8\u91CF\u8D77\u70B9\u548C\u6307\u4EE4\u538B\u7F29\u8981\u6C42" }], "outputs": [{ "type": "era.command_compaction.response", "cardinality": "exactly_one", "as": "compactionResponse", "display_name": "\u786E\u8BA4\u540E\u7684\u6D88\u606F\u6587\u5B57\u53CA\u6307\u4EE4\u538B\u7F29\u7ED3\u8BBA" }] }, "protocol": { "inputs": [{ "key": "wire_request", "type": "era.workflow.packet", "required": true, "display_name": "\u4FDD\u7559\u539F\u503C\u7684\u8DE8\u6D41\u7A0B\u8BF7\u6C42" }], "outputs": [{ "type": "era.workflow.packet", "cardinality": "exactly_one", "as": "wireResponse", "display_name": "\u4FDD\u7559\u539F\u503C\u7684\u8DE8\u6D41\u7A0B\u7ED3\u679C" }] } }, "default_entry": "main", "inputs": [{ "key": "compaction_request", "type": "era.command_compaction.request", "required": true, "display_name": "\u539F\u6D88\u606F\u3001\u53D8\u91CF\u8D77\u70B9\u548C\u6307\u4EE4\u538B\u7F29\u8981\u6C42" }], "outputs": [{ "type": "era.command_compaction.response", "cardinality": "exactly_one", "as": "compactionResponse", "display_name": "\u786E\u8BA4\u540E\u7684\u6D88\u606F\u6587\u5B57\u53CA\u6307\u4EE4\u538B\u7F29\u7ED3\u8BBA" }] });
export {
  VIBEFLOW_PLUGIN_ABI,
  VIBEFLOW_WORKFLOW_ABI,
  VibeFlowWorkflowError,
  runWorkflow,
  workflowDescriptor
};
