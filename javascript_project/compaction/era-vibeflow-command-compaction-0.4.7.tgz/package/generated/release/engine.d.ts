import type { CommandCompactionResponse } from "./command_compaction_interpreter.ts";
export type {CommandCompactionResponse} from "./command_compaction_interpreter.ts";

export declare function compactCommandLayer(input: unknown): CommandCompactionResponse;
