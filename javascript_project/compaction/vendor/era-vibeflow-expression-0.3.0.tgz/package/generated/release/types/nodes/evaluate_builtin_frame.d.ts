export declare function evaluateBuiltinFrameNode(inputs: NodeInputs): any;
export { evaluateBuiltinFrameNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
