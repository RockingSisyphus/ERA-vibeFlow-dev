export declare function resolveValueFrameNode(inputs: NodeInputs): any;
export { resolveValueFrameNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
