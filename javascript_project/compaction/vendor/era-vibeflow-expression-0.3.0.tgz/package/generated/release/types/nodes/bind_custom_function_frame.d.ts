export declare function bindCustomFunctionFrameNode(inputs: NodeInputs): any;
export { bindCustomFunctionFrameNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
