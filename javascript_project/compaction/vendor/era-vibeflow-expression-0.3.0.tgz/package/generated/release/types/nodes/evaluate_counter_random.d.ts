export declare function evaluateCounterRandomNode(inputs: NodeInputs): any;
export { evaluateCounterRandomNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
