import { NormalizedRequest, CompiledLibrary, ParsedOperation, SequenceState, Ast, AstFrameState, JsonValue, Diagnostic } from "./expression_types.ts";
export declare function initializeSequenceState(request: NormalizedRequest, compiled: CompiledLibrary, operations: readonly ParsedOperation[], snapshotCompiled?: CompiledLibrary): SequenceState;
export declare function refValue(ast: Extract<Ast, {
    kind: "ref";
}>, state: SequenceState, env: Readonly<Record<string, number>>, allowState: boolean): number;
export declare function popValues(values: readonly number[], count: number): {
    readonly values: readonly number[];
    readonly args: readonly number[];
};
export declare function inlineCustomAst(ast: Ast, bindings: Readonly<Record<string, Ast>>, library: CompiledLibrary): Ast;
export declare function mathText(ast: Ast): string;
export declare function evaluateFunctionAt(library: CompiledLibrary, name: string, input: number): number;
export declare function calculateCalculus(name: "derivative" | "integral", target: string, args: readonly number[], library: CompiledLibrary): number;
export declare function createAstFrameState(sequence: SequenceState, ast: Ast, env?: Readonly<Record<string, number>>, allowState?: boolean, library?: CompiledLibrary): AstFrameState;
export declare function complete(state: Omit<AstFrameState, "done" | "result">): AstFrameState;
export declare function astFrameRoute(state: AstFrameState): "value" | "operator" | "builtin" | "random" | "custom" | "return";
export declare function advanceAstFrame(state: AstFrameState, expected?: ReturnType<typeof astFrameRoute>): AstFrameState;
/** Standalone operation API reuses the same evaluator and commit policy as Nodes. */
export declare function runOperationStep(state: SequenceState): ReturnType<typeof commitOperationResult>;
export declare function commitOperationResult(state: SequenceState, value: number | null, evaluationDiagnostics: readonly Diagnostic[]): {
    readonly sequenceStateNext: SequenceState;
    readonly sequenceDone: boolean;
    readonly operationExecutionResult: {
        readonly finalState: JsonValue;
        readonly diagnostics: readonly Diagnostic[];
        readonly randomDrawsConsumed: number;
    };
};
/** Evaluate one initialized AST; operation ordering and state commits belong to the workflow. */
export declare function evaluateAst(state: AstFrameState): {
    readonly value: number | null;
    readonly diagnostics: readonly Diagnostic[];
};
