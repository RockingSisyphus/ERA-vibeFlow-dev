export declare function publishFrameTransitionNode(inputs: NodeInputs): any;
export { publishFrameTransitionNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
