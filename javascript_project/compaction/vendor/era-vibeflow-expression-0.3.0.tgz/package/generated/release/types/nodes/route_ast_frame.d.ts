export declare function routeAstFrameNode(inputs: NodeInputs): any;
export { routeAstFrameNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
