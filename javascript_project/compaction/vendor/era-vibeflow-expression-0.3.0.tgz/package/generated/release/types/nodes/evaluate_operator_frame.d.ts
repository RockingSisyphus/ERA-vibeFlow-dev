export declare function evaluateOperatorFrameNode(inputs: NodeInputs): any;
export { evaluateOperatorFrameNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
