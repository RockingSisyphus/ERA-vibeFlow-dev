export declare function returnChildValueNode(inputs: NodeInputs): any;
export { returnChildValueNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
