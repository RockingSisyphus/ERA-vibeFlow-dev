export declare function inspectAstFrameNode(inputs: NodeInputs): any;
export { inspectAstFrameNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
