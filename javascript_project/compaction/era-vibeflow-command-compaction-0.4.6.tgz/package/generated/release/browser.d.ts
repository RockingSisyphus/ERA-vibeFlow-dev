export type WorkflowTraceMode = "off" | "boundary" | "full";

export interface VibeFlowAbortSignal {
  readonly aborted: boolean;
  readonly reason: unknown;
  readonly onabort: ((event: any) => unknown) | null;
  throwIfAborted(): void;
  addEventListener(type: string, listener: any, options?: any): void;
  removeEventListener(type: string, listener: any, options?: any): void;
  dispatchEvent(event: any): boolean;
}

export interface WorkflowRunStatus {
  readonly state: "starting" | "running" | "stopping" | "succeeded" | "failed";
  readonly error: string | null;
  readonly updated_at: string;
  readonly info?: readonly Readonly<Record<string, unknown>>[];
}

export interface WorkflowTraceEvent {
  readonly kind: string;
  readonly workflowId: string;
  readonly nodeId?: string;
  readonly nodePath?: string;
  readonly path?: readonly string[];
  readonly [key: string]: unknown;
}

export class VibeFlowWorkflowError extends Error {
  readonly code: string;
  readonly workflowId: string;
  readonly nodePath: string;
  readonly blockPath: string;
}

export interface WorkflowInputs {
  readonly "compaction_request": { readonly [key: string]: unknown };
}

export interface WorkflowOutputs {
  readonly "compactionResponse": { readonly [key: string]: unknown };
}

export interface WorkflowCapabilities {
}

export interface WorkflowRunOptions {
  readonly workflowInstanceId?: string;
  readonly entry?: string;
  readonly signal?: VibeFlowAbortSignal;
  readonly trace?: WorkflowTraceMode;
  readonly onTrace?: (event: WorkflowTraceEvent) => void;
  readonly capabilities?: WorkflowCapabilities;
  readonly statusIntervalMs?: number;
  readonly statusFile?: string;
  readonly runDir?: string;
  readonly onStatus?: (status: WorkflowRunStatus) => void;
}

export const VIBEFLOW_WORKFLOW_ABI: "vibeflow.workflow.v10";
export const VIBEFLOW_PLUGIN_ABI: "vibeflow.plugin.v4";
export function runWorkflow(inputs: WorkflowInputs, options?: WorkflowRunOptions): WorkflowOutputs;
