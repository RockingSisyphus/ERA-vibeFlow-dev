import {defineBaseLib} from "@vibeflow/plugin";

export const era_expression_types = defineBaseLib({
  "id": "era.expression.types",
  "display_name": "共享类型",
  "description": "共享类型的独立算法与类型，不依赖工作流端口或公共完整求值入口。",
  "version": "1.0.0",
  "implementations": [
    {
      "language": "typescript",
      "targets": [
        "browser",
        "node"
      ],
      "source": {
        "kind": "file",
        "ref": "base_lib/expression_types.ts"
      }
    }
  ],
  "dependencies": [],
  "external_packages": [],
  "rulesets": [
    "vibeflow.base_lib"
  ]
});

