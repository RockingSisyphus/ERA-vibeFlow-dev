export declare const plugin: Readonly<{
    id: string;
    display_name: string;
    description: string;
    declaration_rulesets: string[];
    implementation_files: string[];
    resources: import("@vibeflow/plugin").Resource[];
} & {
    abi: "vibeflow.plugin.v5";
}>;
