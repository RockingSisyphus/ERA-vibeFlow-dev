export declare const contract_1_0: import("@vibeflow/plugin").Resource;
