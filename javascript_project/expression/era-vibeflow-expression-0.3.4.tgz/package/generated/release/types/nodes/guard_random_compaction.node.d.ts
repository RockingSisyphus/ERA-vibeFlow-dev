export declare const era_expression_guard_random_compaction: any;
