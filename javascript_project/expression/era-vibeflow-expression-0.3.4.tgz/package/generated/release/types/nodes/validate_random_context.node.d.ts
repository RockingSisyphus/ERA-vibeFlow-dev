export declare const era_expression_validate_random_context: any;
