export declare const era_expression_validate_function_purity: any;
