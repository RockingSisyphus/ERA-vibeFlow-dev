export declare const era_expression_normalize_compaction: any;
