export declare const era_expression_initialize_ast_frames: any;
