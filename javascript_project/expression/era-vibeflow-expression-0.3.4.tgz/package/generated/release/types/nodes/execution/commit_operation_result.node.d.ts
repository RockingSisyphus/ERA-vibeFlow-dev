export declare const era_expression_commit_operation_result: any;
