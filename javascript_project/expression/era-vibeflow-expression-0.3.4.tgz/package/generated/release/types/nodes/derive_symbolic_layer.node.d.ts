export declare const era_expression_derive_symbolic_layer: any;
