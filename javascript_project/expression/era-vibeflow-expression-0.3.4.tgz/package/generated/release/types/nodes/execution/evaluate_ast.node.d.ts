export declare const era_expression_evaluate_ast: any;
