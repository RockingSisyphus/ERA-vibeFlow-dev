export declare const era_expression_parse_operations: any;
