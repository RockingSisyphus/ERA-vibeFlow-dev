export declare const era_expression_select_next_operation: any;
