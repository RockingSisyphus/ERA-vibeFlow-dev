export declare const era_expression_initialize_sequence_state: any;
