export declare const era_expression_terminal: any;
