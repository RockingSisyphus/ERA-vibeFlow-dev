export declare const era_expression_operation: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
