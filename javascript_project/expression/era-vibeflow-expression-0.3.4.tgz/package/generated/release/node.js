// ../../reports/.expression-package-KOCrKD/node/workflow.js
import * as __vfFs from "node:fs";
import * as __vfPath from "node:path";
import { randomUUID as __vfUuid } from "node:crypto";
import { AsyncLocalStorage as __vfAsyncLocalStorage } from "node:async_hooks";
import { Worker as __vfStatusWorker } from "node:worker_threads";
import gamma from "@stdlib/math-base-special-gamma";
import { derivative, evaluate as mathEvaluate } from "mathjs/number";
function terminalNode() {
  return {};
}
function isBuiltin(name) {
  return [
    "sin",
    "cos",
    "tan",
    "asin",
    "acos",
    "atan",
    "sinh",
    "cosh",
    "tanh",
    "asinh",
    "acosh",
    "atanh",
    "exp",
    "log",
    "ln",
    "sqrt",
    "abs",
    "floor",
    "ceil",
    "round",
    "trunc",
    "min",
    "max",
    "clamp",
    "pow",
    "mod",
    "factorial",
    "gamma",
    "derivative",
    "integral",
    "random"
  ].includes(name);
}
function diagnostic(code, message, extra = {}) {
  return { code, message, ...extra };
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function clone(value) {
  return structuredClone(value);
}
function finite(value, code, message) {
  if (!Number.isFinite(value))
    throw new ExpressionFailure(diagnostic(code, message));
  return Object.is(value, -0) ? 0 : value;
}
var ExpressionFailure = class extends Error {
  constructor(detail) {
    super(detail.message);
    this.detail = detail;
  }
  detail;
};
function getPath(root, path) {
  let value = root;
  for (const segment of path) {
    if (!isRecord(value) || !(segment in value)) return void 0;
    value = value[segment];
  }
  return value;
}
function setPath(root, path, value) {
  if (!isRecord(root))
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_STATE_ROOT", "\u53D8\u91CF\u72B6\u6001\u6839\u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const next = clone(root);
  let cursor = next;
  for (const segment of path.slice(0, -1)) {
    const child = cursor[segment];
    if (!isRecord(child)) cursor[segment] = {};
    cursor = cursor[segment];
  }
  cursor[path[path.length - 1]] = value;
  return next;
}
var UINT64_MASK = (1n << 64n) - 1n;
var FNV64_OFFSET = 0xcbf29ce484222325n;
var FNV64_PRIME = 0x100000001b3n;
var SPLITMIX_GAMMA = 0x9e3779b97f4a7c15n;
var SPLITMIX_MUL_1 = 0xbf58476d1ce4e5b9n;
var SPLITMIX_MUL_2 = 0x94d049bb133111ebn;
var TWO_POW_53 = 9007199254740992;
function fnv1a64(bytes) {
  return bytes.reduce(
    (hash, byte) => (hash ^ BigInt(byte)) * FNV64_PRIME & UINT64_MASK,
    FNV64_OFFSET
  );
}
function randomSeedHash(seed) {
  if (typeof seed === "string") return fnv1a64(new TextEncoder().encode(seed));
  const normalized = Object.is(seed, -0) ? 0 : seed;
  const buffer = new ArrayBuffer(8);
  new DataView(buffer).setFloat64(0, normalized, true);
  return fnv1a64(new Uint8Array(buffer));
}
function deterministicRandomUnit(seed, draw) {
  if (typeof seed === "number" && !Number.isFinite(seed) || !Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 seed \u5FC5\u987B\u6709\u9650\uFF0Cdraw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  const mixed0 = randomSeedHash(seed) + BigInt(draw) + SPLITMIX_GAMMA & UINT64_MASK;
  const mixed1 = (mixed0 ^ mixed0 >> 30n) * SPLITMIX_MUL_1 & UINT64_MASK;
  const mixed2 = (mixed1 ^ mixed1 >> 27n) * SPLITMIX_MUL_2 & UINT64_MASK;
  const mixed3 = mixed2 ^ mixed2 >> 31n;
  return Number((mixed3 & UINT64_MASK) >> 11n) / TWO_POW_53;
}
function calculateRandom(args, context, automaticDraw) {
  if (args.length > 2)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_BUILTIN_ARITY",
        "random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002"
      )
    );
  if (args.length < 2 && !context)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_CONTEXT_REQUIRED",
        "random() \u4E0E random(seed) \u9700\u8981\u6D88\u606F\u968F\u673A\u4E0A\u4E0B\u6587\u3002"
      )
    );
  const seed = args.length === 0 ? context.sourceKey : args[0];
  const draw = args.length === 2 ? args[1] : automaticDraw;
  if (!Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 draw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  return deterministicRandomUnit(seed, draw);
}
function calculateBuiltin(name, args) {
  const unary = {
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    asin: Math.asin,
    acos: Math.acos,
    atan: Math.atan,
    sinh: Math.sinh,
    cosh: Math.cosh,
    tanh: Math.tanh,
    asinh: Math.asinh,
    acosh: Math.acosh,
    atanh: Math.atanh,
    exp: Math.exp,
    log: Math.log,
    ln: Math.log,
    sqrt: Math.sqrt,
    abs: Math.abs,
    floor: Math.floor,
    ceil: Math.ceil,
    round: Math.round,
    trunc: Math.trunc,
    gamma
  };
  if (name in unary) {
    if (args.length !== 1)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      unary[name](args[0]),
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  if (name === "factorial") {
    if (args.length !== 1 || !Number.isSafeInteger(args[0]) || args[0] < 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FACTORIAL_DOMAIN",
          "factorial \u53EA\u63A5\u53D7\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    let result = 1;
    for (let value = 2; value <= args[0]; value += 1)
      result = finite(
        result * value,
        "ERA_EXPR_FACTORIAL_NON_FINITE",
        "factorial \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    return result;
  }
  if (name === "min" || name === "max") {
    if (args.length === 0)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return name === "min" ? Math.min(...args) : Math.max(...args);
  }
  if (name === "clamp") {
    if (args.length !== 3)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", "clamp \u9700\u8981\u4E09\u4E2A\u53C2\u6570\u3002")
      );
    return Math.min(Math.max(args[0], args[1]), args[2]);
  }
  if (name === "pow" || name === "mod") {
    if (args.length !== 2)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u9700\u8981\u4E24\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      name === "pow" ? args[0] ** args[1] : args[0] % args[1],
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  throw new ExpressionFailure(
    diagnostic("ERA_EXPR_BUILTIN_UNKNOWN", `\u672A\u77E5\u5185\u5EFA\u51FD\u6570 ${name}\u3002`)
  );
}
function lex(source) {
  const tokens = [];
  let cursor = 0;
  while (cursor < source.length) {
    const char = source[cursor];
    if (/\s/u.test(char)) {
      cursor += 1;
      continue;
    }
    if (/[0-9.]/u.test(char) && (/[0-9]/u.test(char) || /[0-9]/u.test(source[cursor + 1] ?? ""))) {
      const match = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/u.exec(
        source.slice(cursor)
      );
      if (!match)
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_LEX_INVALID_NUMBER", "\u65E0\u6548\u6570\u5B57\u3002", {
            position: cursor
          })
        );
      tokens.push({ kind: "number", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if (/[A-Za-z_]/u.test(char)) {
      const match = /^[A-Za-z_][A-Za-z0-9_]*/u.exec(source.slice(cursor));
      tokens.push({ kind: "identifier", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if ("+-*/%^@".includes(char)) {
      tokens.push({ kind: "operator", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    if ("(),.".includes(char)) {
      tokens.push({ kind: "punctuation", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_LEX_INVALID_CHARACTER",
        `\u4E0D\u652F\u6301\u5B57\u7B26 ${JSON.stringify(char)}\u3002`,
        { position: cursor }
      )
    );
  }
  tokens.push({ kind: "eof", text: "", position: cursor });
  return tokens;
}
var Parser = class {
  constructor(tokens, allowSnapshot) {
    this.tokens = tokens;
    this.allowSnapshot = allowSnapshot;
  }
  tokens;
  allowSnapshot;
  index = 0;
  current() {
    return this.tokens[this.index];
  }
  take() {
    return this.tokens[this.index++];
  }
  matches(text) {
    return this.current().text === text;
  }
  expect(text) {
    if (!this.matches(text))
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_EXPECTED", `\u6B64\u5904\u5E94\u4E3A ${text}\u3002`, {
          position: this.current().position
        })
      );
    return this.take();
  }
  parse() {
    const ast = this.additive();
    if (this.current().kind !== "eof")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_TRAILING", "\u8868\u8FBE\u5F0F\u672B\u5C3E\u5B58\u5728\u672A\u89E3\u6790\u5185\u5BB9\u3002", {
          position: this.current().position
        })
      );
    return ast;
  }
  additive() {
    let left = this.multiplicative();
    while (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.multiplicative() };
    }
    return left;
  }
  multiplicative() {
    let left = this.unary();
    while (this.matches("*") || this.matches("/") || this.matches("%")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.unary() };
    }
    return left;
  }
  unary() {
    if (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      return { kind: "unary", op, value: this.unary() };
    }
    return this.power();
  }
  power() {
    const left = this.primary();
    if (this.matches("^")) {
      this.take();
      return { kind: "binary", op: "^", left, right: this.unary() };
    }
    return left;
  }
  primary() {
    if (this.matches("(")) {
      this.take();
      const ast = this.additive();
      this.expect(")");
      return ast;
    }
    if (this.current().kind === "number") {
      const token = this.take();
      return {
        kind: "literal",
        value: finite(
          Number(token.text),
          "ERA_EXPR_NUMBER_NON_FINITE",
          "\u6570\u5B57\u5FC5\u987B\u6709\u9650\u3002"
        )
      };
    }
    let snapshot = false;
    if (this.matches("@")) {
      if (!this.allowSnapshot)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_SNAPSHOT_FORBIDDEN",
            "\u7528\u6237\u539F\u59CB\u8868\u8FBE\u5F0F\u4E0D\u80FD\u4F7F\u7528 @path\u3002",
            { position: this.current().position }
          )
        );
      this.take();
      snapshot = true;
    }
    if (this.current().kind !== "identifier")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_PRIMARY", "\u6B64\u5904\u5E94\u4E3A\u6570\u5B57\u3001\u53D8\u91CF\u6216\u51FD\u6570\u8C03\u7528\u3002", {
          position: this.current().position
        })
      );
    const first = this.take();
    if (this.matches("(")) {
      this.take();
      const args = [];
      if (!this.matches(")")) {
        do {
          args.push(this.additive());
          if (!this.matches(",")) break;
          this.take();
        } while (true);
      }
      this.expect(")");
      return { kind: "call", name: first.text, args, snapshot };
    }
    const path = [first.text];
    while (this.matches(".")) {
      this.take();
      const segment = this.current();
      if (segment.kind !== "identifier")
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_PATH_SEGMENT", "\u8DEF\u5F84\u70B9\u53F7\u540E\u5E94\u4E3A\u6807\u8BC6\u7B26\u3002", {
            position: segment.position
          })
        );
      path.push(this.take().text);
    }
    return { kind: "ref", path, snapshot };
  }
};
function parseExpression(source, allowSnapshot = false) {
  try {
    return {
      ast: new Parser(lex(source), allowSnapshot).parse(),
      diagnostics: []
    };
  } catch (error) {
    return {
      ast: null,
      diagnostics: [
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PARSE_FAILED", String(error))
      ]
    };
  }
}
function validatePath(value) {
  const parts = value.split(".");
  if (parts.length === 0 || parts.some((part) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(part)))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_PATH_INVALID",
        `\u65E0\u6548\u53D8\u91CF\u8DEF\u5F84 ${JSON.stringify(value)}\u3002`,
        { path: value }
      )
    );
  return parts;
}
function normaliseRequest(input) {
  const diagnostics = [];
  const request = isRecord(input) ? input : {};
  const initialState = request.initialState;
  if (!isRecord(initialState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_INITIAL_STATE_INVALID",
        "initialState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const snapshotState = request.snapshotState === void 0 ? null : isRecord(request.snapshotState) ? clone(request.snapshotState) : null;
  if (request.snapshotState !== void 0 && !isRecord(request.snapshotState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_STATE_INVALID",
        "snapshotState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const functionLibrary = isRecord(request.functionLibrary) ? request.functionLibrary : {};
  if (request.functionLibrary !== void 0 && !isRecord(request.functionLibrary))
    diagnostics.push(
      diagnostic("ERA_EXPR_LIBRARY_INVALID", "functionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const snapshotFunctionLibrary = request.snapshotFunctionLibrary === void 0 ? null : isRecord(request.snapshotFunctionLibrary) ? request.snapshotFunctionLibrary : null;
  if (request.snapshotFunctionLibrary !== void 0 && !isRecord(request.snapshotFunctionLibrary))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_LIBRARY_INVALID",
        "snapshotFunctionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002"
      )
    );
  let randomContext = null;
  if (request.randomContext !== void 0) {
    if (!isRecord(request.randomContext) || typeof request.randomContext.sourceKey !== "string" || request.randomContext.sourceKey.length === 0 || !Number.isSafeInteger(request.randomContext.drawOffset) || request.randomContext.drawOffset < 0)
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_RANDOM_CONTEXT_INVALID",
          "randomContext \u9700\u8981\u975E\u7A7A sourceKey \u4E0E\u975E\u8D1F\u5B89\u5168\u6574\u6570 drawOffset\u3002"
        )
      );
    else
      randomContext = {
        sourceKey: request.randomContext.sourceKey,
        drawOffset: request.randomContext.drawOffset
      };
  }
  const rawOperations = Array.isArray(request.operations) ? request.operations : [];
  if (!Array.isArray(request.operations))
    diagnostics.push(
      diagnostic("ERA_EXPR_OPERATIONS_INVALID", "operations \u5FC5\u987B\u662F\u6709\u5E8F\u6570\u7EC4\u3002")
    );
  const operations = [];
  for (const [index, operation] of rawOperations.entries()) {
    if (!isRecord(operation) || typeof operation.path !== "string" || typeof operation.expr !== "string") {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_OPERATION_SHAPE",
          `operations[${index}] \u5FC5\u987B\u6709 path \u548C expr \u5B57\u7B26\u4E32\u3002`
        )
      );
      continue;
    }
    operations.push({ path: operation.path, expr: operation.expr });
  }
  return {
    initialState: isRecord(initialState) ? clone(initialState) : {},
    snapshotState,
    functionLibrary,
    snapshotFunctionLibrary,
    allowSnapshots: request.allowSnapshots === true,
    randomContext,
    operations,
    diagnostics,
    valid: diagnostics.length === 0
  };
}
function walk(ast, visitor) {
  visitor(ast);
  if (ast.kind === "unary") walk(ast.value, visitor);
  if (ast.kind === "binary") {
    walk(ast.left, visitor);
    walk(ast.right, visitor);
  }
  if (ast.kind === "call") for (const arg of ast.args) walk(arg, visitor);
}
function parseOperations(request) {
  return request.operations.map((operation, index) => {
    const diagnostics = [];
    let path = [];
    try {
      path = validatePath(operation.path);
    } catch (error) {
      diagnostics.push(
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PATH_INVALID", String(error))
      );
    }
    const parsed = diagnostics.length === 0 ? parseExpression(operation.expr, request.allowSnapshots) : { ast: null, diagnostics: [] };
    return {
      index,
      path,
      expr: operation.expr,
      ast: parsed.ast,
      diagnostics: [...diagnostics, ...parsed.diagnostics]
    };
  });
}
function validateRequestNode(inputs) {
  return {
    normalized_expression_request: normaliseRequest(
      nodeInput(inputs, "era.expression.request")
    )
  };
}
function nodeInput(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function validateRandomContextNode(inputs) {
  return {
    validated_random_request: nodeInput2(
      inputs,
      "era.expression.request.normalized"
    )
  };
}
function nodeInput2(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function parseFunctionDefinitions(request) {
  const parsed = [];
  for (const [name, raw] of Object.entries(request.functionLibrary)) {
    const definition = isRecord(raw) ? { params: raw.params, expr: raw.expr } : raw;
    const diagnostics = [];
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/u.test(name))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME",
          `\u51FD\u6570\u540D ${JSON.stringify(name)} \u65E0\u6548\u3002`,
          { path: name }
        )
      );
    if (isBuiltin(name))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME_CONFLICT",
          `\u51FD\u6570\u540D ${name} \u4E0E\u5185\u5EFA\u51FD\u6570\u51B2\u7A81\u3002`,
          { path: name }
        )
      );
    if (!isRecord(definition) || !Array.isArray(definition.params) || typeof definition.expr !== "string")
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_SHAPE",
          `\u51FD\u6570 ${name} \u5E94\u5305\u542B params \u6570\u7EC4\u4E0E expr \u5B57\u7B26\u4E32\u3002`,
          { path: name }
        )
      );
    const params = isRecord(definition) && Array.isArray(definition.params) ? definition.params.filter(
      (item) => typeof item === "string"
    ) : [];
    if (params.length !== new Set(params).size || params.some((param) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(param)))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_PARAMS",
          `\u51FD\u6570 ${name} \u7684\u5F62\u53C2\u5FC5\u987B\u662F\u4E92\u5F02\u6807\u8BC6\u7B26\u3002`,
          { path: name }
        )
      );
    const expr = isRecord(definition) && typeof definition.expr === "string" ? definition.expr : "";
    const result = diagnostics.length === 0 ? parseExpression(expr, false) : { ast: null, diagnostics: [] };
    parsed.push({
      name,
      params,
      expr,
      ast: result.ast,
      diagnostics: [...diagnostics, ...result.diagnostics]
    });
  }
  return parsed;
}
function extractFunctionDependencies(parsed) {
  const names = new Set(parsed.map((item) => item.name));
  const result = {};
  for (const functionDef of parsed) {
    const dependencies = /* @__PURE__ */ new Set();
    if (functionDef.ast)
      walk(functionDef.ast, (item) => {
        if (item.kind === "call" && names.has(item.name))
          dependencies.add(item.name);
      });
    result[functionDef.name] = [...dependencies].sort();
  }
  return result;
}
function validateFunctionPurity(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const diagnostics = [];
  for (const functionDef of parsed) {
    diagnostics.push(...functionDef.diagnostics);
    if (!functionDef.ast) continue;
    const params = new Set(functionDef.params);
    walk(functionDef.ast, (item) => {
      if (item.kind === "ref" && (!params.has(item.path[0]) || item.path.length !== 1 || item.snapshot))
        diagnostics.push(
          diagnostic(
            "ERA_EXPR_FUNCTION_IMPURE",
            `\u51FD\u6570 ${functionDef.name} \u53EA\u80FD\u8BFB\u53D6\u81EA\u5DF1\u7684\u5F62\u53C2\u3002`,
            { path: functionDef.name }
          )
        );
      if (item.kind === "call") {
        if (item.name === "random" && item.args.length > 2)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_BUILTIN_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u4E2D\u7684 random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002`,
              { path: functionDef.name }
            )
          );
        if (!isBuiltin(item.name) && !functions.has(item.name))
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528\u4E86\u672A\u77E5\u51FD\u6570 ${item.name}\u3002`,
              { path: functionDef.name }
            )
          );
        const target = functions.get(item.name);
        if (target && item.args.length !== target.params.length)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528 ${item.name} \u7684\u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
              { path: functionDef.name }
            )
          );
      }
    });
  }
  return diagnostics;
}
function rejectRecursiveFunctions(dependencies) {
  const visited = /* @__PURE__ */ new Set();
  const visiting = [];
  const diagnostics = [];
  const visit = (name) => {
    const existing = visiting.indexOf(name);
    if (existing >= 0) {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_RECURSION",
          `\u51FD\u6570\u9012\u5F52\u4E0D\u88AB\u652F\u6301\uFF1A${[...visiting.slice(existing), name].join(" \u2192 ")}\u3002`,
          { path: name }
        )
      );
      return;
    }
    if (visited.has(name)) return;
    visiting.push(name);
    for (const dependency of dependencies[name] ?? []) visit(dependency);
    visiting.pop();
    visited.add(name);
  };
  for (const name of Object.keys(dependencies)) visit(name);
  return diagnostics;
}
function findRandomFunctions(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const memo = /* @__PURE__ */ new Map();
  const visiting = /* @__PURE__ */ new Set();
  const contains = (name) => {
    const cached = memo.get(name);
    if (cached !== void 0) return cached;
    if (visiting.has(name)) return false;
    visiting.add(name);
    const definition = functions.get(name);
    let found = false;
    if (definition?.ast)
      walk(definition.ast, (item) => {
        if (item.kind !== "call" || found) return;
        if (item.name === "random") found = true;
        else if (functions.has(item.name) && contains(item.name)) found = true;
      });
    visiting.delete(name);
    memo.set(name, found);
    return found;
  };
  return [...functions.keys()].filter(contains).sort();
}
function compileCallableFunctions(parsed, diagnostics) {
  const all = [...diagnostics];
  return {
    functions: Object.fromEntries(
      parsed.filter((item) => item.ast !== null).map((item) => [item.name, item])
    ),
    randomFunctions: findRandomFunctions(parsed),
    diagnostics: all,
    valid: all.length === 0
  };
}
function compileFunctionLibrary(functionLibrary) {
  const request = {
    initialState: {},
    snapshotState: null,
    functionLibrary,
    snapshotFunctionLibrary: null,
    allowSnapshots: false,
    randomContext: null,
    operations: [],
    diagnostics: [],
    valid: true
  };
  const parsed = parseFunctionDefinitions(request);
  const dependencies = extractFunctionDependencies(parsed);
  return compileCallableFunctions(parsed, [
    ...validateFunctionPurity(parsed),
    ...rejectRecursiveFunctions(dependencies)
  ]);
}
function countAutomaticRandomDraws(ast, currentLibrary, snapshotLibrary = currentLibrary) {
  const visiting = /* @__PURE__ */ new Set();
  const count = (item, library) => {
    if (item.kind === "literal" || item.kind === "ref") return 0;
    if (item.kind === "unary") return count(item.value, library);
    if (item.kind === "binary")
      return count(item.left, library) + count(item.right, library);
    let total = item.args.reduce((sum, arg) => sum + count(arg, library), 0);
    if (item.name === "random") return total + (item.args.length < 2 ? 1 : 0);
    if (isBuiltin(item.name)) return total;
    const targetLibrary = item.snapshot ? snapshotLibrary : library;
    const target = targetLibrary.functions[item.name];
    if (target?.ast && !visiting.has(target)) {
      visiting.add(target);
      total += count(target.ast, targetLibrary);
      visiting.delete(target);
    }
    return total;
  };
  return count(ast, currentLibrary);
}
function parseFunctionDefinitionsNode(inputs) {
  return {
    parsed_function_library: parseFunctionDefinitions(
      nodeInput3(inputs, "era.expression.request.normalized")
    )
  };
}
function nodeInput3(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function extractFunctionDependenciesNode(inputs) {
  return {
    function_dependencies: extractFunctionDependencies(
      nodeInput4(inputs, "era.expression.function_library.parsed")
    )
  };
}
function nodeInput4(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function validateFunctionPurityNode(inputs) {
  return {
    function_purity_report: {
      diagnostics: validateFunctionPurity(
        nodeInput5(
          inputs,
          "era.expression.function_library.parsed"
        )
      )
    }
  };
}
function nodeInput5(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function buildFunctionCallGraphNode(inputs) {
  const dependencies = nodeInput6(
    inputs,
    "era.expression.function_library.dependencies"
  );
  const purity = nodeInput6(
    inputs,
    "era.expression.function_library.purity"
  );
  return {
    function_call_graph: { dependencies, diagnostics: purity.diagnostics }
  };
}
function nodeInput6(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function rejectRecursiveFunctionsNode(inputs) {
  const graph = nodeInput7(inputs, "era.expression.function_library.call_graph");
  return {
    acyclic_function_graph: {
      dependencies: graph.dependencies,
      diagnostics: [
        ...graph.diagnostics,
        ...rejectRecursiveFunctions(graph.dependencies)
      ]
    }
  };
}
function nodeInput7(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function compileCallableFunctionsNode(inputs) {
  return {
    compiled_function_library: compileCallableFunctions(
      nodeInput8(
        inputs,
        "era.expression.function_library.parsed"
      ),
      nodeInput8(
        inputs,
        "era.expression.function_library.acyclic_graph"
      ).diagnostics
    )
  };
}
function nodeInput8(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function parseOperationsNode(inputs) {
  return {
    parsed_operations: parseOperations(
      nodeInput9(inputs, "era.expression.request.normalized")
    )
  };
}
function nodeInput9(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function initializeSequenceState(request, compiled, operations, snapshotCompiled = compiled) {
  return {
    startState: clone(request.snapshotState ?? request.initialState),
    currentState: clone(request.initialState),
    compiled,
    snapshotCompiled,
    operations,
    cursor: 0,
    randomContext: request.randomContext,
    randomDrawsConsumed: 0,
    diagnostics: [...request.diagnostics, ...compiled.diagnostics]
  };
}
function refValue(ast, state, env, allowState) {
  if (ast.path.length === 1 && ast.path[0] in env) return env[ast.path[0]];
  if (!allowState)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_FUNCTION_IMPURE", "\u51FD\u6570\u4F53\u4E0D\u80FD\u8BFB\u53D6\u5916\u90E8\u53D8\u91CF\u72B6\u6001\u3002", {
        path: ast.path.join(".")
      })
    );
  const source = ast.snapshot ? state.startState : state.currentState;
  const value = getPath(source, ast.path);
  if (typeof value !== "number" || !Number.isFinite(value))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_REFERENCE_NON_NUMERIC",
        `\u53D8\u91CF ${ast.path.join(".")} \u5FC5\u987B\u5DF2\u5B9A\u4E49\u4E3A\u6709\u9650\u6570\u5B57\u3002`,
        { path: ast.path.join(".") }
      )
    );
  return value;
}
function popValues(values, count) {
  if (count === 0) return { values, args: [] };
  if (values.length < count)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_EVALUATION_STACK", "\u8868\u8FBE\u5F0F\u6C42\u503C\u6808\u7F3A\u5C11\u5B50\u8868\u8FBE\u5F0F\u7ED3\u679C\u3002")
    );
  return { values: values.slice(0, -count), args: values.slice(-count) };
}
function inlineCustomAst(ast, bindings, library) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref") return bindings[ast.path.join(".")] ?? ast;
  if (ast.kind === "unary")
    return { ...ast, value: inlineCustomAst(ast.value, bindings, library) };
  if (ast.kind === "binary")
    return {
      ...ast,
      left: inlineCustomAst(ast.left, bindings, library),
      right: inlineCustomAst(ast.right, bindings, library)
    };
  const target = library.functions[ast.name];
  const args = ast.args.map((arg) => inlineCustomAst(arg, bindings, library));
  if (!target || !target.ast)
    return { kind: "call", name: ast.name, args, snapshot: ast.snapshot };
  const childBindings = Object.fromEntries(
    target.params.map((param, index) => [param, args[index]])
  );
  return inlineCustomAst(target.ast, childBindings, library);
}
function mathText(ast) {
  if (ast.kind === "literal")
    return Number.isInteger(ast.value) ? `${ast.value}` : `${ast.value}`;
  if (ast.kind === "ref") return ast.path.join("_");
  if (ast.kind === "unary") return `(${ast.op}${mathText(ast.value)})`;
  if (ast.kind === "binary")
    return `(${mathText(ast.left)} ${ast.op} ${mathText(ast.right)})`;
  const names = {
    ln: "log",
    pow: "pow",
    mod: "mod"
  };
  return `${names[ast.name] ?? ast.name}(${ast.args.map(mathText).join(",")})`;
}
function createAstFrameState(sequence, ast, env = {}, allowState = true, library = sequence.compiled) {
  return {
    sequence,
    stack: [{ kind: "eval", ast, env, allowState, library }],
    values: [],
    automaticRandomDrawCursor: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    done: false,
    result: null,
    diagnostics: []
  };
}
function complete(state) {
  if (state.stack.length === 0 && state.values.length === 1)
    return { ...state, done: true, result: state.values[0] };
  return { ...state, done: false, result: null };
}
function astFrameRoute(state) {
  const top = state.stack[state.stack.length - 1];
  if (!top) return "return";
  if (top.kind === "eval") {
    if (top.ast.kind === "literal" || top.ast.kind === "ref") return "value";
    if (top.ast.kind === "unary" || top.ast.kind === "binary")
      return "operator";
    if (top.ast.name === "random") return "random";
    if (isBuiltin(top.ast.name)) return "builtin";
    return "custom";
  }
  if (top.kind === "unary" || top.kind === "binary") return "operator";
  if (top.kind === "builtin" || top.kind === "calculus") return "builtin";
  if (top.kind === "random") return "random";
  if (top.kind === "custom") return "custom";
  return "return";
}
function evaluateFunctionAt(library, name, input) {
  const target = library.functions[name];
  if (!target || !target.ast || target.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name} \u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: name }
      )
    );
  const sequence = {
    startState: {},
    currentState: {},
    compiled: library,
    snapshotCompiled: library,
    operations: [],
    cursor: 0,
    randomContext: null,
    randomDrawsConsumed: 0,
    diagnostics: []
  };
  let frame = createAstFrameState(
    sequence,
    target.ast,
    { [target.params[0]]: input },
    false
  );
  while (!frame.done) frame = advanceAstFrame(frame);
  if (frame.diagnostics.length > 0 || frame.result === null)
    throw new ExpressionFailure(
      frame.diagnostics[0] ?? diagnostic("ERA_EXPR_CALCULUS_EVALUATE", `\u51FD\u6570 ${name} \u65E0\u6CD5\u6C42\u503C\u3002`, {
        path: name
      })
    );
  return frame.result;
}
function calculateCalculus(name, target, args, library) {
  const functionDef = library.functions[target];
  if (!functionDef || !functionDef.ast || functionDef.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name} \u53EA\u63A5\u53D7\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: target }
      )
    );
  if (library.randomFunctions.includes(target))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_RANDOM_FORBIDDEN",
        `${name} \u4E0D\u80FD\u4EE5\u76F4\u63A5\u6216\u95F4\u63A5\u8C03\u7528 random \u7684\u51FD\u6570\u4E3A\u76EE\u6807\u3002`,
        { path: target }
      )
    );
  if (name === "derivative") {
    if (args.length !== 1 && args.length !== 2)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_BUILTIN_ARITY",
          "derivative \u9700\u8981 f\u3001at \u4E0E\u53EF\u9009 order\u3002"
        )
      );
    const order = args.length === 2 ? args[1] : 1;
    if (!Number.isSafeInteger(order) || order <= 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_ORDER",
          "\u5BFC\u6570\u9636\u6570\u5FC5\u987B\u662F\u4EFB\u610F\u6B63\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    const expanded = inlineCustomAst(functionDef.ast, {}, library);
    let derived = mathText(expanded);
    const variable = functionDef.params[0];
    try {
      for (let currentOrder = 0; currentOrder < order; currentOrder += 1) {
        const node = derivative(derived, variable);
        derived = node.toString();
        if (derived === "0") break;
      }
      const value = Number(mathEvaluate(derived, { [variable]: args[0] }));
      return finite(
        value,
        "ERA_EXPR_DERIVATIVE_NON_FINITE",
        "\u5BFC\u6570\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    } catch (error) {
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_UNSUPPORTED",
          `\u65E0\u6CD5\u6784\u9020\u8BE5\u5BFC\u6570\uFF1A${error instanceof Error ? error.message : String(error)}\u3002`,
          { path: target }
        )
      );
    }
  }
  if (args.length !== 2)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_BUILTIN_ARITY", "integral \u9700\u8981 f\u3001start\u3001end\u3002")
    );
  const [start, end] = args;
  if (start === end) return 0;
  const direction = start < end ? 1 : -1;
  const left = Math.min(start, end);
  const right = Math.max(start, end);
  const evaluate = (value) => evaluateFunctionAt(library, target, value);
  const simpson = (a, b, fa, fm, fb) => (b - a) / 6 * (fa + 4 * fm + fb);
  const middle = (left + right) / 2;
  const whole = simpson(
    left,
    right,
    evaluate(left),
    evaluate(middle),
    evaluate(right)
  );
  const stack = [
    {
      a: left,
      b: right,
      fa: evaluate(left),
      fm: evaluate(middle),
      fb: evaluate(right),
      whole,
      tolerance: 1e-9
    }
  ];
  let sum = 0;
  let processed = 0;
  while (stack.length > 0) {
    const segment = stack.pop();
    processed += 1;
    if (processed > 65536)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_INTEGRAL_CONVERGENCE",
          "\u79EF\u5206\u5728\u786E\u5B9A\u6027 Simpson \u8FED\u4EE3\u5185\u672A\u6536\u655B\u3002",
          { path: target }
        )
      );
    const mid = (segment.a + segment.b) / 2;
    const leftMid = (segment.a + mid) / 2;
    const rightMid = (mid + segment.b) / 2;
    const leftValue = evaluate(leftMid);
    const rightValue = evaluate(rightMid);
    const leftArea = simpson(segment.a, mid, segment.fa, leftValue, segment.fm);
    const rightArea = simpson(
      mid,
      segment.b,
      segment.fm,
      rightValue,
      segment.fb
    );
    const delta = leftArea + rightArea - segment.whole;
    if (Math.abs(delta) <= 15 * segment.tolerance) {
      sum += leftArea + rightArea + delta / 15;
      continue;
    }
    stack.push({
      a: mid,
      b: segment.b,
      fa: segment.fm,
      fm: rightValue,
      fb: segment.fb,
      whole: rightArea,
      tolerance: segment.tolerance / 2
    });
    stack.push({
      a: segment.a,
      b: mid,
      fa: segment.fa,
      fm: leftValue,
      fb: segment.fm,
      whole: leftArea,
      tolerance: segment.tolerance / 2
    });
  }
  return finite(
    direction * sum,
    "ERA_EXPR_INTEGRAL_NON_FINITE",
    "\u79EF\u5206\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
  );
}
function advanceAstFrame(state, expected) {
  if (state.done) return state;
  try {
    const actual = astFrameRoute(state);
    if (expected && actual !== expected)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FRAME_ROUTE",
          `\u8C03\u7528\u5E27\u8DEF\u7531\u4E0D\u5339\u914D\uFF1A\u671F\u671B ${expected}\uFF0C\u5B9E\u9645 ${actual}\u3002`
        )
      );
    const stack = [...state.stack];
    const values = [...state.values];
    let automaticRandomDrawCursor = state.automaticRandomDrawCursor;
    const top = stack.pop();
    if (!top) return complete({ ...state, stack, values });
    if (top.kind === "eval") {
      if (top.ast.kind === "literal") values.push(top.ast.value);
      else if (top.ast.kind === "ref")
        values.push(refValue(top.ast, state.sequence, top.env, top.allowState));
      else if (top.ast.kind === "unary") {
        stack.push(
          { kind: "unary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.value,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "binary") {
        stack.push(
          { kind: "binary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.right,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          },
          {
            kind: "eval",
            ast: top.ast.left,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "call") {
        if (top.ast.name === "derivative" || top.ast.name === "integral") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          const targetAst = top.ast.args[0];
          if (!targetAst || targetAst.kind !== "ref" || targetAst.snapshot || targetAst.path.length !== 1)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_CALCULUS_TARGET",
                `${top.ast.name} \u7684\u9996\u53C2\u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u51FD\u6570\u540D\u3002`
              )
            );
          stack.push({
            kind: "calculus",
            name: top.ast.name,
            target: targetAst.path[0],
            count: top.ast.args.length - 1,
            library: top.library
          });
          for (const arg of [...top.ast.args.slice(1)].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (top.ast.name === "random") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({ kind: "random", count: top.ast.args.length });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (isBuiltin(top.ast.name)) {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({
            kind: "builtin",
            name: top.ast.name,
            count: top.ast.args.length
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else {
          stack.push({
            kind: "custom",
            name: top.ast.name,
            count: top.ast.args.length,
            library: top.ast.snapshot ? state.sequence.snapshotCompiled : top.library
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        }
      }
    } else if (top.kind === "unary") {
      const popped = popValues(values, 1);
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          top.op === "+" ? popped.args[0] : -popped.args[0],
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E00\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "binary") {
      const popped = popValues(values, 2);
      const [left, right] = popped.args;
      const result = top.op === "+" ? left + right : top.op === "-" ? left - right : top.op === "*" ? left * right : top.op === "/" ? left / right : top.op === "%" ? left % right : left ** right;
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          result,
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E8C\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "builtin") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateBuiltin(top.name, popped.args)
      );
    } else if (top.kind === "random") {
      const popped = popValues(values, top.count);
      const draw = automaticRandomDrawCursor;
      if (top.count < 2) automaticRandomDrawCursor += 1;
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateRandom(popped.args, state.sequence.randomContext, draw)
      );
    } else if (top.kind === "calculus") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateCalculus(top.name, top.target, popped.args, top.library)
      );
    } else {
      const popped = popValues(values, top.count);
      const target = top.library.functions[top.name];
      if (!target || !target.ast)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
            `\u672A\u77E5\u51FD\u6570 ${top.name}\u3002`,
            { path: top.name }
          )
        );
      if (target.params.length !== popped.args.length)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_ARITY",
            `\u51FD\u6570 ${top.name} \u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
            { path: top.name }
          )
        );
      const env = Object.fromEntries(
        target.params.map((param, index) => [param, popped.args[index]])
      );
      values.splice(0, values.length, ...popped.values);
      stack.push({
        kind: "eval",
        ast: target.ast,
        env,
        allowState: false,
        library: top.library
      });
    }
    return complete({ ...state, stack, values, automaticRandomDrawCursor });
  } catch (error) {
    const detail = error instanceof ExpressionFailure ? error.detail : diagnostic(
      "ERA_EXPR_EVALUATION_FAILED",
      error instanceof Error ? error.message : String(error)
    );
    return {
      ...state,
      stack: [],
      done: true,
      result: null,
      diagnostics: [...state.diagnostics, detail]
    };
  }
}
function initializeRandomSequenceStateNode(inputs) {
  const request = nodeInput10(
    inputs,
    "era.expression.request.normalized"
  );
  const compiled = nodeInput10(
    inputs,
    "era.expression.function_library.compiled"
  );
  const snapshotCompiled = request.snapshotFunctionLibrary ? compileFunctionLibrary(request.snapshotFunctionLibrary) : compiled;
  return {
    sequence_state: initializeSequenceState(
      request,
      compiled,
      nodeInput10(inputs, "era.expression.operations.parsed"),
      snapshotCompiled
    )
  };
}
function nodeInput10(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function selectNextOperationNode(inputs) {
  const sequenceState = nodeInput11(
    inputs,
    "era.expression.sequence.state"
  );
  return {
    current_operation: {
      sequenceState,
      operation: sequenceState.operations[sequenceState.cursor] ?? null
    }
  };
}
function nodeInput11(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function initializeAstFramesNode(inputs) {
  const current = nodeInput12(inputs, "era.expression.operation.current");
  const ast = current.sequenceState.compiled.valid && current.operation?.ast ? current.operation.ast : { kind: "literal", value: 0 };
  return { ast_frame_state: createAstFrameState(current.sequenceState, ast) };
}
function nodeInput12(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function commitOperationResult(state, value, evaluationDiagnostics) {
  const operation = state.operations[state.cursor];
  if (!operation)
    return {
      sequenceStateNext: state,
      sequenceDone: true,
      operationExecutionResult: {
        finalState: state.currentState,
        diagnostics: state.diagnostics,
        randomDrawsConsumed: state.randomDrawsConsumed
      }
    };
  const diagnostics = [
    ...state.diagnostics,
    ...operation.diagnostics,
    ...evaluationDiagnostics
  ];
  const currentState = state.compiled.valid && operation.ast && operation.diagnostics.length === 0 && value !== null ? setPath(state.currentState, operation.path, value) : state.currentState;
  const randomDraws = state.compiled.valid && operation.ast && operation.diagnostics.length === 0 ? countAutomaticRandomDraws(
    operation.ast,
    state.compiled,
    state.snapshotCompiled
  ) : 0;
  const next = {
    ...state,
    currentState,
    cursor: state.cursor + 1,
    randomDrawsConsumed: state.randomDrawsConsumed + randomDraws,
    diagnostics
  };
  return {
    sequenceStateNext: next,
    sequenceDone: next.cursor >= next.operations.length,
    operationExecutionResult: {
      finalState: next.currentState,
      diagnostics: next.diagnostics,
      randomDrawsConsumed: next.randomDrawsConsumed
    }
  };
}
function evaluateAst(state) {
  let frame = state;
  while (!frame.done) frame = advanceAstFrame(frame);
  return { value: frame.result, diagnostics: frame.diagnostics };
}
function run(inputs) {
  const envelope = inputs["era.expression.ast_frame.state"];
  return { evaluated_expression: evaluateAst(envelope.value) };
}
function commitOperationResultNode(inputs) {
  const current = nodeInput13(
    inputs,
    "era.expression.operation.current"
  );
  const evaluated = nodeValue(nodeInput13(inputs, "era.expression.value"));
  const outcome = commitOperationResult(
    current.sequenceState,
    evaluated.value,
    evaluated.diagnostics
  );
  return {
    sequence_state_next: outcome.sequenceStateNext,
    sequence_done: outcome.sequenceDone,
    operation_execution_result: outcome.operationExecutionResult
  };
}
function nodeInput13(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function nodeValue(value) {
  if (value !== null && typeof value === "object" && "value" in value) {
    const item = value;
    return {
      value: typeof item.value === "number" ? item.value : null,
      diagnostics: Array.isArray(item.diagnostics) ? item.diagnostics : []
    };
  }
  return { value: null, diagnostics: [] };
}
function substituteSymbolic(ast, state) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref")
    return state[ast.path.join(".")] ?? {
      kind: "ref",
      path: ast.path,
      snapshot: true
    };
  if (ast.kind === "unary")
    return simplify({
      kind: "unary",
      op: ast.op,
      value: substituteSymbolic(ast.value, state)
    });
  if (ast.kind === "binary")
    return simplify({
      kind: "binary",
      op: ast.op,
      left: substituteSymbolic(ast.left, state),
      right: substituteSymbolic(ast.right, state)
    });
  return {
    kind: "call",
    name: ast.name,
    args: ast.args.map((arg) => substituteSymbolic(arg, state)),
    snapshot: ast.snapshot
  };
}
function literal(value) {
  return { kind: "literal", value: Object.is(value, -0) ? 0 : value };
}
function literalNumber(ast) {
  return ast.kind === "literal" ? ast.value : void 0;
}
function simplify(ast) {
  if (ast.kind === "literal" || ast.kind === "ref") return ast;
  if (ast.kind === "call") return { ...ast, args: ast.args.map(simplify) };
  if (ast.kind === "unary") {
    const value = simplify(ast.value);
    const number = literalNumber(value);
    if (number !== void 0) return literal(ast.op === "+" ? number : -number);
    if (ast.op === "+") return value;
    return { ...ast, value };
  }
  const left = simplify(ast.left);
  const right = simplify(ast.right);
  const leftNumber = literalNumber(left);
  const rightNumber = literalNumber(right);
  if (leftNumber !== void 0 && rightNumber !== void 0) {
    const result = ast.op === "+" ? leftNumber + rightNumber : ast.op === "-" ? leftNumber - rightNumber : ast.op === "*" ? leftNumber * rightNumber : ast.op === "/" ? leftNumber / rightNumber : ast.op === "%" ? leftNumber % rightNumber : leftNumber ** rightNumber;
    return Number.isFinite(result) ? literal(result) : { ...ast, left, right };
  }
  if (ast.op === "+") {
    if (rightNumber === 0) return left;
    if (leftNumber === 0) return right;
    const nested = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && nested !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const subtraction = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && subtraction !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(subtraction - rightNumber)
      });
  }
  if (ast.op === "-") {
    if (rightNumber === 0) return left;
    const nested = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && nested !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const addition = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && addition !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(addition - rightNumber)
      });
  }
  if (ast.op === "*") {
    if (leftNumber === 0 || rightNumber === 0) return literal(0);
    if (leftNumber === 1) return right;
    if (rightNumber === 1) return left;
  }
  if (ast.op === "/" && rightNumber === 1) return left;
  return { ...ast, left, right };
}
function operatorPrecedence(op) {
  return op === "+" || op === "-" ? 1 : op === "*" || op === "/" || op === "%" ? 2 : 3;
}
function printAst(ast, parent = 0) {
  if (ast.kind === "literal") return `${ast.value}`;
  if (ast.kind === "ref")
    return `${ast.snapshot ? "@" : ""}${ast.path.join(".")}`;
  if (ast.kind === "call")
    return `${ast.snapshot ? "@" : ""}${ast.name}(${ast.args.map((arg) => printAst(arg)).join(", ")})`;
  if (ast.kind === "unary") {
    const own2 = 4;
    const text2 = `${ast.op}${printAst(ast.value, own2)}`;
    return own2 < parent ? `(${text2})` : text2;
  }
  const own = operatorPrecedence(ast.op);
  const text = `${printAst(ast.left, own)} ${ast.op} ${printAst(ast.right, own + (ast.op === "^" ? 0 : 1))}`;
  return own < parent ? `(${text})` : text;
}
function deriveSymbolicLayer(sequence) {
  const symbols = {};
  const tainted = /* @__PURE__ */ new Set();
  const conflicts = (left, right) => left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
  const referencesTainted = (ast) => {
    let found = false;
    walk(ast, (item) => {
      if (item.kind === "ref" && !item.snapshot && [...tainted].some((path) => conflicts(item.path.join("."), path)))
        found = true;
    });
    return found;
  };
  for (const operation of sequence.operations) {
    if (!operation.ast || operation.diagnostics.length > 0) continue;
    const path = operation.path.join(".");
    if (countAutomaticRandomDraws(
      operation.ast,
      sequence.compiled,
      sequence.snapshotCompiled
    ) > 0 || referencesTainted(operation.ast)) {
      tainted.add(path);
      for (const existing of Object.keys(symbols))
        if (conflicts(existing, path)) delete symbols[existing];
      continue;
    }
    symbols[path] = simplify(substituteSymbolic(operation.ast, symbols));
  }
  return symbols;
}
function normaliseCompaction(sequence, symbols) {
  const compressed = {};
  for (const [path, ast] of Object.entries(symbols)) {
    const before = getPath(sequence.startState, path.split("."));
    const after = getPath(sequence.currentState, path.split("."));
    if (JSON.stringify(before) !== JSON.stringify(after))
      compressed[path] = { $expr: printAst(simplify(ast)) };
  }
  return {
    status: sequence.diagnostics.length === 0 ? "ok" : sequence.cursor === 0 ? "invalid" : "partial",
    finalState: sequence.currentState,
    diagnostics: sequence.diagnostics,
    compressed,
    compactedOperations: Object.entries(compressed).map(([path, value]) => ({
      path,
      value
    })),
    randomDrawsConsumed: sequence.randomDrawsConsumed,
    nextDrawOffset: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    containsAutomaticRandom: sequence.operations.some(
      (operation) => operation.ast !== null && operation.diagnostics.length === 0 && countAutomaticRandomDraws(
        operation.ast,
        sequence.compiled,
        sequence.snapshotCompiled
      ) > 0
    )
  };
}
function deriveSymbolicLayerNode(inputs) {
  const sequence = nodeInput14(
    inputs,
    "era.expression.sequence.state"
  );
  const execution = nodeInput14(inputs, "era.expression.execution.result");
  return {
    symbolic_layer: deriveSymbolicLayer(completeNodeState(sequence, execution))
  };
}
function nodeInput14(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function completeNodeState(initial, execution) {
  return {
    ...initial,
    currentState: execution.finalState,
    diagnostics: execution.diagnostics,
    randomDrawsConsumed: execution.randomDrawsConsumed ?? initial.randomDrawsConsumed,
    cursor: initial.operations.length
  };
}
function guardRandomCompactionNode(inputs) {
  return {
    random_guarded_symbolic_layer: nodeInput15(
      inputs,
      "era.expression.symbolic.layer"
    )
  };
}
function nodeInput15(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function normalizeCompactionNode(inputs) {
  const sequence = nodeInput16(
    inputs,
    "era.expression.sequence.state"
  );
  const execution = nodeInput16(inputs, "era.expression.execution.result");
  return {
    expression_response: normaliseCompaction(
      completeNodeState2(sequence, execution),
      nodeInput16(inputs, "era.expression.symbolic.layer")
    )
  };
}
function nodeInput16(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function completeNodeState2(initial, execution) {
  return {
    ...initial,
    currentState: execution.finalState,
    diagnostics: execution.diagnostics,
    randomDrawsConsumed: execution.randomDrawsConsumed ?? initial.randomDrawsConsumed,
    cursor: initial.operations.length
  };
}
var FORMAT = "era-values-v1";
function encodePacket(value) {
  const ancestors = /* @__PURE__ */ new Set();
  function encode(item) {
    if (item === null) return ["null"];
    switch (typeof item) {
      case "undefined":
        return ["undefined"];
      case "string":
        return ["string", item];
      case "boolean":
        return ["boolean", item];
      case "number":
        return ["number", Object.is(item, -0) ? "-0" : String(item)];
      case "bigint":
        return ["bigint", String(item)];
      case "object":
        break;
      default:
        throw new TypeError("\u5DE5\u4F5C\u6D41\u4E1A\u52A1\u6D88\u606F\u4E0D\u80FD\u5305\u542B\u51FD\u6570\u6216\u7B26\u53F7\uFF1B\u8FD0\u884C\u8D44\u6E90\u987B\u4F7F\u7528\u6240\u5C5E\u5B9E\u4F8B\u7684\u8D44\u6E90\u7F16\u53F7\u3002");
    }
    const array = Array.isArray(item), proto = Object.getPrototypeOf(item);
    const ordinary = proto === null || proto === Object.prototype || Object.getPrototypeOf(proto) === null && Object.getOwnPropertyDescriptor(proto, "constructor")?.value?.name === "Object";
    if (!array && !ordinary)
      throw new TypeError("\u5DE5\u4F5C\u6D41\u4E1A\u52A1\u6D88\u606F\u53EA\u63A5\u53D7\u666E\u901A\u5BF9\u8C61\u548C\u6570\u7EC4\uFF1B\u9875\u9762\u8D44\u6E90\u987B\u4F7F\u7528\u8D44\u6E90\u7F16\u53F7\u3002");
    if (ancestors.has(item)) throw new TypeError("\u5DE5\u4F5C\u6D41\u4E1A\u52A1\u6D88\u606F\u4E0D\u80FD\u5305\u542B\u5FAA\u73AF\u5F15\u7528\u3002");
    ancestors.add(item);
    try {
      const entries = Object.keys(item).map((key) => [key, encode(item[key])]);
      return array ? ["array", item.length, entries] : ["object", proto === null, entries];
    } finally {
      ancestors.delete(item);
    }
  }
  return { encoding: FORMAT, payload: JSON.stringify(encode(value)) };
}
function decodePacket(packet) {
  if (packet?.encoding !== FORMAT || typeof packet.payload !== "string")
    throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u636E\u5C01\u88C5\u683C\u5F0F\u4E0D\u6B63\u786E\u3002");
  function decode(node) {
    if (!Array.isArray(node)) throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u503C\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
    const [kind, value, entries] = node;
    switch (kind) {
      case "null":
        return null;
      case "undefined":
        return void 0;
      case "string":
        if (typeof value !== "string") throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5B57\u7B26\u4E32\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        return value;
      case "boolean":
        if (typeof value !== "boolean") throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5E03\u5C14\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        return value;
      case "number": {
        if (typeof value !== "string") throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u503C\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        if (value === "NaN") return NaN;
        if (value === "Infinity") return Infinity;
        if (value === "-Infinity") return -Infinity;
        if (value === "-0") return -0;
        const number = Number(value);
        if (!Number.isFinite(number) || String(number) !== value)
          throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u503C\u6587\u5B57\u4E0D\u6B63\u786E\u3002");
        return number;
      }
      case "bigint":
        return BigInt(value);
      case "object":
      case "array": {
        if (!Array.isArray(entries)) throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5BF9\u8C61\u5B57\u6BB5\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        if (kind === "array" && (!Number.isInteger(value) || value < 0 || value > 4294967295))
          throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u7EC4\u957F\u5EA6\u4E0D\u6B63\u786E\u3002");
        if (kind === "object" && typeof value !== "boolean")
          throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5BF9\u8C61\u7C7B\u578B\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
        const result = kind === "array" ? new Array(value) : Object.create(value ? null : Object.prototype);
        for (const entry of entries) {
          if (!Array.isArray(entry) || entry.length !== 2 || typeof entry[0] !== "string")
            throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u5B57\u6BB5\u8BB0\u5F55\u4E0D\u6B63\u786E\u3002");
          const [key, encoded] = entry;
          if (Object.hasOwn(result, key)) throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u5305\u542B\u91CD\u590D\u5B57\u6BB5\u3002");
          if (kind === "array" && /^(0|[1-9][0-9]*)$/u.test(key) && Number(key) < 4294967295 && Number(key) >= value)
            throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u7684\u6570\u7EC4\u4F4D\u7F6E\u8D85\u8FC7\u5DF2\u58F0\u660E\u957F\u5EA6\u3002");
          Object.defineProperty(result, key, { value: decode(encoded), enumerable: true, configurable: true, writable: true });
        }
        return result;
      }
      default:
        throw new TypeError("\u5DE5\u4F5C\u6D41\u6D88\u606F\u5305\u542B\u672A\u77E5\u7684\u503C\u8BB0\u5F55\u3002");
    }
  }
  return decode(JSON.parse(packet.payload));
}
function Decode(inputs) {
  return { request: decodePacket(inputs["era.workflow.packet"].value).expression_request, entry_return: (
    /** @type {"protocol"} */
    "protocol"
  ) };
}
function Encode(inputs) {
  return { packet: encodePacket({ expressionResponse: inputs["era.expression.response"].value }) };
}
function PrepareDirectRequest(inputs) {
  return { prepared_request: inputs["era.expression.request"].value, entry_return: (
    /** @type {"direct"} */
    "direct"
  ) };
}
function SelectEntryReturn(inputs) {
  return { return_route: inputs["era.workflow.entry_return"].value };
}
var __vfConsoleKey = /* @__PURE__ */ Symbol.for("vibeflow.console.observation.v1");
function __vfConsoleStorage() {
  if (!globalThis[__vfConsoleKey]) {
    const storage = new __vfAsyncLocalStorage();
    globalThis[__vfConsoleKey] = storage;
    for (const stream of [process.stdout, process.stderr]) {
      const original = stream.write;
      stream.write = function(chunk, ...args) {
        storage.getStore()?.business(chunk);
        return original.call(this, chunk, ...args);
      };
    }
  }
  return globalThis[__vfConsoleKey];
}
var __vfHeartbeatSource = `
const {workerData, parentPort} = require('node:worker_threads');
const fs = require('node:fs');
const flags = new Int32Array(workerData.flags);
let record = workerData.record;
parentPort.on('message', value => {record = value;});
const timer = setInterval(() => {
  if (Atomics.compareExchange(flags, 1, 0, 1) !== 0) return;
  try {
    if (Atomics.load(flags, 0)) {clearInterval(timer); return;}
    const temporary = workerData.file + '.heartbeat-' + process.pid;
    fs.writeFileSync(temporary, JSON.stringify({...record, updated_at: new Date().toISOString()}) + '\\n');
    fs.renameSync(temporary, workerData.file);
  } catch (error) {
    parentPort.postMessage({error: String(error)});
    clearInterval(timer);
  } finally {
    Atomics.store(flags, 1, 0); Atomics.notify(flags, 1);
  }
}, workerData.interval);
`;
function __vfCreateFileObservation(options, initial, interval) {
  const runDir = __vfPath.resolve(options.runDir ?? __vfPath.join("runs", (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-") + "_" + __vfUuid()));
  const file = __vfPath.resolve(options.statusFile ?? __vfPath.join(runDir, "status.json"));
  __vfFs.mkdirSync(runDir, { recursive: true });
  __vfFs.mkdirSync(__vfPath.dirname(file), { recursive: true });
  const businessFd = __vfFs.openSync(__vfPath.join(runDir, "business.log"), "w");
  const kernelFd = __vfFs.openSync(__vfPath.join(runDir, "vibeflow.log"), "w");
  const flags = new Int32Array(new SharedArrayBuffer(8));
  let worker;
  let heartbeatError;
  let closed = false;
  const storage = __vfConsoleStorage();
  function write(record) {
    if (heartbeatError) throw heartbeatError;
    while (Atomics.compareExchange(flags, 1, 0, 1) !== 0) Atomics.wait(flags, 1, 1, 100);
    const temporary = file + ".main-" + process.pid + "-" + __vfUuid();
    try {
      __vfFs.writeFileSync(temporary, JSON.stringify(record) + "\n");
      __vfFs.renameSync(temporary, file);
    } finally {
      if (__vfFs.existsSync(temporary)) __vfFs.unlinkSync(temporary);
      Atomics.store(flags, 1, 0);
      Atomics.notify(flags, 1);
    }
  }
  const sink = {
    business(chunk) {
      if (!closed) __vfFs.writeSync(businessFd, typeof chunk === "string" ? chunk : Buffer.from(chunk));
    },
    kernel(text) {
      if (!closed) __vfFs.writeSync(kernelFd, text + "\n");
    },
    run(callback) {
      return storage.run(sink, callback);
    },
    cache(record) {
      worker?.postMessage(record);
    },
    publish(record) {
      sink.kernel("STATE " + record.state);
      write(record);
      worker?.postMessage(record);
    },
    finish(record) {
      Atomics.store(flags, 0, 1);
      sink.publish(record);
    },
    close() {
      if (closed) return;
      closed = true;
      Atomics.store(flags, 0, 1);
      worker?.terminate();
      __vfFs.closeSync(businessFd);
      __vfFs.closeSync(kernelFd);
    }
  };
  try {
    write(initial);
    worker = new __vfStatusWorker(__vfHeartbeatSource, { eval: true, execArgv: [], workerData: {
      record: initial,
      file,
      interval,
      flags: flags.buffer
    } });
    worker.on("message", (message) => {
      if (message.error) heartbeatError = new Error(message.error);
    });
    worker.on("error", (error) => {
      heartbeatError = error;
    });
    worker.unref();
    return sink;
  } catch (error) {
    sink.close();
    throw error;
  }
}
var VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v12";
var VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v5";
var VibeFlowWorkflowError = class extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === void 0 ? void 0 : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
    if (details.sourceLocation) this.sourceLocation = details.sourceLocation;
  }
};
function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details
  });
}
function throwIfAborted(signal, workflow, nodePath2 = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath: nodePath2,
    blockPath,
    cause: signal.reason
  });
}
async function awaitWithAbort(value, signal, workflow, nodePath2 = "", blockPath = "") {
  return await value;
}
function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}
function dictionary() {
  return /* @__PURE__ */ Object.create(null);
}
function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true
  });
  return target;
}
function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string" && !new RegExp(schema.pattern).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}
function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every(
    (key, index) => key === rightKeys[index] && jsonEquals(left[key], right[key])
  );
}
function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}
function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}
function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}
function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}
function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}
function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details
  });
  root.kernelLog?.(event);
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause }
    );
  }
}
function normalizeOptions(workflow, options) {
  const raw = options === void 0 ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  if (Object.hasOwn(raw, "detachedTimeoutMs")) throw vfError("VF_ASYNC_MIGRATION", "detachedTimeoutMs was removed; workflow waits for actual Node cleanup", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== void 0 && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    statusStopping: raw.__vfStatusStopping,
    statusUpdate: raw.__vfStatusUpdate,
    kernelLog: raw.__vfKernelLog,
    workflowSession: raw.workflowSession,
    workflowInstanceId: raw.workflowInstanceId
  };
}
function inputValues(workflow, inputs, input) {
  const values = inputs[__vfMultipleInputs]?.get(input.key);
  if (values) return values;
  return [inputs[input.key]];
}
function validatePublicInputs(workflow, inputs, schemas) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input.key);
    if (input.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = inputValues(workflow, inputs, input).map((value) => validateJsonSchema(
      value,
      input.schema || schemas[input.type]
    )).find(Boolean);
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input.key}' failed schema validation: ${failure}`,
        workflow
      );
    }
  }
}
function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}
function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial, root.schemas);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: /* @__PURE__ */ new Map(),
    activeEdges: /* @__PURE__ */ new Set(),
    lastInputs: /* @__PURE__ */ new Map(),
    nodeRuns: /* @__PURE__ */ new Map(),
    stepCount: 0,
    initial
  };
}
function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}
function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input of state.workflow.inputs) {
    if (!accepted.has(input.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input.key)) continue;
    for (const value of inputValues(state.workflow, state.initial, input)) {
      state.inboxes[nodeId].push(createEnvelope(input.key, input.type, value, "pipeline.input"));
    }
  }
}
function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type).sort((a, b) => state.workflow.node_order.indexOf(a.source_node) - state.workflow.node_order.indexOf(b.source_node));
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}
function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}
function conditionMatches(condition, values) {
  if (!condition) return true;
  const equal = Object.is(values[condition.key], condition.literal);
  return condition.operator === "==" ? equal : !equal;
}
function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}
function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  if (outputs && typeof outputs.then === "function") throw vfError("VF_COMPLETION_MISMATCH", "immediate node returned pending work", state.workflow);
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  for (const provider of node.provides) {
    const schema = state.root.schemas[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
  }
  return outputs;
}
function outputEnvelopes(node, outputs) {
  return node.provides.map(
    (provider) => createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}
function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node)
    );
    state.inboxes[targetId].push(envelope);
  }
}
function nodeContext(node, state, execution) {
  return Object.freeze({
    signal: execution?.signal || state.root.signal,
    workflow: nodeWorkflow(state, node, execution),
    updateInfo(info) {
      state.root.statusUpdate?.(info);
    },
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details
      });
    }
  });
}
function invokeStaticImplementationSync(implementation, node, params, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const execution = new NodeExecution(state.root.signal);
  try {
    const outputs = implementation(inputs, params, nodeContext(node, state, execution));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      cause.sourceLocation ||= { path: node.source?.ref || "", symbol: node.source?.export || "" };
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted && (cause?.name === "AbortError" || cause === state.root.signal.reason)) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause }
    );
  } finally {
    execution.exitSync();
  }
}
function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.definition_id
  });
  return inputs;
}
function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.definition_id
  });
}
function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}
function rawInputsForChild(inputSpecs, inputs, workflow, nodeId) {
  const items = [];
  for (const value of Object.values(inputs)) {
    if (Array.isArray(value)) items.push(...value);
    else if (value) items.push(value);
  }
  const initial = dictionary();
  const multiple = /* @__PURE__ */ new Map();
  for (const input of inputSpecs) {
    const matches = items.filter((item) => item?.type === input.type);
    if (matches.length) {
      setOwn(initial, input.key, matches[0].value);
      multiple.set(input.key, matches.map((item) => item.value));
    } else if (input.required) {
      throw vfError(
        "VF_INPUT_REQUIRED",
        `composite node '${nodeId}' cannot supply required body input '${input.key}'`,
        workflow
      );
    }
  }
  Object.defineProperty(initial, __vfMultipleInputs, { value: multiple });
  return initial;
}
function outputsFromChild(node, mappings, childResult, state) {
  const outputs = dictionary();
  for (const mapping of mappings) {
    if (!Object.prototype.hasOwnProperty.call(childResult.publicOutputs, mapping.alias)) {
      throw vfError(
        "VF_OUTPUT_CARDINALITY",
        `composite node '${node.id}' body omitted optional output '${mapping.alias}' required by provider '${mapping.provider}'`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
    setOwn(outputs, mapping.provider, childResult.publicOutputs[mapping.alias]);
  }
  return validateNodeOutputs(node, outputs, state);
}
function valueFromEnvelope(value) {
  if (value && typeof value === "object" && "value" in value && "type" in value) {
    return value.value;
  }
  return value;
}
function resultValues(child) {
  const values = dictionary();
  for (const [key, value] of Object.entries(child.publicOutputs)) setOwn(values, key, value);
  for (const [type, candidates] of child.candidates) {
    if (candidates.length === 1) setOwn(values, type, candidates[0].value);
  }
  return values;
}
function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = [...state.candidates.get(spec.type) || []].sort((a, b) => state.workflow.node_order.indexOf(a.source_node) - state.workflow.node_order.indexOf(b.source_node));
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.root.schemas[spec.type];
    const values = spec.cardinality === "all" ? matches.map((item) => item.value) : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow
        );
      }
    }
  }
  return output;
}
function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
function nodeWorkflow(state, node, execution) {
  const signal = execution?.signal || state.root.signal;
  const session = state.root.workflowSession;
  const location = { nodePath: nodePath(state, node.id), blockPath: formatBlockPath(state.path) };
  function operation(name, request = {}) {
    if (execution && !execution.active) throw vfError("VF_NODE_CONTEXT_EXITED", "Node invocation has exited", state.workflow, location);
    if (name !== "send" && name !== "invoke_sync") throwIfAborted(signal, state.workflow, location.nodePath, location.blockPath);
    if (typeof session?.[name] !== "function") throw vfError(session == null ? "VF_WORKFLOW_UNCONNECTED" : "VF_WORKFLOW_UNSUPPORTED", `workflow session does not provide ${name}`, state.workflow, location);
    return session[name](request, { signal });
  }
  function immediate(name, request) {
    const value = operation(name, request);
    if (value && typeof value.then === "function") throw vfError("VF_COMPLETION_MISMATCH", `workflow ${name} returned pending work`, state.workflow, location);
    return value;
  }
  function suspended(name, request) {
    const promise = (async () => {
      try {
        return await awaitWithAbort(operation(name, request), signal, state.workflow, location.nodePath, location.blockPath);
      } catch (error) {
        if (signal?.aborted) throwIfAborted(signal, state.workflow, location.nodePath, location.blockPath);
        throw error;
      }
    })();
    return execution ? execution.own(promise) : promise;
  }
  return Object.freeze({
    self: () => state.root.identity.self(),
    invoke_sync: (request) => immediate("invoke_sync", request),
    send: (request) => immediate("send", request),
    call: (request) => suspended("call", request),
    wait: (request) => suspended("wait", request),
    receive: (request) => suspended("receive", request),
    kill: (request) => suspended("kill", request)
  });
}
var __vfMultipleInputs = /* @__PURE__ */ Symbol("native input envelopes");
function runtimePluginError(code, descriptor, hook, cause, workflow, location = {}) {
  const suffix = hook ? ` hook '${hook}'` : "";
  return vfError(
    code,
    `runtime plugin '${descriptor.id}'${suffix} failed`,
    workflow,
    {
      nodePath: location.nodePath || "",
      blockPath: location.blockPath || "/",
      cause
    }
  );
}
function runtimePluginContext(workflow, descriptor, root) {
  return Object.freeze({
    abiVersion: VIBEFLOW_PLUGIN_ABI,
    pluginId: descriptor.id,
    pluginType: "runtime",
    target: descriptor.target,
    workflowId: workflow.workflow_id,
    config: deepFreeze(descriptor.config || {}),
    signal: root.signal
  });
}
function runtimePluginSummary(root, details = {}) {
  return deepFreeze({
    workflowId: root.workflowId,
    entryMode: root.workflow.entry_mode,
    ...details
  });
}
function createRuntimePluginsSync(workflow, descriptors, factories, root) {
  const records = [];
  try {
    for (const descriptor of descriptors) {
      const factory = factories[descriptor.factory_index];
      if (typeof factory !== "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("plugin module does not export createPlugin()"),
          workflow
        );
      }
      let instance;
      try {
        instance = factory(runtimePluginContext(workflow, descriptor, root));
      } catch (cause) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          cause,
          workflow
        );
      }
      if (!instance || typeof instance !== "object" || Array.isArray(instance) || typeof instance.then === "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("createPlugin() must return a RuntimePlugin object"),
          workflow
        );
      }
      records.push({ descriptor, instance });
    }
    return records;
  } catch (failure) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      try {
        const returned = records[index].instance.dispose?.();
        if (returned && typeof returned.then === "function") throw new TypeError("sync runtime disposal returned pending work");
      } catch (error) {
        (failure.cleanupErrors ||= []).push(runtimePluginError("VF_RUNTIME_PLUGIN_DISPOSE", records[index].descriptor, "dispose", error, workflow));
      }
    }
    throw failure;
  }
}
function invokeRuntimeHookSync(root, hook, details = {}, preserveFailure = false) {
  const summary = runtimePluginSummary(root, details);
  for (const record of root.runtimePlugins) {
    const callback = record.instance[hook];
    if (typeof callback !== "function") continue;
    try {
      const returned = callback(summary);
      if (returned && typeof returned.then === "function") throw new TypeError("sync runtime hook returned pending work");
    } catch (cause) {
      if (preserveFailure) {
        (root.cleanupErrors ||= []).push(runtimePluginError("VF_RUNTIME_PLUGIN_HOOK", record.descriptor, hook, cause, root.workflow, summary));
        continue;
      }
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_HOOK",
        record.descriptor,
        hook,
        cause,
        root.workflow,
        summary
      );
    }
  }
}
function disposeRuntimePluginsSync(root, preserveFailure = false) {
  let firstFailure;
  for (let index = root.runtimePlugins.length - 1; index >= 0; index--) {
    const record = root.runtimePlugins[index];
    try {
      const returned = record.instance.dispose?.();
      if (returned && typeof returned.then === "function") throw new TypeError("sync runtime disposal returned pending work");
    } catch (cause) {
      const error = runtimePluginError("VF_RUNTIME_PLUGIN_DISPOSE", record.descriptor, "dispose", cause, root.workflow);
      if (preserveFailure) (root.cleanupErrors ||= []).push(error);
      else if (firstFailure) (firstFailure.cleanupErrors ||= []).push(error);
      else firstFailure = error;
    }
  }
  root.runtimePlugins.length = 0;
  if (firstFailure) throw firstFailure;
}
function createRoot(workflow, schemas, normalized) {
  const instanceId = normalized.workflowInstanceId ?? Array.from(globalThis.crypto.getRandomValues(new Uint8Array(16)), (value) => value.toString(16).padStart(2, "0")).join("");
  const controller = new AbortController();
  const parentSignal = normalized.signal;
  const propagate = () => controller.abort(parentSignal.reason);
  parentSignal?.addEventListener("abort", propagate, { once: true });
  if (parentSignal?.aborted) propagate();
  const root = {
    workflow,
    schemas,
    workflowId: workflow.workflow_id,
    identity: Object.freeze({ self: () => ({ id: instanceId }) }),
    signal: controller.signal,
    traceMode: normalized.traceMode,
    onTrace: normalized.onTrace,
    statusStopping: normalized.statusStopping,
    statusUpdate: normalized.statusUpdate,
    kernelLog: normalized.kernelLog,
    workflowSession: normalized.workflowSession,
    controller,
    runtimePlugins: []
  };
  const onAbort = () => {
    try {
      root.statusStopping?.();
    } catch (error) {
      root.observationFailure ||= error;
    }
  };
  root.signal.addEventListener("abort", onAbort, { once: true });
  root.unsubscribeSignal = () => {
    root.signal.removeEventListener("abort", onAbort);
    parentSignal?.removeEventListener("abort", propagate);
  };
  return root;
}
function prepareWorkflowInvocation(workflow, schemas, options, entryMode) {
  let normalized;
  try {
    normalized = normalizeOptions(workflow, options);
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
  const root = createRoot(workflow, schemas, normalized);
  try {
    throwIfAborted(root.signal, workflow);
    emitTrace(root, "run_start", {}, true);
    return root;
  } catch (cause) {
    root.unsubscribeSignal();
    throw ensureErrorLocation(cause, workflow, []);
  }
}
function assertWorkflowAbi(workflow) {
  if (workflow.abi_version !== VIBEFLOW_WORKFLOW_ABI) {
    throw vfError(
      "VF_INTERNAL",
      `generated workflow ABI '${workflow.abi_version}' is unsupported`,
      workflow
    );
  }
}
function createStaticWorkflowSync(workflowMetadata, schemaCatalog, runtimePluginDescriptors, runtimePluginFactories, executeRoot) {
  const workflow = deepFreeze(workflowMetadata);
  const plugins = deepFreeze(runtimePluginDescriptors);
  assertWorkflowAbi(workflow);
  return function invokeWorkflow(inputs, options) {
    const root = prepareWorkflowInvocation(
      workflow,
      schemaCatalog,
      options,
      "sync"
    );
    let failed = false;
    let primaryFailure;
    try {
      root.runtimePlugins = createRuntimePluginsSync(
        workflow,
        plugins,
        runtimePluginFactories,
        root
      );
      invokeRuntimeHookSync(root, "beforeRun", {
        inputKeys: Object.keys(inputs || {}).sort()
      });
      const result = executeRoot(inputs, root, []);
      throwIfAborted(root.signal, workflow);
      invokeRuntimeHookSync(root, "afterRun", {
        outputKeys: Object.keys(result.publicOutputs || {}).sort()
      });
      emitTrace(root, "run_end", {}, true);
      return result.publicOutputs;
    } catch (cause) {
      failed = true;
      const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
      primaryFailure = failure;
      if (failure.code !== "VF_TRACE_SINK_FAILED") {
        try {
          emitTrace(root, "run_failed", {
            code: failure.code,
            message: failure.message
          }, true);
        } catch {
        }
      }
      invokeRuntimeHookSync(root, "runFailed", {
        code: failure.code,
        message: failure.message
      }, true);
      throw ensureErrorLocation(failure, workflow, []);
    } finally {
      try {
        disposeRuntimePluginsSync(root, failed);
      } finally {
        if (primaryFailure && root.cleanupErrors?.length) (primaryFailure.cleanupErrors ||= []).push(...root.cleanupErrors);
        root.unsubscribeSignal();
      }
    }
  };
}
function __vfSnapshotInfo(info) {
  const active = /* @__PURE__ */ new Set();
  function copy(value) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || active.has(value)) throw new TypeError("run info must contain JSON values");
    const array = Array.isArray(value);
    if (!array && ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
      throw new TypeError("run info must contain plain JSON objects");
    }
    active.add(value);
    let result;
    if (array) {
      result = Array.from(value, (item) => copy(item));
    } else {
      result = Object.fromEntries(Object.entries(value).map(([key, item]) => [key, copy(item)]));
    }
    active.delete(value);
    return Object.freeze(result);
  }
  if (!Array.isArray(info) || info.some((item) => !item || typeof item !== "object" || Array.isArray(item))) {
    throw new TypeError("run info must be an array of JSON objects");
  }
  return copy(info);
}
function __vfObservation(options) {
  const raw = options ?? {};
  const interval = raw.statusIntervalMs ?? 6e4;
  if (!Number.isFinite(interval) || interval <= 0) throw new TypeError("statusIntervalMs must be positive finite milliseconds");
  if (raw.onStatus !== void 0 && typeof raw.onStatus !== "function") throw new TypeError("onStatus must be a function");
  let info = Object.freeze([]);
  let state = "starting";
  let error = null;
  let closed = false;
  let timer;
  let sink;
  const record = () => Object.freeze({ state, error, updated_at: (/* @__PURE__ */ new Date()).toISOString(), info });
  const publish = () => {
    const snapshot = record();
    sink?.publish(snapshot);
    raw.onStatus?.(snapshot);
  };
  const observer = {
    updateInfo(value) {
      if (closed) throw new Error("cannot update info after the run has finished");
      info = __vfSnapshotInfo(value);
      sink?.cache(record());
    },
    kernel(event) {
      sink?.kernel(JSON.stringify(event));
    },
    run(callback) {
      return sink ? sink.run(callback) : callback();
    },
    stopping() {
      if (closed || state === "stopping") return;
      state = "stopping";
      publish();
    },
    start() {
      if (typeof __vfCreateFileObservation === "function") {
        sink = __vfCreateFileObservation(raw, record(), interval);
      }
      publish();
      state = "running";
      publish();
      if (raw.onStatus) {
        timer = setInterval(() => {
          try {
            raw.onStatus(record());
          } catch (failure) {
            try {
              observer.finish(failure);
            } catch {
            }
            throw failure;
          }
        }, interval);
        timer.unref?.();
      }
    },
    finish(failure) {
      if (closed) return;
      if (timer) clearInterval(timer);
      state = failure ? "failed" : "succeeded";
      if (failure) {
        const messages = [];
        const seen = /* @__PURE__ */ new Set();
        for (let cause = failure; cause && !seen.has(cause); cause = cause.cause) {
          seen.add(cause);
          messages.push(String(cause.message || cause));
        }
        error = messages.join(": ");
      } else error = null;
      if (failure) sink?.kernel(String(failure.stack || failure));
      closed = true;
      try {
        sink?.finish(record());
        raw.onStatus?.(record());
      } catch (cause) {
        if (!failure) {
          state = "failed";
          error = String(cause?.message || cause);
          try {
            sink?.finish(record());
          } catch {
          }
        }
        throw cause;
      } finally {
        sink?.close();
      }
    }
  };
  return observer;
}
function __vfObservedOptions(options, observer) {
  return {
    ...options ?? {},
    __vfStatusUpdate: (info) => observer.updateInfo(info),
    __vfKernelLog: (event) => observer.kernel(event),
    __vfStatusStopping: () => observer.stopping()
  };
}
function __vfObserveSync(invoke, inputs, options) {
  if (options !== void 0 && (!options || typeof options !== "object" || Array.isArray(options))) return invoke(inputs, options);
  const observer = __vfObservation(options);
  try {
    observer.start();
    const outputs = observer.run(() => invoke(inputs, __vfObservedOptions(options, observer)));
    observer.finish(null);
    return outputs;
  } catch (error) {
    try {
      observer.finish(error);
    } catch {
    }
    throw error;
  }
}
var NodeExecution = class {
  constructor(parentSignal) {
    this.controller = new AbortController();
    this.signal = this.controller.signal;
    this.operations = /* @__PURE__ */ new Set();
    this.active = true;
    this.stopping = false;
    this.parentSignal = parentSignal;
    this.abort = () => this.controller.abort(parentSignal.reason);
    parentSignal.addEventListener("abort", this.abort, { once: true });
    if (parentSignal.aborted) this.abort();
  }
  own(promise) {
    this.operations.add(promise);
    promise.then(() => this.operations.delete(promise), () => this.operations.delete(promise));
    return promise;
  }
  exitSync() {
    this.stopping = true;
    this.controller.abort("Node exiting");
    this.active = false;
    this.parentSignal.removeEventListener("abort", this.abort);
  }
  async exit() {
    this.stopping = true;
    this.controller.abort("Node exiting");
    const failures = [];
    try {
      while (this.operations.size) {
        const outcomes = await Promise.allSettled([...this.operations]);
        for (const outcome of outcomes) {
          if (outcome.status === "rejected" && (outcome.reason?.code !== "VF_ABORTED" || outcome.reason?.cleanupErrors?.length))
            failures.push(outcome.reason);
        }
      }
    } finally {
      this.active = false;
      this.parentSignal.removeEventListener("abort", this.abort);
      this.operations.clear();
    }
    if (failures.length) {
      const first = failures[0];
      if (failures.length > 1) (first.cleanupErrors ||= []).push(...failures.slice(1));
      throw first;
    }
  }
};
function openStaticBlock(program, callIndex, initial, root, path, entry, workflow) {
  const [blockIndex, , params, children] = program.calls[callIndex];
  const [, nodes, variants] = program.blocks[blockIndex];
  const [starts, checks] = variants[entry ?? 0];
  const state = createStaticState(workflow, initial, root, path);
  for (let index = 0; index < nodes.length; index += 1) {
    const node = nodes[index][0];
    initializeInbox(state, node.id);
    const seed = checks[index]?.[0];
    if (seed !== null && seed !== void 0) seedInbox(state, node.id, seed);
  }
  return {
    nodes,
    params,
    children,
    checks,
    state,
    ready: [...starts],
    queued: new Set(starts),
    pendingDispatches: /* @__PURE__ */ new Map(),
    activeDispatches: /* @__PURE__ */ new Map(),
    completed: false
  };
}
function staticNodeAvailable(block, index) {
  const check = block.checks[index];
  if (check === void 0) return false;
  const [, policy, edges, required] = check;
  const { state } = block;
  if (policy === "all" && !edges.every((edge) => state.activeEdges.has(edge))) return false;
  if (policy === "any_active" && !edges.some((edge) => state.activeEdges.has(edge))) return false;
  const inbox = state.inboxes[block.nodes[index][0].id];
  return required.every((type) => inbox.some((item) => item.type === type));
}
function startStaticNode(block, index, node) {
  const { state, pendingDispatches, activeDispatches } = block;
  const dispatches = pendingDispatches.get(index);
  pendingDispatches.delete(index);
  if (dispatches) {
    for (const dispatch of dispatches) dispatch.active += 1;
    activeDispatches.set(index, dispatches);
  }
  if (state.stepCount >= state.workflow.max_steps) {
    throw vfError("VF_MAX_STEPS", "workflow exceeded max_steps", state.workflow);
  }
  state.stepCount += 1;
  const inputs = prepareStaticNode(node, state);
  const [, policy, edges] = block.checks[index];
  if (policy === "all") {
    for (const edge of edges) state.activeEdges.delete(edge);
  }
  return inputs;
}
function releaseStaticDispatch(block, index) {
  for (const dispatch of block.activeDispatches.get(index) || []) dispatch.active -= 1;
  block.activeDispatches.delete(index);
}
function activateStaticRoutes(block, index, outputs, inputs) {
  const [node, , routes, terminal, limit] = block.nodes[index];
  const { state, pendingDispatches, ready, queued } = block;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(node, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  const targets = [];
  for (const [target, edge, accepts, condition] of routes) {
    if (condition !== null && !conditionMatches(condition, values)) continue;
    const targetId = block.nodes[target][0].id;
    if (edge !== null) {
      state.activeEdges.add(edge);
      targets.push(target);
      emitTrace(state.root, "edge_activated", { source: node.id, target: targetId, path: state.path });
    }
    if (accepts !== null) deliverStatic(envelopes, state, targetId, accepts);
  }
  if (terminal) {
    block.completed = true;
    return;
  }
  if (limit !== null) {
    const dispatch = { limit, active: 0 };
    for (const target of targets) {
      if (!pendingDispatches.has(target)) pendingDispatches.set(target, /* @__PURE__ */ new Set());
      pendingDispatches.get(target).add(dispatch);
    }
  }
  enqueueStaticTargets(targets, ready, queued);
}
function staticNodeLocation(node, state) {
  return { nodeId: node.id, nodePath: nodePath(state, node.id), blockPath: formatBlockPath(state.path) };
}
function staticFailureDetails(location, failure) {
  return { ...location, code: failure.code, message: failure.message };
}
function executeStaticBlockSync(program, call, initial, root, path, entry) {
  const location = { blockPath: formatBlockPath(path), path: [...path] };
  const workflow = staticBlockMetadata(program, call, root, entry);
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { ...location, path: [...path] });
    const block = openStaticBlock(program, call, initial, root, path, entry, workflow);
    const { state, ready, queued, nodes } = block;
    while (ready.length) {
      const index = ready.shift();
      queued.delete(index);
      if (staticNodeAvailable(block, index)) {
        const [node, [execute, target]] = nodes[index];
        const event = { ...staticNodeLocation(node, state), type: node.definition_id };
        try {
          const inputs = startStaticNode(block, index, node);
          invokeRuntimeHookSync(root, "beforeNode", event);
          const outputs = execute(program, block, index, node, target, inputs);
          finishStaticNode(node, state);
          invokeRuntimeHookSync(root, "afterNode", { ...event, outputKeys: Object.keys(outputs || {}).sort() });
          activateStaticRoutes(block, index, outputs, inputs);
        } catch (cause) {
          const failure = ensureErrorLocation(cause, workflow, path, node.id);
          invokeRuntimeHookSync(root, "nodeFailed", staticFailureDetails(staticNodeLocation(node, state), failure), true);
          throw failure;
        }
      }
      releaseStaticDispatch(block, index);
    }
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", location);
    return { publicOutputs, candidates: state.candidates, completed: block.completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, workflow, path);
    invokeRuntimeHookSync(root, "blockFailed", staticFailureDetails(location, failure), true);
    throw failure;
  }
}
function staticBlockMetadata(program, call, root, entry) {
  if (entry !== void 0) return root.workflow;
  const [block, workflowId] = program.calls[call];
  return { ...program.blocks[block][0], workflow_id: workflowId };
}
function executeStaticNodeSync(_program, block, index, node, implementation, inputs) {
  return invokeStaticImplementationSync(implementation, node, block.params[index], inputs, block.state);
}
function staticNodesetInputs(program, child, outputs, inputs, state, event) {
  emitTrace(state.root, "nodeset_enter", { nodeId: event.nodeId, nodePath: event.nodePath }, true);
  if (typeof outputs === "string") {
    throw vfError("VF_OUTPUT_CARDINALITY", outputs, state.workflow, { nodePath: event.nodePath });
  }
  const metadata = program.blocks[program.calls[child][0]][0];
  return rawInputsForChild(metadata.inputs, inputs, state.workflow, event.nodeId);
}
function staticNodesetOutputs(node, mapping, child, state, event) {
  const outputs = outputsFromChild(node, mapping, child, state);
  emitTrace(state.root, "nodeset_exit", { nodeId: event.nodeId, nodePath: event.nodePath }, true);
  return outputs;
}
function executeStaticNodesetSync(program, block, index, node, mapping, inputs) {
  const { state } = block;
  const child = block.children[index];
  const event = staticNodeLocation(node, state);
  try {
    invokeRuntimeHookSync(state.root, "beforeNodeset", event);
    const initial = staticNodesetInputs(program, child, mapping, inputs, state, event);
    const result = executeStaticBlockSync(program, child, initial, state.root, [...state.path, node.id]);
    const outputs = staticNodesetOutputs(node, mapping, result, state, event);
    invokeRuntimeHookSync(state.root, "afterNodeset", event);
    return outputs;
  } catch (cause) {
    const failure = ensureErrorLocation(cause, state.workflow, state.path, node.id);
    invokeRuntimeHookSync(state.root, "nodesetFailed", staticFailureDetails(event, failure), true);
    throw failure;
  }
}
function staticLoopValue(values, key, label, code, state, event) {
  if (!Object.prototype.hasOwnProperty.call(values, key)) {
    throw vfError(code, `${label} '${key}' is unavailable`, state.workflow, { nodePath: event.nodePath });
  }
  return values[key];
}
function openStaticLoop(node, spec, inputs, state) {
  const event = { nodeId: node.id, nodePath: nodePath(state, node.id) };
  emitTrace(state.root, "loop_enter", event, true);
  const values = dictionary();
  for (const [type, input] of Object.entries(inputs)) {
    setOwn(values, type, Array.isArray(input) ? input.map(valueFromEnvelope) : valueFromEnvelope(input));
    for (const item of Array.isArray(input) ? input : [input]) {
      if (item?.key) setOwn(values, item.key, item.value);
      if (item?.type) setOwn(values, item.type, item.value);
    }
  }
  for (const carry of spec.carry) {
    setOwn(values, carry.as, staticLoopValue(values, carry.from, "loop carry source", "VF_INPUT_REQUIRED", state, event));
  }
  return { event, values, spec, state, stopped: false };
}
function staticLoopInputs(loop, iteration) {
  const { event, values, spec, state } = loop;
  throwIfAborted(state.root.signal, state.workflow, event.nodePath);
  const initial = dictionary();
  for (const carry of spec.carry) setOwn(initial, carry.as, values[carry.as]);
  emitTrace(state.root, "loop_iteration", { ...event, iteration });
  return initial;
}
function updateStaticLoop(loop, child, iteration) {
  const { event, values, spec, state } = loop;
  for (const [key, value] of Object.entries(resultValues(child))) setOwn(values, key, value);
  for (const carry of spec.carry) {
    setOwn(values, carry.as, staticLoopValue(values, carry.update, "loop carry update", "VF_OUTPUT_KEYS", state, event));
  }
  for (const collect of spec.collect) {
    if (collect.mode !== "all") throw vfError("VF_INTERNAL", `unsupported loop collect mode '${collect.mode}'`, state.workflow);
    const value = staticLoopValue(values, collect.from, "loop collect source", "VF_OUTPUT_KEYS", state, event);
    if (!Array.isArray(values[collect.as])) setOwn(values, collect.as, []);
    values[collect.as].push(value);
  }
  const count = iteration + 1;
  setOwn(values, "loop.iterations", count);
  loop.stopped = count >= (spec.stop_after ?? Infinity);
  if (spec.stop_when) {
    const key = spec.stop_when.from;
    const value = staticLoopValue(values, key, "loop stop source", "VF_OUTPUT_KEYS", state, event);
    if (typeof value !== "boolean") {
      throw vfError("VF_OUTPUT_SCHEMA", `loop stop source '${key}' must be boolean`, state.workflow, { nodePath: event.nodePath });
    }
    loop.stopped ||= value === spec.stop_when.equals;
  }
}
function finishStaticLoop(loop, node) {
  const { event, values, spec, state, stopped } = loop;
  if (!stopped && spec.max_iterations !== null && (spec.stop_after || spec.stop_when)) {
    throw vfError(
      "VF_MAX_STEPS",
      `loop node '${node.id}' exceeded max_iterations=${spec.max_iterations}`,
      state.workflow,
      { nodePath: event.nodePath }
    );
  }
  const outputs = dictionary();
  for (const output of spec.outputs) {
    setOwn(outputs, output.as, staticLoopValue(values, output.from, "loop output source", "VF_OUTPUT_KEYS", state, event));
  }
  emitTrace(state.root, "loop_exit", event, true);
  return validateNodeOutputs(node, outputs, state);
}
function executeStaticLoopSync(program, block, index, node, spec, inputs) {
  const { state } = block;
  const child = block.children[index];
  const loop = openStaticLoop(node, spec, inputs, state);
  for (let i = 0; i < (spec.max_iterations ?? Infinity) && !loop.stopped; i += 1) {
    const initial = staticLoopInputs(loop, i);
    const result = executeStaticBlockSync(program, child, initial, state.root, [...state.path, node.id, `iter_${i}`]);
    updateStaticLoop(loop, result, i);
  }
  return finishStaticLoop(loop, node);
}
var __vfRuntimePluginDescriptors = [];
var __vfRuntimePluginFactories = [];
var __vfData = deepFreeze([{ "$schema": "https://json-schema.org/draft/2020-12/schema", "additionalProperties": true, "type": "object" }, { "$schema": "https://json-schema.org/draft/2020-12/schema", "type": "boolean" }, { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts" }, ["era.expression.sequence.state"], [{ "cardinality": "exactly_one", "type": "era.expression.sequence.state" }], ["era.expression.operation.current"], ["era.expression.operation.current", "era.expression.value"], ["era.expression.ast_frame.state"], { "$schema": "https://json-schema.org/draft/2020-12/schema" }, { "$schema": "https://json-schema.org/draft/2020-12/schema", "additionalProperties": true, "properties": { "compactedOperations": { "type": "array" }, "containsAutomaticRandom": { "type": "boolean" }, "diagnostics": { "type": "array" }, "finalState": { "type": "object" }, "nextDrawOffset": { "minimum": 0, "type": "integer" }, "randomDrawsConsumed": { "minimum": 0, "type": "integer" } }, "required": ["finalState", "diagnostics", "compactedOperations", "randomDrawsConsumed", "nextDrawOffset", "containsAutomaticRandom"], "type": "object" }, ["era.expression.request"], [{ "cardinality": "exactly_one", "type": "era.expression.request" }], ["era.expression.request.normalized"], [{ "cardinality": "exactly_one", "type": "era.expression.request.normalized" }], ["era.expression.request.normalized", "era.expression.function_library.compiled", "era.expression.operations.parsed"], ["era.expression.function_library.parsed"], ["era.expression.function_library.parsed", "era.expression.function_library.dependencies"], ["era.expression.function_library.parsed", "era.expression.function_library.acyclic_graph"], ["era.expression.function_library.dependencies", "era.expression.function_library.purity"], ["era.expression.function_library.call_graph"], ["era.expression.sequence.state", "era.expression.execution.result"], ["era.expression.sequence.state", "era.expression.execution.result", "era.expression.symbolic.layer"], ["era.expression.symbolic.layer"], [{ "key": "expression_response", "type": "era.expression.response" }], ["era.expression.response"], ["era.workflow.packet"], ["era.workflow.entry_return"], { "$schema": "https://json-schema.org/draft/2020-12/schema", "items": { "type": "object" }, "type": "array" }, { "$schema": "https://json-schema.org/draft/2020-12/schema", "additionalProperties": false, "properties": { "encoding": { "const": "era-values-v1" }, "payload": { "type": "string" } }, "required": ["encoding", "payload"], "type": "object" }]);
var __vfSchemaCatalog = deepFreeze({ "era.expression.ast_frame.state": __vfData[0], "era.expression.execution.result": __vfData[0], "era.expression.function_library.acyclic_graph": __vfData[0], "era.expression.function_library.call_graph": __vfData[0], "era.expression.function_library.compiled": __vfData[0], "era.expression.function_library.dependencies": __vfData[0], "era.expression.function_library.parsed": __vfData[27], "era.expression.function_library.purity": __vfData[0], "era.expression.operation.current": __vfData[0], "era.expression.operations.parsed": __vfData[27], "era.expression.request": __vfData[8], "era.expression.request.normalized": __vfData[0], "era.expression.response": __vfData[9], "era.expression.sequence.done": __vfData[1], "era.expression.sequence.state": __vfData[0], "era.expression.symbolic.layer": __vfData[0], "era.expression.value": __vfData[0], "era.workflow.entry_return": { "$schema": "https://json-schema.org/draft/2020-12/schema", "enum": ["direct", "protocol"], "type": "string" }, "era.workflow.packet": __vfData[28] });
var __vfProgram = { blocks: [[{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "select_next_operation", "initialize_ast_frames", "evaluate_ast", "commit_operation_result", "end"], "inputs": [{ "key": "sequence_state", "type": "era.expression.sequence.state", "required": true, "schema": __vfData[0] }], "outputs": [{ "type": "era.expression.sequence.state", "cardinality": "exactly_one", "as": "sequenceStateNext", "schema": __vfData[0] }, { "type": "era.expression.sequence.done", "cardinality": "exactly_one", "as": "sequenceDone", "schema": __vfData[1] }, { "type": "era.expression.execution.result", "cardinality": "exactly_one", "as": "operationExecutionResult", "schema": __vfData[0] }], "max_steps": 8, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [[1, 0, __vfData[3], null]], false, null], [{ "id": "select_next_operation", "definition_id": "era.expression.select_next_operation", "requires": __vfData[4], "provides": [{ "key": "current_operation", "type": "era.expression.operation.current" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/select_next_operation.ts" } }, [executeStaticNodeSync, selectNextOperationNode], [[2, 1, __vfData[5], null], [4, null, __vfData[6], null]], false, null], [{ "id": "initialize_ast_frames", "definition_id": "era.expression.initialize_ast_frames", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.operation.current" }], "provides": [{ "key": "ast_frame_state", "type": "era.expression.ast_frame.state" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/execution/initialize_ast_frames.ts" } }, [executeStaticNodeSync, initializeAstFramesNode], [[3, 2, __vfData[7], null]], false, null], [{ "id": "evaluate_ast", "definition_id": "era.expression.evaluate_ast", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.ast_frame.state" }], "provides": [{ "key": "evaluated_expression", "type": "era.expression.value" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/execution/evaluate_ast.ts" } }, [executeStaticNodeSync, run], [[4, 3, __vfData[6], null]], false, null], [{ "id": "commit_operation_result", "definition_id": "era.expression.commit_operation_result", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.operation.current" }, { "cardinality": "exactly_one", "type": "era.expression.value" }], "provides": [{ "key": "sequence_state_next", "type": "era.expression.sequence.state" }, { "key": "sequence_done", "type": "era.expression.sequence.done" }, { "key": "operation_execution_result", "type": "era.expression.execution.result" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/execution/commit_operation_result.ts" } }, [executeStaticNodeSync, commitOperationResultNode], [[5, 4, [], null]], false, null], [{ "id": "end", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [], true, null]], [[[0], [[null, null, [], []], [__vfData[3], null, [], __vfData[3]], [null, null, [], __vfData[5]], [null, null, [], __vfData[7]], [null, null, [], __vfData[6]], [null, null, [], []]]]]], [{ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "validate_request", "validate_random_context", "parse_function_definitions", "extract_function_dependencies", "validate_function_purity", "build_function_call_graph", "reject_recursive_functions", "compile_callable_functions", "parse_operations", "initialize_sequence_state", "operation_loop", "derive_symbolic_layer", "guard_random_compaction", "normalize_compaction", "end"], "inputs": [{ "key": "expression_request", "type": "era.expression.request", "required": true, "schema": __vfData[8] }], "outputs": [{ "type": "era.expression.response", "cardinality": "exactly_one", "as": "expressionResponse", "schema": __vfData[9] }], "max_steps": 19, "entry_mode": "sync" }, [[{ "id": "start", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [[1, 0, __vfData[10], null]], false, null], [{ "id": "validate_request", "definition_id": "era.expression.validate_request", "requires": __vfData[11], "provides": [{ "key": "normalized_expression_request", "type": "era.expression.request.normalized" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/validate_request.ts" } }, [executeStaticNodeSync, validateRequestNode], [[2, 1, __vfData[12], null]], false, null], [{ "id": "validate_random_context", "definition_id": "era.expression.validate_random_context", "requires": __vfData[13], "provides": [{ "key": "validated_random_request", "type": "era.expression.request.normalized" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/validate_random_context.ts" } }, [executeStaticNodeSync, validateRandomContextNode], [[3, 2, __vfData[12], null], [9, 8, __vfData[12], null], [10, null, __vfData[14], null]], false, 8], [{ "id": "parse_function_definitions", "definition_id": "era.expression.parse_function_definitions", "requires": __vfData[13], "provides": [{ "key": "parsed_function_library", "type": "era.expression.function_library.parsed" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/parse_function_definitions.ts" } }, [executeStaticNodeSync, parseFunctionDefinitionsNode], [[4, 3, __vfData[15], null], [5, null, __vfData[16], null], [8, null, __vfData[17], null]], false, null], [{ "id": "extract_function_dependencies", "definition_id": "era.expression.extract_function_dependencies", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.function_library.parsed" }], "provides": [{ "key": "function_dependencies", "type": "era.expression.function_library.dependencies" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/extract_function_dependencies.ts" } }, [executeStaticNodeSync, extractFunctionDependenciesNode], [[5, 4, __vfData[16], null], [6, null, __vfData[18], null]], false, null], [{ "id": "validate_function_purity", "definition_id": "era.expression.validate_function_purity", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.function_library.parsed" }, { "cardinality": "exactly_one", "type": "era.expression.function_library.dependencies" }], "provides": [{ "key": "function_purity_report", "type": "era.expression.function_library.purity" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/validate_function_purity.ts" } }, [executeStaticNodeSync, validateFunctionPurityNode], [[6, 5, __vfData[18], null]], false, null], [{ "id": "build_function_call_graph", "definition_id": "era.expression.build_function_call_graph", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.function_library.dependencies" }, { "cardinality": "exactly_one", "type": "era.expression.function_library.purity" }], "provides": [{ "key": "function_call_graph", "type": "era.expression.function_library.call_graph" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/build_function_call_graph.ts" } }, [executeStaticNodeSync, buildFunctionCallGraphNode], [[7, 6, __vfData[19], null]], false, null], [{ "id": "reject_recursive_functions", "definition_id": "era.expression.reject_recursive_functions", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.function_library.call_graph" }], "provides": [{ "key": "acyclic_function_graph", "type": "era.expression.function_library.acyclic_graph" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/reject_recursive_functions.ts" } }, [executeStaticNodeSync, rejectRecursiveFunctionsNode], [[8, 7, __vfData[17], null]], false, null], [{ "id": "compile_callable_functions", "definition_id": "era.expression.compile_callable_functions", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.function_library.parsed" }, { "cardinality": "exactly_one", "type": "era.expression.function_library.acyclic_graph" }], "provides": [{ "key": "compiled_function_library", "type": "era.expression.function_library.compiled" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/compile_callable_functions.ts" } }, [executeStaticNodeSync, compileCallableFunctionsNode], [[10, 14, __vfData[14], null]], false, null], [{ "id": "parse_operations", "definition_id": "era.expression.parse_operations", "requires": __vfData[13], "provides": [{ "key": "parsed_operations", "type": "era.expression.operations.parsed" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/parse_operations.ts" } }, [executeStaticNodeSync, parseOperationsNode], [[10, 15, __vfData[14], null]], false, null], [{ "id": "initialize_sequence_state", "definition_id": "era.expression.initialize_random_sequence_state", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.request.normalized" }, { "cardinality": "exactly_one", "type": "era.expression.function_library.compiled" }, { "cardinality": "exactly_one", "type": "era.expression.operations.parsed" }], "provides": [{ "key": "sequence_state", "type": "era.expression.sequence.state" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/initialize_random_sequence_state.ts" } }, [executeStaticNodeSync, initializeRandomSequenceStateNode], [[11, 9, __vfData[3], null], [12, null, __vfData[20], null], [14, null, __vfData[21], null]], false, null], [{ "id": "operation_loop", "definition_id": "vibeflow.loop.while", "requires": __vfData[4], "provides": [{ "key": "numeric_execution", "type": "era.expression.execution.result" }] }, [executeStaticLoopSync, { "carry": [{ "as": "sequence_state", "from": "era.expression.sequence.state", "update": "sequenceStateNext" }], "collect": [], "max_iterations": null, "outputs": [{ "as": "numeric_execution", "from": "operationExecutionResult" }], "stop_when": { "equals": true, "from": "sequenceDone" } }], [[12, 10, __vfData[20], null], [14, null, __vfData[21], null]], false, null], [{ "id": "derive_symbolic_layer", "definition_id": "era.expression.derive_symbolic_layer", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.sequence.state" }, { "cardinality": "exactly_one", "type": "era.expression.execution.result" }], "provides": [{ "key": "symbolic_layer", "type": "era.expression.symbolic.layer" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/derive_symbolic_layer.ts" } }, [executeStaticNodeSync, deriveSymbolicLayerNode], [[13, 11, __vfData[22], null]], false, null], [{ "id": "guard_random_compaction", "definition_id": "era.expression.guard_random_compaction", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.symbolic.layer" }], "provides": [{ "key": "random_guarded_symbolic_layer", "type": "era.expression.symbolic.layer" }], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/guard_random_compaction.ts" } }, [executeStaticNodeSync, guardRandomCompactionNode], [[14, 12, __vfData[21], null]], false, null], [{ "id": "normalize_compaction", "definition_id": "era.expression.normalize_compaction", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.sequence.state" }, { "cardinality": "exactly_one", "type": "era.expression.execution.result" }, { "cardinality": "exactly_one", "type": "era.expression.symbolic.layer" }], "provides": __vfData[23], "source": { "completion": "immediate", "export": "run", "language": "typescript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/normalize_compaction.ts" } }, [executeStaticNodeSync, normalizeCompactionNode], [[15, 13, [], null]], false, null], [{ "id": "end", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [], true, null]], [[[0], [[null, null, [], []], [__vfData[10], null, [], __vfData[10]], [null, null, [], __vfData[12]], [null, null, [], __vfData[12]], [null, null, [], __vfData[15]], [null, null, [], __vfData[16]], [null, null, [], __vfData[18]], [null, null, [], __vfData[19]], [null, null, [], __vfData[17]], [null, null, [], __vfData[12]], [null, "all", [14, 15], __vfData[14]], [null, null, [], __vfData[3]], [null, null, [], __vfData[20]], [null, null, [], __vfData[22]], [null, null, [], __vfData[21]], [null, null, [], []]]]]], [null, [[{ "id": "start", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [[7, 3, __vfData[10], null]], false, null], [{ "id": "execute_layer", "definition_id": "era.expression.execute_layer", "requires": __vfData[11], "provides": __vfData[23] }, [executeStaticNodesetSync, [{ "alias": "expressionResponse", "provider": "expression_response" }]], [[8, 5, null, null], [5, null, __vfData[24], null]], false, null], [{ "id": "end", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [], true, null], [{ "id": "protocol_start", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [[4, 0, __vfData[25], null]], false, null], [{ "id": "decode_request", "definition_id": "era.workflow.decode_expression", "requires": [{ "cardinality": "exactly_one", "type": "era.workflow.packet" }], "provides": [{ "key": "request", "type": "era.expression.request" }, { "key": "entry_return", "type": "era.workflow.entry_return" }], "source": { "completion": "immediate", "export": "Decode", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, Decode], [[1, 1, __vfData[10], null], [8, null, __vfData[26], null]], false, null], [{ "id": "encode_response", "definition_id": "era.workflow.encode_expression", "requires": [{ "cardinality": "exactly_one", "type": "era.expression.response" }], "provides": [{ "key": "packet", "type": "era.workflow.packet" }], "source": { "completion": "immediate", "export": "Encode", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, Encode], [[6, 2, [], null]], false, null], [{ "id": "protocol_end", "definition_id": "era.expression.terminal", "requires": [], "provides": [], "source": __vfData[2] }, [executeStaticNodeSync, terminalNode], [], true, null], [{ "id": "prepare_direct_request", "definition_id": "era.expression.boundary.PrepareDirectRequest", "requires": __vfData[11], "provides": [{ "key": "prepared_request", "type": "era.expression.request" }, { "key": "entry_return", "type": "era.workflow.entry_return" }], "source": { "completion": "immediate", "export": "PrepareDirectRequest", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, PrepareDirectRequest], [[1, 4, __vfData[10], null], [8, null, __vfData[26], null]], false, null], [{ "id": "select_entry_return", "definition_id": "era.expression.boundary.SelectEntryReturn", "requires": [{ "cardinality": "exactly_one", "type": "era.workflow.entry_return" }], "provides": [{ "key": "return_route", "type": "era.workflow.entry_return" }], "source": { "completion": "immediate", "export": "SelectEntryReturn", "language": "javascript", "module": "/home/rockingsisyphus/projects/ERA-vibeFlow/javascript_project/expression/nodes/workflow/boundary.mjs" } }, [executeStaticNodeSync, SelectEntryReturn], [[2, 6, null, { "key": "return_route", "literal": "direct", "operator": "==" }], [5, 7, null, { "key": "return_route", "literal": "protocol", "operator": "==" }]], false, 8]], [[[0], { "0": [null, null, [], []], "1": [null, null, [], __vfData[10]], "2": [null, "any_active", [6], []], "5": [null, "any_active", [7], __vfData[24]], "6": [null, null, [], []], "7": [__vfData[10], null, [], __vfData[10]], "8": [null, null, [], __vfData[26]] }], [[3], { "1": [null, null, [], __vfData[10]], "2": [null, "any_active", [6], []], "3": [null, null, [], []], "4": [__vfData[25], null, [], __vfData[25]], "5": [null, "any_active", [7], __vfData[24]], "6": [null, null, [], []], "8": [null, null, [], __vfData[26]] }]]]], calls: [[0, "era.expression.execute_layer.operation_loop", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }], {}], [1, "era.expression.execute_layer", [{ "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "11": 0 }], [2, "era.expression", [{ "_global": {} }, {}, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }, { "_global": {} }], { "1": 1 }]] };
var __vfEntryInvoke_0 = createStaticWorkflowSync({ "abi_version": "vibeflow.workflow.v12", "node_order": ["start", "execute_layer", "end", "encode_response", "protocol_end", "prepare_direct_request", "select_entry_return"], "inputs": [{ "key": "expression_request", "type": "era.expression.request", "required": true, "schema": __vfData[8] }], "outputs": [{ "type": "era.expression.response", "cardinality": "exactly_one", "as": "expressionResponse", "schema": __vfData[9] }], "max_steps": 9, "entry_mode": "sync", "workflow_id": "era.expression" }, __vfSchemaCatalog, __vfRuntimePluginDescriptors, __vfRuntimePluginFactories, (inputs, root, path) => executeStaticBlockSync(__vfProgram, 2, inputs, root, path, 0));
var __vfEntryInvoke_1 = createStaticWorkflowSync({ "abi_version": "vibeflow.workflow.v12", "node_order": ["execute_layer", "end", "protocol_start", "decode_request", "encode_response", "protocol_end", "select_entry_return"], "inputs": [{ "key": "wire_request", "type": "era.workflow.packet", "required": true, "schema": __vfData[28] }], "outputs": [{ "type": "era.workflow.packet", "cardinality": "exactly_one", "as": "wireResponse", "schema": __vfData[28] }], "max_steps": 9, "entry_mode": "sync", "workflow_id": "era.expression" }, __vfSchemaCatalog, __vfRuntimePluginDescriptors, __vfRuntimePluginFactories, (inputs, root, path) => executeStaticBlockSync(__vfProgram, 2, inputs, root, path, 1));
var __vfEntryInvocations = /* @__PURE__ */ new Map([["main", __vfEntryInvoke_0], ["protocol", __vfEntryInvoke_1]]);
function __vfInvokeWorkflow(inputs, options = {}) {
  const invoke = __vfEntryInvocations.get(options.entry ?? "main");
  if (!invoke) throw new Error("select a workflow entry: " + [...__vfEntryInvocations.keys()].join(", "));
  return invoke(inputs, options);
}
function runWorkflow(inputs, options) {
  return __vfObserveSync(__vfInvokeWorkflow, inputs, options);
}
var workflowDescriptor = deepFreeze({ "workflow": { "root": "era-expression", "path": "configs/era.expression.jsonc" }, "entry_mode": "sync", "calls": [], "entries": { "main": { "inputs": [{ "key": "expression_request", "type": "era.expression.request", "required": true, "display_name": "\u521D\u59CB\u53D8\u91CF\u3001\u51FD\u6570\u53CA\u9700\u8981\u4F9D\u6B21\u8BA1\u7B97\u7684\u516C\u5F0F" }], "outputs": [{ "type": "era.expression.response", "cardinality": "exactly_one", "as": "expressionResponse", "display_name": "\u516C\u5F0F\u8BA1\u7B97\u7684\u6700\u7EC8\u53D8\u91CF\u548C\u7F29\u77ED\u5EFA\u8BAE" }] }, "protocol": { "inputs": [{ "key": "wire_request", "type": "era.workflow.packet", "required": true, "display_name": "\u4FDD\u7559\u539F\u503C\u7684\u8DE8\u6D41\u7A0B\u8BF7\u6C42" }], "outputs": [{ "type": "era.workflow.packet", "cardinality": "exactly_one", "as": "wireResponse", "display_name": "\u4FDD\u7559\u539F\u503C\u7684\u8DE8\u6D41\u7A0B\u7ED3\u679C" }] } }, "default_entry": "main", "inputs": [{ "key": "expression_request", "type": "era.expression.request", "required": true, "display_name": "\u521D\u59CB\u53D8\u91CF\u3001\u51FD\u6570\u53CA\u9700\u8981\u4F9D\u6B21\u8BA1\u7B97\u7684\u516C\u5F0F" }], "outputs": [{ "type": "era.expression.response", "cardinality": "exactly_one", "as": "expressionResponse", "display_name": "\u516C\u5F0F\u8BA1\u7B97\u7684\u6700\u7EC8\u53D8\u91CF\u548C\u7F29\u77ED\u5EFA\u8BAE" }] });
export {
  VIBEFLOW_PLUGIN_ABI,
  VIBEFLOW_WORKFLOW_ABI,
  VibeFlowWorkflowError,
  runWorkflow,
  workflowDescriptor
};
