export type WorkflowTraceMode = "off" | "boundary" | "full";

export interface VibeFlowAbortSignal {
  readonly aborted: boolean;
  readonly reason: unknown;
  readonly onabort: ((event: any) => unknown) | null;
  throwIfAborted(): void;
  addEventListener(type: string, listener: any, options?: any): void;
  removeEventListener(type: string, listener: any, options?: any): void;
  dispatchEvent(event: any): boolean;
}

export interface WorkflowRunStatus {
  readonly state: "starting" | "running" | "stopping" | "succeeded" | "failed";
  readonly error: string | null;
  readonly updated_at: string;
  readonly info?: readonly Readonly<Record<string, unknown>>[];
}

export interface WorkflowTraceEvent {
  readonly kind: string;
  readonly workflowId: string;
  readonly nodeId?: string;
  readonly nodePath?: string;
  readonly path?: readonly string[];
  readonly [key: string]: unknown;
}

export class VibeFlowWorkflowError extends Error {
  readonly code: string;
  readonly workflowId: string;
  readonly nodePath: string;
  readonly blockPath: string;
}

export interface WorkflowEntryInputs {
  readonly "main": { readonly "expression_request": unknown; };
  readonly "protocol": { readonly "wire_request": { readonly "encoding": "era-values-v1"; readonly "payload": string }; };
}
export interface WorkflowEntryOutputs {
  readonly "main": { readonly "expressionResponse": { readonly "finalState": { readonly [key: string]: unknown }; readonly "diagnostics": readonly (unknown)[]; readonly "compactedOperations": readonly (unknown)[]; readonly "randomDrawsConsumed": number; readonly "nextDrawOffset": number; readonly "containsAutomaticRandom": boolean; readonly [key: string]: unknown }; };
  readonly "protocol": { readonly "wireResponse": { readonly "encoding": "era-values-v1"; readonly "payload": string }; };
}
export type WorkflowEntry = keyof WorkflowEntryInputs;
export type WorkflowInputs = WorkflowEntryInputs[WorkflowEntry];
export type WorkflowOutputs = WorkflowEntryOutputs[WorkflowEntry];

export interface WorkflowReference { readonly root?: string; readonly path: string; readonly entry?: string }
export interface WorkflowStatus { readonly id?: string; readonly state: "starting" | "running" | "stopping" | "succeeded" | "failed" | "cancelled"; readonly outputs?: any; readonly error?: any }
export interface WorkflowSession {
  invoke_sync?(request: {workflow: WorkflowReference; inputs?: Record<string, unknown>}, context?: {signal?: any}): Record<string, unknown>;
  call(request: {workflow: WorkflowReference; launch: Record<string, unknown>; inputs?: Record<string, unknown>; timeout?: number}, context?: {signal?: any}): Promise<{id: string}>;
  wait(request: {id: string; timeout?: number}, context?: {signal?: any}): Promise<WorkflowStatus>;
  send(request: {id: string; port?: string; payload: unknown}, context?: {signal?: any}): void;
  receive(request?: {port?: string; timeout?: number}, context?: {signal?: any}): Promise<{sender: string; port: string; payload: any}>;
  kill(request: {id: string; workflow: WorkflowReference; timeout?: number}, context?: {signal?: any}): Promise<WorkflowStatus>;
}
export interface WorkflowNodeContext {
  readonly signal?: {readonly aborted: boolean; readonly reason: unknown; readonly onabort: ((event: any) => unknown) | null; throwIfAborted(): void; addEventListener(type: string, listener: any, options?: any): void; removeEventListener(type: string, listener: any, options?: any): void; dispatchEvent(event: any): boolean};
  readonly workflow: Readonly<Omit<WorkflowSession, "invoke_sync"> & {self(): {id: string}; invoke_sync(request: {workflow: WorkflowReference; inputs?: Record<string, unknown>}): Record<string, unknown>}>;
  trace(kind: string, details?: Readonly<Record<string, unknown>>): void;
  updateInfo(info: readonly Readonly<Record<string, unknown>>[]): void;
}


export interface WorkflowRunOptions {
  readonly workflowInstanceId?: string;
  readonly entry?: WorkflowEntry;
  readonly signal?: VibeFlowAbortSignal;
  readonly trace?: WorkflowTraceMode;
  readonly onTrace?: (event: WorkflowTraceEvent) => void;
  readonly workflowSession?: WorkflowSession;
  readonly statusIntervalMs?: number;
  readonly statusFile?: string;
  readonly runDir?: string;
  readonly onStatus?: (status: WorkflowRunStatus) => void;
}

export const VIBEFLOW_WORKFLOW_ABI: "vibeflow.workflow.v12";
export const VIBEFLOW_PLUGIN_ABI: "vibeflow.plugin.v5";
export function runWorkflow<E extends WorkflowEntry>(inputs: WorkflowEntryInputs[E], options: WorkflowRunOptions & {readonly entry: E}): WorkflowEntryOutputs[E];
export function runWorkflow(inputs: WorkflowEntryInputs["main"], options?: WorkflowRunOptions & {readonly entry?: "main"}): WorkflowEntryOutputs["main"];

export const workflowDescriptor: Readonly<{workflow: {root: string; path: string; entry?: string} | null; entry_mode: 'sync' | 'async'; inputs: readonly unknown[]; outputs: readonly unknown[]; calls: readonly Readonly<{operation: 'invoke_sync' | 'call'; workflow: {root: string; path: string; entry?: string}; launch?: unknown}>[]; entries: Readonly<Record<string, unknown>>; default_entry: string}>;