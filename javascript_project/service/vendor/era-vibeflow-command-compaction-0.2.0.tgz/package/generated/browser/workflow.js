// base_lib/command_compaction_engine.ts
import { executeExpressionLayer } from "@era/vibeflow-expression/engine";
function tagInfo(value) {
  if (value === "variableinsert") return { kind: "insert", tag: "VariableInsert" };
  if (value === "variableedit") return { kind: "edit", tag: "VariableEdit" };
  if (value === "variabledelete") return { kind: "delete", tag: "VariableDelete" };
  if (value === "functioninsert") return { kind: "function-insert", tag: "FunctionInsert" };
  if (value === "functionedit") return { kind: "function-edit", tag: "FunctionEdit" };
  if (value === "functiondelete") return { kind: "function-delete", tag: "FunctionDelete" };
  return null;
}
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function plain(value) {
  if (!record(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
function clone(value) {
  return structuredClone(value);
}
function equal(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function diagnostic(code, message, commandIndex, path) {
  return { code, message, ...commandIndex === void 0 ? {} : { commandIndex }, ...path === void 0 ? {} : { path } };
}
function stripFence(text) {
  const match = /^```(?:json)?\s*([\s\S]*?)\s*```$/iu.exec(text.trim());
  return match ? match[1] : text.trim();
}
function parseData(text, commandIndex) {
  try {
    const parsed = JSON.parse(stripFence(text));
    const values = Array.isArray(parsed) ? parsed : [parsed];
    if (!values.every(plain)) {
      return { data: [], diagnostic: diagnostic("ERA_COMPACT_COMMAND_DATA_INVALID", "指令内容必须是 JSON 对象或对象数组。", commandIndex) };
    }
    return { data: values };
  } catch (error) {
    return { data: [], diagnostic: diagnostic("ERA_COMPACT_COMMAND_JSON_INVALID", `指令 JSON 无法解析：${error instanceof Error ? error.message : String(error)}`, commandIndex) };
  }
}
function parseCommandLayer(input2) {
  const source = record(input2) ? input2 : {};
  const request = {
    content: typeof source.content === "string" ? source.content : "",
    initialStatData: plain(source.initialStatData) ? clone(source.initialStatData) : {},
    initialStatFunc: plain(source.initialStatFunc) ? clone(source.initialStatFunc) : {},
    eraMeta: plain(source.eraMeta) ? clone(source.eraMeta) : {},
    templateContext: plain(source.templateContext) ? clone(source.templateContext) : {}
  };
  const commands = [];
  const diagnostics = [];
  const pattern = /<((?:Variable|Function)(?:Insert|Edit|Delete))>\s*([\s\S]*?)\s*<\/\1>/giu;
  let match;
  while ((match = pattern.exec(request.content)) !== null) {
    const info = tagInfo((match[1] ?? "").toLowerCase());
    if (!info) continue;
    const index = commands.length;
    const parsed = parseData(match[2] ?? "", index);
    if (parsed.diagnostic) diagnostics.push(parsed.diagnostic);
    commands.push({
      index,
      kind: info.kind,
      tag: info.tag,
      data: parsed.data,
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0]
    });
  }
  return { request, commands, diagnostics };
}
function getAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function hasAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return false;
    cursor = cursor[segment];
  }
  return true;
}
function setAt(root, segments, value) {
  let cursor = root;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const key = segments[index];
    if (!plain(cursor[key])) cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[segments[segments.length - 1]] = clone(value);
}
function unsetAt(root, segments) {
  let cursor = root;
  for (const segment of segments.slice(0, -1)) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return;
    cursor = cursor[segment];
  }
  if (record(cursor)) delete cursor[segments[segments.length - 1]];
}
function metaValue(value, key) {
  return plain(value) && plain(value.$meta) ? value.$meta[key] : void 0;
}
function merge(left, right) {
  if (!plain(left) || !plain(right)) return clone(right);
  const output = clone(left);
  for (const [key, value] of Object.entries(right)) {
    output[key] = Object.prototype.hasOwnProperty.call(output, key) ? merge(output[key], value) : clone(value);
  }
  return output;
}
function templateFor(parent, key) {
  if (!plain(parent) || !plain(parent.$template)) return void 0;
  const template = parent.$template;
  const general = plain(template.$template) ? template.$template : void 0;
  const specific = plain(template[key]) ? template[key] : void 0;
  return general && specific ? merge(general, specific) : specific ?? general;
}
function applyInsertAt(stat, segments, patch) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) {
    const parent = getAt(stat, segments.slice(0, -1));
    const template = templateFor(parent, segments[segments.length - 1]);
    setAt(stat, segments, template && plain(patch) ? merge(template, patch) : patch);
    return;
  }
  if (!plain(current) || !plain(patch)) return;
  const protection = metaValue(current, "unInsertAble");
  const keys = Object.keys(patch);
  const metaOnly = keys.every((key) => key === "$meta");
  if (protection === "all" && keys.length > 0 && !metaOnly) return;
  for (const key of keys) {
    if (protection === "self" && key !== "$meta" && !Object.prototype.hasOwnProperty.call(current, key)) continue;
    applyInsertAt(stat, [...segments, key], patch[key]);
  }
}
function expressionValue(stat, layerStart, statFunc, startFunc, path, expr) {
  const request = {
    initialState: stat,
    snapshotState: layerStart,
    functionLibrary: statFunc,
    snapshotFunctionLibrary: startFunc,
    allowSnapshots: true,
    operations: [{ path: path.join("."), expr }]
  };
  const response = executeExpressionLayer(request);
  const value = getAt(response.finalState, path);
  const issue = response.diagnostics[0];
  if (issue || typeof value !== "number" || !Number.isFinite(value)) {
    return { diagnostic: diagnostic(issue?.code ?? "ERA_COMPACT_EXPR_NON_FINITE", issue?.message ?? "$expr 必须得到有限数值。", void 0, path.join(".")) };
  }
  return { value };
}
function applyEditAt(stat, layerStart, statFunc, startFunc, segments, patch, diagnostics, commandIndex) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  if (metaValue(current, "updatable") === false) {
    const unlock = plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true;
    if (!unlock) return;
  }
  if (plain(patch) && Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (segments.length === 0 || !hasAt(stat, segments)) return;
    const resolved = expressionValue(stat, layerStart, statFunc, startFunc, segments, patch.$expr);
    if (resolved.diagnostic) diagnostics.push({ ...resolved.diagnostic, commandIndex });
    else setAt(stat, segments, resolved.value);
    return;
  }
  if (!plain(patch)) {
    if (segments.length > 0 && hasAt(stat, segments)) setAt(stat, segments, patch);
    return;
  }
  for (const [key, value] of Object.entries(patch)) {
    applyEditAt(stat, layerStart, statFunc, startFunc, [...segments, key], value, diagnostics, commandIndex);
  }
}
function deleteBypass(patch) {
  return plain(patch) && plain(patch.$meta) && Object.prototype.hasOwnProperty.call(patch.$meta, "necessary");
}
function emptyRecord(value) {
  return plain(value) && Object.keys(value).length === 0;
}
function applyDeleteAt(stat, segments, patch) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  const necessary = metaValue(current, "necessary");
  const bypass = deleteBypass(patch);
  if (plain(patch) && Object.keys(patch).length > 0) {
    if (necessary === "all" && !bypass) return;
    for (const [key, value] of Object.entries(patch)) {
      if (necessary === "children" && emptyRecord(value) && !(key === "$meta" && bypass)) continue;
      applyDeleteAt(stat, [...segments, key], value);
    }
    return;
  }
  if (segments.length === 0 || necessary === "self" || necessary === "all") return;
  unsetAt(stat, segments);
}
function functionDiagnostic(code, message, commandIndex, name) {
  return diagnostic(code, message, commandIndex, name);
}
function functionMetaInvalid(value) {
  const meta = plain(value) && plain(value.$meta) ? value.$meta : null;
  if (!meta) return null;
  if (Object.prototype.hasOwnProperty.call(meta, "unInsertAble")) return "函数是平面实体，不支持 $meta.unInsertAble。";
  if (meta.necessary === "children") return "函数是平面实体，不支持 $meta.necessary: children。";
  return null;
}
function validateFunctions(library) {
  const result = executeExpressionLayer({ initialState: {}, functionLibrary: library, operations: [] });
  const issue = result.diagnostics[0];
  return issue ? diagnostic(issue.code, issue.message, void 0, "<library>") : null;
}
function editFunction(current, patch) {
  if (!plain(current) || !plain(patch)) return clone(patch);
  const patchMeta = plain(patch.$meta) ? patch.$meta : null;
  if (Object.keys(patch).length === 1 && patchMeta) {
    const next2 = clone(current);
    next2.$meta = merge(current.$meta, patchMeta);
    return next2;
  }
  const next = clone(patch);
  if (!Object.prototype.hasOwnProperty.call(patch, "$meta") && Object.prototype.hasOwnProperty.call(current, "$meta")) next.$meta = clone(current.$meta);
  else if (patchMeta) next.$meta = merge(current.$meta, patchMeta);
  return next;
}
function applyFunction(library, type, data, diagnostics, commandIndex) {
  let current = clone(library);
  for (const root of data) {
    if (Object.keys(root).length === 0) {
      diagnostics.push(functionDiagnostic("ERA_FUNCTION_COMMAND_INVALID", "函数指令必须是非空对象。", commandIndex));
      continue;
    }
    const candidate = clone(current);
    for (const [name, patch] of Object.entries(root)) {
      const exists = Object.prototype.hasOwnProperty.call(current, name);
      if (type === "function-insert") {
        if (exists) {
          diagnostics.push(functionDiagnostic("ERA_FUNCTION_ALREADY_EXISTS", "FunctionInsert 只能新增不存在的函数。", commandIndex, name));
          continue;
        }
        const invalid2 = functionMetaInvalid(patch);
        if (invalid2) {
          diagnostics.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = clone(patch);
      } else if (type === "function-edit") {
        if (!exists) {
          diagnostics.push(functionDiagnostic("ERA_FUNCTION_NOT_FOUND", "FunctionEdit 只能修改既有函数。", commandIndex, name));
          continue;
        }
        if (metaValue(current[name], "updatable") === false && !(plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true)) continue;
        const next = editFunction(current[name], patch);
        const invalid2 = functionMetaInvalid(next);
        if (invalid2) {
          diagnostics.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = next;
      } else {
        if (!plain(patch)) {
          diagnostics.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete 的函数值必须是空对象。", commandIndex, name));
          continue;
        }
        if (Object.keys(patch).length === 0) {
          if (exists && !["self", "all"].includes(String(metaValue(current[name], "necessary")))) delete candidate[name];
        } else if (Object.keys(patch).length === 1 && plain(patch.$meta) && exists) {
          const next = clone(current[name]);
          const metaPatch = patch.$meta;
          if (plain(next.$meta)) {
            for (const key of Object.keys(metaPatch)) delete next.$meta[key];
          }
          candidate[name] = next;
        } else diagnostics.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete 的函数值必须是空对象。", commandIndex, name));
      }
    }
    const invalid = validateFunctions(candidate);
    if (invalid) {
      diagnostics.push({ ...invalid, commandIndex });
      continue;
    }
    current = candidate;
  }
  return current;
}
function executeOriginalSemantics(parsed) {
  const stat = clone(parsed.request.initialStatData);
  const start = clone(parsed.request.initialStatData);
  let functions = clone(parsed.request.initialStatFunc ?? {});
  const startFunctions = clone(functions);
  const diagnostics = [...parsed.diagnostics];
  for (const command of parsed.commands) {
    if (command.data.length === 0) continue;
    if (command.kind === "insert") for (const patch of command.data) applyInsertAt(stat, [], patch);
    else if (command.kind === "edit") for (const patch of command.data) applyEditAt(stat, start, functions, startFunctions, [], patch, diagnostics, command.index);
    else if (command.kind === "delete") for (const patch of command.data) applyDeleteAt(stat, [], patch);
    else functions = applyFunction(functions, command.kind, command.data, diagnostics, command.index);
  }
  return { ...parsed, finalStatData: stat, finalStatFunc: functions, diagnostics };
}
function hasMeta(value) {
  if (!plain(value)) return false;
  if (Object.prototype.hasOwnProperty.call(value, "$meta") || Object.prototype.hasOwnProperty.call(value, "$template")) return true;
  return Object.values(value).some(hasMeta);
}
function flattenNumericEdits(patch, prefix = [], output = []) {
  if (!plain(patch)) return false;
  if (Object.prototype.hasOwnProperty.call(patch, "$meta") || Object.prototype.hasOwnProperty.call(patch, "$template")) return false;
  if (Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (prefix.length === 0) return false;
    output.push({ path: prefix.join("."), expr: patch.$expr });
    return true;
  }
  for (const [key, value] of Object.entries(patch)) {
    if (plain(value)) {
      if (!flattenNumericEdits(value, [...prefix, key], output)) return false;
    } else if (typeof value === "number" && Number.isFinite(value)) output.push({ path: [...prefix, key].join("."), expr: JSON.stringify(value) });
    else return false;
  }
  return output.length > 0;
}
function nestingRecord(paths) {
  const result = {};
  for (const item of paths) {
    const parts = item.path.split(".");
    let cursor = result;
    for (const part of parts.slice(0, -1)) {
      if (Object.prototype.hasOwnProperty.call(cursor, part) && !plain(cursor[part])) return null;
      cursor[part] ??= {};
      cursor = cursor[part];
    }
    const leaf = parts[parts.length - 1];
    if (plain(cursor[leaf])) return null;
    cursor[leaf] = { $expr: item.expr };
  }
  return result;
}
function renderTag(tag, data) {
  return `<${tag}>
${JSON.stringify(data)}
</${tag}>`;
}
function mergeInsertPatch(left, right) {
  if (!plain(left) || !plain(right) || hasMeta(left) || hasMeta(right)) return null;
  const output = clone(left);
  for (const [key, value] of Object.entries(right)) {
    if (!Object.prototype.hasOwnProperty.call(output, key)) output[key] = clone(value);
    else if (plain(output[key]) && plain(value)) {
      const merged = mergeInsertPatch(output[key], value);
      if (merged === null) return null;
      output[key] = merged;
    }
  }
  return output;
}
function allCommandData(command) {
  if (command.data.length !== 1) return null;
  return command.data[0] ?? null;
}
function compactEditRun(trace, commands) {
  const operations = [];
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data || !flattenNumericEdits(data, [], operations)) return null;
  }
  const response = executeExpressionLayer({
    initialState: trace.request.initialStatData,
    snapshotState: trace.request.initialStatData,
    functionLibrary: trace.request.initialStatFunc ?? {},
    snapshotFunctionLibrary: trace.request.initialStatFunc ?? {},
    allowSnapshots: true,
    operations
  });
  if (response.diagnostics.length > 0) return null;
  const output = nestingRecord(response.compactedOperations.map((item) => ({ path: item.path, expr: item.value.$expr })));
  return output && Object.keys(output).length > 0 ? renderTag("VariableEdit", output) : "";
}
function compactInsertRun(commands) {
  let merged = {};
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data) return null;
    const next = mergeInsertPatch(merged, data);
    if (next === null) return null;
    merged = next;
  }
  return plain(merged) && Object.keys(merged).length > 0 ? renderTag("VariableInsert", merged) : null;
}
function candidateFor(trace) {
  const replacements = /* @__PURE__ */ new Map();
  const reasons = [];
  if (trace.diagnostics.length > 0) return { ...trace, replacements, reasons: ["原命令含诊断，保留全部标签。"] };
  let cursor = 0;
  while (cursor < trace.commands.length) {
    const kind = trace.commands[cursor].kind;
    let end = cursor + 1;
    while (end < trace.commands.length && trace.commands[end].kind === kind) end += 1;
    const run = trace.commands.slice(cursor, end);
    let replacement = null;
    if (kind === "edit") replacement = compactEditRun(trace, run);
    else if (kind === "insert") replacement = compactInsertRun(run);
    else reasons.push(`${run.map((command) => command.tag).join("/")} 保留：尚无可证明的通用重写规则。`);
    if (replacement !== null && (run.length > 1 || replacement !== run[0].raw)) {
      replacements.set(run[0].index, replacement);
      for (const command of run.slice(1)) replacements.set(command.index, "");
    }
    cursor = end;
  }
  return { ...trace, replacements, reasons };
}
function render(trace, replacements) {
  let content = trace.request.content;
  for (const command of [...trace.commands].sort((left, right) => right.start - left.start)) {
    const replacement = replacements.get(command.index);
    if (replacement !== void 0) content = `${content.slice(0, command.start)}${replacement}${content.slice(command.end)}`;
  }
  return content;
}
function equivalent(trace, content) {
  const replay = executeOriginalSemantics(parseCommandLayer({ ...trace.request, content }));
  return replay.diagnostics.length === trace.diagnostics.length && equal(replay.finalStatData, trace.finalStatData) && equal(replay.finalStatFunc, trace.finalStatFunc);
}
function compactCommandLayer(input2) {
  const parsed = parseCommandLayer(input2);
  const trace = executeOriginalSemantics(parsed);
  if (parsed.diagnostics.length > 0) return { status: "invalid", content: parsed.request.content, finalStatData: trace.finalStatData, finalStatFunc: trace.finalStatFunc, diagnostics: trace.diagnostics, reasons: ["标签 JSON 无效，未改写消息。"], parsedCommands: parsed.commands };
  const candidate = candidateFor(trace);
  if (candidate.replacements.size === 0) return { status: "unchanged", content: trace.request.content, finalStatData: trace.finalStatData, finalStatFunc: trace.finalStatFunc, diagnostics: trace.diagnostics, reasons: candidate.reasons.length ? candidate.reasons : ["没有可证明安全的缩写。"], parsedCommands: trace.commands };
  const content = render(trace, candidate.replacements);
  if (!equivalent(trace, content)) return { status: "unchanged", content: trace.request.content, finalStatData: trace.finalStatData, finalStatFunc: trace.finalStatFunc, diagnostics: trace.diagnostics, reasons: [...candidate.reasons, "候选未通过同一起点真实重放，已退回原命令。"], parsedCommands: trace.commands };
  const all = candidate.replacements.size === trace.commands.length || [...candidate.replacements.keys()].every((index) => trace.commands[index].kind === "edit" || trace.commands[index].kind === "insert");
  return { status: all ? "compacted" : "partial", content, finalStatData: trace.finalStatData, finalStatFunc: trace.finalStatFunc, diagnostics: trace.diagnostics, reasons: candidate.reasons, parsedCommands: trace.commands };
}
function input(inputs, key) {
  const value = inputs[key];
  return value !== null && typeof value === "object" && "value" in value ? value.value : value;
}
function parseCommandBlocksNode(inputs) {
  return { parsed: parseCommandLayer(input(inputs, "compaction_request")) };
}
function executeOriginalSemanticsNode(inputs) {
  return { trace: executeOriginalSemantics(input(inputs, "parsed")) };
}
function deriveReplayInvariantsNode(inputs) {
  const trace = input(inputs, "trace");
  return { invariants: { trace, conservative: true } };
}
function partitionSafeRegionsNode(inputs) {
  const invariants = input(inputs, "invariants");
  return { regions: { ...invariants, regions: invariants.trace.commands.map((command) => ({ index: command.index, kind: command.kind })) } };
}
function symbolizeDependenciesNode(inputs) {
  return { symbols: input(inputs, "regions") };
}
function rewriteSafeRegionsNode(inputs) {
  const payload = input(inputs, "symbols");
  return { candidate: candidateFor(payload.trace) };
}
function verifyReplayEquivalenceNode(inputs) {
  const candidate = input(inputs, "candidate");
  const content = render(candidate, candidate.replacements);
  return { verified: { candidate, content, equivalent: equivalent(candidate, content) } };
}
function renderCompactionResultNode(inputs) {
  const verified = input(inputs, "verified");
  return { compaction_response: verified.equivalent ? compactCommandLayer(verified.candidate.request) : compactCommandLayer({ ...verified.candidate.request, content: verified.candidate.request.content }) };
}
function terminalNode() {
  return {};
}

// vibeflow-generated:workflow-entry.mjs
var VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v4";
var VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v1";
var VibeFlowWorkflowError = class extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === void 0 ? void 0 : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
  }
};
function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details
  });
}
function throwIfAborted(signal, workflow, nodePath2 = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath: nodePath2,
    blockPath,
    cause: signal.reason
  });
}
async function awaitWithAbort(value, signal, workflow, nodePath2 = "", blockPath = "") {
  throwIfAborted(signal, workflow, nodePath2, blockPath);
  if (!signal) return await value;
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(vfError(
      "VF_ABORTED",
      "workflow execution was aborted",
      workflow,
      { nodePath: nodePath2, blockPath, cause: signal.reason }
    ));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([Promise.resolve(value), aborted]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}
function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}
function dictionary() {
  return /* @__PURE__ */ Object.create(null);
}
function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true
  });
  return target;
}
function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string" && !new RegExp(schema.pattern).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}
function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every(
    (key, index) => key === rightKeys[index] && jsonEquals(left[key], right[key])
  );
}
function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}
function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}
function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}
function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}
function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}
function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details
  });
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause }
    );
  }
}
function normalizeOptions(workflow, options) {
  const raw = options === void 0 ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== void 0 && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  const detachedTimeoutMs = raw.detachedTimeoutMs ?? 5e3;
  if (!Number.isFinite(detachedTimeoutMs) || detachedTimeoutMs < 0) {
    throw vfError("VF_INTERNAL", "options.detachedTimeoutMs must be a non-negative number", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    capabilities: raw.capabilities ?? {},
    detachedTimeoutMs
  };
}
function capabilityLocation(caller) {
  return {
    nodePath: typeof caller?.nodePath === "string" ? caller.nodePath : "",
    blockPath: typeof caller?.blockPath === "string" ? caller.blockPath : ""
  };
}
function validateCapabilityInput(workflow, schemas, capabilityId, operationName, operationDescriptor, input2, location) {
  const failure = validateJsonSchema(
    input2,
    operationDescriptor.input_type ? schemas[operationDescriptor.input_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_INPUT",
      `capability '${capabilityId}.${operationName}' input failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
}
function validateCapabilityOutput(workflow, schemas, capabilityId, operationName, operationDescriptor, output, location) {
  const failure = validateJsonSchema(
    output,
    operationDescriptor.output_type ? schemas[operationDescriptor.output_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_OUTPUT",
      `capability '${capabilityId}.${operationName}' output failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
  return output;
}
function wrapCapabilityFailure(cause, workflow, root, capabilityId, operationName, location) {
  if (cause instanceof VibeFlowWorkflowError) throw cause;
  if (root.signal?.aborted) {
    throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
  }
  throw vfError(
    "VF_CAPABILITY_FAILED",
    `capability '${capabilityId}.${operationName}' failed`,
    workflow,
    { ...location, cause }
  );
}
function prepareCapabilities(workflow, descriptors, requirements, schemas, supplied, root, entryMode) {
  assertObject(
    supplied,
    "VF_CAPABILITY_MISSING",
    "options.capabilities must be an object",
    workflow
  );
  const wrapped = dictionary();
  for (const [capabilityId, operationNames] of Object.entries(requirements)) {
    const implementation = Object.prototype.hasOwnProperty.call(supplied, capabilityId) ? supplied[capabilityId] : void 0;
    if (!implementation || typeof implementation !== "object") {
      throw vfError(
        "VF_CAPABILITY_MISSING",
        `required capability '${capabilityId}' was not supplied`,
        workflow
      );
    }
    const descriptor = descriptors[capabilityId] || {};
    const capability = dictionary();
    for (const operationName of operationNames) {
      const callable = implementation[operationName];
      if (typeof callable !== "function") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `capability '${capabilityId}' is missing operation '${operationName}'`,
          workflow
        );
      }
      const operationDescriptor = descriptor.operations?.[operationName] || {};
      const completion = operationDescriptor.completion || "immediate";
      if (entryMode === "sync" && completion === "suspend") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `sync workflow cannot use suspending capability '${capabilityId}.${operationName}'`,
          workflow
        );
      }
      if (completion === "suspend") {
        setOwn(capability, operationName, async (input2, caller = {}) => {
          const location = capabilityLocation(caller);
          throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input2,
            location
          );
          try {
            const output = await awaitWithAbort(
              callable.call(implementation, input2, { signal: root.signal }),
              root.signal,
              workflow,
              location.nodePath,
              location.blockPath
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      } else {
        setOwn(capability, operationName, (input2, caller = {}) => {
          const location = capabilityLocation(caller);
          throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input2,
            location
          );
          try {
            const output = callable.call(
              implementation,
              input2,
              { signal: root.signal }
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      }
    }
    setOwn(wrapped, capabilityId, Object.freeze(capability));
  }
  return Object.freeze(wrapped);
}
function validatePublicInputs(workflow, inputs) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input2 of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input2.key);
    if (input2.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input2.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = validateJsonSchema(
      inputs[input2.key],
      input2.schema || workflow.schemas?.[input2.type]
    );
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input2.key}' failed schema validation: ${failure}`,
        workflow
      );
    }
  }
}
function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}
function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: /* @__PURE__ */ new Map(),
    activeEdges: /* @__PURE__ */ new Set(),
    lastInputs: /* @__PURE__ */ new Map(),
    pending: /* @__PURE__ */ new Map(),
    nodeRuns: /* @__PURE__ */ new Map(),
    stepCount: 0,
    initial
  };
}
function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}
function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input2 of state.workflow.inputs) {
    if (!accepted.has(input2.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input2.key)) continue;
    state.inboxes[nodeId].push(
      createEnvelope(input2.key, input2.type, state.initial[input2.key], "pipeline.input")
    );
  }
}
function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type);
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}
function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}
function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}
function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  for (const provider of node.provides) {
    const schema = state.workflow.schemas?.[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
  }
  return outputs;
}
function outputEnvelopes(node, outputs) {
  return node.provides.map(
    (provider) => createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}
function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node)
    );
    state.inboxes[targetId].push(envelope);
  }
}
function nodeContext(node, state) {
  const allowed = dictionary();
  for (const requirement of node.capabilities || []) {
    const capability = state.root.capabilities[requirement.id];
    if (!capability) continue;
    const contextual = dictionary();
    const requested = new Set(requirement.operations || []);
    for (const [operationName, operation] of Object.entries(capability)) {
      if (requested.size && !requested.has(operationName)) continue;
      setOwn(contextual, operationName, (input2) => operation(input2, {
        nodePath: nodePath(state, node.id),
        blockPath: formatBlockPath(state.path)
      }));
    }
    setOwn(allowed, requirement.id, Object.freeze(contextual));
  }
  return Object.freeze({
    signal: state.root.signal,
    capabilities: Object.freeze(allowed),
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details
      });
    }
  });
}
function invokeStaticImplementationSync(implementation, node, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  try {
    const outputs = implementation(inputs, node.params, nodeContext(node, state));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause }
    );
  }
}
function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
  return inputs;
}
function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
}
function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}
function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = state.candidates.get(spec.type) || [];
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.workflow.schemas?.[spec.type];
    const values = spec.cardinality === "all" ? matches.map((item) => item.value) : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow
        );
      }
    }
  }
  return output;
}
function abandonPending(state) {
  for (const [nodeId, promise] of state.pending) {
    promise.catch(() => {
    });
    emitTrace(state.root, "async_result_abandoned", {
      nodeId,
      nodePath: nodePath(state, nodeId),
      blockPath: formatBlockPath(state.path)
    });
  }
}
function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
function runtimePluginError(code, descriptor, hook, cause, workflow, location = {}) {
  const suffix = hook ? ` hook '${hook}'` : "";
  return vfError(
    code,
    `runtime plugin '${descriptor.id}'${suffix} failed`,
    workflow,
    {
      nodePath: location.nodePath || "",
      blockPath: location.blockPath || "/",
      cause
    }
  );
}
function runtimePluginContext(workflow, descriptor, root) {
  return Object.freeze({
    abiVersion: VIBEFLOW_PLUGIN_ABI,
    pluginId: descriptor.id,
    pluginType: "runtime",
    target: descriptor.target,
    workflowId: workflow.workflow_id,
    config: deepFreeze(descriptor.config || {}),
    signal: root.signal
  });
}
function runtimePluginSummary(root, details = {}) {
  return deepFreeze({
    workflowId: root.workflowId,
    entryMode: root.workflow.entry_mode,
    ...details
  });
}
function createRuntimePluginsSync(workflow, descriptors, factories, root) {
  const records = [];
  try {
    for (const descriptor of descriptors) {
      const factory = factories[descriptor.factory_index];
      if (typeof factory !== "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("plugin module does not export createPlugin()"),
          workflow
        );
      }
      let instance;
      try {
        instance = factory(runtimePluginContext(workflow, descriptor, root));
      } catch (cause) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          cause,
          workflow
        );
      }
      if (!instance || typeof instance !== "object" || Array.isArray(instance)) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("createPlugin() must return a RuntimePlugin object"),
          workflow
        );
      }
      records.push({ descriptor, instance });
    }
    return records;
  } catch (failure) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      try {
        records[index].instance.dispose?.();
      } catch {
      }
    }
    throw failure;
  }
}
function invokeRuntimeHookSync(root, hook, details = {}, preserveFailure = false) {
  const summary = runtimePluginSummary(root, details);
  for (const record2 of root.runtimePlugins) {
    const callback = record2.instance[hook];
    if (typeof callback !== "function") continue;
    try {
      callback(summary);
    } catch (cause) {
      if (preserveFailure) continue;
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_HOOK",
        record2.descriptor,
        hook,
        cause,
        root.workflow,
        summary
      );
    }
  }
}
function disposeRuntimePluginsSync(root, preserveFailure = false) {
  for (let index = root.runtimePlugins.length - 1; index >= 0; index -= 1) {
    const record2 = root.runtimePlugins[index];
    if (typeof record2.instance.dispose !== "function") continue;
    try {
      record2.instance.dispose();
    } catch (cause) {
      if (preserveFailure) continue;
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_DISPOSE",
        record2.descriptor,
        "dispose",
        cause,
        root.workflow
      );
    }
  }
  root.runtimePlugins.length = 0;
}
function createRoot(workflow, normalized) {
  return {
    workflow,
    workflowId: workflow.workflow_id,
    signal: normalized.signal || new AbortController().signal,
    traceMode: normalized.traceMode,
    onTrace: normalized.onTrace,
    detachedTimeoutMs: normalized.detachedTimeoutMs,
    detached: /* @__PURE__ */ new Set(),
    detachedFailure: null,
    capabilities: {},
    runtimePlugins: []
  };
}
function prepareWorkflowInvocation(workflow, descriptors, requirements, schemas, options, entryMode) {
  let normalized;
  try {
    normalized = normalizeOptions(workflow, options);
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
  const root = createRoot(workflow, normalized);
  try {
    throwIfAborted(root.signal, workflow);
    root.capabilities = prepareCapabilities(
      workflow,
      descriptors,
      requirements,
      schemas,
      normalized.capabilities,
      root,
      entryMode
    );
    emitTrace(root, "run_start", {}, true);
    return root;
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
}
function assertWorkflowAbi(workflow) {
  if (workflow.abi_version !== VIBEFLOW_WORKFLOW_ABI) {
    throw vfError(
      "VF_INTERNAL",
      `generated workflow ABI '${workflow.abi_version}' is unsupported`,
      workflow
    );
  }
}
function createStaticWorkflowSync(workflowMetadata, capabilityDescriptors, capabilityRequirements, schemaCatalog, runtimePluginDescriptors, runtimePluginFactories, executeRoot) {
  const workflow = deepFreeze(workflowMetadata);
  const descriptors = deepFreeze(capabilityDescriptors);
  const requirements = deepFreeze(capabilityRequirements);
  const schemas = deepFreeze(schemaCatalog);
  const plugins = deepFreeze(runtimePluginDescriptors);
  assertWorkflowAbi(workflow);
  return function invokeWorkflow(inputs, options) {
    const root = prepareWorkflowInvocation(
      workflow,
      descriptors,
      requirements,
      schemas,
      options,
      "sync"
    );
    root.runtimePlugins = createRuntimePluginsSync(
      workflow,
      plugins,
      runtimePluginFactories,
      root
    );
    let failed = false;
    try {
      invokeRuntimeHookSync(root, "beforeRun", {
        inputKeys: Object.keys(inputs || {}).sort()
      });
      const result = executeRoot(inputs, root, []);
      throwIfAborted(root.signal, workflow);
      invokeRuntimeHookSync(root, "afterRun", {
        outputKeys: Object.keys(result.publicOutputs || {}).sort()
      });
      emitTrace(root, "run_end", {}, true);
      return result.publicOutputs;
    } catch (cause) {
      failed = true;
      const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
      if (failure.code !== "VF_TRACE_SINK_FAILED") {
        try {
          emitTrace(root, "run_failed", {
            code: failure.code,
            message: failure.message
          }, true);
        } catch {
        }
      }
      invokeRuntimeHookSync(root, "runFailed", {
        code: failure.code,
        message: failure.message
      }, true);
      throw ensureErrorLocation(failure, workflow, []);
    } finally {
      disposeRuntimePluginsSync(root, failed);
    }
  };
}
var __vfRuntimePluginDescriptors = [];
var __vfRuntimePluginFactories = [];
var __vf_workflow_0_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v4","entry_mode":"sync","inputs":[{"key":"compaction_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.request"}],"max_steps":1000,"outputs":[{"as":"compactionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.response"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.invariants":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.regions":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction"}'));
var __vf_w0_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w0_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"parse_command_blocks","params":{"_global":{}},"provides":[{"key":"parsed","type":"era.command_compaction.parsed"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.request"}],"schedule":"inline","type_used":"era.command_compaction.parse_command_blocks"}'));
var __vf_w0_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"execute_original_semantics","params":{"_global":{}},"provides":[{"key":"trace","type":"era.command_compaction.semantic_trace"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.parsed"}],"schedule":"inline","type_used":"era.command_compaction.execute_original_semantics"}'));
var __vf_w0_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"derive_replay_invariants","params":{"_global":{}},"provides":[{"key":"invariants","type":"era.command_compaction.invariants"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.semantic_trace"}],"schedule":"inline","type_used":"era.command_compaction.derive_replay_invariants"}'));
var __vf_w0_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"partition_safe_regions","params":{"_global":{}},"provides":[{"key":"regions","type":"era.command_compaction.regions"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.invariants"}],"schedule":"inline","type_used":"era.command_compaction.partition_safe_regions"}'));
var __vf_w0_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"symbolize_dependencies","params":{"_global":{}},"provides":[{"key":"symbols","type":"era.command_compaction.symbols"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.regions"}],"schedule":"inline","type_used":"era.command_compaction.symbolize_dependencies"}'));
var __vf_w0_n6 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"rewrite_safe_regions","params":{"_global":{}},"provides":[{"key":"candidate","type":"era.command_compaction.candidate"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.symbols"}],"schedule":"inline","type_used":"era.command_compaction.rewrite_safe_regions"}'));
var __vf_w0_n7 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"verify_equivalence","params":{"_global":{}},"provides":[{"key":"verified","type":"era.command_compaction.verified"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.candidate"}],"schedule":"inline","type_used":"era.command_compaction.verify_replay_equivalence"}'));
var __vf_w0_n8 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"render_result","params":{"_global":{}},"provides":[{"key":"compaction_response","type":"era.command_compaction.response"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.verified"}],"schedule":"inline","type_used":"era.command_compaction.render_compaction_result"}'));
var __vf_w0_n9 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vfCapabilityDescriptors = Object.freeze(JSON.parse("{}"));
var __vfCapabilityRequirements = Object.freeze(JSON.parse("{}"));
var __vfSchemaCatalog = Object.freeze(JSON.parse('{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.invariants":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.regions":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}}'));
function __vf_activate_w0_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("parse_command_blocks");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0parse_command_blocks");
  targets.push("parse_command_blocks");
  emitTrace(state.root, "edge_activated", { source: "start", target: "parse_command_blocks", path: state.path });
  deliverStatic(envelopes, state, "parse_command_blocks", JSON.parse('["era.command_compaction.request"]'));
  return targets;
}
function __vf_execute_w0_n0(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w0_n0, inputs, state);
}
function __vf_activate_w0_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("execute_original_semantics");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("parse_command_blocks\0execute_original_semantics");
  targets.push("execute_original_semantics");
  emitTrace(state.root, "edge_activated", { source: "parse_command_blocks", target: "execute_original_semantics", path: state.path });
  deliverStatic(envelopes, state, "execute_original_semantics", JSON.parse('["era.command_compaction.parsed"]'));
  return targets;
}
function __vf_execute_w0_n1(inputs, state) {
  return invokeStaticImplementationSync(parseCommandBlocksNode, __vf_w0_n1, inputs, state);
}
function __vf_activate_w0_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("derive_replay_invariants");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("execute_original_semantics\0derive_replay_invariants");
  targets.push("derive_replay_invariants");
  emitTrace(state.root, "edge_activated", { source: "execute_original_semantics", target: "derive_replay_invariants", path: state.path });
  deliverStatic(envelopes, state, "derive_replay_invariants", JSON.parse('["era.command_compaction.semantic_trace"]'));
  return targets;
}
function __vf_execute_w0_n2(inputs, state) {
  return invokeStaticImplementationSync(executeOriginalSemanticsNode, __vf_w0_n2, inputs, state);
}
function __vf_activate_w0_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("partition_safe_regions");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("derive_replay_invariants\0partition_safe_regions");
  targets.push("partition_safe_regions");
  emitTrace(state.root, "edge_activated", { source: "derive_replay_invariants", target: "partition_safe_regions", path: state.path });
  deliverStatic(envelopes, state, "partition_safe_regions", JSON.parse('["era.command_compaction.invariants"]'));
  return targets;
}
function __vf_execute_w0_n3(inputs, state) {
  return invokeStaticImplementationSync(deriveReplayInvariantsNode, __vf_w0_n3, inputs, state);
}
function __vf_activate_w0_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("symbolize_dependencies");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("partition_safe_regions\0symbolize_dependencies");
  targets.push("symbolize_dependencies");
  emitTrace(state.root, "edge_activated", { source: "partition_safe_regions", target: "symbolize_dependencies", path: state.path });
  deliverStatic(envelopes, state, "symbolize_dependencies", JSON.parse('["era.command_compaction.regions"]'));
  return targets;
}
function __vf_execute_w0_n4(inputs, state) {
  return invokeStaticImplementationSync(partitionSafeRegionsNode, __vf_w0_n4, inputs, state);
}
function __vf_activate_w0_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("rewrite_safe_regions");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("symbolize_dependencies\0rewrite_safe_regions");
  targets.push("rewrite_safe_regions");
  emitTrace(state.root, "edge_activated", { source: "symbolize_dependencies", target: "rewrite_safe_regions", path: state.path });
  deliverStatic(envelopes, state, "rewrite_safe_regions", JSON.parse('["era.command_compaction.symbols"]'));
  return targets;
}
function __vf_execute_w0_n5(inputs, state) {
  return invokeStaticImplementationSync(symbolizeDependenciesNode, __vf_w0_n5, inputs, state);
}
function __vf_activate_w0_n6(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("verify_equivalence");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n6, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("rewrite_safe_regions\0verify_equivalence");
  targets.push("verify_equivalence");
  emitTrace(state.root, "edge_activated", { source: "rewrite_safe_regions", target: "verify_equivalence", path: state.path });
  deliverStatic(envelopes, state, "verify_equivalence", JSON.parse('["era.command_compaction.candidate"]'));
  return targets;
}
function __vf_execute_w0_n6(inputs, state) {
  return invokeStaticImplementationSync(rewriteSafeRegionsNode, __vf_w0_n6, inputs, state);
}
function __vf_activate_w0_n7(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("render_result");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n7, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("verify_equivalence\0render_result");
  targets.push("render_result");
  emitTrace(state.root, "edge_activated", { source: "verify_equivalence", target: "render_result", path: state.path });
  deliverStatic(envelopes, state, "render_result", JSON.parse('["era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w0_n7(inputs, state) {
  return invokeStaticImplementationSync(verifyReplayEquivalenceNode, __vf_w0_n7, inputs, state);
}
function __vf_activate_w0_n8(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n8, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("render_result\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "render_result", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w0_n8(inputs, state) {
  return invokeStaticImplementationSync(renderCompactionResultNode, __vf_w0_n8, inputs, state);
}
function __vf_activate_w0_n9(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n9, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w0_n9(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w0_n9, inputs, state);
}
function __vf_workflow_0_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_0_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "parse_command_blocks");
    initializeInbox(state, "execute_original_semantics");
    initializeInbox(state, "derive_replay_invariants");
    initializeInbox(state, "partition_safe_regions");
    initializeInbox(state, "symbolize_dependencies");
    initializeInbox(state, "rewrite_safe_regions");
    initializeInbox(state, "verify_equivalence");
    initializeInbox(state, "render_result");
    initializeInbox(state, "end");
    seedInbox(state, "parse_command_blocks", JSON.parse('["era.command_compaction.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_0_metadata);
      if (state.stepCount >= 1e3) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=1000",
          __vf_workflow_0_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n0(inputs, state);
            finishStaticNode(__vf_w0_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "parse_command_blocks": {
          if (!state.inboxes["parse_command_blocks"].some((item) => item.type === "era.command_compaction.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "parse_command_blocks", nodePath: nodePath(state, "parse_command_blocks"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.parse_command_blocks" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n1(inputs, state);
            finishStaticNode(__vf_w0_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "parse_command_blocks", nodePath: nodePath(state, "parse_command_blocks"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.parse_command_blocks", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "parse_command_blocks");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "parse_command_blocks", nodePath: nodePath(state, "parse_command_blocks"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "execute_original_semantics": {
          if (!state.inboxes["execute_original_semantics"].some((item) => item.type === "era.command_compaction.parsed")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "execute_original_semantics", nodePath: nodePath(state, "execute_original_semantics"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.execute_original_semantics" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n2(inputs, state);
            finishStaticNode(__vf_w0_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "execute_original_semantics", nodePath: nodePath(state, "execute_original_semantics"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.execute_original_semantics", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "execute_original_semantics");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "execute_original_semantics", nodePath: nodePath(state, "execute_original_semantics"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "derive_replay_invariants": {
          if (!state.inboxes["derive_replay_invariants"].some((item) => item.type === "era.command_compaction.semantic_trace")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "derive_replay_invariants", nodePath: nodePath(state, "derive_replay_invariants"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.derive_replay_invariants" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n3(inputs, state);
            finishStaticNode(__vf_w0_n3, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "derive_replay_invariants", nodePath: nodePath(state, "derive_replay_invariants"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.derive_replay_invariants", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "derive_replay_invariants");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "derive_replay_invariants", nodePath: nodePath(state, "derive_replay_invariants"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "partition_safe_regions": {
          if (!state.inboxes["partition_safe_regions"].some((item) => item.type === "era.command_compaction.invariants")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "partition_safe_regions", nodePath: nodePath(state, "partition_safe_regions"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.partition_safe_regions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n4(inputs, state);
            finishStaticNode(__vf_w0_n4, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "partition_safe_regions", nodePath: nodePath(state, "partition_safe_regions"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.partition_safe_regions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "partition_safe_regions");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "partition_safe_regions", nodePath: nodePath(state, "partition_safe_regions"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "symbolize_dependencies": {
          if (!state.inboxes["symbolize_dependencies"].some((item) => item.type === "era.command_compaction.regions")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "symbolize_dependencies", nodePath: nodePath(state, "symbolize_dependencies"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.symbolize_dependencies" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n5(inputs, state);
            finishStaticNode(__vf_w0_n5, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "symbolize_dependencies", nodePath: nodePath(state, "symbolize_dependencies"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.symbolize_dependencies", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "symbolize_dependencies");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "symbolize_dependencies", nodePath: nodePath(state, "symbolize_dependencies"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "rewrite_safe_regions": {
          if (!state.inboxes["rewrite_safe_regions"].some((item) => item.type === "era.command_compaction.symbols")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n6, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "rewrite_safe_regions", nodePath: nodePath(state, "rewrite_safe_regions"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.rewrite_safe_regions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n6(inputs, state);
            finishStaticNode(__vf_w0_n6, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n6(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "rewrite_safe_regions", nodePath: nodePath(state, "rewrite_safe_regions"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.rewrite_safe_regions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "rewrite_safe_regions");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "rewrite_safe_regions", nodePath: nodePath(state, "rewrite_safe_regions"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "verify_equivalence": {
          if (!state.inboxes["verify_equivalence"].some((item) => item.type === "era.command_compaction.candidate")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n7, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "verify_equivalence", nodePath: nodePath(state, "verify_equivalence"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_replay_equivalence" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n7(inputs, state);
            finishStaticNode(__vf_w0_n7, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n7(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "verify_equivalence", nodePath: nodePath(state, "verify_equivalence"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_replay_equivalence", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "verify_equivalence");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "verify_equivalence", nodePath: nodePath(state, "verify_equivalence"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "render_result": {
          if (!state.inboxes["render_result"].some((item) => item.type === "era.command_compaction.verified")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n8, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "render_result", nodePath: nodePath(state, "render_result"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.render_compaction_result" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n8(inputs, state);
            finishStaticNode(__vf_w0_n8, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n8(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "render_result", nodePath: nodePath(state, "render_result"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.render_compaction_result", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "render_result");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "render_result", nodePath: nodePath(state, "render_result"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n9, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n9(inputs, state);
            finishStaticNode(__vf_w0_n9, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n9(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
var __vfInvokeWorkflow = createStaticWorkflowSync(
  __vf_workflow_0_metadata,
  __vfCapabilityDescriptors,
  __vfCapabilityRequirements,
  __vfSchemaCatalog,
  __vfRuntimePluginDescriptors,
  __vfRuntimePluginFactories,
  __vf_workflow_0_execute
);
function runWorkflow(inputs, options) {
  return __vfInvokeWorkflow(inputs, options);
}
export {
  VIBEFLOW_PLUGIN_ABI,
  VIBEFLOW_WORKFLOW_ABI,
  VibeFlowWorkflowError,
  runWorkflow
};
