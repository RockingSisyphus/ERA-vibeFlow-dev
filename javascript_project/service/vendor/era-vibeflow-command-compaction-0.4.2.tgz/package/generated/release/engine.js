// node_modules/@era/vibeflow-expression/base_lib/expression_engine.ts
import gamma from "@stdlib/math-base-special-gamma";
import { derivative, evaluate as mathEvaluate } from "mathjs/number";
function isBuiltin(name) {
  return [
    "sin",
    "cos",
    "tan",
    "asin",
    "acos",
    "atan",
    "sinh",
    "cosh",
    "tanh",
    "asinh",
    "acosh",
    "atanh",
    "exp",
    "log",
    "ln",
    "sqrt",
    "abs",
    "floor",
    "ceil",
    "round",
    "trunc",
    "min",
    "max",
    "clamp",
    "pow",
    "mod",
    "factorial",
    "gamma",
    "derivative",
    "integral",
    "random"
  ].includes(name);
}
function diagnostic(code, message, extra = {}) {
  return { code, message, ...extra };
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function clone(value) {
  return structuredClone(value);
}
function finite(value, code, message) {
  if (!Number.isFinite(value))
    throw new ExpressionFailure(diagnostic(code, message));
  return Object.is(value, -0) ? 0 : value;
}
var ExpressionFailure = class extends Error {
  constructor(detail) {
    super(detail.message);
    this.detail = detail;
  }
  detail;
};
function lex(source) {
  const tokens = [];
  let cursor = 0;
  while (cursor < source.length) {
    const char = source[cursor];
    if (/\s/u.test(char)) {
      cursor += 1;
      continue;
    }
    if (/[0-9.]/u.test(char) && (/[0-9]/u.test(char) || /[0-9]/u.test(source[cursor + 1] ?? ""))) {
      const match = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/u.exec(
        source.slice(cursor)
      );
      if (!match)
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_LEX_INVALID_NUMBER", "\u65E0\u6548\u6570\u5B57\u3002", {
            position: cursor
          })
        );
      tokens.push({ kind: "number", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if (/[A-Za-z_]/u.test(char)) {
      const match = /^[A-Za-z_][A-Za-z0-9_]*/u.exec(source.slice(cursor));
      tokens.push({ kind: "identifier", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if ("+-*/%^@".includes(char)) {
      tokens.push({ kind: "operator", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    if ("(),.".includes(char)) {
      tokens.push({ kind: "punctuation", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_LEX_INVALID_CHARACTER",
        `\u4E0D\u652F\u6301\u5B57\u7B26 ${JSON.stringify(char)}\u3002`,
        { position: cursor }
      )
    );
  }
  tokens.push({ kind: "eof", text: "", position: cursor });
  return tokens;
}
var Parser = class {
  constructor(tokens, allowSnapshot) {
    this.tokens = tokens;
    this.allowSnapshot = allowSnapshot;
  }
  tokens;
  allowSnapshot;
  index = 0;
  current() {
    return this.tokens[this.index];
  }
  take() {
    return this.tokens[this.index++];
  }
  matches(text) {
    return this.current().text === text;
  }
  expect(text) {
    if (!this.matches(text))
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_EXPECTED", `\u6B64\u5904\u5E94\u4E3A ${text}\u3002`, {
          position: this.current().position
        })
      );
    return this.take();
  }
  parse() {
    const ast = this.additive();
    if (this.current().kind !== "eof")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_TRAILING", "\u8868\u8FBE\u5F0F\u672B\u5C3E\u5B58\u5728\u672A\u89E3\u6790\u5185\u5BB9\u3002", {
          position: this.current().position
        })
      );
    return ast;
  }
  additive() {
    let left = this.multiplicative();
    while (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.multiplicative() };
    }
    return left;
  }
  multiplicative() {
    let left = this.unary();
    while (this.matches("*") || this.matches("/") || this.matches("%")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.unary() };
    }
    return left;
  }
  unary() {
    if (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      return { kind: "unary", op, value: this.unary() };
    }
    return this.power();
  }
  power() {
    const left = this.primary();
    if (this.matches("^")) {
      this.take();
      return { kind: "binary", op: "^", left, right: this.unary() };
    }
    return left;
  }
  primary() {
    if (this.matches("(")) {
      this.take();
      const ast = this.additive();
      this.expect(")");
      return ast;
    }
    if (this.current().kind === "number") {
      const token = this.take();
      return {
        kind: "literal",
        value: finite(
          Number(token.text),
          "ERA_EXPR_NUMBER_NON_FINITE",
          "\u6570\u5B57\u5FC5\u987B\u6709\u9650\u3002"
        )
      };
    }
    let snapshot = false;
    if (this.matches("@")) {
      if (!this.allowSnapshot)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_SNAPSHOT_FORBIDDEN",
            "\u7528\u6237\u539F\u59CB\u8868\u8FBE\u5F0F\u4E0D\u80FD\u4F7F\u7528 @path\u3002",
            { position: this.current().position }
          )
        );
      this.take();
      snapshot = true;
    }
    if (this.current().kind !== "identifier")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_PRIMARY", "\u6B64\u5904\u5E94\u4E3A\u6570\u5B57\u3001\u53D8\u91CF\u6216\u51FD\u6570\u8C03\u7528\u3002", {
          position: this.current().position
        })
      );
    const first = this.take();
    if (this.matches("(")) {
      this.take();
      const args = [];
      if (!this.matches(")")) {
        do {
          args.push(this.additive());
          if (!this.matches(",")) break;
          this.take();
        } while (true);
      }
      this.expect(")");
      return { kind: "call", name: first.text, args, snapshot };
    }
    const path = [first.text];
    while (this.matches(".")) {
      this.take();
      const segment = this.current();
      if (segment.kind !== "identifier")
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_PATH_SEGMENT", "\u8DEF\u5F84\u70B9\u53F7\u540E\u5E94\u4E3A\u6807\u8BC6\u7B26\u3002", {
            position: segment.position
          })
        );
      path.push(this.take().text);
    }
    return { kind: "ref", path, snapshot };
  }
};
function parseExpression(source, allowSnapshot = false) {
  try {
    return {
      ast: new Parser(lex(source), allowSnapshot).parse(),
      diagnostics: []
    };
  } catch (error) {
    return {
      ast: null,
      diagnostics: [
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PARSE_FAILED", String(error))
      ]
    };
  }
}
function validatePath(value) {
  const parts = value.split(".");
  if (parts.length === 0 || parts.some((part) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(part)))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_PATH_INVALID",
        `\u65E0\u6548\u53D8\u91CF\u8DEF\u5F84 ${JSON.stringify(value)}\u3002`,
        { path: value }
      )
    );
  return parts;
}
function getPath(root, path) {
  let value = root;
  for (const segment of path) {
    if (!isRecord(value) || !(segment in value)) return void 0;
    value = value[segment];
  }
  return value;
}
function setPath(root, path, value) {
  if (!isRecord(root))
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_STATE_ROOT", "\u53D8\u91CF\u72B6\u6001\u6839\u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const next = clone(root);
  let cursor = next;
  for (const segment of path.slice(0, -1)) {
    const child = cursor[segment];
    if (!isRecord(child)) cursor[segment] = {};
    cursor = cursor[segment];
  }
  cursor[path[path.length - 1]] = value;
  return next;
}
function normaliseRequest(input) {
  const diagnostics = [];
  const request = isRecord(input) ? input : {};
  const initialState = request.initialState;
  if (!isRecord(initialState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_INITIAL_STATE_INVALID",
        "initialState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const snapshotState = request.snapshotState === void 0 ? null : isRecord(request.snapshotState) ? clone(request.snapshotState) : null;
  if (request.snapshotState !== void 0 && !isRecord(request.snapshotState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_STATE_INVALID",
        "snapshotState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const functionLibrary = isRecord(request.functionLibrary) ? request.functionLibrary : {};
  if (request.functionLibrary !== void 0 && !isRecord(request.functionLibrary))
    diagnostics.push(
      diagnostic("ERA_EXPR_LIBRARY_INVALID", "functionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const snapshotFunctionLibrary = request.snapshotFunctionLibrary === void 0 ? null : isRecord(request.snapshotFunctionLibrary) ? request.snapshotFunctionLibrary : null;
  if (request.snapshotFunctionLibrary !== void 0 && !isRecord(request.snapshotFunctionLibrary))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_LIBRARY_INVALID",
        "snapshotFunctionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002"
      )
    );
  let randomContext = null;
  if (request.randomContext !== void 0) {
    if (!isRecord(request.randomContext) || typeof request.randomContext.sourceKey !== "string" || request.randomContext.sourceKey.length === 0 || !Number.isSafeInteger(request.randomContext.drawOffset) || request.randomContext.drawOffset < 0)
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_RANDOM_CONTEXT_INVALID",
          "randomContext \u9700\u8981\u975E\u7A7A sourceKey \u4E0E\u975E\u8D1F\u5B89\u5168\u6574\u6570 drawOffset\u3002"
        )
      );
    else
      randomContext = {
        sourceKey: request.randomContext.sourceKey,
        drawOffset: request.randomContext.drawOffset
      };
  }
  const rawOperations = Array.isArray(request.operations) ? request.operations : [];
  if (!Array.isArray(request.operations))
    diagnostics.push(
      diagnostic("ERA_EXPR_OPERATIONS_INVALID", "operations \u5FC5\u987B\u662F\u6709\u5E8F\u6570\u7EC4\u3002")
    );
  const operations = [];
  for (const [index, operation] of rawOperations.entries()) {
    if (!isRecord(operation) || typeof operation.path !== "string" || typeof operation.expr !== "string") {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_OPERATION_SHAPE",
          `operations[${index}] \u5FC5\u987B\u6709 path \u548C expr \u5B57\u7B26\u4E32\u3002`
        )
      );
      continue;
    }
    operations.push({ path: operation.path, expr: operation.expr });
  }
  return {
    initialState: isRecord(initialState) ? clone(initialState) : {},
    snapshotState,
    functionLibrary,
    snapshotFunctionLibrary,
    allowSnapshots: request.allowSnapshots === true,
    randomContext,
    operations,
    diagnostics,
    valid: diagnostics.length === 0
  };
}
function parseFunctionDefinitions(request) {
  const parsed = [];
  for (const [name, raw] of Object.entries(request.functionLibrary)) {
    const definition = isRecord(raw) ? { params: raw.params, expr: raw.expr } : raw;
    const diagnostics = [];
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/u.test(name))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME",
          `\u51FD\u6570\u540D ${JSON.stringify(name)} \u65E0\u6548\u3002`,
          { path: name }
        )
      );
    if (isBuiltin(name))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME_CONFLICT",
          `\u51FD\u6570\u540D ${name} \u4E0E\u5185\u5EFA\u51FD\u6570\u51B2\u7A81\u3002`,
          { path: name }
        )
      );
    if (!isRecord(definition) || !Array.isArray(definition.params) || typeof definition.expr !== "string")
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_SHAPE",
          `\u51FD\u6570 ${name} \u5E94\u5305\u542B params \u6570\u7EC4\u4E0E expr \u5B57\u7B26\u4E32\u3002`,
          { path: name }
        )
      );
    const params = isRecord(definition) && Array.isArray(definition.params) ? definition.params.filter((item) => typeof item === "string") : [];
    if (params.length !== new Set(params).size || params.some((param) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(param)))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_PARAMS",
          `\u51FD\u6570 ${name} \u7684\u5F62\u53C2\u5FC5\u987B\u662F\u4E92\u5F02\u6807\u8BC6\u7B26\u3002`,
          { path: name }
        )
      );
    const expr = isRecord(definition) && typeof definition.expr === "string" ? definition.expr : "";
    const result = diagnostics.length === 0 ? parseExpression(expr, false) : { ast: null, diagnostics: [] };
    parsed.push({
      name,
      params,
      expr,
      ast: result.ast,
      diagnostics: [...diagnostics, ...result.diagnostics]
    });
  }
  return parsed;
}
function walk(ast, visitor) {
  visitor(ast);
  if (ast.kind === "unary") walk(ast.value, visitor);
  if (ast.kind === "binary") {
    walk(ast.left, visitor);
    walk(ast.right, visitor);
  }
  if (ast.kind === "call") for (const arg of ast.args) walk(arg, visitor);
}
function extractFunctionDependencies(parsed) {
  const names = new Set(parsed.map((item) => item.name));
  const result = {};
  for (const functionDef of parsed) {
    const dependencies = /* @__PURE__ */ new Set();
    if (functionDef.ast)
      walk(functionDef.ast, (item) => {
        if (item.kind === "call" && names.has(item.name))
          dependencies.add(item.name);
      });
    result[functionDef.name] = [...dependencies].sort();
  }
  return result;
}
function validateFunctionPurity(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const diagnostics = [];
  for (const functionDef of parsed) {
    diagnostics.push(...functionDef.diagnostics);
    if (!functionDef.ast) continue;
    const params = new Set(functionDef.params);
    walk(functionDef.ast, (item) => {
      if (item.kind === "ref" && (!params.has(item.path[0]) || item.path.length !== 1 || item.snapshot))
        diagnostics.push(
          diagnostic(
            "ERA_EXPR_FUNCTION_IMPURE",
            `\u51FD\u6570 ${functionDef.name} \u53EA\u80FD\u8BFB\u53D6\u81EA\u5DF1\u7684\u5F62\u53C2\u3002`,
            { path: functionDef.name }
          )
        );
      if (item.kind === "call") {
        if (item.name === "random" && item.args.length > 2)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_BUILTIN_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u4E2D\u7684 random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002`,
              { path: functionDef.name }
            )
          );
        if (!isBuiltin(item.name) && !functions.has(item.name))
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528\u4E86\u672A\u77E5\u51FD\u6570 ${item.name}\u3002`,
              { path: functionDef.name }
            )
          );
        const target = functions.get(item.name);
        if (target && item.args.length !== target.params.length)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528 ${item.name} \u7684\u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
              { path: functionDef.name }
            )
          );
      }
    });
  }
  return diagnostics;
}
function rejectRecursiveFunctions(dependencies) {
  const visited = /* @__PURE__ */ new Set();
  const visiting = [];
  const diagnostics = [];
  const visit = (name) => {
    const existing = visiting.indexOf(name);
    if (existing >= 0) {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_RECURSION",
          `\u51FD\u6570\u9012\u5F52\u4E0D\u88AB\u652F\u6301\uFF1A${[...visiting.slice(existing), name].join(" \u2192 ")}\u3002`,
          { path: name }
        )
      );
      return;
    }
    if (visited.has(name)) return;
    visiting.push(name);
    for (const dependency of dependencies[name] ?? []) visit(dependency);
    visiting.pop();
    visited.add(name);
  };
  for (const name of Object.keys(dependencies)) visit(name);
  return diagnostics;
}
function findRandomFunctions(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const memo = /* @__PURE__ */ new Map();
  const visiting = /* @__PURE__ */ new Set();
  const contains = (name) => {
    const cached = memo.get(name);
    if (cached !== void 0) return cached;
    if (visiting.has(name)) return false;
    visiting.add(name);
    const definition = functions.get(name);
    let found = false;
    if (definition?.ast)
      walk(definition.ast, (item) => {
        if (item.kind !== "call" || found) return;
        if (item.name === "random") found = true;
        else if (functions.has(item.name) && contains(item.name)) found = true;
      });
    visiting.delete(name);
    memo.set(name, found);
    return found;
  };
  return [...functions.keys()].filter(contains).sort();
}
function compileCallableFunctions(parsed, diagnostics) {
  const all = [...diagnostics];
  return {
    functions: Object.fromEntries(
      parsed.filter((item) => item.ast !== null).map((item) => [item.name, item])
    ),
    randomFunctions: findRandomFunctions(parsed),
    diagnostics: all,
    valid: all.length === 0
  };
}
function compileFunctionLibrary(functionLibrary) {
  const request = {
    initialState: {},
    snapshotState: null,
    functionLibrary,
    snapshotFunctionLibrary: null,
    allowSnapshots: false,
    randomContext: null,
    operations: [],
    diagnostics: [],
    valid: true
  };
  const parsed = parseFunctionDefinitions(request);
  const dependencies = extractFunctionDependencies(parsed);
  return compileCallableFunctions(parsed, [
    ...validateFunctionPurity(parsed),
    ...rejectRecursiveFunctions(dependencies)
  ]);
}
function countAutomaticRandomDraws(ast, currentLibrary, snapshotLibrary = currentLibrary) {
  const visiting = /* @__PURE__ */ new Set();
  const count = (item, library) => {
    if (item.kind === "literal" || item.kind === "ref") return 0;
    if (item.kind === "unary") return count(item.value, library);
    if (item.kind === "binary")
      return count(item.left, library) + count(item.right, library);
    let total = item.args.reduce(
      (sum, arg) => sum + count(arg, library),
      0
    );
    if (item.name === "random") return total + (item.args.length < 2 ? 1 : 0);
    if (isBuiltin(item.name)) return total;
    const targetLibrary = item.snapshot ? snapshotLibrary : library;
    const target = targetLibrary.functions[item.name];
    if (target?.ast && !visiting.has(target)) {
      visiting.add(target);
      total += count(target.ast, targetLibrary);
      visiting.delete(target);
    }
    return total;
  };
  return count(ast, currentLibrary);
}
function parseOperations(request) {
  return request.operations.map((operation, index) => {
    const diagnostics = [];
    let path = [];
    try {
      path = validatePath(operation.path);
    } catch (error) {
      diagnostics.push(
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PATH_INVALID", String(error))
      );
    }
    const parsed = diagnostics.length === 0 ? parseExpression(operation.expr, request.allowSnapshots) : { ast: null, diagnostics: [] };
    return {
      index,
      path,
      expr: operation.expr,
      ast: parsed.ast,
      diagnostics: [...diagnostics, ...parsed.diagnostics]
    };
  });
}
function initializeSequenceState(request, compiled, operations, snapshotCompiled = compiled) {
  return {
    startState: clone(request.snapshotState ?? request.initialState),
    currentState: clone(request.initialState),
    compiled,
    snapshotCompiled,
    operations,
    cursor: 0,
    randomContext: request.randomContext,
    randomDrawsConsumed: 0,
    diagnostics: [...request.diagnostics, ...compiled.diagnostics]
  };
}
function refValue(ast, state, env, allowState) {
  if (ast.path.length === 1 && ast.path[0] in env) return env[ast.path[0]];
  if (!allowState)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_FUNCTION_IMPURE", "\u51FD\u6570\u4F53\u4E0D\u80FD\u8BFB\u53D6\u5916\u90E8\u53D8\u91CF\u72B6\u6001\u3002", {
        path: ast.path.join(".")
      })
    );
  const source = ast.snapshot ? state.startState : state.currentState;
  const value = getPath(source, ast.path);
  if (typeof value !== "number" || !Number.isFinite(value))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_REFERENCE_NON_NUMERIC",
        `\u53D8\u91CF ${ast.path.join(".")} \u5FC5\u987B\u5DF2\u5B9A\u4E49\u4E3A\u6709\u9650\u6570\u5B57\u3002`,
        { path: ast.path.join(".") }
      )
    );
  return value;
}
function popValues(values, count) {
  if (count === 0) return { values, args: [] };
  if (values.length < count)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_EVALUATION_STACK", "\u8868\u8FBE\u5F0F\u6C42\u503C\u6808\u7F3A\u5C11\u5B50\u8868\u8FBE\u5F0F\u7ED3\u679C\u3002")
    );
  return { values: values.slice(0, -count), args: values.slice(-count) };
}
var UINT64_MASK = (1n << 64n) - 1n;
var FNV64_OFFSET = 0xcbf29ce484222325n;
var FNV64_PRIME = 0x100000001b3n;
var SPLITMIX_GAMMA = 0x9e3779b97f4a7c15n;
var SPLITMIX_MUL_1 = 0xbf58476d1ce4e5b9n;
var SPLITMIX_MUL_2 = 0x94d049bb133111ebn;
var TWO_POW_53 = 9007199254740992;
function fnv1a64(bytes) {
  return bytes.reduce(
    (hash, byte) => (hash ^ BigInt(byte)) * FNV64_PRIME & UINT64_MASK,
    FNV64_OFFSET
  );
}
function randomSeedHash(seed) {
  if (typeof seed === "string") return fnv1a64(new TextEncoder().encode(seed));
  const normalized = Object.is(seed, -0) ? 0 : seed;
  const buffer = new ArrayBuffer(8);
  new DataView(buffer).setFloat64(0, normalized, true);
  return fnv1a64(new Uint8Array(buffer));
}
function deterministicRandomUnit(seed, draw) {
  if (typeof seed === "number" && !Number.isFinite(seed) || !Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 seed \u5FC5\u987B\u6709\u9650\uFF0Cdraw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  const mixed0 = randomSeedHash(seed) + BigInt(draw) + SPLITMIX_GAMMA & UINT64_MASK;
  const mixed1 = (mixed0 ^ mixed0 >> 30n) * SPLITMIX_MUL_1 & UINT64_MASK;
  const mixed2 = (mixed1 ^ mixed1 >> 27n) * SPLITMIX_MUL_2 & UINT64_MASK;
  const mixed3 = mixed2 ^ mixed2 >> 31n;
  return Number((mixed3 & UINT64_MASK) >> 11n) / TWO_POW_53;
}
function calculateRandom(args, context, automaticDraw) {
  if (args.length > 2)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_BUILTIN_ARITY",
        "random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002"
      )
    );
  if (args.length < 2 && !context)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_CONTEXT_REQUIRED",
        "random() \u4E0E random(seed) \u9700\u8981\u6D88\u606F\u968F\u673A\u4E0A\u4E0B\u6587\u3002"
      )
    );
  const seed = args.length === 0 ? context.sourceKey : args[0];
  const draw = args.length === 2 ? args[1] : automaticDraw;
  if (!Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 draw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  return deterministicRandomUnit(seed, draw);
}
function calculateBuiltin(name, args) {
  const unary = {
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    asin: Math.asin,
    acos: Math.acos,
    atan: Math.atan,
    sinh: Math.sinh,
    cosh: Math.cosh,
    tanh: Math.tanh,
    asinh: Math.asinh,
    acosh: Math.acosh,
    atanh: Math.atanh,
    exp: Math.exp,
    log: Math.log,
    ln: Math.log,
    sqrt: Math.sqrt,
    abs: Math.abs,
    floor: Math.floor,
    ceil: Math.ceil,
    round: Math.round,
    trunc: Math.trunc,
    gamma
  };
  if (name in unary) {
    if (args.length !== 1)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      unary[name](args[0]),
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  if (name === "factorial") {
    if (args.length !== 1 || !Number.isSafeInteger(args[0]) || args[0] < 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FACTORIAL_DOMAIN",
          "factorial \u53EA\u63A5\u53D7\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    let result = 1;
    for (let value = 2; value <= args[0]; value += 1)
      result = finite(
        result * value,
        "ERA_EXPR_FACTORIAL_NON_FINITE",
        "factorial \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    return result;
  }
  if (name === "min" || name === "max") {
    if (args.length === 0)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return name === "min" ? Math.min(...args) : Math.max(...args);
  }
  if (name === "clamp") {
    if (args.length !== 3)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", "clamp \u9700\u8981\u4E09\u4E2A\u53C2\u6570\u3002")
      );
    return Math.min(Math.max(args[0], args[1]), args[2]);
  }
  if (name === "pow" || name === "mod") {
    if (args.length !== 2)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u9700\u8981\u4E24\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      name === "pow" ? args[0] ** args[1] : args[0] % args[1],
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  throw new ExpressionFailure(
    diagnostic("ERA_EXPR_BUILTIN_UNKNOWN", `\u672A\u77E5\u5185\u5EFA\u51FD\u6570 ${name}\u3002`)
  );
}
function inlineCustomAst(ast, bindings, library) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref") return bindings[ast.path.join(".")] ?? ast;
  if (ast.kind === "unary")
    return { ...ast, value: inlineCustomAst(ast.value, bindings, library) };
  if (ast.kind === "binary")
    return {
      ...ast,
      left: inlineCustomAst(ast.left, bindings, library),
      right: inlineCustomAst(ast.right, bindings, library)
    };
  const target = library.functions[ast.name];
  const args = ast.args.map((arg) => inlineCustomAst(arg, bindings, library));
  if (!target || !target.ast)
    return { kind: "call", name: ast.name, args, snapshot: ast.snapshot };
  const childBindings = Object.fromEntries(
    target.params.map((param, index) => [param, args[index]])
  );
  return inlineCustomAst(target.ast, childBindings, library);
}
function mathText(ast) {
  if (ast.kind === "literal")
    return Number.isInteger(ast.value) ? `${ast.value}` : `${ast.value}`;
  if (ast.kind === "ref") return ast.path.join("_");
  if (ast.kind === "unary") return `(${ast.op}${mathText(ast.value)})`;
  if (ast.kind === "binary")
    return `(${mathText(ast.left)} ${ast.op} ${mathText(ast.right)})`;
  const names = {
    ln: "log",
    pow: "pow",
    mod: "mod"
  };
  return `${names[ast.name] ?? ast.name}(${ast.args.map(mathText).join(",")})`;
}
function evaluateFunctionAt(library, name, input) {
  const target = library.functions[name];
  if (!target || !target.ast || target.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name} \u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: name }
      )
    );
  const sequence = {
    startState: {},
    currentState: {},
    compiled: library,
    snapshotCompiled: library,
    operations: [],
    cursor: 0,
    randomContext: null,
    randomDrawsConsumed: 0,
    diagnostics: []
  };
  let frame = createAstFrameState(
    sequence,
    target.ast,
    { [target.params[0]]: input },
    false
  );
  while (!frame.done) frame = advanceAstFrame(frame);
  if (frame.diagnostics.length > 0 || frame.result === null)
    throw new ExpressionFailure(
      frame.diagnostics[0] ?? diagnostic("ERA_EXPR_CALCULUS_EVALUATE", `\u51FD\u6570 ${name} \u65E0\u6CD5\u6C42\u503C\u3002`, {
        path: name
      })
    );
  return frame.result;
}
function calculateCalculus(name, target, args, library) {
  const functionDef = library.functions[target];
  if (!functionDef || !functionDef.ast || functionDef.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name} \u53EA\u63A5\u53D7\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: target }
      )
    );
  if (library.randomFunctions.includes(target))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_RANDOM_FORBIDDEN",
        `${name} \u4E0D\u80FD\u4EE5\u76F4\u63A5\u6216\u95F4\u63A5\u8C03\u7528 random \u7684\u51FD\u6570\u4E3A\u76EE\u6807\u3002`,
        { path: target }
      )
    );
  if (name === "derivative") {
    if (args.length !== 1 && args.length !== 2)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_BUILTIN_ARITY",
          "derivative \u9700\u8981 f\u3001at \u4E0E\u53EF\u9009 order\u3002"
        )
      );
    const order = args.length === 2 ? args[1] : 1;
    if (!Number.isSafeInteger(order) || order <= 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_ORDER",
          "\u5BFC\u6570\u9636\u6570\u5FC5\u987B\u662F\u4EFB\u610F\u6B63\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    const expanded = inlineCustomAst(functionDef.ast, {}, library);
    let derived = mathText(expanded);
    const variable = functionDef.params[0];
    try {
      for (let currentOrder = 0; currentOrder < order; currentOrder += 1) {
        const node = derivative(derived, variable);
        derived = node.toString();
        if (derived === "0") break;
      }
      const value = Number(mathEvaluate(derived, { [variable]: args[0] }));
      return finite(
        value,
        "ERA_EXPR_DERIVATIVE_NON_FINITE",
        "\u5BFC\u6570\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    } catch (error) {
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_UNSUPPORTED",
          `\u65E0\u6CD5\u6784\u9020\u8BE5\u5BFC\u6570\uFF1A${error instanceof Error ? error.message : String(error)}\u3002`,
          { path: target }
        )
      );
    }
  }
  if (args.length !== 2)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_BUILTIN_ARITY", "integral \u9700\u8981 f\u3001start\u3001end\u3002")
    );
  const [start, end] = args;
  if (start === end) return 0;
  const direction = start < end ? 1 : -1;
  const left = Math.min(start, end);
  const right = Math.max(start, end);
  const evaluate = (value) => evaluateFunctionAt(library, target, value);
  const simpson = (a, b, fa, fm, fb) => (b - a) / 6 * (fa + 4 * fm + fb);
  const middle = (left + right) / 2;
  const whole = simpson(
    left,
    right,
    evaluate(left),
    evaluate(middle),
    evaluate(right)
  );
  const stack = [
    {
      a: left,
      b: right,
      fa: evaluate(left),
      fm: evaluate(middle),
      fb: evaluate(right),
      whole,
      tolerance: 1e-9
    }
  ];
  let sum = 0;
  let processed = 0;
  while (stack.length > 0) {
    const segment = stack.pop();
    processed += 1;
    if (processed > 65536)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_INTEGRAL_CONVERGENCE",
          "\u79EF\u5206\u5728\u786E\u5B9A\u6027 Simpson \u8FED\u4EE3\u5185\u672A\u6536\u655B\u3002",
          { path: target }
        )
      );
    const mid = (segment.a + segment.b) / 2;
    const leftMid = (segment.a + mid) / 2;
    const rightMid = (mid + segment.b) / 2;
    const leftValue = evaluate(leftMid);
    const rightValue = evaluate(rightMid);
    const leftArea = simpson(segment.a, mid, segment.fa, leftValue, segment.fm);
    const rightArea = simpson(
      mid,
      segment.b,
      segment.fm,
      rightValue,
      segment.fb
    );
    const delta = leftArea + rightArea - segment.whole;
    if (Math.abs(delta) <= 15 * segment.tolerance) {
      sum += leftArea + rightArea + delta / 15;
      continue;
    }
    stack.push({
      a: mid,
      b: segment.b,
      fa: segment.fm,
      fm: rightValue,
      fb: segment.fb,
      whole: rightArea,
      tolerance: segment.tolerance / 2
    });
    stack.push({
      a: segment.a,
      b: mid,
      fa: segment.fa,
      fm: leftValue,
      fb: segment.fm,
      whole: leftArea,
      tolerance: segment.tolerance / 2
    });
  }
  return finite(
    direction * sum,
    "ERA_EXPR_INTEGRAL_NON_FINITE",
    "\u79EF\u5206\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
  );
}
function createAstFrameState(sequence, ast, env = {}, allowState = true, library = sequence.compiled) {
  return {
    sequence,
    stack: [{ kind: "eval", ast, env, allowState, library }],
    values: [],
    automaticRandomDrawCursor: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    done: false,
    result: null,
    diagnostics: []
  };
}
function complete(state) {
  if (state.stack.length === 0 && state.values.length === 1)
    return { ...state, done: true, result: state.values[0] };
  return { ...state, done: false, result: null };
}
function astFrameRoute(state) {
  const top = state.stack[state.stack.length - 1];
  if (!top) return "return";
  if (top.kind === "eval") {
    if (top.ast.kind === "literal" || top.ast.kind === "ref") return "value";
    if (top.ast.kind === "unary" || top.ast.kind === "binary")
      return "operator";
    if (top.ast.name === "random") return "random";
    if (isBuiltin(top.ast.name)) return "builtin";
    return "custom";
  }
  if (top.kind === "unary" || top.kind === "binary") return "operator";
  if (top.kind === "builtin" || top.kind === "calculus") return "builtin";
  if (top.kind === "random") return "random";
  if (top.kind === "custom") return "custom";
  return "return";
}
function advanceAstFrame(state, expected) {
  if (state.done) return state;
  try {
    const actual = astFrameRoute(state);
    if (expected && actual !== expected)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FRAME_ROUTE",
          `\u8C03\u7528\u5E27\u8DEF\u7531\u4E0D\u5339\u914D\uFF1A\u671F\u671B ${expected}\uFF0C\u5B9E\u9645 ${actual}\u3002`
        )
      );
    const stack = [...state.stack];
    const values = [...state.values];
    let automaticRandomDrawCursor = state.automaticRandomDrawCursor;
    const top = stack.pop();
    if (!top) return complete({ ...state, stack, values });
    if (top.kind === "eval") {
      if (top.ast.kind === "literal") values.push(top.ast.value);
      else if (top.ast.kind === "ref")
        values.push(refValue(top.ast, state.sequence, top.env, top.allowState));
      else if (top.ast.kind === "unary") {
        stack.push(
          { kind: "unary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.value,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "binary") {
        stack.push(
          { kind: "binary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.right,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          },
          {
            kind: "eval",
            ast: top.ast.left,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "call") {
        if (top.ast.name === "derivative" || top.ast.name === "integral") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          const targetAst = top.ast.args[0];
          if (!targetAst || targetAst.kind !== "ref" || targetAst.snapshot || targetAst.path.length !== 1)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_CALCULUS_TARGET",
                `${top.ast.name} \u7684\u9996\u53C2\u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u51FD\u6570\u540D\u3002`
              )
            );
          stack.push({
            kind: "calculus",
            name: top.ast.name,
            target: targetAst.path[0],
            count: top.ast.args.length - 1,
            library: top.library
          });
          for (const arg of [...top.ast.args.slice(1)].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (top.ast.name === "random") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({ kind: "random", count: top.ast.args.length });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (isBuiltin(top.ast.name)) {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({
            kind: "builtin",
            name: top.ast.name,
            count: top.ast.args.length
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else {
          stack.push({
            kind: "custom",
            name: top.ast.name,
            count: top.ast.args.length,
            library: top.ast.snapshot ? state.sequence.snapshotCompiled : top.library
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        }
      }
    } else if (top.kind === "unary") {
      const popped = popValues(values, 1);
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          top.op === "+" ? popped.args[0] : -popped.args[0],
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E00\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "binary") {
      const popped = popValues(values, 2);
      const [left, right] = popped.args;
      const result = top.op === "+" ? left + right : top.op === "-" ? left - right : top.op === "*" ? left * right : top.op === "/" ? left / right : top.op === "%" ? left % right : left ** right;
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          result,
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E8C\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "builtin") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateBuiltin(top.name, popped.args)
      );
    } else if (top.kind === "random") {
      const popped = popValues(values, top.count);
      const draw = automaticRandomDrawCursor;
      if (top.count < 2) automaticRandomDrawCursor += 1;
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateRandom(popped.args, state.sequence.randomContext, draw)
      );
    } else if (top.kind === "calculus") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateCalculus(
          top.name,
          top.target,
          popped.args,
          top.library
        )
      );
    } else {
      const popped = popValues(values, top.count);
      const target = top.library.functions[top.name];
      if (!target || !target.ast)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
            `\u672A\u77E5\u51FD\u6570 ${top.name}\u3002`,
            { path: top.name }
          )
        );
      if (target.params.length !== popped.args.length)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_ARITY",
            `\u51FD\u6570 ${top.name} \u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
            { path: top.name }
          )
        );
      const env = Object.fromEntries(
        target.params.map((param, index) => [param, popped.args[index]])
      );
      values.splice(0, values.length, ...popped.values);
      stack.push({
        kind: "eval",
        ast: target.ast,
        env,
        allowState: false,
        library: top.library
      });
    }
    return complete({ ...state, stack, values, automaticRandomDrawCursor });
  } catch (error) {
    const detail = error instanceof ExpressionFailure ? error.detail : diagnostic(
      "ERA_EXPR_EVALUATION_FAILED",
      error instanceof Error ? error.message : String(error)
    );
    return {
      ...state,
      stack: [],
      done: true,
      result: null,
      diagnostics: [...state.diagnostics, detail]
    };
  }
}
function runOperationStep(state) {
  const operation = state.operations[state.cursor];
  if (!operation)
    return {
      sequenceStateNext: state,
      sequenceDone: true,
      operationExecutionResult: {
        finalState: state.currentState,
        diagnostics: state.diagnostics,
        randomDrawsConsumed: state.randomDrawsConsumed
      }
    };
  if (!state.compiled.valid) {
    const next2 = {
      ...state,
      cursor: state.cursor + 1,
      diagnostics: [...state.diagnostics, ...operation.diagnostics]
    };
    return {
      sequenceStateNext: next2,
      sequenceDone: next2.cursor >= next2.operations.length,
      operationExecutionResult: {
        finalState: next2.currentState,
        diagnostics: next2.diagnostics,
        randomDrawsConsumed: next2.randomDrawsConsumed
      }
    };
  }
  if (!operation.ast || operation.diagnostics.length > 0) {
    const next2 = {
      ...state,
      cursor: state.cursor + 1,
      diagnostics: [...state.diagnostics, ...operation.diagnostics]
    };
    return {
      sequenceStateNext: next2,
      sequenceDone: next2.cursor >= next2.operations.length,
      operationExecutionResult: {
        finalState: next2.currentState,
        diagnostics: next2.diagnostics,
        randomDrawsConsumed: next2.randomDrawsConsumed
      }
    };
  }
  const randomDraws = countAutomaticRandomDraws(
    operation.ast,
    state.compiled,
    state.snapshotCompiled
  );
  let frame = createAstFrameState(state, operation.ast);
  while (!frame.done) frame = advanceAstFrame(frame);
  const diagnostics = [...state.diagnostics, ...frame.diagnostics];
  const currentState = frame.result === null ? state.currentState : setPath(state.currentState, operation.path, frame.result);
  const next = {
    ...state,
    currentState,
    cursor: state.cursor + 1,
    randomDrawsConsumed: state.randomDrawsConsumed + randomDraws,
    diagnostics
  };
  return {
    sequenceStateNext: next,
    sequenceDone: next.cursor >= next.operations.length,
    operationExecutionResult: {
      finalState: next.currentState,
      diagnostics: next.diagnostics,
      randomDrawsConsumed: next.randomDrawsConsumed
    }
  };
}
function substituteSymbolic(ast, state) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref")
    return state[ast.path.join(".")] ?? {
      kind: "ref",
      path: ast.path,
      snapshot: true
    };
  if (ast.kind === "unary")
    return simplify({
      kind: "unary",
      op: ast.op,
      value: substituteSymbolic(ast.value, state)
    });
  if (ast.kind === "binary")
    return simplify({
      kind: "binary",
      op: ast.op,
      left: substituteSymbolic(ast.left, state),
      right: substituteSymbolic(ast.right, state)
    });
  return {
    kind: "call",
    name: ast.name,
    args: ast.args.map((arg) => substituteSymbolic(arg, state)),
    snapshot: ast.snapshot
  };
}
function literal(value) {
  return { kind: "literal", value: Object.is(value, -0) ? 0 : value };
}
function literalNumber(ast) {
  return ast.kind === "literal" ? ast.value : void 0;
}
function simplify(ast) {
  if (ast.kind === "literal" || ast.kind === "ref") return ast;
  if (ast.kind === "call") return { ...ast, args: ast.args.map(simplify) };
  if (ast.kind === "unary") {
    const value = simplify(ast.value);
    const number = literalNumber(value);
    if (number !== void 0) return literal(ast.op === "+" ? number : -number);
    if (ast.op === "+") return value;
    return { ...ast, value };
  }
  const left = simplify(ast.left);
  const right = simplify(ast.right);
  const leftNumber = literalNumber(left);
  const rightNumber = literalNumber(right);
  if (leftNumber !== void 0 && rightNumber !== void 0) {
    const result = ast.op === "+" ? leftNumber + rightNumber : ast.op === "-" ? leftNumber - rightNumber : ast.op === "*" ? leftNumber * rightNumber : ast.op === "/" ? leftNumber / rightNumber : ast.op === "%" ? leftNumber % rightNumber : leftNumber ** rightNumber;
    return Number.isFinite(result) ? literal(result) : { ...ast, left, right };
  }
  if (ast.op === "+") {
    if (rightNumber === 0) return left;
    if (leftNumber === 0) return right;
    const nested = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && nested !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const subtraction = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && subtraction !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(subtraction - rightNumber)
      });
  }
  if (ast.op === "-") {
    if (rightNumber === 0) return left;
    const nested = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && nested !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const addition = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && addition !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(addition - rightNumber)
      });
  }
  if (ast.op === "*") {
    if (leftNumber === 0 || rightNumber === 0) return literal(0);
    if (leftNumber === 1) return right;
    if (rightNumber === 1) return left;
  }
  if (ast.op === "/" && rightNumber === 1) return left;
  return { ...ast, left, right };
}
function operatorPrecedence(op) {
  return op === "+" || op === "-" ? 1 : op === "*" || op === "/" || op === "%" ? 2 : 3;
}
function printAst(ast, parent = 0) {
  if (ast.kind === "literal") return `${ast.value}`;
  if (ast.kind === "ref")
    return `${ast.snapshot ? "@" : ""}${ast.path.join(".")}`;
  if (ast.kind === "call")
    return `${ast.snapshot ? "@" : ""}${ast.name}(${ast.args.map((arg) => printAst(arg)).join(", ")})`;
  if (ast.kind === "unary") {
    const own2 = 4;
    const text2 = `${ast.op}${printAst(ast.value, own2)}`;
    return own2 < parent ? `(${text2})` : text2;
  }
  const own = operatorPrecedence(ast.op);
  const text = `${printAst(ast.left, own)} ${ast.op} ${printAst(ast.right, own + (ast.op === "^" ? 0 : 1))}`;
  return own < parent ? `(${text})` : text;
}
function deriveSymbolicLayer(sequence) {
  const symbols = {};
  const tainted = /* @__PURE__ */ new Set();
  const conflicts = (left, right) => left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
  const referencesTainted = (ast) => {
    let found = false;
    walk(ast, (item) => {
      if (item.kind === "ref" && !item.snapshot && [...tainted].some((path) => conflicts(item.path.join("."), path)))
        found = true;
    });
    return found;
  };
  for (const operation of sequence.operations) {
    if (!operation.ast || operation.diagnostics.length > 0) continue;
    const path = operation.path.join(".");
    if (countAutomaticRandomDraws(
      operation.ast,
      sequence.compiled,
      sequence.snapshotCompiled
    ) > 0 || referencesTainted(operation.ast)) {
      tainted.add(path);
      for (const existing of Object.keys(symbols))
        if (conflicts(existing, path)) delete symbols[existing];
      continue;
    }
    symbols[path] = simplify(substituteSymbolic(operation.ast, symbols));
  }
  return symbols;
}
function normaliseCompaction(sequence, symbols) {
  const compressed = {};
  for (const [path, ast] of Object.entries(symbols)) {
    const before = getPath(sequence.startState, path.split("."));
    const after = getPath(sequence.currentState, path.split("."));
    if (JSON.stringify(before) !== JSON.stringify(after))
      compressed[path] = { $expr: printAst(simplify(ast)) };
  }
  return {
    status: sequence.diagnostics.length === 0 ? "ok" : sequence.cursor === 0 ? "invalid" : "partial",
    finalState: sequence.currentState,
    diagnostics: sequence.diagnostics,
    compressed,
    compactedOperations: Object.entries(compressed).map(([path, value]) => ({
      path,
      value
    })),
    randomDrawsConsumed: sequence.randomDrawsConsumed,
    nextDrawOffset: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    containsAutomaticRandom: sequence.operations.some(
      (operation) => operation.ast !== null && operation.diagnostics.length === 0 && countAutomaticRandomDraws(
        operation.ast,
        sequence.compiled,
        sequence.snapshotCompiled
      ) > 0
    )
  };
}
function executeExpressionLayer(input) {
  const normalized = normaliseRequest(input);
  const compiled = compileFunctionLibrary(normalized.functionLibrary);
  const snapshotCompiled = normalized.snapshotFunctionLibrary ? compileFunctionLibrary(normalized.snapshotFunctionLibrary) : compiled;
  const operations = parseOperations(normalized);
  let state = initializeSequenceState(
    normalized,
    compiled,
    operations,
    snapshotCompiled
  );
  while (state.cursor < state.operations.length)
    state = runOperationStep(state).sequenceStateNext;
  return normaliseCompaction(state, deriveSymbolicLayer(state));
}

// generated/release/workflow.js
function run() {
  return {};
}
function tagInfo(value) {
  if (value === "variableinsert") return { kind: "insert", tag: "VariableInsert" };
  if (value === "variableedit") return { kind: "edit", tag: "VariableEdit" };
  if (value === "variabledelete") return { kind: "delete", tag: "VariableDelete" };
  if (value === "functioninsert") return { kind: "function-insert", tag: "FunctionInsert" };
  if (value === "functionedit") return { kind: "function-edit", tag: "FunctionEdit" };
  if (value === "functiondelete") return { kind: "function-delete", tag: "FunctionDelete" };
  return null;
}
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function plain(value) {
  if (!record(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
function clone2(value) {
  return structuredClone(value);
}
function equal(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function diagnostic2(code, message, commandIndex, path) {
  return { code, message, ...commandIndex === void 0 ? {} : { commandIndex }, ...path === void 0 ? {} : { path } };
}
function stripFence(text) {
  const match = /^```(?:json)?\s*([\s\S]*?)\s*```$/iu.exec(text.trim());
  return match ? match[1] : text.trim();
}
function parseData(text, commandIndex) {
  try {
    const parsed = JSON.parse(stripFence(text));
    const values = Array.isArray(parsed) ? parsed : [parsed];
    if (!values.every(plain)) {
      return { data: [], diagnostic: diagnostic2("ERA_COMPACT_COMMAND_DATA_INVALID", "\u6307\u4EE4\u5185\u5BB9\u5FC5\u987B\u662F JSON \u5BF9\u8C61\u6216\u5BF9\u8C61\u6570\u7EC4\u3002", commandIndex) };
    }
    return { data: values };
  } catch (error) {
    return { data: [], diagnostic: diagnostic2("ERA_COMPACT_COMMAND_JSON_INVALID", `\u6307\u4EE4 JSON \u65E0\u6CD5\u89E3\u6790\uFF1A${error instanceof Error ? error.message : String(error)}`, commandIndex) };
  }
}
function parseCommandLayer(input) {
  const source = record(input) ? input : {};
  const request = {
    content: typeof source.content === "string" ? source.content : "",
    initialStatData: plain(source.initialStatData) ? clone2(source.initialStatData) : {},
    initialStatFunc: plain(source.initialStatFunc) ? clone2(source.initialStatFunc) : {},
    snapshotStatData: plain(source.snapshotStatData) ? clone2(source.snapshotStatData) : plain(source.initialStatData) ? clone2(source.initialStatData) : {},
    snapshotStatFunc: plain(source.snapshotStatFunc) ? clone2(source.snapshotStatFunc) : plain(source.initialStatFunc) ? clone2(source.initialStatFunc) : {},
    eraMeta: plain(source.eraMeta) ? clone2(source.eraMeta) : {},
    templateContext: plain(source.templateContext) ? clone2(source.templateContext) : {},
    randomContext: plain(source.randomContext) && typeof source.randomContext.sourceKey === "string" && source.randomContext.sourceKey.length > 0 && Number.isSafeInteger(source.randomContext.drawOffset) && source.randomContext.drawOffset >= 0 ? {
      sourceKey: source.randomContext.sourceKey,
      drawOffset: source.randomContext.drawOffset
    } : void 0
  };
  const commands = [];
  const diagnostics = [];
  const pattern = /<((?:Variable|Function)(?:Insert|Edit|Delete))>\s*([\s\S]*?)\s*<\/\1>/giu;
  let match;
  while ((match = pattern.exec(request.content)) !== null) {
    const info = tagInfo((match[1] ?? "").toLowerCase());
    if (!info) continue;
    const index = commands.length;
    const parsed = parseData(match[2] ?? "", index);
    if (parsed.diagnostic) diagnostics.push(parsed.diagnostic);
    commands.push({
      index,
      kind: info.kind,
      tag: info.tag,
      data: parsed.data,
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0]
    });
  }
  return { request, commands, diagnostics };
}
function getAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function hasAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return false;
    cursor = cursor[segment];
  }
  return true;
}
function setAt(root, segments, value) {
  let cursor = root;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const key = segments[index];
    if (!plain(cursor[key])) cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[segments[segments.length - 1]] = clone2(value);
}
function unsetAt(root, segments) {
  let cursor = root;
  for (const segment of segments.slice(0, -1)) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return;
    cursor = cursor[segment];
  }
  if (record(cursor)) delete cursor[segments[segments.length - 1]];
}
function metaValue(value, key) {
  return plain(value) && plain(value.$meta) ? value.$meta[key] : void 0;
}
function merge(left, right) {
  if (!plain(left) || !plain(right)) return clone2(right);
  const output = clone2(left);
  for (const [key, value] of Object.entries(right)) {
    output[key] = Object.prototype.hasOwnProperty.call(output, key) ? merge(output[key], value) : clone2(value);
  }
  return output;
}
function inheritedTemplateContent(parentTemplate, key) {
  if (!plain(parentTemplate)) return void 0;
  const general = parentTemplate.$template;
  const specific = parentTemplate[key];
  if (plain(general) && plain(specific)) return merge(general, specific);
  return plain(specific) ? specific : plain(general) ? general : void 0;
}
function resolvedTemplate(inherited, parentData) {
  const own = plain(parentData) ? parentData.$template : void 0;
  const result = merge(plain(inherited) ? inherited : {}, plain(own) ? own : {});
  return plain(result) && Object.keys(result).length > 0 ? result : void 0;
}
function applyTemplate(template, patch) {
  if (!plain(patch) || !plain(template)) return clone2(patch);
  return Object.keys(patch).length === 0 ? clone2(template) : merge(template, patch);
}
function applyInsertAt(stat, segments, patch, inheritedTemplate = void 0, parentData = void 0) {
  const current = getAt(stat, segments);
  const localTemplate = resolvedTemplate(inheritedTemplate, parentData);
  if (segments.length > 0 && current === void 0) {
    setAt(stat, segments, applyTemplate(localTemplate, patch));
    return;
  }
  if (!plain(current) || !plain(patch)) return;
  const protection = metaValue(current, "unInsertAble");
  const keys = Object.keys(patch);
  const metaOnly = keys.every((key) => key === "$meta");
  if (protection === "all" && keys.length > 0 && !metaOnly) return;
  for (const key of keys) {
    if (protection === "self" && key !== "$meta" && !Object.prototype.hasOwnProperty.call(current, key)) continue;
    applyInsertAt(
      stat,
      [...segments, key],
      patch[key],
      inheritedTemplateContent(localTemplate, key),
      current
    );
  }
}
function expressionValue(stat, layerStart, statFunc, startFunc, path, expr, randomCursor) {
  const request = {
    initialState: stat,
    snapshotState: layerStart,
    functionLibrary: statFunc,
    snapshotFunctionLibrary: startFunc,
    allowSnapshots: true,
    operations: [{ path: path.join("."), expr }],
    ...randomCursor ? { randomContext: randomCursor } : {}
  };
  const response = executeExpressionLayer(request);
  if (randomCursor) randomCursor.drawOffset = response.nextDrawOffset;
  const value = getAt(response.finalState, path);
  const issue = response.diagnostics[0];
  if (issue || typeof value !== "number" || !Number.isFinite(value)) {
    return { diagnostic: diagnostic2(issue?.code ?? "ERA_COMPACT_EXPR_NON_FINITE", issue?.message ?? "$expr \u5FC5\u987B\u5F97\u5230\u6709\u9650\u6570\u503C\u3002", void 0, path.join(".")) };
  }
  return { value };
}
function applyEditAt(stat, layerStart, statFunc, startFunc, segments, patch, diagnostics, commandIndex, randomCursor) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  if (metaValue(current, "updatable") === false) {
    const unlock = plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true;
    if (!unlock) return;
  }
  if (plain(patch) && Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (segments.length === 0 || !hasAt(stat, segments)) return;
    const resolved = expressionValue(
      stat,
      layerStart,
      statFunc,
      startFunc,
      segments,
      patch.$expr,
      randomCursor
    );
    if (resolved.diagnostic) diagnostics.push({ ...resolved.diagnostic, commandIndex });
    else setAt(stat, segments, resolved.value);
    return;
  }
  if (!plain(patch)) {
    if (segments.length > 0 && hasAt(stat, segments)) setAt(stat, segments, patch);
    return;
  }
  for (const [key, value] of Object.entries(patch)) {
    applyEditAt(stat, layerStart, statFunc, startFunc, [...segments, key], value, diagnostics, commandIndex, randomCursor);
  }
}
function deleteBypass(patch) {
  return plain(patch) && plain(patch.$meta) && Object.prototype.hasOwnProperty.call(patch.$meta, "necessary");
}
function emptyRecord(value) {
  return plain(value) && Object.keys(value).length === 0;
}
function applyDeleteAt(stat, segments, patch) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  const necessary = metaValue(current, "necessary");
  const bypass = deleteBypass(patch);
  if (plain(patch) && Object.keys(patch).length > 0) {
    if (necessary === "all" && !bypass) return;
    for (const [key, value] of Object.entries(patch)) {
      if (necessary === "children" && emptyRecord(value) && !(key === "$meta" && bypass)) continue;
      applyDeleteAt(stat, [...segments, key], value);
    }
    return;
  }
  if (segments.length === 0 || necessary === "self" || necessary === "all") return;
  unsetAt(stat, segments);
}
function functionDiagnostic(code, message, commandIndex, name) {
  return diagnostic2(code, message, commandIndex, name);
}
function functionMetaInvalid(value) {
  const meta = plain(value) && plain(value.$meta) ? value.$meta : null;
  if (!meta) return null;
  if (Object.prototype.hasOwnProperty.call(meta, "unInsertAble")) return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.unInsertAble\u3002";
  if (meta.necessary === "children") return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.necessary: children\u3002";
  return null;
}
function validateFunctions(library) {
  const result = executeExpressionLayer({ initialState: {}, functionLibrary: library, operations: [] });
  const issue = result.diagnostics[0];
  return issue ? diagnostic2(issue.code, issue.message, void 0, "<library>") : null;
}
function editFunction(current, patch) {
  if (!plain(current) || !plain(patch)) return clone2(patch);
  const patchMeta = plain(patch.$meta) ? patch.$meta : null;
  if (Object.keys(patch).length === 1 && patchMeta) {
    const next2 = clone2(current);
    next2.$meta = merge(current.$meta, patchMeta);
    return next2;
  }
  const next = clone2(patch);
  if (!Object.prototype.hasOwnProperty.call(patch, "$meta") && Object.prototype.hasOwnProperty.call(current, "$meta")) next.$meta = clone2(current.$meta);
  else if (patchMeta) next.$meta = merge(current.$meta, patchMeta);
  return next;
}
function applyFunction(library, type, data, diagnostics, commandIndex) {
  let current = clone2(library);
  for (const root of data) {
    if (Object.keys(root).length === 0) {
      diagnostics.push(functionDiagnostic("ERA_FUNCTION_COMMAND_INVALID", "\u51FD\u6570\u6307\u4EE4\u5FC5\u987B\u662F\u975E\u7A7A\u5BF9\u8C61\u3002", commandIndex));
      continue;
    }
    const candidate = clone2(current);
    const issues = [];
    for (const [name, patch] of Object.entries(root)) {
      const exists = Object.prototype.hasOwnProperty.call(current, name);
      if (type === "function-insert") {
        if (exists) {
          issues.push(functionDiagnostic("ERA_FUNCTION_ALREADY_EXISTS", "FunctionInsert \u53EA\u80FD\u65B0\u589E\u4E0D\u5B58\u5728\u7684\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        const invalid2 = functionMetaInvalid(patch);
        if (invalid2) {
          issues.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = clone2(patch);
      } else if (type === "function-edit") {
        if (!exists) {
          issues.push(functionDiagnostic("ERA_FUNCTION_NOT_FOUND", "FunctionEdit \u53EA\u80FD\u4FEE\u6539\u65E2\u6709\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        if (metaValue(current[name], "updatable") === false && !(plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true)) continue;
        const next = editFunction(current[name], patch);
        const invalid2 = functionMetaInvalid(next);
        if (invalid2) {
          issues.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = next;
      } else {
        if (!plain(patch)) {
          issues.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
          continue;
        }
        if (Object.keys(patch).length === 0) {
          if (exists && !["self", "all"].includes(String(metaValue(current[name], "necessary")))) delete candidate[name];
        } else if (Object.keys(patch).length === 1 && plain(patch.$meta) && exists) {
          const next = clone2(current[name]);
          const metaPatch = patch.$meta;
          if (plain(next.$meta)) {
            for (const key of Object.keys(metaPatch)) delete next.$meta[key];
          }
          candidate[name] = next;
        } else issues.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
      }
    }
    if (issues.length > 0) {
      diagnostics.push(...issues);
      continue;
    }
    const invalid = validateFunctions(candidate);
    if (invalid) {
      diagnostics.push({ ...invalid, commandIndex });
      continue;
    }
    current = candidate;
  }
  return current;
}
function executeOriginalSemantics(parsed) {
  const stat = clone2(parsed.request.initialStatData);
  const start = clone2(parsed.request.snapshotStatData ?? parsed.request.initialStatData);
  let functions = clone2(parsed.request.initialStatFunc ?? {});
  const startFunctions = clone2(parsed.request.snapshotStatFunc ?? parsed.request.initialStatFunc ?? {});
  const diagnostics = [...parsed.diagnostics];
  const randomCursor = parsed.request.randomContext ? { ...parsed.request.randomContext } : null;
  for (const command of parsed.commands) {
    if (command.data.length === 0) continue;
    if (command.kind === "insert") for (const patch of command.data) applyInsertAt(stat, [], patch);
    else if (command.kind === "edit") for (const patch of command.data) applyEditAt(stat, start, functions, startFunctions, [], patch, diagnostics, command.index, randomCursor);
    else if (command.kind === "delete") for (const patch of command.data) applyDeleteAt(stat, [], patch);
    else functions = applyFunction(functions, command.kind, command.data, diagnostics, command.index);
  }
  return {
    ...parsed,
    finalStatData: stat,
    finalStatFunc: functions,
    diagnostics,
    nextRandomDrawOffset: randomCursor?.drawOffset ?? parsed.request.randomContext?.drawOffset ?? 0
  };
}
function hasMeta(value) {
  if (!plain(value)) return false;
  if (Object.prototype.hasOwnProperty.call(value, "$meta") || Object.prototype.hasOwnProperty.call(value, "$template")) return true;
  return Object.values(value).some(hasMeta);
}
function flattenNumericEdits(patch, prefix = [], output = []) {
  if (!plain(patch)) return false;
  if (Object.prototype.hasOwnProperty.call(patch, "$meta") || Object.prototype.hasOwnProperty.call(patch, "$template")) return false;
  if (Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (prefix.length === 0) return false;
    output.push({ path: prefix.join("."), expr: patch.$expr, source: "expr" });
    return true;
  }
  for (const [key, value] of Object.entries(patch)) {
    if (plain(value)) {
      if (!flattenNumericEdits(value, [...prefix, key], output)) return false;
    } else if (typeof value === "number" && Number.isFinite(value)) output.push({ path: [...prefix, key].join("."), expr: JSON.stringify(value), source: "literal", literal: value });
    else return false;
  }
  return output.length > 0;
}
function nestingRecord(paths) {
  const result = {};
  for (const item of paths) {
    const parts = item.path.split(".");
    let cursor = result;
    for (const part of parts.slice(0, -1)) {
      if (Object.prototype.hasOwnProperty.call(cursor, part) && !plain(cursor[part])) return null;
      cursor[part] ??= {};
      cursor = cursor[part];
    }
    const leaf = parts[parts.length - 1];
    if (plain(cursor[leaf])) return null;
    cursor[leaf] = item.value;
  }
  return result;
}
function renderTag(tag, data) {
  return `<${tag}>
${JSON.stringify(data)}
</${tag}>`;
}
function mergeInsertPatch(left, right) {
  if (!plain(left) || !plain(right) || hasMeta(left) || hasMeta(right)) return null;
  const output = clone2(left);
  for (const [key, value] of Object.entries(right)) {
    if (!Object.prototype.hasOwnProperty.call(output, key)) output[key] = clone2(value);
    else if (plain(output[key]) && plain(value)) {
      const merged = mergeInsertPatch(output[key], value);
      if (merged === null) return null;
      output[key] = merged;
    } else if (!plain(output[key]) && plain(value)) {
      return null;
    }
  }
  return output;
}
function allCommandData(command) {
  if (command.data.length !== 1) return null;
  return command.data[0] ?? null;
}
function compactEditRun(trace, commands) {
  const operations = [];
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data || !flattenNumericEdits(data, [], operations)) return null;
  }
  const response = executeExpressionLayer({
    initialState: trace.request.initialStatData,
    snapshotState: trace.request.snapshotStatData ?? trace.request.initialStatData,
    functionLibrary: trace.request.initialStatFunc ?? {},
    snapshotFunctionLibrary: trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {},
    allowSnapshots: true,
    operations,
    ...trace.request.randomContext ? { randomContext: trace.request.randomContext } : {}
  });
  if (response.diagnostics.length > 0) return null;
  const sourceByPath = /* @__PURE__ */ new Map();
  const lastLiteralByPath = /* @__PURE__ */ new Map();
  for (const operation of operations) {
    const prior = sourceByPath.get(operation.path);
    sourceByPath.set(operation.path, prior === void 0 || prior === operation.source ? operation.source : "mixed");
    if (operation.source === "literal") lastLiteralByPath.set(operation.path, operation.literal);
  }
  if ([...sourceByPath.values()].includes("mixed")) return null;
  const output = nestingRecord(response.compactedOperations.map((item) => {
    const source = sourceByPath.get(item.path);
    return source === "literal" ? { path: item.path, value: lastLiteralByPath.get(item.path) } : { path: item.path, value: { $expr: item.value.$expr } };
  }));
  return output && Object.keys(output).length > 0 ? renderTag("VariableEdit", output) : "";
}
function pathConflict(left, right) {
  return left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
}
function operationRefs(ast) {
  const refs = /* @__PURE__ */ new Set();
  const visit = (item) => {
    if (item.kind === "ref") {
      if (!item.snapshot) refs.add(item.path.join("."));
      return;
    }
    if (item.kind === "unary") visit(item.value);
    else if (item.kind === "binary") {
      visit(item.left);
      visit(item.right);
    } else if (item.kind === "call") for (const arg of item.args) visit(arg);
  };
  visit(ast);
  return [...refs];
}
function commandExpressionFacts(trace, command) {
  const operations = [];
  const data = allCommandData(command);
  if (!data || !flattenNumericEdits(data, [], operations))
    return { automaticRandom: false, paths: [], refs: [], flattenable: false };
  const current = compileFunctionLibrary(trace.request.initialStatFunc ?? {});
  const snapshot = compileFunctionLibrary(
    trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {}
  );
  const refs = /* @__PURE__ */ new Set();
  let automaticRandom = false;
  for (const operation of operations) {
    const parsed = parseExpression(operation.expr, true);
    if (!parsed.ast) continue;
    if (countAutomaticRandomDraws(parsed.ast, current, snapshot) > 0)
      automaticRandom = true;
    for (const ref of operationRefs(parsed.ast)) refs.add(ref);
  }
  return {
    automaticRandom,
    paths: operations.map((operation) => operation.path),
    refs: [...refs],
    flattenable: true
  };
}
function segmentDoesNotDependOnPriorChanges(facts, priorPaths) {
  return facts.every(
    (fact) => fact.refs.every(
      (ref) => ![...priorPaths].some((path) => pathConflict(ref, path))
    )
  );
}
function compactInsertRun(commands) {
  let merged = {};
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data) return null;
    const next = mergeInsertPatch(merged, data);
    if (next === null) return null;
    merged = next;
  }
  return plain(merged) && Object.keys(merged).length > 0 ? renderTag("VariableInsert", merged) : null;
}
function candidateFor(analysis) {
  const { trace } = analysis;
  const replacements = /* @__PURE__ */ new Map();
  const reasons = [];
  if (trace.diagnostics.length > 0) return { ...trace, replacements, reasons: ["\u539F\u547D\u4EE4\u542B\u8BCA\u65AD\uFF0C\u4FDD\u7559\u5168\u90E8\u6807\u7B7E\u3002"] };
  let cursor = 0;
  while (cursor < trace.commands.length) {
    const kind = trace.commands[cursor].kind;
    let end = cursor + 1;
    while (end < trace.commands.length && trace.commands[end].kind === kind) end += 1;
    const run12 = trace.commands.slice(cursor, end);
    let replacement = null;
    if (kind === "edit") {
      if (cursor === 0) {
        const facts = run12.map((command) => analysis.facts[command.index]);
        const priorPaths = /* @__PURE__ */ new Set();
        let segmentStart = 0;
        const compactSegment = (segmentEnd) => {
          if (segmentEnd <= segmentStart) return;
          const segment = run12.slice(segmentStart, segmentEnd);
          const segmentFacts = facts.slice(segmentStart, segmentEnd);
          if (segmentFacts.every((fact) => fact.flattenable) && segmentDoesNotDependOnPriorChanges(segmentFacts, priorPaths)) {
            const compacted = compactEditRun(trace, segment);
            if (compacted !== null && (segment.length > 1 || compacted !== segment[0].raw)) {
              replacements.set(segment[0].index, compacted);
              for (const command of segment.slice(1))
                replacements.set(command.index, "");
            }
          } else {
            reasons.push(
              `${segment.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u4F9D\u8D56\u968F\u673A\u5C4F\u969C\u6216\u66F4\u65E9\u547D\u4EE4\u6539\u53D8\u7684\u8DEF\u5F84\u3002`
            );
          }
          for (const fact of segmentFacts)
            for (const path of fact.paths) priorPaths.add(path);
        };
        for (let index = 0; index < run12.length; index += 1) {
          if (!facts[index].automaticRandom) continue;
          compactSegment(index);
          for (const path of facts[index].paths) priorPaths.add(path);
          reasons.push(`${run12[index].tag} \u4FDD\u7559\uFF1A\u5305\u542B\u81EA\u52A8 random \u8C03\u7528\u3002`);
          segmentStart = index + 1;
        }
        compactSegment(run12.length);
        replacement = null;
      } else
        reasons.push(`${run12.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u524D\u5E8F\u547D\u4EE4\u4F1A\u6539\u53D8\u8BE5\u533A\u95F4\u7684\u5C42\u8D77\u59CB\u8BED\u4E49\u3002`);
    } else if (kind === "insert") replacement = compactInsertRun(run12);
    else reasons.push(`${run12.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u5C1A\u65E0\u53EF\u8BC1\u660E\u7684\u901A\u7528\u91CD\u5199\u89C4\u5219\u3002`);
    if (replacement !== null && (run12.length > 1 || replacement !== run12[0].raw)) {
      replacements.set(run12[0].index, replacement);
      for (const command of run12.slice(1)) replacements.set(command.index, "");
    }
    cursor = end;
  }
  return { ...trace, replacements, reasons };
}
function render(trace, replacements) {
  let content = trace.request.content;
  for (const command of [...trace.commands].sort((left, right) => right.start - left.start)) {
    const replacement = replacements.get(command.index);
    if (replacement !== void 0) content = `${content.slice(0, command.start)}${replacement}${content.slice(command.end)}`;
  }
  return content;
}
function equivalent(trace, content) {
  const replay = executeOriginalSemantics(parseCommandLayer({ ...trace.request, content }));
  const sameDiagnostics = replay.diagnostics.length === trace.diagnostics.length && replay.diagnostics.every((issue, index) => {
    const expected = trace.diagnostics[index];
    return expected !== void 0 && issue.code === expected.code && issue.path === expected.path;
  });
  return sameDiagnostics && equal(replay.finalStatData, trace.finalStatData) && equal(replay.finalStatFunc, trace.finalStatFunc) && replay.nextRandomDrawOffset === trace.nextRandomDrawOffset;
}
function analyzeDependencies(trace) {
  const facts = {};
  if (trace.diagnostics.length === 0) {
    for (const command of trace.commands) {
      if (command.kind !== "edit") break;
      facts[command.index] = commandExpressionFacts(trace, command);
    }
  }
  return { trace, facts };
}
function scopedTransactions(content) {
  const result = [];
  const pattern = /<era_tx\b([^>]*)>([\s\S]*?)<\/era_tx>/giu;
  let match;
  while ((match = pattern.exec(content)) !== null) {
    const scopeMatch = /\bs\s*=\s*["']([^"']+)["']/iu.exec(match[1] ?? "");
    const rawScope = scopeMatch?.[1] ?? "";
    result.push({
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0],
      body: match[2] ?? "",
      scope: rawScope === "m" || rawScope === "b" || rawScope === "a" ? rawScope : null
    });
  }
  return result;
}
function withStartState(request, content, statData, statFunc) {
  return {
    ...request,
    content,
    initialStatData: statData,
    initialStatFunc: statFunc
  };
}
function parseLayer(input) {
  const parsed = parseCommandLayer(input);
  const transactions = scopedTransactions(parsed.request.content);
  if (transactions.length === 0)
    return {
      ...parsed,
      scoped: false,
      segments: [
        {
          text: parsed.request.content,
          raw: parsed.request.content,
          scope: null,
          allowRewrite: true
        }
      ]
    };
  const segments = [];
  let cursor = 0;
  for (let index = 0; index < transactions.length; ) {
    const current = transactions[index];
    const prefix = parsed.request.content.slice(cursor, current.start);
    segments.push({
      text: prefix,
      raw: prefix,
      scope: null,
      allowRewrite: true
    });
    let endIndex = index;
    let text = current.body;
    let raw = current.raw;
    if (current.scope !== null) {
      while (endIndex + 1 < transactions.length) {
        const next = transactions[endIndex + 1];
        const between = parsed.request.content.slice(
          transactions[endIndex].end,
          next.start
        );
        if (next.scope !== current.scope || between.trim().length > 0) break;
        text += `${between}${next.body}`;
        raw += `${between}${next.raw}`;
        endIndex += 1;
      }
    }
    segments.push({
      text,
      raw,
      scope: current.scope,
      allowRewrite: current.scope !== null && endIndex > index
    });
    cursor = transactions[endIndex].end;
    index = endIndex + 1;
  }
  const tail = parsed.request.content.slice(cursor);
  segments.push({ text: tail, raw: tail, scope: null, allowRewrite: true });
  return { ...parsed, segments, scoped: true };
}
function initializeSegments(parsed) {
  return {
    cursor: 0,
    segments: parsed.segments,
    request: parsed.request,
    parsed,
    statData: clone2(parsed.request.initialStatData),
    statFunc: clone2(parsed.request.initialStatFunc ?? {}),
    drawOffset: parsed.request.randomContext?.drawOffset ?? 0,
    parts: [],
    diagnostics: [],
    reasons: [],
    changed: false,
    commandSegments: 0,
    rewrittenSegments: 0,
    lastResult: null
  };
}
function selectSegment(state) {
  const segment = state.segments[state.cursor];
  if (!state.parsed.scoped) return parseCommandLayer(state.request);
  const request = {
    ...state.request,
    ...state.request.randomContext ? {
      randomContext: {
        sourceKey: state.request.randomContext.sourceKey,
        drawOffset: state.drawOffset
      }
    } : {}
  };
  return parseCommandLayer(
    withStartState(request, segment.text, state.statData, state.statFunc)
  );
}
function rewriteSegment(analysis) {
  const candidate = candidateFor(analysis);
  return { ...candidate, replacements: [...candidate.replacements] };
}
function verifySegment(candidate) {
  const replacements = new Map(candidate.replacements);
  const base = {
    content: candidate.request.content,
    finalStatData: candidate.finalStatData,
    finalStatFunc: candidate.finalStatFunc,
    diagnostics: candidate.diagnostics,
    parsedCommands: candidate.commands,
    nextRandomDrawOffset: candidate.nextRandomDrawOffset
  };
  if (parseCommandLayer(candidate.request).diagnostics.length > 0)
    return {
      ...base,
      status: "invalid",
      reasons: ["\u6807\u7B7E JSON \u65E0\u6548\uFF0C\u672A\u6539\u5199\u6D88\u606F\u3002"]
    };
  if (replacements.size === 0)
    return {
      ...base,
      status: "unchanged",
      reasons: candidate.reasons.length ? candidate.reasons : ["\u6CA1\u6709\u53EF\u8BC1\u660E\u5B89\u5168\u7684\u7F29\u5199\u3002"]
    };
  const content = render(candidate, replacements);
  if (!equivalent(candidate, content))
    return {
      ...base,
      status: "unchanged",
      reasons: [
        ...candidate.reasons,
        "\u5019\u9009\u672A\u901A\u8FC7\u540C\u4E00\u8D77\u70B9\u771F\u5B9E\u91CD\u653E\uFF0C\u5DF2\u9000\u56DE\u539F\u547D\u4EE4\u3002"
      ]
    };
  return {
    ...base,
    content,
    status: candidate.commands.every(
      (command) => replacements.has(command.index)
    ) ? "compacted" : "partial",
    reasons: candidate.reasons
  };
}
function advanceSegment(state, result) {
  const segment = state.segments[state.cursor];
  const hasCommands = result.parsedCommands.length > 0;
  const changed = hasCommands && segment.allowRewrite && result.content !== segment.text && result.diagnostics.length === 0;
  const text = changed ? segment.scope === null ? result.content : `<era_tx s="${segment.scope}">${result.content}</era_tx>` : segment.raw;
  return {
    ...state,
    cursor: state.cursor + 1,
    statData: clone2(result.finalStatData),
    statFunc: clone2(result.finalStatFunc),
    drawOffset: result.nextRandomDrawOffset,
    parts: [...state.parts, text],
    diagnostics: [...state.diagnostics, ...result.diagnostics],
    reasons: [...state.reasons, ...result.reasons],
    changed: state.changed || changed,
    commandSegments: state.commandSegments + Number(hasCommands),
    rewrittenSegments: state.rewrittenSegments + Number(changed),
    lastResult: result
  };
}
function verifyLayer(state) {
  if (!state.parsed.scoped) return state.lastResult;
  const originalTrace = executeOriginalSemantics(state.parsed);
  const content = state.parts.join("");
  const replay = executeOriginalSemantics(
    parseCommandLayer({ ...state.request, content })
  );
  const equivalentResult = equal(originalTrace.finalStatData, replay.finalStatData) && equal(originalTrace.finalStatFunc, replay.finalStatFunc) && originalTrace.nextRandomDrawOffset === replay.nextRandomDrawOffset && originalTrace.diagnostics.length === replay.diagnostics.length && originalTrace.diagnostics.every(
    (issue, index) => issue.code === replay.diagnostics[index]?.code && issue.path === replay.diagnostics[index]?.path
  );
  const base = {
    finalStatData: originalTrace.finalStatData,
    finalStatFunc: originalTrace.finalStatFunc,
    diagnostics: originalTrace.diagnostics,
    parsedCommands: state.parsed.commands,
    nextRandomDrawOffset: originalTrace.nextRandomDrawOffset
  };
  if (!state.changed || !equivalentResult)
    return {
      ...base,
      status: state.diagnostics.length > 0 ? "invalid" : "unchanged",
      content: state.request.content,
      reasons: equivalentResult ? state.reasons : [
        ...state.reasons,
        "\u540C scope \u5206\u6BB5\u5019\u9009\u672A\u901A\u8FC7\u6574\u5C42\u771F\u5B9E\u91CD\u653E\uFF0C\u5DF2\u4FDD\u7559\u539F\u4E8B\u52A1\u3002"
      ]
    };
  return {
    ...base,
    status: state.rewrittenSegments === state.commandSegments ? "compacted" : "partial",
    content,
    reasons: state.reasons
  };
}
function run2(inputs) {
  return { parsed: parseLayer(inputs["era.command_compaction.request"].value) };
}
function run3(inputs) {
  return {
    segment_state: initializeSegments(
      inputs["era.command_compaction.parsed"].value
    )
  };
}
function run4(inputs) {
  const state = inputs["era.command_compaction.segment.state"].value;
  return { parsed: selectSegment(state), segment_state_before: state };
}
function run5(inputs) {
  return {
    trace: executeOriginalSemantics(
      inputs["era.command_compaction.parsed"].value
    )
  };
}
function run6(inputs) {
  return {
    symbols: analyzeDependencies(
      inputs["era.command_compaction.semantic_trace"].value
    )
  };
}
function run7(inputs) {
  return {
    candidate: rewriteSegment(
      inputs["era.command_compaction.symbols"].value
    )
  };
}
function run8(inputs) {
  return {
    verified: verifySegment(
      inputs["era.command_compaction.candidate"].value
    )
  };
}
function run9(inputs) {
  const next = advanceSegment(
    inputs["era.command_compaction.segment.state.before"].value,
    inputs["era.command_compaction.verified"].value
  );
  return {
    segment_state_next: next,
    segment_done: next.cursor >= next.segments.length
  };
}
function run10(inputs) {
  return {
    verified: verifyLayer(
      inputs["era.command_compaction.segment.state"].value
    )
  };
}
function run11(inputs) {
  return {
    compaction_response: inputs["era.command_compaction.verified"].value
  };
}
var VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v4";
var VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v1";
var VibeFlowWorkflowError = class extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === void 0 ? void 0 : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
  }
};
function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details
  });
}
function throwIfAborted(signal, workflow, nodePath2 = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath: nodePath2,
    blockPath,
    cause: signal.reason
  });
}
async function awaitWithAbort(value, signal, workflow, nodePath2 = "", blockPath = "") {
  throwIfAborted(signal, workflow, nodePath2, blockPath);
  if (!signal) return await value;
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(vfError(
      "VF_ABORTED",
      "workflow execution was aborted",
      workflow,
      { nodePath: nodePath2, blockPath, cause: signal.reason }
    ));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([Promise.resolve(value), aborted]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}
function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}
function dictionary() {
  return /* @__PURE__ */ Object.create(null);
}
function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true
  });
  return target;
}
function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string" && !new RegExp(schema.pattern).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}
function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every(
    (key, index) => key === rightKeys[index] && jsonEquals(left[key], right[key])
  );
}
function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}
function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}
function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}
function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}
function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}
function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details
  });
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause }
    );
  }
}
function normalizeOptions(workflow, options) {
  const raw = options === void 0 ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== void 0 && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  const detachedTimeoutMs = raw.detachedTimeoutMs ?? 5e3;
  if (!Number.isFinite(detachedTimeoutMs) || detachedTimeoutMs < 0) {
    throw vfError("VF_INTERNAL", "options.detachedTimeoutMs must be a non-negative number", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    capabilities: raw.capabilities ?? {},
    detachedTimeoutMs
  };
}
function capabilityLocation(caller) {
  return {
    nodePath: typeof caller?.nodePath === "string" ? caller.nodePath : "",
    blockPath: typeof caller?.blockPath === "string" ? caller.blockPath : ""
  };
}
function validateCapabilityInput(workflow, schemas, capabilityId, operationName, operationDescriptor, input, location) {
  const failure = validateJsonSchema(
    input,
    operationDescriptor.input_type ? schemas[operationDescriptor.input_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_INPUT",
      `capability '${capabilityId}.${operationName}' input failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
}
function validateCapabilityOutput(workflow, schemas, capabilityId, operationName, operationDescriptor, output, location) {
  const failure = validateJsonSchema(
    output,
    operationDescriptor.output_type ? schemas[operationDescriptor.output_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_OUTPUT",
      `capability '${capabilityId}.${operationName}' output failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
  return output;
}
function wrapCapabilityFailure(cause, workflow, root, capabilityId, operationName, location) {
  if (cause instanceof VibeFlowWorkflowError) throw cause;
  if (root.signal?.aborted) {
    throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
  }
  throw vfError(
    "VF_CAPABILITY_FAILED",
    `capability '${capabilityId}.${operationName}' failed`,
    workflow,
    { ...location, cause }
  );
}
function prepareCapabilities(workflow, descriptors, requirements, schemas, supplied, root, entryMode) {
  assertObject(
    supplied,
    "VF_CAPABILITY_MISSING",
    "options.capabilities must be an object",
    workflow
  );
  const wrapped = dictionary();
  for (const [capabilityId, operationNames] of Object.entries(requirements)) {
    const implementation = Object.prototype.hasOwnProperty.call(supplied, capabilityId) ? supplied[capabilityId] : void 0;
    if (!implementation || typeof implementation !== "object") {
      throw vfError(
        "VF_CAPABILITY_MISSING",
        `required capability '${capabilityId}' was not supplied`,
        workflow
      );
    }
    const descriptor = descriptors[capabilityId] || {};
    const capability = dictionary();
    for (const operationName of operationNames) {
      const callable = implementation[operationName];
      if (typeof callable !== "function") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `capability '${capabilityId}' is missing operation '${operationName}'`,
          workflow
        );
      }
      const operationDescriptor = descriptor.operations?.[operationName] || {};
      const completion = operationDescriptor.completion || "immediate";
      if (entryMode === "sync" && completion === "suspend") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `sync workflow cannot use suspending capability '${capabilityId}.${operationName}'`,
          workflow
        );
      }
      if (completion === "suspend") {
        setOwn(capability, operationName, async (input, caller = {}) => {
          const location = capabilityLocation(caller);
          throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input,
            location
          );
          try {
            const output = await awaitWithAbort(
              callable.call(implementation, input, { signal: root.signal }),
              root.signal,
              workflow,
              location.nodePath,
              location.blockPath
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      } else {
        setOwn(capability, operationName, (input, caller = {}) => {
          const location = capabilityLocation(caller);
          throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input,
            location
          );
          try {
            const output = callable.call(
              implementation,
              input,
              { signal: root.signal }
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      }
    }
    setOwn(wrapped, capabilityId, Object.freeze(capability));
  }
  return Object.freeze(wrapped);
}
function validatePublicInputs(workflow, inputs) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input.key);
    if (input.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = validateJsonSchema(
      inputs[input.key],
      input.schema || workflow.schemas?.[input.type]
    );
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input.key}' failed schema validation: ${failure}`,
        workflow
      );
    }
  }
}
function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}
function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: /* @__PURE__ */ new Map(),
    activeEdges: /* @__PURE__ */ new Set(),
    lastInputs: /* @__PURE__ */ new Map(),
    pending: /* @__PURE__ */ new Map(),
    nodeRuns: /* @__PURE__ */ new Map(),
    stepCount: 0,
    initial
  };
}
function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}
function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input of state.workflow.inputs) {
    if (!accepted.has(input.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input.key)) continue;
    state.inboxes[nodeId].push(
      createEnvelope(input.key, input.type, state.initial[input.key], "pipeline.input")
    );
  }
}
function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type);
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}
function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}
function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}
function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  for (const provider of node.provides) {
    const schema = state.workflow.schemas?.[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
  }
  return outputs;
}
function outputEnvelopes(node, outputs) {
  return node.provides.map(
    (provider) => createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}
function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node)
    );
    state.inboxes[targetId].push(envelope);
  }
}
function nodeContext(node, state) {
  const allowed = dictionary();
  for (const requirement of node.capabilities || []) {
    const capability = state.root.capabilities[requirement.id];
    if (!capability) continue;
    const contextual = dictionary();
    const requested = new Set(requirement.operations || []);
    for (const [operationName, operation] of Object.entries(capability)) {
      if (requested.size && !requested.has(operationName)) continue;
      setOwn(contextual, operationName, (input) => operation(input, {
        nodePath: nodePath(state, node.id),
        blockPath: formatBlockPath(state.path)
      }));
    }
    setOwn(allowed, requirement.id, Object.freeze(contextual));
  }
  return Object.freeze({
    signal: state.root.signal,
    capabilities: Object.freeze(allowed),
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details
      });
    }
  });
}
function invokeStaticImplementationSync(implementation, node, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  try {
    const outputs = implementation(inputs, node.params, nodeContext(node, state));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause }
    );
  }
}
function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
  return inputs;
}
function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
}
function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}
function rawInputsForChild(inputSpecs, inputs, workflow, nodeId) {
  const items = [];
  for (const value of Object.values(inputs)) {
    if (Array.isArray(value)) items.push(...value);
    else if (value) items.push(value);
  }
  const initial = dictionary();
  for (const input of inputSpecs) {
    const match = items.find((item) => item?.type === input.type);
    if (match) setOwn(initial, input.key, match.value);
    else if (input.required) {
      throw vfError(
        "VF_INPUT_REQUIRED",
        `composite node '${nodeId}' cannot supply required body input '${input.key}'`,
        workflow
      );
    }
  }
  return initial;
}
function outputsFromChild(node, mappings, childResult, state) {
  const outputs = dictionary();
  for (const mapping of mappings) {
    if (!Object.prototype.hasOwnProperty.call(childResult.publicOutputs, mapping.alias)) {
      throw vfError(
        "VF_OUTPUT_CARDINALITY",
        `composite node '${node.id}' body omitted optional output '${mapping.alias}' required by provider '${mapping.provider}'`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
    setOwn(outputs, mapping.provider, childResult.publicOutputs[mapping.alias]);
  }
  return validateNodeOutputs(node, outputs, state);
}
function valueFromEnvelope(value) {
  if (value && typeof value === "object" && "value" in value && "type" in value) {
    return value.value;
  }
  return value;
}
function resultValues(child) {
  const values = dictionary();
  for (const [key, value] of Object.entries(child.publicOutputs)) setOwn(values, key, value);
  for (const [type, candidates] of child.candidates) {
    if (candidates.length === 1) setOwn(values, type, candidates[0].value);
  }
  return values;
}
function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = state.candidates.get(spec.type) || [];
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.workflow.schemas?.[spec.type];
    const values = spec.cardinality === "all" ? matches.map((item) => item.value) : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow
        );
      }
    }
  }
  return output;
}
function abandonPending(state) {
  for (const [nodeId, promise] of state.pending) {
    promise.catch(() => {
    });
    emitTrace(state.root, "async_result_abandoned", {
      nodeId,
      nodePath: nodePath(state, nodeId),
      blockPath: formatBlockPath(state.path)
    });
  }
}
function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
function runtimePluginError(code, descriptor, hook, cause, workflow, location = {}) {
  const suffix = hook ? ` hook '${hook}'` : "";
  return vfError(
    code,
    `runtime plugin '${descriptor.id}'${suffix} failed`,
    workflow,
    {
      nodePath: location.nodePath || "",
      blockPath: location.blockPath || "/",
      cause
    }
  );
}
function runtimePluginContext(workflow, descriptor, root) {
  return Object.freeze({
    abiVersion: VIBEFLOW_PLUGIN_ABI,
    pluginId: descriptor.id,
    pluginType: "runtime",
    target: descriptor.target,
    workflowId: workflow.workflow_id,
    config: deepFreeze(descriptor.config || {}),
    signal: root.signal
  });
}
function runtimePluginSummary(root, details = {}) {
  return deepFreeze({
    workflowId: root.workflowId,
    entryMode: root.workflow.entry_mode,
    ...details
  });
}
function createRuntimePluginsSync(workflow, descriptors, factories, root) {
  const records = [];
  try {
    for (const descriptor of descriptors) {
      const factory = factories[descriptor.factory_index];
      if (typeof factory !== "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("plugin module does not export createPlugin()"),
          workflow
        );
      }
      let instance;
      try {
        instance = factory(runtimePluginContext(workflow, descriptor, root));
      } catch (cause) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          cause,
          workflow
        );
      }
      if (!instance || typeof instance !== "object" || Array.isArray(instance)) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("createPlugin() must return a RuntimePlugin object"),
          workflow
        );
      }
      records.push({ descriptor, instance });
    }
    return records;
  } catch (failure) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      try {
        records[index].instance.dispose?.();
      } catch {
      }
    }
    throw failure;
  }
}
function invokeRuntimeHookSync(root, hook, details = {}, preserveFailure = false) {
  const summary = runtimePluginSummary(root, details);
  for (const record22 of root.runtimePlugins) {
    const callback = record22.instance[hook];
    if (typeof callback !== "function") continue;
    try {
      callback(summary);
    } catch (cause) {
      if (preserveFailure) continue;
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_HOOK",
        record22.descriptor,
        hook,
        cause,
        root.workflow,
        summary
      );
    }
  }
}
function disposeRuntimePluginsSync(root, preserveFailure = false) {
  for (let index = root.runtimePlugins.length - 1; index >= 0; index -= 1) {
    const record22 = root.runtimePlugins[index];
    if (typeof record22.instance.dispose !== "function") continue;
    try {
      record22.instance.dispose();
    } catch (cause) {
      if (preserveFailure) continue;
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_DISPOSE",
        record22.descriptor,
        "dispose",
        cause,
        root.workflow
      );
    }
  }
  root.runtimePlugins.length = 0;
}
function createRoot(workflow, normalized) {
  return {
    workflow,
    workflowId: workflow.workflow_id,
    signal: normalized.signal || new AbortController().signal,
    traceMode: normalized.traceMode,
    onTrace: normalized.onTrace,
    detachedTimeoutMs: normalized.detachedTimeoutMs,
    detached: /* @__PURE__ */ new Set(),
    detachedFailure: null,
    capabilities: {},
    runtimePlugins: []
  };
}
function prepareWorkflowInvocation(workflow, descriptors, requirements, schemas, options, entryMode) {
  let normalized;
  try {
    normalized = normalizeOptions(workflow, options);
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
  const root = createRoot(workflow, normalized);
  try {
    throwIfAborted(root.signal, workflow);
    root.capabilities = prepareCapabilities(
      workflow,
      descriptors,
      requirements,
      schemas,
      normalized.capabilities,
      root,
      entryMode
    );
    emitTrace(root, "run_start", {}, true);
    return root;
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
}
function assertWorkflowAbi(workflow) {
  if (workflow.abi_version !== VIBEFLOW_WORKFLOW_ABI) {
    throw vfError(
      "VF_INTERNAL",
      `generated workflow ABI '${workflow.abi_version}' is unsupported`,
      workflow
    );
  }
}
function createStaticWorkflowSync(workflowMetadata, capabilityDescriptors, capabilityRequirements, schemaCatalog, runtimePluginDescriptors, runtimePluginFactories, executeRoot) {
  const workflow = deepFreeze(workflowMetadata);
  const descriptors = deepFreeze(capabilityDescriptors);
  const requirements = deepFreeze(capabilityRequirements);
  const schemas = deepFreeze(schemaCatalog);
  const plugins = deepFreeze(runtimePluginDescriptors);
  assertWorkflowAbi(workflow);
  return function invokeWorkflow(inputs, options) {
    const root = prepareWorkflowInvocation(
      workflow,
      descriptors,
      requirements,
      schemas,
      options,
      "sync"
    );
    root.runtimePlugins = createRuntimePluginsSync(
      workflow,
      plugins,
      runtimePluginFactories,
      root
    );
    let failed = false;
    try {
      invokeRuntimeHookSync(root, "beforeRun", {
        inputKeys: Object.keys(inputs || {}).sort()
      });
      const result = executeRoot(inputs, root, []);
      throwIfAborted(root.signal, workflow);
      invokeRuntimeHookSync(root, "afterRun", {
        outputKeys: Object.keys(result.publicOutputs || {}).sort()
      });
      emitTrace(root, "run_end", {}, true);
      return result.publicOutputs;
    } catch (cause) {
      failed = true;
      const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
      if (failure.code !== "VF_TRACE_SINK_FAILED") {
        try {
          emitTrace(root, "run_failed", {
            code: failure.code,
            message: failure.message
          }, true);
        } catch {
        }
      }
      invokeRuntimeHookSync(root, "runFailed", {
        code: failure.code,
        message: failure.message
      }, true);
      throw ensureErrorLocation(failure, workflow, []);
    } finally {
      disposeRuntimePluginsSync(root, failed);
    }
  };
}
var __vfRuntimePluginDescriptors = [];
var __vfRuntimePluginFactories = [];
var __vf_workflow_2_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v4","entry_mode":"sync","inputs":[{"key":"segment_state","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"type":"era.command_compaction.segment.state"}],"max_steps":8,"outputs":[{"as":"segmentStateNext","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"type":"era.command_compaction.segment.state"},{"as":"segmentDone","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"type":"era.command_compaction.segment.done"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction.compact_layer.segment_loop"}'));
var __vf_w2_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w2_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"select_segment","params":{"_global":{}},"provides":[{"key":"parsed","type":"era.command_compaction.parsed"},{"key":"segment_state_before","type":"era.command_compaction.segment.state.before"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state"}],"schedule":"inline","type_used":"era.command_compaction.select_segment"}'));
var __vf_w2_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"execute","params":{"_global":{}},"provides":[{"key":"trace","type":"era.command_compaction.semantic_trace"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.parsed"}],"schedule":"inline","type_used":"era.command_compaction.execute_original_semantics"}'));
var __vf_w2_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"analyze_dependencies","params":{"_global":{}},"provides":[{"key":"symbols","type":"era.command_compaction.symbols"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.semantic_trace"}],"schedule":"inline","type_used":"era.command_compaction.analyze_dependencies"}'));
var __vf_w2_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"rewrite","params":{"_global":{}},"provides":[{"key":"candidate","type":"era.command_compaction.candidate"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.symbols"}],"schedule":"inline","type_used":"era.command_compaction.rewrite_safe_regions"}'));
var __vf_w2_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"verify","params":{"_global":{}},"provides":[{"key":"verified","type":"era.command_compaction.verified"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.candidate"}],"schedule":"inline","type_used":"era.command_compaction.verify_replay_equivalence"}'));
var __vf_w2_n6 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"advance_segment","params":{"_global":{}},"provides":[{"key":"segment_state_next","type":"era.command_compaction.segment.state"},{"key":"segment_done","type":"era.command_compaction.segment.done"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state.before"},{"cardinality":"exactly_one","type":"era.command_compaction.verified"}],"schedule":"inline","type_used":"era.command_compaction.advance_segment"}'));
var __vf_w2_n7 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_workflow_1_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v4","entry_mode":"sync","inputs":[{"key":"compaction_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.request"}],"max_steps":7,"outputs":[{"as":"compactionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.response"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction.compact_layer"}'));
var __vf_w1_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w1_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"parse","params":{"_global":{}},"provides":[{"key":"parsed","type":"era.command_compaction.parsed"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.request"}],"schedule":"inline","type_used":"era.command_compaction.parse_command_blocks"}'));
var __vf_w1_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"initialize_segments","params":{"_global":{}},"provides":[{"key":"segment_state","type":"era.command_compaction.segment.state"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.parsed"}],"schedule":"inline","type_used":"era.command_compaction.initialize_segments"}'));
var __vf_w1_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"segment_loop","params":{},"provides":[{"key":"segment_state_final","type":"era.command_compaction.segment.state"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state"}],"schedule":"inline","type_used":"vibeflow.loop.while"}'));
var __vf_w1_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"verify_layer","params":{"_global":{}},"provides":[{"key":"verified","type":"era.command_compaction.verified"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state"}],"schedule":"inline","type_used":"era.command_compaction.verify_layer"}'));
var __vf_w1_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"render","params":{"_global":{}},"provides":[{"key":"compaction_response","type":"era.command_compaction.response"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.verified"}],"schedule":"inline","type_used":"era.command_compaction.render_compaction_result"}'));
var __vf_w1_n6 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_workflow_0_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v4","entry_mode":"sync","inputs":[{"key":"compaction_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.request"}],"max_steps":1000,"outputs":[{"as":"compactionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.response"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction"}'));
var __vf_w0_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w0_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"compact_layer","params":{},"provides":[{"key":"compaction_response","type":"era.command_compaction.response"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.request"}],"schedule":"inline","type_used":"era.command_compaction.compact_layer"}'));
var __vf_w0_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vfCapabilityDescriptors = Object.freeze(JSON.parse("{}"));
var __vfCapabilityRequirements = Object.freeze(JSON.parse("{}"));
var __vfSchemaCatalog = Object.freeze(JSON.parse('{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}}'));
function __vf_activate_w0_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("compact_layer");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0compact_layer");
  targets.push("compact_layer");
  emitTrace(state.root, "edge_activated", { source: "start", target: "compact_layer", path: state.path });
  deliverStatic(envelopes, state, "compact_layer", JSON.parse('["era.command_compaction.request"]'));
  return targets;
}
function __vf_execute_w0_n0(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w0_n0, inputs, state);
}
function __vf_activate_w0_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("compact_layer\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "compact_layer", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w0_n1(inputs, state) {
  try {
    invokeRuntimeHookSync(state.root, "beforeNodeset", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path) });
    emitTrace(state.root, "nodeset_enter", {
      nodeId: "compact_layer",
      nodePath: nodePath(state, "compact_layer")
    }, true);
    const initial = rawInputsForChild(__vf_workflow_1_metadata.inputs, inputs, state.workflow, "compact_layer");
    const child = __vf_workflow_1_execute(initial, state.root, [...state.path, "compact_layer"]);
    const outputs = outputsFromChild(__vf_w0_n1, JSON.parse('[{"alias":"compactionResponse","provider":"compaction_response"}]'), child, state);
    emitTrace(state.root, "nodeset_exit", {
      nodeId: "compact_layer",
      nodePath: nodePath(state, "compact_layer")
    }, true);
    invokeRuntimeHookSync(state.root, "afterNodeset", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path) });
    return outputs;
  } catch (cause) {
    const failure = ensureErrorLocation(cause, state.workflow, state.path, "compact_layer");
    invokeRuntimeHookSync(state.root, "nodesetFailed", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w0_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w0_n2(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w0_n2, inputs, state);
}
function __vf_workflow_0_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_0_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "compact_layer");
    initializeInbox(state, "end");
    seedInbox(state, "compact_layer", JSON.parse('["era.command_compaction.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_0_metadata);
      if (state.stepCount >= 1e3) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=1000",
          __vf_workflow_0_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n0(inputs, state);
            finishStaticNode(__vf_w0_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "compact_layer": {
          if (!state.inboxes["compact_layer"].some((item) => item.type === "era.command_compaction.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.compact_layer" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n1(inputs, state);
            finishStaticNode(__vf_w0_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.compact_layer", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "compact_layer");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n2(inputs, state);
            finishStaticNode(__vf_w0_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w1_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("parse");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0parse");
  targets.push("parse");
  emitTrace(state.root, "edge_activated", { source: "start", target: "parse", path: state.path });
  deliverStatic(envelopes, state, "parse", JSON.parse('["era.command_compaction.request"]'));
  return targets;
}
function __vf_execute_w1_n0(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w1_n0, inputs, state);
}
function __vf_activate_w1_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("initialize_segments");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("parse\0initialize_segments");
  targets.push("initialize_segments");
  emitTrace(state.root, "edge_activated", { source: "parse", target: "initialize_segments", path: state.path });
  deliverStatic(envelopes, state, "initialize_segments", JSON.parse('["era.command_compaction.parsed"]'));
  return targets;
}
function __vf_execute_w1_n1(inputs, state) {
  return invokeStaticImplementationSync(run2, __vf_w1_n1, inputs, state);
}
function __vf_activate_w1_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("segment_loop");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("initialize_segments\0segment_loop");
  targets.push("segment_loop");
  emitTrace(state.root, "edge_activated", { source: "initialize_segments", target: "segment_loop", path: state.path });
  deliverStatic(envelopes, state, "segment_loop", JSON.parse('["era.command_compaction.segment.state"]'));
  return targets;
}
function __vf_execute_w1_n2(inputs, state) {
  return invokeStaticImplementationSync(run3, __vf_w1_n2, inputs, state);
}
function __vf_activate_w1_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("verify_layer");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("segment_loop\0verify_layer");
  targets.push("verify_layer");
  emitTrace(state.root, "edge_activated", { source: "segment_loop", target: "verify_layer", path: state.path });
  deliverStatic(envelopes, state, "verify_layer", JSON.parse('["era.command_compaction.segment.state"]'));
  return targets;
}
function __vf_execute_w1_n3(inputs, state) {
  emitTrace(state.root, "loop_enter", {
    nodeId: "segment_loop",
    nodePath: nodePath(state, "segment_loop")
  }, true);
  const values = dictionary();
  for (const [type, input] of Object.entries(inputs)) {
    setOwn(values, type, Array.isArray(input) ? input.map(valueFromEnvelope) : valueFromEnvelope(input));
    const items = Array.isArray(input) ? input : [input];
    for (const item of items) {
      if (item?.key) setOwn(values, item.key, item.value);
      if (item?.type) setOwn(values, item.type, item.value);
    }
  }
  if (!Object.prototype.hasOwnProperty.call(values, "era.command_compaction.segment.state")) {
    throw vfError("VF_INPUT_REQUIRED", "loop carry source 'era.command_compaction.segment.state' is unavailable", state.workflow, { nodePath: nodePath(state, "segment_loop") });
  }
  setOwn(values, "segment_state", values["era.command_compaction.segment.state"]);
  let stopped = false;
  for (let iteration = 0; ; iteration += 1) {
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, "segment_loop"));
    const initial = dictionary();
    setOwn(initial, "segment_state", values["segment_state"]);
    emitTrace(state.root, "loop_iteration", {
      nodeId: "segment_loop",
      nodePath: nodePath(state, "segment_loop"),
      iteration
    });
    const child = __vf_workflow_2_execute(initial, state.root, [...state.path, "segment_loop", `iter_${iteration}`]);
    const childValues = resultValues(child);
    for (const [key, value] of Object.entries(childValues)) setOwn(values, key, value);
    if (!Object.prototype.hasOwnProperty.call(values, "segmentStateNext")) {
      throw vfError("VF_OUTPUT_KEYS", "loop carry update 'segmentStateNext' is unavailable", state.workflow, { nodePath: nodePath(state, "segment_loop") });
    }
    setOwn(values, "segment_state", values["segmentStateNext"]);
    const iterationCount = iteration + 1;
    setOwn(values, "loop.iterations", iterationCount);
    if (!Object.prototype.hasOwnProperty.call(values, "segmentDone")) {
      throw vfError("VF_OUTPUT_KEYS", "loop stop source 'segmentDone' is unavailable", state.workflow);
    }
    if (typeof values["segmentDone"] !== "boolean") {
      throw vfError("VF_OUTPUT_SCHEMA", "loop stop source 'segmentDone' must be boolean", state.workflow);
    }
    stopped = stopped || values["segmentDone"] === true;
    if (stopped) break;
  }
  const outputs = dictionary();
  if (!Object.prototype.hasOwnProperty.call(values, "segmentStateNext")) {
    throw vfError("VF_OUTPUT_KEYS", "loop output source 'segmentStateNext' is unavailable", state.workflow);
  }
  setOwn(outputs, "segment_state_final", values["segmentStateNext"]);
  emitTrace(state.root, "loop_exit", {
    nodeId: "segment_loop",
    nodePath: nodePath(state, "segment_loop")
  }, true);
  return validateNodeOutputs(__vf_w1_n3, outputs, state);
}
function __vf_activate_w1_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("render");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("verify_layer\0render");
  targets.push("render");
  emitTrace(state.root, "edge_activated", { source: "verify_layer", target: "render", path: state.path });
  deliverStatic(envelopes, state, "render", JSON.parse('["era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w1_n4(inputs, state) {
  return invokeStaticImplementationSync(run10, __vf_w1_n4, inputs, state);
}
function __vf_activate_w1_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("render\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "render", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w1_n5(inputs, state) {
  return invokeStaticImplementationSync(run11, __vf_w1_n5, inputs, state);
}
function __vf_activate_w1_n6(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n6, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w1_n6(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w1_n6, inputs, state);
}
function __vf_workflow_1_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_1_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "parse");
    initializeInbox(state, "initialize_segments");
    initializeInbox(state, "segment_loop");
    initializeInbox(state, "verify_layer");
    initializeInbox(state, "render");
    initializeInbox(state, "end");
    seedInbox(state, "parse", JSON.parse('["era.command_compaction.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_1_metadata);
      if (state.stepCount >= 7) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=7",
          __vf_workflow_1_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w1_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n0(inputs, state);
            finishStaticNode(__vf_w1_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "parse": {
          if (!state.inboxes["parse"].some((item) => item.type === "era.command_compaction.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "parse", nodePath: nodePath(state, "parse"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.parse_command_blocks" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n1(inputs, state);
            finishStaticNode(__vf_w1_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "parse", nodePath: nodePath(state, "parse"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.parse_command_blocks", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "parse");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "parse", nodePath: nodePath(state, "parse"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "initialize_segments": {
          if (!state.inboxes["initialize_segments"].some((item) => item.type === "era.command_compaction.parsed")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "initialize_segments", nodePath: nodePath(state, "initialize_segments"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.initialize_segments" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n2(inputs, state);
            finishStaticNode(__vf_w1_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "initialize_segments", nodePath: nodePath(state, "initialize_segments"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.initialize_segments", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "initialize_segments");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "initialize_segments", nodePath: nodePath(state, "initialize_segments"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "segment_loop": {
          if (!state.inboxes["segment_loop"].some((item) => item.type === "era.command_compaction.segment.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "segment_loop", nodePath: nodePath(state, "segment_loop"), blockPath: formatBlockPath(state.path), type: "vibeflow.loop.while" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n3(inputs, state);
            finishStaticNode(__vf_w1_n3, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "segment_loop", nodePath: nodePath(state, "segment_loop"), blockPath: formatBlockPath(state.path), type: "vibeflow.loop.while", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "segment_loop");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "segment_loop", nodePath: nodePath(state, "segment_loop"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "verify_layer": {
          if (!state.inboxes["verify_layer"].some((item) => item.type === "era.command_compaction.segment.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "verify_layer", nodePath: nodePath(state, "verify_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_layer" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n4(inputs, state);
            finishStaticNode(__vf_w1_n4, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "verify_layer", nodePath: nodePath(state, "verify_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_layer", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "verify_layer");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "verify_layer", nodePath: nodePath(state, "verify_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "render": {
          if (!state.inboxes["render"].some((item) => item.type === "era.command_compaction.verified")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "render", nodePath: nodePath(state, "render"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.render_compaction_result" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n5(inputs, state);
            finishStaticNode(__vf_w1_n5, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "render", nodePath: nodePath(state, "render"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.render_compaction_result", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "render");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "render", nodePath: nodePath(state, "render"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w1_n6, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n6(inputs, state);
            finishStaticNode(__vf_w1_n6, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n6(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w2_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("select_segment");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0select_segment");
  targets.push("select_segment");
  emitTrace(state.root, "edge_activated", { source: "start", target: "select_segment", path: state.path });
  deliverStatic(envelopes, state, "select_segment", JSON.parse('["era.command_compaction.segment.state"]'));
  return targets;
}
function __vf_execute_w2_n0(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w2_n0, inputs, state);
}
function __vf_activate_w2_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("execute");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("select_segment\0execute");
  targets.push("execute");
  emitTrace(state.root, "edge_activated", { source: "select_segment", target: "execute", path: state.path });
  deliverStatic(envelopes, state, "execute", JSON.parse('["era.command_compaction.parsed"]'));
  deliverStatic(envelopes, state, "advance_segment", JSON.parse('["era.command_compaction.segment.state.before","era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w2_n1(inputs, state) {
  return invokeStaticImplementationSync(run4, __vf_w2_n1, inputs, state);
}
function __vf_activate_w2_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("analyze_dependencies");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("execute\0analyze_dependencies");
  targets.push("analyze_dependencies");
  emitTrace(state.root, "edge_activated", { source: "execute", target: "analyze_dependencies", path: state.path });
  deliverStatic(envelopes, state, "analyze_dependencies", JSON.parse('["era.command_compaction.semantic_trace"]'));
  return targets;
}
function __vf_execute_w2_n2(inputs, state) {
  return invokeStaticImplementationSync(run5, __vf_w2_n2, inputs, state);
}
function __vf_activate_w2_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("rewrite");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("analyze_dependencies\0rewrite");
  targets.push("rewrite");
  emitTrace(state.root, "edge_activated", { source: "analyze_dependencies", target: "rewrite", path: state.path });
  deliverStatic(envelopes, state, "rewrite", JSON.parse('["era.command_compaction.symbols"]'));
  return targets;
}
function __vf_execute_w2_n3(inputs, state) {
  return invokeStaticImplementationSync(run6, __vf_w2_n3, inputs, state);
}
function __vf_activate_w2_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("verify");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("rewrite\0verify");
  targets.push("verify");
  emitTrace(state.root, "edge_activated", { source: "rewrite", target: "verify", path: state.path });
  deliverStatic(envelopes, state, "verify", JSON.parse('["era.command_compaction.candidate"]'));
  return targets;
}
function __vf_execute_w2_n4(inputs, state) {
  return invokeStaticImplementationSync(run7, __vf_w2_n4, inputs, state);
}
function __vf_activate_w2_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("advance_segment");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("verify\0advance_segment");
  targets.push("advance_segment");
  emitTrace(state.root, "edge_activated", { source: "verify", target: "advance_segment", path: state.path });
  deliverStatic(envelopes, state, "advance_segment", JSON.parse('["era.command_compaction.segment.state.before","era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w2_n5(inputs, state) {
  return invokeStaticImplementationSync(run8, __vf_w2_n5, inputs, state);
}
function __vf_activate_w2_n6(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n6, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("advance_segment\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "advance_segment", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w2_n6(inputs, state) {
  return invokeStaticImplementationSync(run9, __vf_w2_n6, inputs, state);
}
function __vf_activate_w2_n7(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n7, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w2_n7(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w2_n7, inputs, state);
}
function __vf_workflow_2_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_2_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "select_segment");
    initializeInbox(state, "execute");
    initializeInbox(state, "analyze_dependencies");
    initializeInbox(state, "rewrite");
    initializeInbox(state, "verify");
    initializeInbox(state, "advance_segment");
    initializeInbox(state, "end");
    seedInbox(state, "select_segment", JSON.parse('["era.command_compaction.segment.state"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_2_metadata);
      if (state.stepCount >= 8) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=8",
          __vf_workflow_2_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w2_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n0(inputs, state);
            finishStaticNode(__vf_w2_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "select_segment": {
          if (!state.inboxes["select_segment"].some((item) => item.type === "era.command_compaction.segment.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "select_segment", nodePath: nodePath(state, "select_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.select_segment" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n1(inputs, state);
            finishStaticNode(__vf_w2_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "select_segment", nodePath: nodePath(state, "select_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.select_segment", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "select_segment");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "select_segment", nodePath: nodePath(state, "select_segment"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "execute": {
          if (!state.inboxes["execute"].some((item) => item.type === "era.command_compaction.parsed")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "execute", nodePath: nodePath(state, "execute"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.execute_original_semantics" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n2(inputs, state);
            finishStaticNode(__vf_w2_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "execute", nodePath: nodePath(state, "execute"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.execute_original_semantics", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "execute");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "execute", nodePath: nodePath(state, "execute"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "analyze_dependencies": {
          if (!state.inboxes["analyze_dependencies"].some((item) => item.type === "era.command_compaction.semantic_trace")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "analyze_dependencies", nodePath: nodePath(state, "analyze_dependencies"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.analyze_dependencies" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n3(inputs, state);
            finishStaticNode(__vf_w2_n3, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "analyze_dependencies", nodePath: nodePath(state, "analyze_dependencies"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.analyze_dependencies", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "analyze_dependencies");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "analyze_dependencies", nodePath: nodePath(state, "analyze_dependencies"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "rewrite": {
          if (!state.inboxes["rewrite"].some((item) => item.type === "era.command_compaction.symbols")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "rewrite", nodePath: nodePath(state, "rewrite"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.rewrite_safe_regions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n4(inputs, state);
            finishStaticNode(__vf_w2_n4, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "rewrite", nodePath: nodePath(state, "rewrite"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.rewrite_safe_regions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "rewrite");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "rewrite", nodePath: nodePath(state, "rewrite"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "verify": {
          if (!state.inboxes["verify"].some((item) => item.type === "era.command_compaction.candidate")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "verify", nodePath: nodePath(state, "verify"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_replay_equivalence" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n5(inputs, state);
            finishStaticNode(__vf_w2_n5, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "verify", nodePath: nodePath(state, "verify"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_replay_equivalence", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "verify");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "verify", nodePath: nodePath(state, "verify"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "advance_segment": {
          if (!(state.inboxes["advance_segment"].some((item) => item.type === "era.command_compaction.segment.state.before") && state.inboxes["advance_segment"].some((item) => item.type === "era.command_compaction.verified"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n6, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "advance_segment", nodePath: nodePath(state, "advance_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.advance_segment" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n6(inputs, state);
            finishStaticNode(__vf_w2_n6, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n6(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "advance_segment", nodePath: nodePath(state, "advance_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.advance_segment", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "advance_segment");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "advance_segment", nodePath: nodePath(state, "advance_segment"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w2_n7, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n7(inputs, state);
            finishStaticNode(__vf_w2_n7, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n7(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
var __vfInvokeWorkflow = createStaticWorkflowSync(
  __vf_workflow_0_metadata,
  __vfCapabilityDescriptors,
  __vfCapabilityRequirements,
  __vfSchemaCatalog,
  __vfRuntimePluginDescriptors,
  __vfRuntimePluginFactories,
  __vf_workflow_0_execute
);
function runWorkflow(inputs, options) {
  return __vfInvokeWorkflow(inputs, options);
}

// base_lib/command_compaction_engine.ts
function tagInfo2(value) {
  if (value === "variableinsert") return { kind: "insert", tag: "VariableInsert" };
  if (value === "variableedit") return { kind: "edit", tag: "VariableEdit" };
  if (value === "variabledelete") return { kind: "delete", tag: "VariableDelete" };
  if (value === "functioninsert") return { kind: "function-insert", tag: "FunctionInsert" };
  if (value === "functionedit") return { kind: "function-edit", tag: "FunctionEdit" };
  if (value === "functiondelete") return { kind: "function-delete", tag: "FunctionDelete" };
  return null;
}
function record2(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function plain2(value) {
  if (!record2(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
function clone3(value) {
  return structuredClone(value);
}
function equal2(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function diagnostic3(code, message, commandIndex, path) {
  return { code, message, ...commandIndex === void 0 ? {} : { commandIndex }, ...path === void 0 ? {} : { path } };
}
function stripFence2(text) {
  const match = /^```(?:json)?\s*([\s\S]*?)\s*```$/iu.exec(text.trim());
  return match ? match[1] : text.trim();
}
function parseData2(text, commandIndex) {
  try {
    const parsed = JSON.parse(stripFence2(text));
    const values = Array.isArray(parsed) ? parsed : [parsed];
    if (!values.every(plain2)) {
      return { data: [], diagnostic: diagnostic3("ERA_COMPACT_COMMAND_DATA_INVALID", "\u6307\u4EE4\u5185\u5BB9\u5FC5\u987B\u662F JSON \u5BF9\u8C61\u6216\u5BF9\u8C61\u6570\u7EC4\u3002", commandIndex) };
    }
    return { data: values };
  } catch (error) {
    return { data: [], diagnostic: diagnostic3("ERA_COMPACT_COMMAND_JSON_INVALID", `\u6307\u4EE4 JSON \u65E0\u6CD5\u89E3\u6790\uFF1A${error instanceof Error ? error.message : String(error)}`, commandIndex) };
  }
}
function parseCommandLayer2(input) {
  const source = record2(input) ? input : {};
  const request = {
    content: typeof source.content === "string" ? source.content : "",
    initialStatData: plain2(source.initialStatData) ? clone3(source.initialStatData) : {},
    initialStatFunc: plain2(source.initialStatFunc) ? clone3(source.initialStatFunc) : {},
    snapshotStatData: plain2(source.snapshotStatData) ? clone3(source.snapshotStatData) : plain2(source.initialStatData) ? clone3(source.initialStatData) : {},
    snapshotStatFunc: plain2(source.snapshotStatFunc) ? clone3(source.snapshotStatFunc) : plain2(source.initialStatFunc) ? clone3(source.initialStatFunc) : {},
    eraMeta: plain2(source.eraMeta) ? clone3(source.eraMeta) : {},
    templateContext: plain2(source.templateContext) ? clone3(source.templateContext) : {},
    randomContext: plain2(source.randomContext) && typeof source.randomContext.sourceKey === "string" && source.randomContext.sourceKey.length > 0 && Number.isSafeInteger(source.randomContext.drawOffset) && source.randomContext.drawOffset >= 0 ? {
      sourceKey: source.randomContext.sourceKey,
      drawOffset: source.randomContext.drawOffset
    } : void 0
  };
  const commands = [];
  const diagnostics = [];
  const pattern = /<((?:Variable|Function)(?:Insert|Edit|Delete))>\s*([\s\S]*?)\s*<\/\1>/giu;
  let match;
  while ((match = pattern.exec(request.content)) !== null) {
    const info = tagInfo2((match[1] ?? "").toLowerCase());
    if (!info) continue;
    const index = commands.length;
    const parsed = parseData2(match[2] ?? "", index);
    if (parsed.diagnostic) diagnostics.push(parsed.diagnostic);
    commands.push({
      index,
      kind: info.kind,
      tag: info.tag,
      data: parsed.data,
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0]
    });
  }
  return { request, commands, diagnostics };
}
function getAt2(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record2(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function hasAt2(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record2(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return false;
    cursor = cursor[segment];
  }
  return true;
}
function setAt2(root, segments, value) {
  let cursor = root;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const key = segments[index];
    if (!plain2(cursor[key])) cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[segments[segments.length - 1]] = clone3(value);
}
function unsetAt2(root, segments) {
  let cursor = root;
  for (const segment of segments.slice(0, -1)) {
    if (!record2(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return;
    cursor = cursor[segment];
  }
  if (record2(cursor)) delete cursor[segments[segments.length - 1]];
}
function metaValue2(value, key) {
  return plain2(value) && plain2(value.$meta) ? value.$meta[key] : void 0;
}
function merge2(left, right) {
  if (!plain2(left) || !plain2(right)) return clone3(right);
  const output = clone3(left);
  for (const [key, value] of Object.entries(right)) {
    output[key] = Object.prototype.hasOwnProperty.call(output, key) ? merge2(output[key], value) : clone3(value);
  }
  return output;
}
function inheritedTemplateContent2(parentTemplate, key) {
  if (!plain2(parentTemplate)) return void 0;
  const general = parentTemplate.$template;
  const specific = parentTemplate[key];
  if (plain2(general) && plain2(specific)) return merge2(general, specific);
  return plain2(specific) ? specific : plain2(general) ? general : void 0;
}
function resolvedTemplate2(inherited, parentData) {
  const own = plain2(parentData) ? parentData.$template : void 0;
  const result = merge2(plain2(inherited) ? inherited : {}, plain2(own) ? own : {});
  return plain2(result) && Object.keys(result).length > 0 ? result : void 0;
}
function applyTemplate2(template, patch) {
  if (!plain2(patch) || !plain2(template)) return clone3(patch);
  return Object.keys(patch).length === 0 ? clone3(template) : merge2(template, patch);
}
function applyInsertAt2(stat, segments, patch, inheritedTemplate = void 0, parentData = void 0) {
  const current = getAt2(stat, segments);
  const localTemplate = resolvedTemplate2(inheritedTemplate, parentData);
  if (segments.length > 0 && current === void 0) {
    setAt2(stat, segments, applyTemplate2(localTemplate, patch));
    return;
  }
  if (!plain2(current) || !plain2(patch)) return;
  const protection = metaValue2(current, "unInsertAble");
  const keys = Object.keys(patch);
  const metaOnly = keys.every((key) => key === "$meta");
  if (protection === "all" && keys.length > 0 && !metaOnly) return;
  for (const key of keys) {
    if (protection === "self" && key !== "$meta" && !Object.prototype.hasOwnProperty.call(current, key)) continue;
    applyInsertAt2(
      stat,
      [...segments, key],
      patch[key],
      inheritedTemplateContent2(localTemplate, key),
      current
    );
  }
}
function expressionValue2(stat, layerStart, statFunc, startFunc, path, expr, randomCursor) {
  const request = {
    initialState: stat,
    snapshotState: layerStart,
    functionLibrary: statFunc,
    snapshotFunctionLibrary: startFunc,
    allowSnapshots: true,
    operations: [{ path: path.join("."), expr }],
    ...randomCursor ? { randomContext: randomCursor } : {}
  };
  const response = executeExpressionLayer(request);
  if (randomCursor) randomCursor.drawOffset = response.nextDrawOffset;
  const value = getAt2(response.finalState, path);
  const issue = response.diagnostics[0];
  if (issue || typeof value !== "number" || !Number.isFinite(value)) {
    return { diagnostic: diagnostic3(issue?.code ?? "ERA_COMPACT_EXPR_NON_FINITE", issue?.message ?? "$expr \u5FC5\u987B\u5F97\u5230\u6709\u9650\u6570\u503C\u3002", void 0, path.join(".")) };
  }
  return { value };
}
function applyEditAt2(stat, layerStart, statFunc, startFunc, segments, patch, diagnostics, commandIndex, randomCursor) {
  const current = getAt2(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  if (metaValue2(current, "updatable") === false) {
    const unlock = plain2(patch) && plain2(patch.$meta) && patch.$meta.updatable === true;
    if (!unlock) return;
  }
  if (plain2(patch) && Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (segments.length === 0 || !hasAt2(stat, segments)) return;
    const resolved = expressionValue2(
      stat,
      layerStart,
      statFunc,
      startFunc,
      segments,
      patch.$expr,
      randomCursor
    );
    if (resolved.diagnostic) diagnostics.push({ ...resolved.diagnostic, commandIndex });
    else setAt2(stat, segments, resolved.value);
    return;
  }
  if (!plain2(patch)) {
    if (segments.length > 0 && hasAt2(stat, segments)) setAt2(stat, segments, patch);
    return;
  }
  for (const [key, value] of Object.entries(patch)) {
    applyEditAt2(stat, layerStart, statFunc, startFunc, [...segments, key], value, diagnostics, commandIndex, randomCursor);
  }
}
function deleteBypass2(patch) {
  return plain2(patch) && plain2(patch.$meta) && Object.prototype.hasOwnProperty.call(patch.$meta, "necessary");
}
function emptyRecord2(value) {
  return plain2(value) && Object.keys(value).length === 0;
}
function applyDeleteAt2(stat, segments, patch) {
  const current = getAt2(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  const necessary = metaValue2(current, "necessary");
  const bypass = deleteBypass2(patch);
  if (plain2(patch) && Object.keys(patch).length > 0) {
    if (necessary === "all" && !bypass) return;
    for (const [key, value] of Object.entries(patch)) {
      if (necessary === "children" && emptyRecord2(value) && !(key === "$meta" && bypass)) continue;
      applyDeleteAt2(stat, [...segments, key], value);
    }
    return;
  }
  if (segments.length === 0 || necessary === "self" || necessary === "all") return;
  unsetAt2(stat, segments);
}
function functionDiagnostic2(code, message, commandIndex, name) {
  return diagnostic3(code, message, commandIndex, name);
}
function functionMetaInvalid2(value) {
  const meta = plain2(value) && plain2(value.$meta) ? value.$meta : null;
  if (!meta) return null;
  if (Object.prototype.hasOwnProperty.call(meta, "unInsertAble")) return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.unInsertAble\u3002";
  if (meta.necessary === "children") return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.necessary: children\u3002";
  return null;
}
function validateFunctions2(library) {
  const result = executeExpressionLayer({ initialState: {}, functionLibrary: library, operations: [] });
  const issue = result.diagnostics[0];
  return issue ? diagnostic3(issue.code, issue.message, void 0, "<library>") : null;
}
function editFunction2(current, patch) {
  if (!plain2(current) || !plain2(patch)) return clone3(patch);
  const patchMeta = plain2(patch.$meta) ? patch.$meta : null;
  if (Object.keys(patch).length === 1 && patchMeta) {
    const next2 = clone3(current);
    next2.$meta = merge2(current.$meta, patchMeta);
    return next2;
  }
  const next = clone3(patch);
  if (!Object.prototype.hasOwnProperty.call(patch, "$meta") && Object.prototype.hasOwnProperty.call(current, "$meta")) next.$meta = clone3(current.$meta);
  else if (patchMeta) next.$meta = merge2(current.$meta, patchMeta);
  return next;
}
function applyFunction2(library, type, data, diagnostics, commandIndex) {
  let current = clone3(library);
  for (const root of data) {
    if (Object.keys(root).length === 0) {
      diagnostics.push(functionDiagnostic2("ERA_FUNCTION_COMMAND_INVALID", "\u51FD\u6570\u6307\u4EE4\u5FC5\u987B\u662F\u975E\u7A7A\u5BF9\u8C61\u3002", commandIndex));
      continue;
    }
    const candidate = clone3(current);
    const issues = [];
    for (const [name, patch] of Object.entries(root)) {
      const exists = Object.prototype.hasOwnProperty.call(current, name);
      if (type === "function-insert") {
        if (exists) {
          issues.push(functionDiagnostic2("ERA_FUNCTION_ALREADY_EXISTS", "FunctionInsert \u53EA\u80FD\u65B0\u589E\u4E0D\u5B58\u5728\u7684\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        const invalid2 = functionMetaInvalid2(patch);
        if (invalid2) {
          issues.push(functionDiagnostic2("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = clone3(patch);
      } else if (type === "function-edit") {
        if (!exists) {
          issues.push(functionDiagnostic2("ERA_FUNCTION_NOT_FOUND", "FunctionEdit \u53EA\u80FD\u4FEE\u6539\u65E2\u6709\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        if (metaValue2(current[name], "updatable") === false && !(plain2(patch) && plain2(patch.$meta) && patch.$meta.updatable === true)) continue;
        const next = editFunction2(current[name], patch);
        const invalid2 = functionMetaInvalid2(next);
        if (invalid2) {
          issues.push(functionDiagnostic2("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = next;
      } else {
        if (!plain2(patch)) {
          issues.push(functionDiagnostic2("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
          continue;
        }
        if (Object.keys(patch).length === 0) {
          if (exists && !["self", "all"].includes(String(metaValue2(current[name], "necessary")))) delete candidate[name];
        } else if (Object.keys(patch).length === 1 && plain2(patch.$meta) && exists) {
          const next = clone3(current[name]);
          const metaPatch = patch.$meta;
          if (plain2(next.$meta)) {
            for (const key of Object.keys(metaPatch)) delete next.$meta[key];
          }
          candidate[name] = next;
        } else issues.push(functionDiagnostic2("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
      }
    }
    if (issues.length > 0) {
      diagnostics.push(...issues);
      continue;
    }
    const invalid = validateFunctions2(candidate);
    if (invalid) {
      diagnostics.push({ ...invalid, commandIndex });
      continue;
    }
    current = candidate;
  }
  return current;
}
function executeOriginalSemantics2(parsed) {
  const stat = clone3(parsed.request.initialStatData);
  const start = clone3(parsed.request.snapshotStatData ?? parsed.request.initialStatData);
  let functions = clone3(parsed.request.initialStatFunc ?? {});
  const startFunctions = clone3(parsed.request.snapshotStatFunc ?? parsed.request.initialStatFunc ?? {});
  const diagnostics = [...parsed.diagnostics];
  const randomCursor = parsed.request.randomContext ? { ...parsed.request.randomContext } : null;
  for (const command of parsed.commands) {
    if (command.data.length === 0) continue;
    if (command.kind === "insert") for (const patch of command.data) applyInsertAt2(stat, [], patch);
    else if (command.kind === "edit") for (const patch of command.data) applyEditAt2(stat, start, functions, startFunctions, [], patch, diagnostics, command.index, randomCursor);
    else if (command.kind === "delete") for (const patch of command.data) applyDeleteAt2(stat, [], patch);
    else functions = applyFunction2(functions, command.kind, command.data, diagnostics, command.index);
  }
  return {
    ...parsed,
    finalStatData: stat,
    finalStatFunc: functions,
    diagnostics,
    nextRandomDrawOffset: randomCursor?.drawOffset ?? parsed.request.randomContext?.drawOffset ?? 0
  };
}
function hasMeta2(value) {
  if (!plain2(value)) return false;
  if (Object.prototype.hasOwnProperty.call(value, "$meta") || Object.prototype.hasOwnProperty.call(value, "$template")) return true;
  return Object.values(value).some(hasMeta2);
}
function flattenNumericEdits2(patch, prefix = [], output = []) {
  if (!plain2(patch)) return false;
  if (Object.prototype.hasOwnProperty.call(patch, "$meta") || Object.prototype.hasOwnProperty.call(patch, "$template")) return false;
  if (Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (prefix.length === 0) return false;
    output.push({ path: prefix.join("."), expr: patch.$expr, source: "expr" });
    return true;
  }
  for (const [key, value] of Object.entries(patch)) {
    if (plain2(value)) {
      if (!flattenNumericEdits2(value, [...prefix, key], output)) return false;
    } else if (typeof value === "number" && Number.isFinite(value)) output.push({ path: [...prefix, key].join("."), expr: JSON.stringify(value), source: "literal", literal: value });
    else return false;
  }
  return output.length > 0;
}
function nestingRecord2(paths) {
  const result = {};
  for (const item of paths) {
    const parts = item.path.split(".");
    let cursor = result;
    for (const part of parts.slice(0, -1)) {
      if (Object.prototype.hasOwnProperty.call(cursor, part) && !plain2(cursor[part])) return null;
      cursor[part] ??= {};
      cursor = cursor[part];
    }
    const leaf = parts[parts.length - 1];
    if (plain2(cursor[leaf])) return null;
    cursor[leaf] = item.value;
  }
  return result;
}
function renderTag2(tag, data) {
  return `<${tag}>
${JSON.stringify(data)}
</${tag}>`;
}
function mergeInsertPatch2(left, right) {
  if (!plain2(left) || !plain2(right) || hasMeta2(left) || hasMeta2(right)) return null;
  const output = clone3(left);
  for (const [key, value] of Object.entries(right)) {
    if (!Object.prototype.hasOwnProperty.call(output, key)) output[key] = clone3(value);
    else if (plain2(output[key]) && plain2(value)) {
      const merged = mergeInsertPatch2(output[key], value);
      if (merged === null) return null;
      output[key] = merged;
    } else if (!plain2(output[key]) && plain2(value)) {
      return null;
    }
  }
  return output;
}
function allCommandData2(command) {
  if (command.data.length !== 1) return null;
  return command.data[0] ?? null;
}
function compactEditRun2(trace, commands) {
  const operations = [];
  for (const command of commands) {
    const data = allCommandData2(command);
    if (!data || !flattenNumericEdits2(data, [], operations)) return null;
  }
  const response = executeExpressionLayer({
    initialState: trace.request.initialStatData,
    snapshotState: trace.request.snapshotStatData ?? trace.request.initialStatData,
    functionLibrary: trace.request.initialStatFunc ?? {},
    snapshotFunctionLibrary: trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {},
    allowSnapshots: true,
    operations,
    ...trace.request.randomContext ? { randomContext: trace.request.randomContext } : {}
  });
  if (response.diagnostics.length > 0) return null;
  const sourceByPath = /* @__PURE__ */ new Map();
  const lastLiteralByPath = /* @__PURE__ */ new Map();
  for (const operation of operations) {
    const prior = sourceByPath.get(operation.path);
    sourceByPath.set(operation.path, prior === void 0 || prior === operation.source ? operation.source : "mixed");
    if (operation.source === "literal") lastLiteralByPath.set(operation.path, operation.literal);
  }
  if ([...sourceByPath.values()].includes("mixed")) return null;
  const output = nestingRecord2(response.compactedOperations.map((item) => {
    const source = sourceByPath.get(item.path);
    return source === "literal" ? { path: item.path, value: lastLiteralByPath.get(item.path) } : { path: item.path, value: { $expr: item.value.$expr } };
  }));
  return output && Object.keys(output).length > 0 ? renderTag2("VariableEdit", output) : "";
}
function pathConflict2(left, right) {
  return left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
}
function operationRefs2(ast) {
  const refs = /* @__PURE__ */ new Set();
  const visit = (item) => {
    if (item.kind === "ref") {
      if (!item.snapshot) refs.add(item.path.join("."));
      return;
    }
    if (item.kind === "unary") visit(item.value);
    else if (item.kind === "binary") {
      visit(item.left);
      visit(item.right);
    } else if (item.kind === "call") for (const arg of item.args) visit(arg);
  };
  visit(ast);
  return [...refs];
}
function commandExpressionFacts2(trace, command) {
  const operations = [];
  const data = allCommandData2(command);
  if (!data || !flattenNumericEdits2(data, [], operations))
    return { automaticRandom: false, paths: [], refs: [], flattenable: false };
  const current = compileFunctionLibrary(trace.request.initialStatFunc ?? {});
  const snapshot = compileFunctionLibrary(
    trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {}
  );
  const refs = /* @__PURE__ */ new Set();
  let automaticRandom = false;
  for (const operation of operations) {
    const parsed = parseExpression(operation.expr, true);
    if (!parsed.ast) continue;
    if (countAutomaticRandomDraws(parsed.ast, current, snapshot) > 0)
      automaticRandom = true;
    for (const ref of operationRefs2(parsed.ast)) refs.add(ref);
  }
  return {
    automaticRandom,
    paths: operations.map((operation) => operation.path),
    refs: [...refs],
    flattenable: true
  };
}
function segmentDoesNotDependOnPriorChanges2(facts, priorPaths) {
  return facts.every(
    (fact) => fact.refs.every(
      (ref) => ![...priorPaths].some((path) => pathConflict2(ref, path))
    )
  );
}
function compactInsertRun2(commands) {
  let merged = {};
  for (const command of commands) {
    const data = allCommandData2(command);
    if (!data) return null;
    const next = mergeInsertPatch2(merged, data);
    if (next === null) return null;
    merged = next;
  }
  return plain2(merged) && Object.keys(merged).length > 0 ? renderTag2("VariableInsert", merged) : null;
}
function candidateFor2(analysis) {
  const { trace } = analysis;
  const replacements = /* @__PURE__ */ new Map();
  const reasons = [];
  if (trace.diagnostics.length > 0) return { ...trace, replacements, reasons: ["\u539F\u547D\u4EE4\u542B\u8BCA\u65AD\uFF0C\u4FDD\u7559\u5168\u90E8\u6807\u7B7E\u3002"] };
  let cursor = 0;
  while (cursor < trace.commands.length) {
    const kind = trace.commands[cursor].kind;
    let end = cursor + 1;
    while (end < trace.commands.length && trace.commands[end].kind === kind) end += 1;
    const run12 = trace.commands.slice(cursor, end);
    let replacement = null;
    if (kind === "edit") {
      if (cursor === 0) {
        const facts = run12.map((command) => analysis.facts[command.index]);
        const priorPaths = /* @__PURE__ */ new Set();
        let segmentStart = 0;
        const compactSegment = (segmentEnd) => {
          if (segmentEnd <= segmentStart) return;
          const segment = run12.slice(segmentStart, segmentEnd);
          const segmentFacts = facts.slice(segmentStart, segmentEnd);
          if (segmentFacts.every((fact) => fact.flattenable) && segmentDoesNotDependOnPriorChanges2(segmentFacts, priorPaths)) {
            const compacted = compactEditRun2(trace, segment);
            if (compacted !== null && (segment.length > 1 || compacted !== segment[0].raw)) {
              replacements.set(segment[0].index, compacted);
              for (const command of segment.slice(1))
                replacements.set(command.index, "");
            }
          } else {
            reasons.push(
              `${segment.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u4F9D\u8D56\u968F\u673A\u5C4F\u969C\u6216\u66F4\u65E9\u547D\u4EE4\u6539\u53D8\u7684\u8DEF\u5F84\u3002`
            );
          }
          for (const fact of segmentFacts)
            for (const path of fact.paths) priorPaths.add(path);
        };
        for (let index = 0; index < run12.length; index += 1) {
          if (!facts[index].automaticRandom) continue;
          compactSegment(index);
          for (const path of facts[index].paths) priorPaths.add(path);
          reasons.push(`${run12[index].tag} \u4FDD\u7559\uFF1A\u5305\u542B\u81EA\u52A8 random \u8C03\u7528\u3002`);
          segmentStart = index + 1;
        }
        compactSegment(run12.length);
        replacement = null;
      } else
        reasons.push(`${run12.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u524D\u5E8F\u547D\u4EE4\u4F1A\u6539\u53D8\u8BE5\u533A\u95F4\u7684\u5C42\u8D77\u59CB\u8BED\u4E49\u3002`);
    } else if (kind === "insert") replacement = compactInsertRun2(run12);
    else reasons.push(`${run12.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u5C1A\u65E0\u53EF\u8BC1\u660E\u7684\u901A\u7528\u91CD\u5199\u89C4\u5219\u3002`);
    if (replacement !== null && (run12.length > 1 || replacement !== run12[0].raw)) {
      replacements.set(run12[0].index, replacement);
      for (const command of run12.slice(1)) replacements.set(command.index, "");
    }
    cursor = end;
  }
  return { ...trace, replacements, reasons };
}
function render2(trace, replacements) {
  let content = trace.request.content;
  for (const command of [...trace.commands].sort((left, right) => right.start - left.start)) {
    const replacement = replacements.get(command.index);
    if (replacement !== void 0) content = `${content.slice(0, command.start)}${replacement}${content.slice(command.end)}`;
  }
  return content;
}
function equivalent2(trace, content) {
  const replay = executeOriginalSemantics2(parseCommandLayer2({ ...trace.request, content }));
  const sameDiagnostics = replay.diagnostics.length === trace.diagnostics.length && replay.diagnostics.every((issue, index) => {
    const expected = trace.diagnostics[index];
    return expected !== void 0 && issue.code === expected.code && issue.path === expected.path;
  });
  return sameDiagnostics && equal2(replay.finalStatData, trace.finalStatData) && equal2(replay.finalStatFunc, trace.finalStatFunc) && replay.nextRandomDrawOffset === trace.nextRandomDrawOffset;
}
function analyzeDependencies2(trace) {
  const facts = {};
  if (trace.diagnostics.length === 0) {
    for (const command of trace.commands) {
      if (command.kind !== "edit") break;
      facts[command.index] = commandExpressionFacts2(trace, command);
    }
  }
  return { trace, facts };
}

// api/engine.ts
function compactCommandLayer(input) {
  return runWorkflow({ compaction_request: input }).compactionResponse;
}
export {
  analyzeDependencies2 as analyzeDependencies,
  candidateFor2 as candidateFor,
  clone3 as clone,
  compactCommandLayer,
  equal2 as equal,
  equivalent2 as equivalent,
  executeOriginalSemantics2 as executeOriginalSemantics,
  parseCommandLayer2 as parseCommandLayer,
  render2 as render,
  renderTag2 as renderTag
};
