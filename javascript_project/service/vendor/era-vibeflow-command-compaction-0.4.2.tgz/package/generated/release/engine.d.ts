export type JsonValue = null | boolean | number | string | JsonValue[] | {
    [key: string]: JsonValue;
};
export type CommandKind = "insert" | "edit" | "delete" | "function-insert" | "function-edit" | "function-delete";
export interface CommandDiagnostic {
    readonly [key: string]: unknown;
    readonly code: string;
    readonly message: string;
    readonly commandIndex?: number;
    readonly path?: string;
}
export interface ParsedCommand {
    readonly [key: string]: unknown;
    readonly index: number;
    readonly kind: CommandKind;
    readonly tag: string;
    readonly data: readonly Record<string, unknown>[];
    readonly start: number;
    readonly end: number;
    readonly raw: string;
}
export interface CommandCompactionRequest {
    readonly [key: string]: unknown;
    readonly content: string;
    readonly initialStatData: Readonly<Record<string, unknown>>;
    readonly initialStatFunc?: Readonly<Record<string, unknown>>;
    /** 整条消息开始时的变量快照；分段压缩时与当前段起点不同。 */
    readonly snapshotStatData?: Readonly<Record<string, unknown>>;
    /** 整条消息开始时的函数快照；供 @f(...) 在任意 scope 段保持同一闭包。 */
    readonly snapshotStatFunc?: Readonly<Record<string, unknown>>;
    readonly eraMeta?: Readonly<Record<string, unknown>>;
    readonly templateContext?: Readonly<Record<string, unknown>>;
    /** Service passes the sealed message MK; no target path or persistent cursor. */
    readonly randomContext?: {
        readonly sourceKey: string;
        readonly drawOffset: number;
    };
}
export interface CommandCompactionResponse {
    readonly [key: string]: unknown;
    readonly status: "compacted" | "partial" | "unchanged" | "invalid";
    readonly content: string;
    readonly finalStatData: Readonly<Record<string, unknown>>;
    readonly finalStatFunc: Readonly<Record<string, unknown>>;
    readonly diagnostics: readonly CommandDiagnostic[];
    readonly reasons: readonly string[];
    readonly parsedCommands: readonly ParsedCommand[];
    readonly nextRandomDrawOffset: number;
}
export interface ParsedLayer {
    readonly [key: string]: unknown;
    readonly request: CommandCompactionRequest;
    readonly commands: readonly ParsedCommand[];
    readonly diagnostics: readonly CommandDiagnostic[];
}
export interface SemanticTrace extends ParsedLayer {
    readonly [key: string]: unknown;
    readonly finalStatData: Readonly<Record<string, unknown>>;
    readonly finalStatFunc: Readonly<Record<string, unknown>>;
    readonly diagnostics: readonly CommandDiagnostic[];
    readonly nextRandomDrawOffset: number;
}
export interface Candidate extends SemanticTrace {
    readonly [key: string]: unknown;
    readonly replacements: ReadonlyMap<number, string>;
    readonly reasons: readonly string[];
}
export declare function clone<T>(value: T): T;
export declare function equal(left: unknown, right: unknown): boolean;
export declare function parseCommandLayer(input: unknown): ParsedLayer;
export declare function executeOriginalSemantics(parsed: ParsedLayer): SemanticTrace;
export declare function renderTag(tag: string, data: Record<string, unknown>): string;
declare function commandExpressionFacts(trace: SemanticTrace, command: ParsedCommand): {
    readonly automaticRandom: boolean;
    readonly paths: readonly string[];
    readonly refs: readonly string[];
    readonly flattenable: boolean;
};
export declare function candidateFor(analysis: DependencyAnalysis): Candidate;
export declare function render(trace: SemanticTrace, replacements: ReadonlyMap<number, string>): string;
export declare function equivalent(trace: SemanticTrace, content: string): boolean;
/** Facts used by rewriting are computed at the explicit analysis stage. */
export interface DependencyAnalysis {
    readonly [key: string]: unknown;
    readonly trace: SemanticTrace;
    readonly facts: Readonly<Record<number, ReturnType<typeof commandExpressionFacts>>>;
}
export declare function analyzeDependencies(trace: SemanticTrace): DependencyAnalysis;
export {};

export declare function compactCommandLayer(input: unknown): CommandCompactionResponse;
