export type WorkflowTraceMode = "off" | "boundary" | "full";

export interface VibeFlowAbortSignal {
  readonly aborted: boolean;
  readonly reason: unknown;
  readonly onabort: ((event: any) => unknown) | null;
  throwIfAborted(): void;
  addEventListener(type: string, listener: any, options?: any): void;
  removeEventListener(type: string, listener: any, options?: any): void;
  dispatchEvent(event: any): boolean;
}

export interface WorkflowTraceEvent {
  readonly kind: string;
  readonly workflowId: string;
  readonly nodeId?: string;
  readonly nodePath?: string;
  readonly path?: readonly string[];
  readonly [key: string]: unknown;
}

export class VibeFlowWorkflowError extends Error {
  readonly code: string;
  readonly workflowId: string;
  readonly nodePath: string;
  readonly blockPath: string;
}

export interface WorkflowInputs {
  readonly "compaction_request": { readonly [key: string]: unknown };
}

export interface WorkflowOutputs {
  readonly "compactionResponse": { readonly [key: string]: unknown };
}

export interface WorkflowCapabilities {
}

export interface WorkflowRunOptions {
  readonly signal?: VibeFlowAbortSignal;
  readonly trace?: WorkflowTraceMode;
  readonly onTrace?: (event: WorkflowTraceEvent) => void;
  readonly capabilities?: WorkflowCapabilities;
  readonly detachedTimeoutMs?: number;
}

export const VIBEFLOW_WORKFLOW_ABI: "vibeflow.workflow.v4";
export const VIBEFLOW_PLUGIN_ABI: "vibeflow.plugin.v1";
export function runWorkflow(inputs: WorkflowInputs, options?: WorkflowRunOptions): WorkflowOutputs;
