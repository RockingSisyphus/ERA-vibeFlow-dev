// ../../../../../../ai-tmp/era-packages-q5xd0ixw/era-expression-package-hfM9MT/browser/workflow.js
import gamma from "@stdlib/math-base-special-gamma";
import { derivative, evaluate as mathEvaluate } from "mathjs/number";
function terminalNode() {
  return {};
}
function isBuiltin(name) {
  return [
    "sin",
    "cos",
    "tan",
    "asin",
    "acos",
    "atan",
    "sinh",
    "cosh",
    "tanh",
    "asinh",
    "acosh",
    "atanh",
    "exp",
    "log",
    "ln",
    "sqrt",
    "abs",
    "floor",
    "ceil",
    "round",
    "trunc",
    "min",
    "max",
    "clamp",
    "pow",
    "mod",
    "factorial",
    "gamma",
    "derivative",
    "integral",
    "random"
  ].includes(name);
}
function diagnostic(code, message, extra = {}) {
  return { code, message, ...extra };
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function clone(value) {
  return structuredClone(value);
}
function finite(value, code, message) {
  if (!Number.isFinite(value))
    throw new ExpressionFailure(diagnostic(code, message));
  return Object.is(value, -0) ? 0 : value;
}
var ExpressionFailure = class extends Error {
  constructor(detail) {
    super(detail.message);
    this.detail = detail;
  }
  detail;
};
function getPath(root, path) {
  let value = root;
  for (const segment of path) {
    if (!isRecord(value) || !(segment in value)) return void 0;
    value = value[segment];
  }
  return value;
}
function setPath(root, path, value) {
  if (!isRecord(root))
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_STATE_ROOT", "\u53D8\u91CF\u72B6\u6001\u6839\u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const next = clone(root);
  let cursor = next;
  for (const segment of path.slice(0, -1)) {
    const child = cursor[segment];
    if (!isRecord(child)) cursor[segment] = {};
    cursor = cursor[segment];
  }
  cursor[path[path.length - 1]] = value;
  return next;
}
var UINT64_MASK = (1n << 64n) - 1n;
var FNV64_OFFSET = 0xcbf29ce484222325n;
var FNV64_PRIME = 0x100000001b3n;
var SPLITMIX_GAMMA = 0x9e3779b97f4a7c15n;
var SPLITMIX_MUL_1 = 0xbf58476d1ce4e5b9n;
var SPLITMIX_MUL_2 = 0x94d049bb133111ebn;
var TWO_POW_53 = 9007199254740992;
function fnv1a64(bytes) {
  return bytes.reduce(
    (hash, byte) => (hash ^ BigInt(byte)) * FNV64_PRIME & UINT64_MASK,
    FNV64_OFFSET
  );
}
function randomSeedHash(seed) {
  if (typeof seed === "string") return fnv1a64(new TextEncoder().encode(seed));
  const normalized = Object.is(seed, -0) ? 0 : seed;
  const buffer = new ArrayBuffer(8);
  new DataView(buffer).setFloat64(0, normalized, true);
  return fnv1a64(new Uint8Array(buffer));
}
function deterministicRandomUnit(seed, draw) {
  if (typeof seed === "number" && !Number.isFinite(seed) || !Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 seed \u5FC5\u987B\u6709\u9650\uFF0Cdraw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  const mixed0 = randomSeedHash(seed) + BigInt(draw) + SPLITMIX_GAMMA & UINT64_MASK;
  const mixed1 = (mixed0 ^ mixed0 >> 30n) * SPLITMIX_MUL_1 & UINT64_MASK;
  const mixed2 = (mixed1 ^ mixed1 >> 27n) * SPLITMIX_MUL_2 & UINT64_MASK;
  const mixed3 = mixed2 ^ mixed2 >> 31n;
  return Number((mixed3 & UINT64_MASK) >> 11n) / TWO_POW_53;
}
function calculateRandom(args, context, automaticDraw) {
  if (args.length > 2)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_BUILTIN_ARITY",
        "random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002"
      )
    );
  if (args.length < 2 && !context)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_CONTEXT_REQUIRED",
        "random() \u4E0E random(seed) \u9700\u8981\u6D88\u606F\u968F\u673A\u4E0A\u4E0B\u6587\u3002"
      )
    );
  const seed = args.length === 0 ? context.sourceKey : args[0];
  const draw = args.length === 2 ? args[1] : automaticDraw;
  if (!Number.isSafeInteger(draw) || draw < 0)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_RANDOM_DRAW_INVALID",
        "random \u7684 draw \u5FC5\u987B\u662F\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
      )
    );
  return deterministicRandomUnit(seed, draw);
}
function calculateBuiltin(name, args) {
  const unary = {
    sin: Math.sin,
    cos: Math.cos,
    tan: Math.tan,
    asin: Math.asin,
    acos: Math.acos,
    atan: Math.atan,
    sinh: Math.sinh,
    cosh: Math.cosh,
    tanh: Math.tanh,
    asinh: Math.asinh,
    acosh: Math.acosh,
    atanh: Math.atanh,
    exp: Math.exp,
    log: Math.log,
    ln: Math.log,
    sqrt: Math.sqrt,
    abs: Math.abs,
    floor: Math.floor,
    ceil: Math.ceil,
    round: Math.round,
    trunc: Math.trunc,
    gamma
  };
  if (name in unary) {
    if (args.length !== 1)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      unary[name](args[0]),
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  if (name === "factorial") {
    if (args.length !== 1 || !Number.isSafeInteger(args[0]) || args[0] < 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FACTORIAL_DOMAIN",
          "factorial \u53EA\u63A5\u53D7\u975E\u8D1F\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    let result = 1;
    for (let value = 2; value <= args[0]; value += 1)
      result = finite(
        result * value,
        "ERA_EXPR_FACTORIAL_NON_FINITE",
        "factorial \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    return result;
  }
  if (name === "min" || name === "max") {
    if (args.length === 0)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u53C2\u6570\u3002`)
      );
    return name === "min" ? Math.min(...args) : Math.max(...args);
  }
  if (name === "clamp") {
    if (args.length !== 3)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", "clamp \u9700\u8981\u4E09\u4E2A\u53C2\u6570\u3002")
      );
    return Math.min(Math.max(args[0], args[1]), args[2]);
  }
  if (name === "pow" || name === "mod") {
    if (args.length !== 2)
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_BUILTIN_ARITY", `${name} \u9700\u8981\u4E24\u4E2A\u53C2\u6570\u3002`)
      );
    return finite(
      name === "pow" ? args[0] ** args[1] : args[0] % args[1],
      "ERA_EXPR_BUILTIN_NON_FINITE",
      `${name} \u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002`
    );
  }
  throw new ExpressionFailure(
    diagnostic("ERA_EXPR_BUILTIN_UNKNOWN", `\u672A\u77E5\u5185\u5EFA\u51FD\u6570 ${name}\u3002`)
  );
}
function lex(source) {
  const tokens = [];
  let cursor = 0;
  while (cursor < source.length) {
    const char = source[cursor];
    if (/\s/u.test(char)) {
      cursor += 1;
      continue;
    }
    if (/[0-9.]/u.test(char) && (/[0-9]/u.test(char) || /[0-9]/u.test(source[cursor + 1] ?? ""))) {
      const match = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/u.exec(
        source.slice(cursor)
      );
      if (!match)
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_LEX_INVALID_NUMBER", "\u65E0\u6548\u6570\u5B57\u3002", {
            position: cursor
          })
        );
      tokens.push({ kind: "number", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if (/[A-Za-z_]/u.test(char)) {
      const match = /^[A-Za-z_][A-Za-z0-9_]*/u.exec(source.slice(cursor));
      tokens.push({ kind: "identifier", text: match[0], position: cursor });
      cursor += match[0].length;
      continue;
    }
    if ("+-*/%^@".includes(char)) {
      tokens.push({ kind: "operator", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    if ("(),.".includes(char)) {
      tokens.push({ kind: "punctuation", text: char, position: cursor });
      cursor += 1;
      continue;
    }
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_LEX_INVALID_CHARACTER",
        `\u4E0D\u652F\u6301\u5B57\u7B26 ${JSON.stringify(char)}\u3002`,
        { position: cursor }
      )
    );
  }
  tokens.push({ kind: "eof", text: "", position: cursor });
  return tokens;
}
var Parser = class {
  constructor(tokens, allowSnapshot) {
    this.tokens = tokens;
    this.allowSnapshot = allowSnapshot;
  }
  tokens;
  allowSnapshot;
  index = 0;
  current() {
    return this.tokens[this.index];
  }
  take() {
    return this.tokens[this.index++];
  }
  matches(text) {
    return this.current().text === text;
  }
  expect(text) {
    if (!this.matches(text))
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_EXPECTED", `\u6B64\u5904\u5E94\u4E3A ${text}\u3002`, {
          position: this.current().position
        })
      );
    return this.take();
  }
  parse() {
    const ast = this.additive();
    if (this.current().kind !== "eof")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_TRAILING", "\u8868\u8FBE\u5F0F\u672B\u5C3E\u5B58\u5728\u672A\u89E3\u6790\u5185\u5BB9\u3002", {
          position: this.current().position
        })
      );
    return ast;
  }
  additive() {
    let left = this.multiplicative();
    while (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.multiplicative() };
    }
    return left;
  }
  multiplicative() {
    let left = this.unary();
    while (this.matches("*") || this.matches("/") || this.matches("%")) {
      const op = this.take().text;
      left = { kind: "binary", op, left, right: this.unary() };
    }
    return left;
  }
  unary() {
    if (this.matches("+") || this.matches("-")) {
      const op = this.take().text;
      return { kind: "unary", op, value: this.unary() };
    }
    return this.power();
  }
  power() {
    const left = this.primary();
    if (this.matches("^")) {
      this.take();
      return { kind: "binary", op: "^", left, right: this.unary() };
    }
    return left;
  }
  primary() {
    if (this.matches("(")) {
      this.take();
      const ast = this.additive();
      this.expect(")");
      return ast;
    }
    if (this.current().kind === "number") {
      const token = this.take();
      return {
        kind: "literal",
        value: finite(
          Number(token.text),
          "ERA_EXPR_NUMBER_NON_FINITE",
          "\u6570\u5B57\u5FC5\u987B\u6709\u9650\u3002"
        )
      };
    }
    let snapshot = false;
    if (this.matches("@")) {
      if (!this.allowSnapshot)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_SNAPSHOT_FORBIDDEN",
            "\u7528\u6237\u539F\u59CB\u8868\u8FBE\u5F0F\u4E0D\u80FD\u4F7F\u7528 @path\u3002",
            { position: this.current().position }
          )
        );
      this.take();
      snapshot = true;
    }
    if (this.current().kind !== "identifier")
      throw new ExpressionFailure(
        diagnostic("ERA_EXPR_PARSE_PRIMARY", "\u6B64\u5904\u5E94\u4E3A\u6570\u5B57\u3001\u53D8\u91CF\u6216\u51FD\u6570\u8C03\u7528\u3002", {
          position: this.current().position
        })
      );
    const first = this.take();
    if (this.matches("(")) {
      this.take();
      const args = [];
      if (!this.matches(")")) {
        do {
          args.push(this.additive());
          if (!this.matches(",")) break;
          this.take();
        } while (true);
      }
      this.expect(")");
      return { kind: "call", name: first.text, args, snapshot };
    }
    const path = [first.text];
    while (this.matches(".")) {
      this.take();
      const segment = this.current();
      if (segment.kind !== "identifier")
        throw new ExpressionFailure(
          diagnostic("ERA_EXPR_PATH_SEGMENT", "\u8DEF\u5F84\u70B9\u53F7\u540E\u5E94\u4E3A\u6807\u8BC6\u7B26\u3002", {
            position: segment.position
          })
        );
      path.push(this.take().text);
    }
    return { kind: "ref", path, snapshot };
  }
};
function parseExpression(source, allowSnapshot = false) {
  try {
    return {
      ast: new Parser(lex(source), allowSnapshot).parse(),
      diagnostics: []
    };
  } catch (error) {
    return {
      ast: null,
      diagnostics: [
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PARSE_FAILED", String(error))
      ]
    };
  }
}
function validatePath(value) {
  const parts = value.split(".");
  if (parts.length === 0 || parts.some((part) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(part)))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_PATH_INVALID",
        `\u65E0\u6548\u53D8\u91CF\u8DEF\u5F84 ${JSON.stringify(value)}\u3002`,
        { path: value }
      )
    );
  return parts;
}
function normaliseRequest(input) {
  const diagnostics = [];
  const request = isRecord(input) ? input : {};
  const initialState = request.initialState;
  if (!isRecord(initialState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_INITIAL_STATE_INVALID",
        "initialState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const snapshotState = request.snapshotState === void 0 ? null : isRecord(request.snapshotState) ? clone(request.snapshotState) : null;
  if (request.snapshotState !== void 0 && !isRecord(request.snapshotState))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_STATE_INVALID",
        "snapshotState \u5FC5\u987B\u662F JSON \u5BF9\u8C61\u3002"
      )
    );
  const functionLibrary = isRecord(request.functionLibrary) ? request.functionLibrary : {};
  if (request.functionLibrary !== void 0 && !isRecord(request.functionLibrary))
    diagnostics.push(
      diagnostic("ERA_EXPR_LIBRARY_INVALID", "functionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002")
    );
  const snapshotFunctionLibrary = request.snapshotFunctionLibrary === void 0 ? null : isRecord(request.snapshotFunctionLibrary) ? request.snapshotFunctionLibrary : null;
  if (request.snapshotFunctionLibrary !== void 0 && !isRecord(request.snapshotFunctionLibrary))
    diagnostics.push(
      diagnostic(
        "ERA_EXPR_SNAPSHOT_LIBRARY_INVALID",
        "snapshotFunctionLibrary \u5FC5\u987B\u662F\u5BF9\u8C61\u3002"
      )
    );
  let randomContext = null;
  if (request.randomContext !== void 0) {
    if (!isRecord(request.randomContext) || typeof request.randomContext.sourceKey !== "string" || request.randomContext.sourceKey.length === 0 || !Number.isSafeInteger(request.randomContext.drawOffset) || request.randomContext.drawOffset < 0)
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_RANDOM_CONTEXT_INVALID",
          "randomContext \u9700\u8981\u975E\u7A7A sourceKey \u4E0E\u975E\u8D1F\u5B89\u5168\u6574\u6570 drawOffset\u3002"
        )
      );
    else
      randomContext = {
        sourceKey: request.randomContext.sourceKey,
        drawOffset: request.randomContext.drawOffset
      };
  }
  const rawOperations = Array.isArray(request.operations) ? request.operations : [];
  if (!Array.isArray(request.operations))
    diagnostics.push(
      diagnostic("ERA_EXPR_OPERATIONS_INVALID", "operations \u5FC5\u987B\u662F\u6709\u5E8F\u6570\u7EC4\u3002")
    );
  const operations = [];
  for (const [index, operation] of rawOperations.entries()) {
    if (!isRecord(operation) || typeof operation.path !== "string" || typeof operation.expr !== "string") {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_OPERATION_SHAPE",
          `operations[${index}] \u5FC5\u987B\u6709 path \u548C expr \u5B57\u7B26\u4E32\u3002`
        )
      );
      continue;
    }
    operations.push({ path: operation.path, expr: operation.expr });
  }
  return {
    initialState: isRecord(initialState) ? clone(initialState) : {},
    snapshotState,
    functionLibrary,
    snapshotFunctionLibrary,
    allowSnapshots: request.allowSnapshots === true,
    randomContext,
    operations,
    diagnostics,
    valid: diagnostics.length === 0
  };
}
function walk(ast, visitor) {
  visitor(ast);
  if (ast.kind === "unary") walk(ast.value, visitor);
  if (ast.kind === "binary") {
    walk(ast.left, visitor);
    walk(ast.right, visitor);
  }
  if (ast.kind === "call") for (const arg of ast.args) walk(arg, visitor);
}
function parseOperations(request) {
  return request.operations.map((operation, index) => {
    const diagnostics = [];
    let path = [];
    try {
      path = validatePath(operation.path);
    } catch (error) {
      diagnostics.push(
        error instanceof ExpressionFailure ? error.detail : diagnostic("ERA_EXPR_PATH_INVALID", String(error))
      );
    }
    const parsed = diagnostics.length === 0 ? parseExpression(operation.expr, request.allowSnapshots) : { ast: null, diagnostics: [] };
    return {
      index,
      path,
      expr: operation.expr,
      ast: parsed.ast,
      diagnostics: [...diagnostics, ...parsed.diagnostics]
    };
  });
}
function validateRequestNode(inputs) {
  return {
    normalized_expression_request: normaliseRequest(
      nodeInput(inputs, "era.expression.request")
    )
  };
}
function nodeInput(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function validateRandomContextNode(inputs) {
  return {
    validated_random_request: nodeInput2(
      inputs,
      "era.expression.request.normalized"
    )
  };
}
function nodeInput2(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function parseFunctionDefinitions(request) {
  const parsed = [];
  for (const [name, raw] of Object.entries(request.functionLibrary)) {
    const definition = isRecord(raw) ? { params: raw.params, expr: raw.expr } : raw;
    const diagnostics = [];
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/u.test(name))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME",
          `\u51FD\u6570\u540D ${JSON.stringify(name)} \u65E0\u6548\u3002`,
          { path: name }
        )
      );
    if (isBuiltin(name))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_NAME_CONFLICT",
          `\u51FD\u6570\u540D ${name} \u4E0E\u5185\u5EFA\u51FD\u6570\u51B2\u7A81\u3002`,
          { path: name }
        )
      );
    if (!isRecord(definition) || !Array.isArray(definition.params) || typeof definition.expr !== "string")
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_SHAPE",
          `\u51FD\u6570 ${name} \u5E94\u5305\u542B params \u6570\u7EC4\u4E0E expr \u5B57\u7B26\u4E32\u3002`,
          { path: name }
        )
      );
    const params = isRecord(definition) && Array.isArray(definition.params) ? definition.params.filter(
      (item) => typeof item === "string"
    ) : [];
    if (params.length !== new Set(params).size || params.some((param) => !/^[A-Za-z_][A-Za-z0-9_]*$/u.test(param)))
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_PARAMS",
          `\u51FD\u6570 ${name} \u7684\u5F62\u53C2\u5FC5\u987B\u662F\u4E92\u5F02\u6807\u8BC6\u7B26\u3002`,
          { path: name }
        )
      );
    const expr = isRecord(definition) && typeof definition.expr === "string" ? definition.expr : "";
    const result = diagnostics.length === 0 ? parseExpression(expr, false) : { ast: null, diagnostics: [] };
    parsed.push({
      name,
      params,
      expr,
      ast: result.ast,
      diagnostics: [...diagnostics, ...result.diagnostics]
    });
  }
  return parsed;
}
function extractFunctionDependencies(parsed) {
  const names = new Set(parsed.map((item) => item.name));
  const result = {};
  for (const functionDef of parsed) {
    const dependencies = /* @__PURE__ */ new Set();
    if (functionDef.ast)
      walk(functionDef.ast, (item) => {
        if (item.kind === "call" && names.has(item.name))
          dependencies.add(item.name);
      });
    result[functionDef.name] = [...dependencies].sort();
  }
  return result;
}
function validateFunctionPurity(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const diagnostics = [];
  for (const functionDef of parsed) {
    diagnostics.push(...functionDef.diagnostics);
    if (!functionDef.ast) continue;
    const params = new Set(functionDef.params);
    walk(functionDef.ast, (item) => {
      if (item.kind === "ref" && (!params.has(item.path[0]) || item.path.length !== 1 || item.snapshot))
        diagnostics.push(
          diagnostic(
            "ERA_EXPR_FUNCTION_IMPURE",
            `\u51FD\u6570 ${functionDef.name} \u53EA\u80FD\u8BFB\u53D6\u81EA\u5DF1\u7684\u5F62\u53C2\u3002`,
            { path: functionDef.name }
          )
        );
      if (item.kind === "call") {
        if (item.name === "random" && item.args.length > 2)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_BUILTIN_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u4E2D\u7684 random \u53EA\u63A5\u53D7\u96F6\u4E2A\u3001\u4E00\u4E2A\u6216\u4E24\u4E2A\u53C2\u6570\u3002`,
              { path: functionDef.name }
            )
          );
        if (!isBuiltin(item.name) && !functions.has(item.name))
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528\u4E86\u672A\u77E5\u51FD\u6570 ${item.name}\u3002`,
              { path: functionDef.name }
            )
          );
        const target = functions.get(item.name);
        if (target && item.args.length !== target.params.length)
          diagnostics.push(
            diagnostic(
              "ERA_EXPR_FUNCTION_ARITY",
              `\u51FD\u6570 ${functionDef.name} \u8C03\u7528 ${item.name} \u7684\u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
              { path: functionDef.name }
            )
          );
      }
    });
  }
  return diagnostics;
}
function rejectRecursiveFunctions(dependencies) {
  const visited = /* @__PURE__ */ new Set();
  const visiting = [];
  const diagnostics = [];
  const visit = (name) => {
    const existing = visiting.indexOf(name);
    if (existing >= 0) {
      diagnostics.push(
        diagnostic(
          "ERA_EXPR_FUNCTION_RECURSION",
          `\u51FD\u6570\u9012\u5F52\u4E0D\u88AB\u652F\u6301\uFF1A${[...visiting.slice(existing), name].join(" \u2192 ")}\u3002`,
          { path: name }
        )
      );
      return;
    }
    if (visited.has(name)) return;
    visiting.push(name);
    for (const dependency of dependencies[name] ?? []) visit(dependency);
    visiting.pop();
    visited.add(name);
  };
  for (const name of Object.keys(dependencies)) visit(name);
  return diagnostics;
}
function findRandomFunctions(parsed) {
  const functions = new Map(parsed.map((item) => [item.name, item]));
  const memo = /* @__PURE__ */ new Map();
  const visiting = /* @__PURE__ */ new Set();
  const contains = (name) => {
    const cached = memo.get(name);
    if (cached !== void 0) return cached;
    if (visiting.has(name)) return false;
    visiting.add(name);
    const definition = functions.get(name);
    let found = false;
    if (definition?.ast)
      walk(definition.ast, (item) => {
        if (item.kind !== "call" || found) return;
        if (item.name === "random") found = true;
        else if (functions.has(item.name) && contains(item.name)) found = true;
      });
    visiting.delete(name);
    memo.set(name, found);
    return found;
  };
  return [...functions.keys()].filter(contains).sort();
}
function compileCallableFunctions(parsed, diagnostics) {
  const all = [...diagnostics];
  return {
    functions: Object.fromEntries(
      parsed.filter((item) => item.ast !== null).map((item) => [item.name, item])
    ),
    randomFunctions: findRandomFunctions(parsed),
    diagnostics: all,
    valid: all.length === 0
  };
}
function compileFunctionLibrary(functionLibrary) {
  const request = {
    initialState: {},
    snapshotState: null,
    functionLibrary,
    snapshotFunctionLibrary: null,
    allowSnapshots: false,
    randomContext: null,
    operations: [],
    diagnostics: [],
    valid: true
  };
  const parsed = parseFunctionDefinitions(request);
  const dependencies = extractFunctionDependencies(parsed);
  return compileCallableFunctions(parsed, [
    ...validateFunctionPurity(parsed),
    ...rejectRecursiveFunctions(dependencies)
  ]);
}
function countAutomaticRandomDraws(ast, currentLibrary, snapshotLibrary = currentLibrary) {
  const visiting = /* @__PURE__ */ new Set();
  const count = (item, library) => {
    if (item.kind === "literal" || item.kind === "ref") return 0;
    if (item.kind === "unary") return count(item.value, library);
    if (item.kind === "binary")
      return count(item.left, library) + count(item.right, library);
    let total = item.args.reduce((sum, arg) => sum + count(arg, library), 0);
    if (item.name === "random") return total + (item.args.length < 2 ? 1 : 0);
    if (isBuiltin(item.name)) return total;
    const targetLibrary = item.snapshot ? snapshotLibrary : library;
    const target = targetLibrary.functions[item.name];
    if (target?.ast && !visiting.has(target)) {
      visiting.add(target);
      total += count(target.ast, targetLibrary);
      visiting.delete(target);
    }
    return total;
  };
  return count(ast, currentLibrary);
}
function parseFunctionDefinitionsNode(inputs) {
  return {
    parsed_function_library: parseFunctionDefinitions(
      nodeInput3(inputs, "era.expression.request.normalized")
    )
  };
}
function nodeInput3(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function extractFunctionDependenciesNode(inputs) {
  return {
    function_dependencies: extractFunctionDependencies(
      nodeInput4(inputs, "era.expression.function_library.parsed")
    )
  };
}
function nodeInput4(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function validateFunctionPurityNode(inputs) {
  return {
    function_purity_report: {
      diagnostics: validateFunctionPurity(
        nodeInput5(
          inputs,
          "era.expression.function_library.parsed"
        )
      )
    }
  };
}
function nodeInput5(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function buildFunctionCallGraphNode(inputs) {
  const dependencies = nodeInput6(
    inputs,
    "era.expression.function_library.dependencies"
  );
  const purity = nodeInput6(
    inputs,
    "era.expression.function_library.purity"
  );
  return {
    function_call_graph: { dependencies, diagnostics: purity.diagnostics }
  };
}
function nodeInput6(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function rejectRecursiveFunctionsNode(inputs) {
  const graph = nodeInput7(inputs, "era.expression.function_library.call_graph");
  return {
    acyclic_function_graph: {
      dependencies: graph.dependencies,
      diagnostics: [
        ...graph.diagnostics,
        ...rejectRecursiveFunctions(graph.dependencies)
      ]
    }
  };
}
function nodeInput7(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function compileCallableFunctionsNode(inputs) {
  return {
    compiled_function_library: compileCallableFunctions(
      nodeInput8(
        inputs,
        "era.expression.function_library.parsed"
      ),
      nodeInput8(
        inputs,
        "era.expression.function_library.acyclic_graph"
      ).diagnostics
    )
  };
}
function nodeInput8(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function parseOperationsNode(inputs) {
  return {
    parsed_operations: parseOperations(
      nodeInput9(inputs, "era.expression.request.normalized")
    )
  };
}
function nodeInput9(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function initializeSequenceState(request, compiled, operations, snapshotCompiled = compiled) {
  return {
    startState: clone(request.snapshotState ?? request.initialState),
    currentState: clone(request.initialState),
    compiled,
    snapshotCompiled,
    operations,
    cursor: 0,
    randomContext: request.randomContext,
    randomDrawsConsumed: 0,
    diagnostics: [...request.diagnostics, ...compiled.diagnostics]
  };
}
function refValue(ast, state, env, allowState) {
  if (ast.path.length === 1 && ast.path[0] in env) return env[ast.path[0]];
  if (!allowState)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_FUNCTION_IMPURE", "\u51FD\u6570\u4F53\u4E0D\u80FD\u8BFB\u53D6\u5916\u90E8\u53D8\u91CF\u72B6\u6001\u3002", {
        path: ast.path.join(".")
      })
    );
  const source = ast.snapshot ? state.startState : state.currentState;
  const value = getPath(source, ast.path);
  if (typeof value !== "number" || !Number.isFinite(value))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_REFERENCE_NON_NUMERIC",
        `\u53D8\u91CF ${ast.path.join(".")} \u5FC5\u987B\u5DF2\u5B9A\u4E49\u4E3A\u6709\u9650\u6570\u5B57\u3002`,
        { path: ast.path.join(".") }
      )
    );
  return value;
}
function popValues(values, count) {
  if (count === 0) return { values, args: [] };
  if (values.length < count)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_EVALUATION_STACK", "\u8868\u8FBE\u5F0F\u6C42\u503C\u6808\u7F3A\u5C11\u5B50\u8868\u8FBE\u5F0F\u7ED3\u679C\u3002")
    );
  return { values: values.slice(0, -count), args: values.slice(-count) };
}
function inlineCustomAst(ast, bindings, library) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref") return bindings[ast.path.join(".")] ?? ast;
  if (ast.kind === "unary")
    return { ...ast, value: inlineCustomAst(ast.value, bindings, library) };
  if (ast.kind === "binary")
    return {
      ...ast,
      left: inlineCustomAst(ast.left, bindings, library),
      right: inlineCustomAst(ast.right, bindings, library)
    };
  const target = library.functions[ast.name];
  const args = ast.args.map((arg) => inlineCustomAst(arg, bindings, library));
  if (!target || !target.ast)
    return { kind: "call", name: ast.name, args, snapshot: ast.snapshot };
  const childBindings = Object.fromEntries(
    target.params.map((param, index) => [param, args[index]])
  );
  return inlineCustomAst(target.ast, childBindings, library);
}
function mathText(ast) {
  if (ast.kind === "literal")
    return Number.isInteger(ast.value) ? `${ast.value}` : `${ast.value}`;
  if (ast.kind === "ref") return ast.path.join("_");
  if (ast.kind === "unary") return `(${ast.op}${mathText(ast.value)})`;
  if (ast.kind === "binary")
    return `(${mathText(ast.left)} ${ast.op} ${mathText(ast.right)})`;
  const names = {
    ln: "log",
    pow: "pow",
    mod: "mod"
  };
  return `${names[ast.name] ?? ast.name}(${ast.args.map(mathText).join(",")})`;
}
function createAstFrameState(sequence, ast, env = {}, allowState = true, library = sequence.compiled) {
  return {
    sequence,
    stack: [{ kind: "eval", ast, env, allowState, library }],
    values: [],
    automaticRandomDrawCursor: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    done: false,
    result: null,
    diagnostics: []
  };
}
function complete(state) {
  if (state.stack.length === 0 && state.values.length === 1)
    return { ...state, done: true, result: state.values[0] };
  return { ...state, done: false, result: null };
}
function astFrameRoute(state) {
  const top = state.stack[state.stack.length - 1];
  if (!top) return "return";
  if (top.kind === "eval") {
    if (top.ast.kind === "literal" || top.ast.kind === "ref") return "value";
    if (top.ast.kind === "unary" || top.ast.kind === "binary")
      return "operator";
    if (top.ast.name === "random") return "random";
    if (isBuiltin(top.ast.name)) return "builtin";
    return "custom";
  }
  if (top.kind === "unary" || top.kind === "binary") return "operator";
  if (top.kind === "builtin" || top.kind === "calculus") return "builtin";
  if (top.kind === "random") return "random";
  if (top.kind === "custom") return "custom";
  return "return";
}
function evaluateFunctionAt(library, name, input) {
  const target = library.functions[name];
  if (!target || !target.ast || target.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name} \u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: name }
      )
    );
  const sequence = {
    startState: {},
    currentState: {},
    compiled: library,
    snapshotCompiled: library,
    operations: [],
    cursor: 0,
    randomContext: null,
    randomDrawsConsumed: 0,
    diagnostics: []
  };
  let frame = createAstFrameState(
    sequence,
    target.ast,
    { [target.params[0]]: input },
    false
  );
  while (!frame.done) frame = advanceAstFrame(frame);
  if (frame.diagnostics.length > 0 || frame.result === null)
    throw new ExpressionFailure(
      frame.diagnostics[0] ?? diagnostic("ERA_EXPR_CALCULUS_EVALUATE", `\u51FD\u6570 ${name} \u65E0\u6CD5\u6C42\u503C\u3002`, {
        path: name
      })
    );
  return frame.result;
}
function calculateCalculus(name, target, args, library) {
  const functionDef = library.functions[target];
  if (!functionDef || !functionDef.ast || functionDef.params.length !== 1)
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_TARGET",
        `${name} \u53EA\u63A5\u53D7\u5DF2\u5B9A\u4E49\u7684\u4E00\u5143\u7EAF\u51FD\u6570\u3002`,
        { path: target }
      )
    );
  if (library.randomFunctions.includes(target))
    throw new ExpressionFailure(
      diagnostic(
        "ERA_EXPR_CALCULUS_RANDOM_FORBIDDEN",
        `${name} \u4E0D\u80FD\u4EE5\u76F4\u63A5\u6216\u95F4\u63A5\u8C03\u7528 random \u7684\u51FD\u6570\u4E3A\u76EE\u6807\u3002`,
        { path: target }
      )
    );
  if (name === "derivative") {
    if (args.length !== 1 && args.length !== 2)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_BUILTIN_ARITY",
          "derivative \u9700\u8981 f\u3001at \u4E0E\u53EF\u9009 order\u3002"
        )
      );
    const order = args.length === 2 ? args[1] : 1;
    if (!Number.isSafeInteger(order) || order <= 0)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_ORDER",
          "\u5BFC\u6570\u9636\u6570\u5FC5\u987B\u662F\u4EFB\u610F\u6B63\u5B89\u5168\u6574\u6570\u3002"
        )
      );
    const expanded = inlineCustomAst(functionDef.ast, {}, library);
    let derived = mathText(expanded);
    const variable = functionDef.params[0];
    try {
      for (let currentOrder = 0; currentOrder < order; currentOrder += 1) {
        const node = derivative(derived, variable);
        derived = node.toString();
        if (derived === "0") break;
      }
      const value = Number(mathEvaluate(derived, { [variable]: args[0] }));
      return finite(
        value,
        "ERA_EXPR_DERIVATIVE_NON_FINITE",
        "\u5BFC\u6570\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
      );
    } catch (error) {
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_DERIVATIVE_UNSUPPORTED",
          `\u65E0\u6CD5\u6784\u9020\u8BE5\u5BFC\u6570\uFF1A${error instanceof Error ? error.message : String(error)}\u3002`,
          { path: target }
        )
      );
    }
  }
  if (args.length !== 2)
    throw new ExpressionFailure(
      diagnostic("ERA_EXPR_BUILTIN_ARITY", "integral \u9700\u8981 f\u3001start\u3001end\u3002")
    );
  const [start, end] = args;
  if (start === end) return 0;
  const direction = start < end ? 1 : -1;
  const left = Math.min(start, end);
  const right = Math.max(start, end);
  const evaluate = (value) => evaluateFunctionAt(library, target, value);
  const simpson = (a, b, fa, fm, fb) => (b - a) / 6 * (fa + 4 * fm + fb);
  const middle = (left + right) / 2;
  const whole = simpson(
    left,
    right,
    evaluate(left),
    evaluate(middle),
    evaluate(right)
  );
  const stack = [
    {
      a: left,
      b: right,
      fa: evaluate(left),
      fm: evaluate(middle),
      fb: evaluate(right),
      whole,
      tolerance: 1e-9
    }
  ];
  let sum = 0;
  let processed = 0;
  while (stack.length > 0) {
    const segment = stack.pop();
    processed += 1;
    if (processed > 65536)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_INTEGRAL_CONVERGENCE",
          "\u79EF\u5206\u5728\u786E\u5B9A\u6027 Simpson \u8FED\u4EE3\u5185\u672A\u6536\u655B\u3002",
          { path: target }
        )
      );
    const mid = (segment.a + segment.b) / 2;
    const leftMid = (segment.a + mid) / 2;
    const rightMid = (mid + segment.b) / 2;
    const leftValue = evaluate(leftMid);
    const rightValue = evaluate(rightMid);
    const leftArea = simpson(segment.a, mid, segment.fa, leftValue, segment.fm);
    const rightArea = simpson(
      mid,
      segment.b,
      segment.fm,
      rightValue,
      segment.fb
    );
    const delta = leftArea + rightArea - segment.whole;
    if (Math.abs(delta) <= 15 * segment.tolerance) {
      sum += leftArea + rightArea + delta / 15;
      continue;
    }
    stack.push({
      a: mid,
      b: segment.b,
      fa: segment.fm,
      fm: rightValue,
      fb: segment.fb,
      whole: rightArea,
      tolerance: segment.tolerance / 2
    });
    stack.push({
      a: segment.a,
      b: mid,
      fa: segment.fa,
      fm: leftValue,
      fb: segment.fm,
      whole: leftArea,
      tolerance: segment.tolerance / 2
    });
  }
  return finite(
    direction * sum,
    "ERA_EXPR_INTEGRAL_NON_FINITE",
    "\u79EF\u5206\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
  );
}
function advanceAstFrame(state, expected) {
  if (state.done) return state;
  try {
    const actual = astFrameRoute(state);
    if (expected && actual !== expected)
      throw new ExpressionFailure(
        diagnostic(
          "ERA_EXPR_FRAME_ROUTE",
          `\u8C03\u7528\u5E27\u8DEF\u7531\u4E0D\u5339\u914D\uFF1A\u671F\u671B ${expected}\uFF0C\u5B9E\u9645 ${actual}\u3002`
        )
      );
    const stack = [...state.stack];
    const values = [...state.values];
    let automaticRandomDrawCursor = state.automaticRandomDrawCursor;
    const top = stack.pop();
    if (!top) return complete({ ...state, stack, values });
    if (top.kind === "eval") {
      if (top.ast.kind === "literal") values.push(top.ast.value);
      else if (top.ast.kind === "ref")
        values.push(refValue(top.ast, state.sequence, top.env, top.allowState));
      else if (top.ast.kind === "unary") {
        stack.push(
          { kind: "unary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.value,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "binary") {
        stack.push(
          { kind: "binary", op: top.ast.op },
          {
            kind: "eval",
            ast: top.ast.right,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          },
          {
            kind: "eval",
            ast: top.ast.left,
            env: top.env,
            allowState: top.allowState,
            library: top.library
          }
        );
      } else if (top.ast.kind === "call") {
        if (top.ast.name === "derivative" || top.ast.name === "integral") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          const targetAst = top.ast.args[0];
          if (!targetAst || targetAst.kind !== "ref" || targetAst.snapshot || targetAst.path.length !== 1)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_CALCULUS_TARGET",
                `${top.ast.name} \u7684\u9996\u53C2\u5FC5\u987B\u662F\u5DF2\u5B9A\u4E49\u51FD\u6570\u540D\u3002`
              )
            );
          stack.push({
            kind: "calculus",
            name: top.ast.name,
            target: targetAst.path[0],
            count: top.ast.args.length - 1,
            library: top.library
          });
          for (const arg of [...top.ast.args.slice(1)].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (top.ast.name === "random") {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({ kind: "random", count: top.ast.args.length });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else if (isBuiltin(top.ast.name)) {
          if (top.ast.snapshot)
            throw new ExpressionFailure(
              diagnostic(
                "ERA_EXPR_SNAPSHOT_FUNCTION_REQUIRED",
                "@ \u4EC5\u53EF\u7528\u4E8E\u81EA\u5B9A\u4E49\u51FD\u6570\u8C03\u7528\u3002"
              )
            );
          stack.push({
            kind: "builtin",
            name: top.ast.name,
            count: top.ast.args.length
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        } else {
          stack.push({
            kind: "custom",
            name: top.ast.name,
            count: top.ast.args.length,
            library: top.ast.snapshot ? state.sequence.snapshotCompiled : top.library
          });
          for (const arg of [...top.ast.args].reverse())
            stack.push({
              kind: "eval",
              ast: arg,
              env: top.env,
              allowState: top.allowState,
              library: top.library
            });
        }
      }
    } else if (top.kind === "unary") {
      const popped = popValues(values, 1);
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          top.op === "+" ? popped.args[0] : -popped.args[0],
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E00\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "binary") {
      const popped = popValues(values, 2);
      const [left, right] = popped.args;
      const result = top.op === "+" ? left + right : top.op === "-" ? left - right : top.op === "*" ? left * right : top.op === "/" ? left / right : top.op === "%" ? left % right : left ** right;
      values.splice(
        0,
        values.length,
        ...popped.values,
        finite(
          result,
          "ERA_EXPR_RESULT_NON_FINITE",
          "\u4E8C\u5143\u8FD0\u7B97\u4EA7\u751F\u4E86\u975E\u6709\u9650\u7ED3\u679C\u3002"
        )
      );
    } else if (top.kind === "builtin") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateBuiltin(top.name, popped.args)
      );
    } else if (top.kind === "random") {
      const popped = popValues(values, top.count);
      const draw = automaticRandomDrawCursor;
      if (top.count < 2) automaticRandomDrawCursor += 1;
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateRandom(popped.args, state.sequence.randomContext, draw)
      );
    } else if (top.kind === "calculus") {
      const popped = popValues(values, top.count);
      values.splice(
        0,
        values.length,
        ...popped.values,
        calculateCalculus(top.name, top.target, popped.args, top.library)
      );
    } else {
      const popped = popValues(values, top.count);
      const target = top.library.functions[top.name];
      if (!target || !target.ast)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_UNKNOWN_CALL",
            `\u672A\u77E5\u51FD\u6570 ${top.name}\u3002`,
            { path: top.name }
          )
        );
      if (target.params.length !== popped.args.length)
        throw new ExpressionFailure(
          diagnostic(
            "ERA_EXPR_FUNCTION_ARITY",
            `\u51FD\u6570 ${top.name} \u5B9E\u53C2\u6570\u4E0D\u5339\u914D\u3002`,
            { path: top.name }
          )
        );
      const env = Object.fromEntries(
        target.params.map((param, index) => [param, popped.args[index]])
      );
      values.splice(0, values.length, ...popped.values);
      stack.push({
        kind: "eval",
        ast: target.ast,
        env,
        allowState: false,
        library: top.library
      });
    }
    return complete({ ...state, stack, values, automaticRandomDrawCursor });
  } catch (error) {
    const detail = error instanceof ExpressionFailure ? error.detail : diagnostic(
      "ERA_EXPR_EVALUATION_FAILED",
      error instanceof Error ? error.message : String(error)
    );
    return {
      ...state,
      stack: [],
      done: true,
      result: null,
      diagnostics: [...state.diagnostics, detail]
    };
  }
}
function initializeRandomSequenceStateNode(inputs) {
  const request = nodeInput10(
    inputs,
    "era.expression.request.normalized"
  );
  const compiled = nodeInput10(
    inputs,
    "era.expression.function_library.compiled"
  );
  const snapshotCompiled = request.snapshotFunctionLibrary ? compileFunctionLibrary(request.snapshotFunctionLibrary) : compiled;
  return {
    sequence_state: initializeSequenceState(
      request,
      compiled,
      nodeInput10(inputs, "era.expression.operations.parsed"),
      snapshotCompiled
    )
  };
}
function nodeInput10(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function selectNextOperationNode(inputs) {
  const sequenceState = nodeInput11(
    inputs,
    "era.expression.sequence.state"
  );
  return {
    current_operation: {
      sequenceState,
      operation: sequenceState.operations[sequenceState.cursor] ?? null
    }
  };
}
function nodeInput11(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function initializeAstFramesNode(inputs) {
  const current = nodeInput12(inputs, "era.expression.operation.current");
  const ast = current.sequenceState.compiled.valid && current.operation?.ast ? current.operation.ast : { kind: "literal", value: 0 };
  return { ast_frame_state: createAstFrameState(current.sequenceState, ast) };
}
function nodeInput12(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function commitOperationResult(state, value, evaluationDiagnostics) {
  const operation = state.operations[state.cursor];
  if (!operation)
    return {
      sequenceStateNext: state,
      sequenceDone: true,
      operationExecutionResult: {
        finalState: state.currentState,
        diagnostics: state.diagnostics,
        randomDrawsConsumed: state.randomDrawsConsumed
      }
    };
  const diagnostics = [
    ...state.diagnostics,
    ...operation.diagnostics,
    ...evaluationDiagnostics
  ];
  const currentState = state.compiled.valid && operation.ast && operation.diagnostics.length === 0 && value !== null ? setPath(state.currentState, operation.path, value) : state.currentState;
  const randomDraws = state.compiled.valid && operation.ast && operation.diagnostics.length === 0 ? countAutomaticRandomDraws(
    operation.ast,
    state.compiled,
    state.snapshotCompiled
  ) : 0;
  const next = {
    ...state,
    currentState,
    cursor: state.cursor + 1,
    randomDrawsConsumed: state.randomDrawsConsumed + randomDraws,
    diagnostics
  };
  return {
    sequenceStateNext: next,
    sequenceDone: next.cursor >= next.operations.length,
    operationExecutionResult: {
      finalState: next.currentState,
      diagnostics: next.diagnostics,
      randomDrawsConsumed: next.randomDrawsConsumed
    }
  };
}
function evaluateAst(state) {
  let frame = state;
  while (!frame.done) frame = advanceAstFrame(frame);
  return { value: frame.result, diagnostics: frame.diagnostics };
}
function run(inputs) {
  const envelope = inputs["era.expression.ast_frame.state"];
  return { evaluated_expression: evaluateAst(envelope.value) };
}
function commitOperationResultNode(inputs) {
  const current = nodeInput13(
    inputs,
    "era.expression.operation.current"
  );
  const evaluated = nodeValue(nodeInput13(inputs, "era.expression.value"));
  const outcome = commitOperationResult(
    current.sequenceState,
    evaluated.value,
    evaluated.diagnostics
  );
  return {
    sequence_state_next: outcome.sequenceStateNext,
    sequence_done: outcome.sequenceDone,
    operation_execution_result: outcome.operationExecutionResult
  };
}
function nodeInput13(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function nodeValue(value) {
  if (value !== null && typeof value === "object" && "value" in value) {
    const item = value;
    return {
      value: typeof item.value === "number" ? item.value : null,
      diagnostics: Array.isArray(item.diagnostics) ? item.diagnostics : []
    };
  }
  return { value: null, diagnostics: [] };
}
function substituteSymbolic(ast, state) {
  if (ast.kind === "literal") return ast;
  if (ast.kind === "ref")
    return state[ast.path.join(".")] ?? {
      kind: "ref",
      path: ast.path,
      snapshot: true
    };
  if (ast.kind === "unary")
    return simplify({
      kind: "unary",
      op: ast.op,
      value: substituteSymbolic(ast.value, state)
    });
  if (ast.kind === "binary")
    return simplify({
      kind: "binary",
      op: ast.op,
      left: substituteSymbolic(ast.left, state),
      right: substituteSymbolic(ast.right, state)
    });
  return {
    kind: "call",
    name: ast.name,
    args: ast.args.map((arg) => substituteSymbolic(arg, state)),
    snapshot: ast.snapshot
  };
}
function literal(value) {
  return { kind: "literal", value: Object.is(value, -0) ? 0 : value };
}
function literalNumber(ast) {
  return ast.kind === "literal" ? ast.value : void 0;
}
function simplify(ast) {
  if (ast.kind === "literal" || ast.kind === "ref") return ast;
  if (ast.kind === "call") return { ...ast, args: ast.args.map(simplify) };
  if (ast.kind === "unary") {
    const value = simplify(ast.value);
    const number = literalNumber(value);
    if (number !== void 0) return literal(ast.op === "+" ? number : -number);
    if (ast.op === "+") return value;
    return { ...ast, value };
  }
  const left = simplify(ast.left);
  const right = simplify(ast.right);
  const leftNumber = literalNumber(left);
  const rightNumber = literalNumber(right);
  if (leftNumber !== void 0 && rightNumber !== void 0) {
    const result = ast.op === "+" ? leftNumber + rightNumber : ast.op === "-" ? leftNumber - rightNumber : ast.op === "*" ? leftNumber * rightNumber : ast.op === "/" ? leftNumber / rightNumber : ast.op === "%" ? leftNumber % rightNumber : leftNumber ** rightNumber;
    return Number.isFinite(result) ? literal(result) : { ...ast, left, right };
  }
  if (ast.op === "+") {
    if (rightNumber === 0) return left;
    if (leftNumber === 0) return right;
    const nested = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && nested !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const subtraction = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && subtraction !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(subtraction - rightNumber)
      });
  }
  if (ast.op === "-") {
    if (rightNumber === 0) return left;
    const nested = left.kind === "binary" && left.op === "-" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "-" && nested !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "-",
        left: left.left,
        right: literal(nested + rightNumber)
      });
    const addition = left.kind === "binary" && left.op === "+" ? literalNumber(left.right) : void 0;
    if (left.kind === "binary" && left.op === "+" && addition !== void 0 && rightNumber !== void 0)
      return simplify({
        kind: "binary",
        op: "+",
        left: left.left,
        right: literal(addition - rightNumber)
      });
  }
  if (ast.op === "*") {
    if (leftNumber === 0 || rightNumber === 0) return literal(0);
    if (leftNumber === 1) return right;
    if (rightNumber === 1) return left;
  }
  if (ast.op === "/" && rightNumber === 1) return left;
  return { ...ast, left, right };
}
function operatorPrecedence(op) {
  return op === "+" || op === "-" ? 1 : op === "*" || op === "/" || op === "%" ? 2 : 3;
}
function printAst(ast, parent = 0) {
  if (ast.kind === "literal") return `${ast.value}`;
  if (ast.kind === "ref")
    return `${ast.snapshot ? "@" : ""}${ast.path.join(".")}`;
  if (ast.kind === "call")
    return `${ast.snapshot ? "@" : ""}${ast.name}(${ast.args.map((arg) => printAst(arg)).join(", ")})`;
  if (ast.kind === "unary") {
    const own2 = 4;
    const text2 = `${ast.op}${printAst(ast.value, own2)}`;
    return own2 < parent ? `(${text2})` : text2;
  }
  const own = operatorPrecedence(ast.op);
  const text = `${printAst(ast.left, own)} ${ast.op} ${printAst(ast.right, own + (ast.op === "^" ? 0 : 1))}`;
  return own < parent ? `(${text})` : text;
}
function deriveSymbolicLayer(sequence) {
  const symbols = {};
  const tainted = /* @__PURE__ */ new Set();
  const conflicts = (left, right) => left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
  const referencesTainted = (ast) => {
    let found = false;
    walk(ast, (item) => {
      if (item.kind === "ref" && !item.snapshot && [...tainted].some((path) => conflicts(item.path.join("."), path)))
        found = true;
    });
    return found;
  };
  for (const operation of sequence.operations) {
    if (!operation.ast || operation.diagnostics.length > 0) continue;
    const path = operation.path.join(".");
    if (countAutomaticRandomDraws(
      operation.ast,
      sequence.compiled,
      sequence.snapshotCompiled
    ) > 0 || referencesTainted(operation.ast)) {
      tainted.add(path);
      for (const existing of Object.keys(symbols))
        if (conflicts(existing, path)) delete symbols[existing];
      continue;
    }
    symbols[path] = simplify(substituteSymbolic(operation.ast, symbols));
  }
  return symbols;
}
function normaliseCompaction(sequence, symbols) {
  const compressed = {};
  for (const [path, ast] of Object.entries(symbols)) {
    const before = getPath(sequence.startState, path.split("."));
    const after = getPath(sequence.currentState, path.split("."));
    if (JSON.stringify(before) !== JSON.stringify(after))
      compressed[path] = { $expr: printAst(simplify(ast)) };
  }
  return {
    status: sequence.diagnostics.length === 0 ? "ok" : sequence.cursor === 0 ? "invalid" : "partial",
    finalState: sequence.currentState,
    diagnostics: sequence.diagnostics,
    compressed,
    compactedOperations: Object.entries(compressed).map(([path, value]) => ({
      path,
      value
    })),
    randomDrawsConsumed: sequence.randomDrawsConsumed,
    nextDrawOffset: (sequence.randomContext?.drawOffset ?? 0) + sequence.randomDrawsConsumed,
    containsAutomaticRandom: sequence.operations.some(
      (operation) => operation.ast !== null && operation.diagnostics.length === 0 && countAutomaticRandomDraws(
        operation.ast,
        sequence.compiled,
        sequence.snapshotCompiled
      ) > 0
    )
  };
}
function deriveSymbolicLayerNode(inputs) {
  const sequence = nodeInput14(
    inputs,
    "era.expression.sequence.state"
  );
  const execution = nodeInput14(inputs, "era.expression.execution.result");
  return {
    symbolic_layer: deriveSymbolicLayer(completeNodeState(sequence, execution))
  };
}
function nodeInput14(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function completeNodeState(initial, execution) {
  return {
    ...initial,
    currentState: execution.finalState,
    diagnostics: execution.diagnostics,
    randomDrawsConsumed: execution.randomDrawsConsumed ?? initial.randomDrawsConsumed,
    cursor: initial.operations.length
  };
}
function guardRandomCompactionNode(inputs) {
  return {
    random_guarded_symbolic_layer: nodeInput15(
      inputs,
      "era.expression.symbolic.layer"
    )
  };
}
function nodeInput15(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function normalizeCompactionNode(inputs) {
  const sequence = nodeInput16(
    inputs,
    "era.expression.sequence.state"
  );
  const execution = nodeInput16(inputs, "era.expression.execution.result");
  return {
    expression_response: normaliseCompaction(
      completeNodeState2(sequence, execution),
      nodeInput16(inputs, "era.expression.symbolic.layer")
    )
  };
}
function nodeInput16(inputs, key) {
  const item = inputs[key];
  return item !== null && typeof item === "object" && "value" in item ? item.value : item;
}
function completeNodeState2(initial, execution) {
  return {
    ...initial,
    currentState: execution.finalState,
    diagnostics: execution.diagnostics,
    randomDrawsConsumed: execution.randomDrawsConsumed ?? initial.randomDrawsConsumed,
    cursor: initial.operations.length
  };
}
var VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v6";
var VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v3";
var VibeFlowWorkflowError = class extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === void 0 ? void 0 : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
    if (details.taskErrors) this.taskErrors = details.taskErrors;
    if (details.sourceLocation) this.sourceLocation = details.sourceLocation;
  }
};
function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details
  });
}
function throwIfAborted(signal, workflow, nodePath2 = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath: nodePath2,
    blockPath,
    cause: signal.reason
  });
}
async function awaitWithAbort(value, signal, workflow, nodePath2 = "", blockPath = "") {
  return await value;
}
function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}
function dictionary() {
  return /* @__PURE__ */ Object.create(null);
}
function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true
  });
  return target;
}
function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string" && !new RegExp(schema.pattern).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}
function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every(
    (key, index) => key === rightKeys[index] && jsonEquals(left[key], right[key])
  );
}
function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}
function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}
function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}
function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}
function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}
function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details
  });
  root.kernelLog?.(event);
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause }
    );
  }
}
function normalizeOptions(workflow, options) {
  const raw = options === void 0 ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  if (Object.hasOwn(raw, "detachedTimeoutMs")) throw vfError("VF_ASYNC_MIGRATION", "detachedTimeoutMs was removed; workflow waits for actual task cleanup", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== void 0 && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    statusStopping: raw.__vfStatusStopping,
    statusUpdate: raw.__vfStatusUpdate,
    kernelLog: raw.__vfKernelLog,
    capabilities: raw.capabilities ?? {}
  };
}
function capabilityLocation(caller) {
  return {
    nodePath: typeof caller?.nodePath === "string" ? caller.nodePath : "",
    blockPath: typeof caller?.blockPath === "string" ? caller.blockPath : ""
  };
}
function validateCapabilityInput(workflow, schemas, capabilityId, operationName, operationDescriptor, input, location) {
  const failure = validateJsonSchema(
    input,
    operationDescriptor.input_type ? schemas[operationDescriptor.input_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_INPUT",
      `capability '${capabilityId}.${operationName}' input failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
}
function validateCapabilityOutput(workflow, schemas, capabilityId, operationName, operationDescriptor, output, location) {
  const failure = validateJsonSchema(
    output,
    operationDescriptor.output_type ? schemas[operationDescriptor.output_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_OUTPUT",
      `capability '${capabilityId}.${operationName}' output failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
  return output;
}
function wrapCapabilityFailure(cause, workflow, root, capabilityId, operationName, location) {
  if (cause instanceof VibeFlowWorkflowError) throw cause;
  if (root.signal?.aborted && (cause?.name === "AbortError" || cause === root.signal.reason)) {
    throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
  }
  throw vfError(
    "VF_CAPABILITY_FAILED",
    `capability '${capabilityId}.${operationName}' failed`,
    workflow,
    { ...location, cause }
  );
}
function prepareCapabilities(workflow, descriptors, requirements, schemas, supplied, root, entryMode) {
  assertObject(
    supplied,
    "VF_CAPABILITY_MISSING",
    "options.capabilities must be an object",
    workflow
  );
  const wrapped = dictionary();
  for (const [capabilityId, operationNames] of Object.entries(requirements)) {
    const implementation = Object.prototype.hasOwnProperty.call(supplied, capabilityId) ? supplied[capabilityId] : void 0;
    if (!implementation || typeof implementation !== "object") {
      throw vfError(
        "VF_CAPABILITY_MISSING",
        `required capability '${capabilityId}' was not supplied`,
        workflow
      );
    }
    const descriptor = descriptors[capabilityId] || {};
    const capability = dictionary();
    for (const operationName of operationNames) {
      const callable = implementation[operationName];
      if (typeof callable !== "function") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `capability '${capabilityId}' is missing operation '${operationName}'`,
          workflow
        );
      }
      const operationDescriptor = descriptor.operations?.[operationName] || {};
      const completion = operationDescriptor.completion || "immediate";
      if (entryMode === "sync" && completion === "suspend") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `sync workflow cannot use suspending capability '${capabilityId}.${operationName}'`,
          workflow
        );
      }
      if (completion === "suspend") {
        setOwn(capability, operationName, (input, caller = {}) => {
          const promise = (async () => {
            const location = capabilityLocation(caller);
            const signal = caller.signal || root.signal;
            validateCapabilityInput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              input,
              location
            );
            try {
              const output = await awaitWithAbort(
                callable.call(implementation, input, { signal }),
                signal,
                workflow,
                location.nodePath,
                location.blockPath
              );
              return validateCapabilityOutput(
                workflow,
                schemas,
                capabilityId,
                operationName,
                operationDescriptor,
                output,
                location
              );
            } catch (cause) {
              return wrapCapabilityFailure(
                cause,
                workflow,
                { signal },
                capabilityId,
                operationName,
                location
              );
            }
          })();
          return caller.execution ? caller.execution.own(promise) : promise;
        });
      } else {
        setOwn(capability, operationName, (input, caller = {}) => {
          const location = capabilityLocation(caller);
          const signal = caller.signal || root.signal;
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input,
            location
          );
          try {
            const output = callable.call(
              implementation,
              input,
              { signal }
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      }
    }
    setOwn(wrapped, capabilityId, Object.freeze(capability));
  }
  return Object.freeze(wrapped);
}
var __vfMultipleInputs = /* @__PURE__ */ Symbol("native input envelopes");
function inputValues(workflow, inputs, input) {
  const values = inputs[__vfMultipleInputs]?.get(input.key);
  if (values) return values;
  if (workflow.task_input_cardinalities?.[input.type] === "all") {
    if (!Array.isArray(inputs[input.key])) throw vfError("VF_TASK_INPUT_INVALID", `all input '${input.key}' requires an array`, workflow);
    return inputs[input.key];
  }
  return [inputs[input.key]];
}
function validatePublicInputs(workflow, inputs) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input.key);
    if (input.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = inputValues(workflow, inputs, input).map((value) => validateJsonSchema(
      value,
      input.schema || workflow.schemas?.[input.type]
    )).find(Boolean);
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input.key}' failed schema validation: ${failure}`,
        workflow
      );
    }
  }
}
function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}
function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: /* @__PURE__ */ new Map(),
    activeEdges: /* @__PURE__ */ new Set(),
    lastInputs: /* @__PURE__ */ new Map(),
    taskExecutors: dictionary(),
    nodeRuns: /* @__PURE__ */ new Map(),
    stepCount: 0,
    initial
  };
}
function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}
function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input of state.workflow.inputs) {
    if (!accepted.has(input.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input.key)) continue;
    for (const value of inputValues(state.workflow, state.initial, input)) {
      state.inboxes[nodeId].push(createEnvelope(input.key, input.type, value, "pipeline.input"));
    }
  }
}
function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type);
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}
function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}
function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}
function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  for (const provider of node.provides) {
    const schema = state.workflow.schemas?.[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
  }
  return outputs;
}
function outputEnvelopes(node, outputs) {
  return node.provides.map(
    (provider) => createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}
function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node)
    );
    state.inboxes[targetId].push(envelope);
  }
}
function nodeContext(node, state, execution) {
  const allowed = dictionary();
  for (const requirement of node.capabilities || []) {
    const capability = state.root.capabilities[requirement.id];
    if (!capability) continue;
    const contextual = dictionary();
    const requested = new Set(requirement.operations || []);
    for (const [operationName, operation] of Object.entries(capability)) {
      if (requested.size && !requested.has(operationName)) continue;
      setOwn(contextual, operationName, (input) => {
        if (execution && !execution.active) throw vfError("VF_NODE_CONTEXT_EXITED", "Node invocation has exited", state.workflow);
        return operation(input, {
          nodePath: nodePath(state, node.id),
          blockPath: formatBlockPath(state.path),
          signal: execution?.signal || state.root.signal,
          execution
        });
      });
    }
    setOwn(allowed, requirement.id, Object.freeze(contextual));
  }
  return Object.freeze({
    signal: execution?.signal || state.root.signal,
    get tasks() {
      if (node.flow_kind !== "task_manager") throw vfError("VF_TASK_CONTROL_FORBIDDEN", "only task_manager nodes have a task controller", state.workflow, { nodePath: nodePath(state, node.id) });
      return taskController(node, state, execution);
    },
    capabilities: Object.freeze(allowed),
    updateInfo(info) {
      state.root.statusUpdate?.(info);
    },
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details
      });
    }
  });
}
function invokeStaticImplementationSync(implementation, node, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const execution = new NodeExecution(state.root.signal);
  try {
    const outputs = implementation(inputs, node.params, nodeContext(node, state, execution));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      cause.sourceLocation ||= { path: node.source?.ref || "", symbol: node.source?.export || "" };
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted && (cause?.name === "AbortError" || cause === state.root.signal.reason)) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause }
    );
  } finally {
    execution.exitSync();
  }
}
function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
  return inputs;
}
function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
}
function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}
function rawInputsForChild(inputSpecs, inputs, workflow, nodeId) {
  const items = [];
  for (const value of Object.values(inputs)) {
    if (Array.isArray(value)) items.push(...value);
    else if (value) items.push(value);
  }
  const initial = dictionary();
  const multiple = /* @__PURE__ */ new Map();
  for (const input of inputSpecs) {
    const matches = items.filter((item) => item?.type === input.type);
    if (matches.length) {
      setOwn(initial, input.key, matches[0].value);
      multiple.set(input.key, matches.map((item) => item.value));
    } else if (input.required) {
      throw vfError(
        "VF_INPUT_REQUIRED",
        `composite node '${nodeId}' cannot supply required body input '${input.key}'`,
        workflow
      );
    }
  }
  Object.defineProperty(initial, __vfMultipleInputs, { value: multiple });
  return initial;
}
function outputsFromChild(node, mappings, childResult, state) {
  const outputs = dictionary();
  for (const mapping of mappings) {
    if (!Object.prototype.hasOwnProperty.call(childResult.publicOutputs, mapping.alias)) {
      throw vfError(
        "VF_OUTPUT_CARDINALITY",
        `composite node '${node.id}' body omitted optional output '${mapping.alias}' required by provider '${mapping.provider}'`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
    setOwn(outputs, mapping.provider, childResult.publicOutputs[mapping.alias]);
  }
  return validateNodeOutputs(node, outputs, state);
}
function valueFromEnvelope(value) {
  if (value && typeof value === "object" && "value" in value && "type" in value) {
    return value.value;
  }
  return value;
}
function resultValues(child) {
  const values = dictionary();
  for (const [key, value] of Object.entries(child.publicOutputs)) setOwn(values, key, value);
  for (const [type, candidates] of child.candidates) {
    if (candidates.length === 1) setOwn(values, type, candidates[0].value);
  }
  return values;
}
function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = state.candidates.get(spec.type) || [];
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.workflow.schemas?.[spec.type];
    const values = spec.cardinality === "all" ? matches.map((item) => item.value) : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow
        );
      }
    }
  }
  return output;
}
function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
function runtimePluginError(code, descriptor, hook, cause, workflow, location = {}) {
  const suffix = hook ? ` hook '${hook}'` : "";
  return vfError(
    code,
    `runtime plugin '${descriptor.id}'${suffix} failed`,
    workflow,
    {
      nodePath: location.nodePath || "",
      blockPath: location.blockPath || "/",
      cause
    }
  );
}
function runtimePluginContext(workflow, descriptor, root) {
  return Object.freeze({
    abiVersion: VIBEFLOW_PLUGIN_ABI,
    pluginId: descriptor.id,
    pluginType: "runtime",
    target: descriptor.target,
    workflowId: workflow.workflow_id,
    config: deepFreeze(descriptor.config || {}),
    signal: root.signal
  });
}
function runtimePluginSummary(root, details = {}) {
  return deepFreeze({
    workflowId: root.workflowId,
    entryMode: root.workflow.entry_mode,
    ...details
  });
}
function createRuntimePluginsSync(workflow, descriptors, factories, root) {
  const records = [];
  try {
    for (const descriptor of descriptors) {
      const factory = factories[descriptor.factory_index];
      if (typeof factory !== "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("plugin module does not export createPlugin()"),
          workflow
        );
      }
      let instance;
      try {
        instance = factory(runtimePluginContext(workflow, descriptor, root));
      } catch (cause) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          cause,
          workflow
        );
      }
      if (!instance || typeof instance !== "object" || Array.isArray(instance)) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("createPlugin() must return a RuntimePlugin object"),
          workflow
        );
      }
      records.push({ descriptor, instance });
    }
    return records;
  } catch (failure) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      try {
        records[index].instance.dispose?.();
      } catch (error) {
        (failure.cleanupErrors ||= []).push(runtimePluginError("VF_RUNTIME_PLUGIN_DISPOSE", records[index].descriptor, "dispose", error, workflow));
      }
    }
    throw failure;
  }
}
function invokeRuntimeHookSync(root, hook, details = {}, preserveFailure = false) {
  const summary = runtimePluginSummary(root, details);
  for (const record of root.runtimePlugins) {
    const callback = record.instance[hook];
    if (typeof callback !== "function") continue;
    try {
      callback(summary);
    } catch (cause) {
      if (preserveFailure) {
        (root.cleanupErrors ||= []).push(runtimePluginError("VF_RUNTIME_PLUGIN_HOOK", record.descriptor, hook, cause, root.workflow, summary));
        continue;
      }
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_HOOK",
        record.descriptor,
        hook,
        cause,
        root.workflow,
        summary
      );
    }
  }
}
function disposeRuntimePluginsSync(root, preserveFailure = false) {
  let firstFailure;
  for (let index = root.runtimePlugins.length - 1; index >= 0; index--) {
    const record = root.runtimePlugins[index];
    try {
      record.instance.dispose?.();
    } catch (cause) {
      const error = runtimePluginError("VF_RUNTIME_PLUGIN_DISPOSE", record.descriptor, "dispose", cause, root.workflow);
      if (preserveFailure) (root.cleanupErrors ||= []).push(error);
      else if (firstFailure) (firstFailure.cleanupErrors ||= []).push(error);
      else firstFailure = error;
    }
  }
  root.runtimePlugins.length = 0;
  if (firstFailure) throw firstFailure;
}
function createRoot(workflow, normalized) {
  const root = {
    workflow,
    workflowId: workflow.workflow_id,
    signal: normalized.signal || new AbortController().signal,
    traceMode: normalized.traceMode,
    onTrace: normalized.onTrace,
    statusStopping: normalized.statusStopping,
    statusUpdate: normalized.statusUpdate,
    kernelLog: normalized.kernelLog,
    capabilities: {},
    taskRegistry: new TaskRegistry(),
    runtimePlugins: []
  };
  const onAbort = () => {
    try {
      root.statusStopping?.();
    } catch (error) {
      root.observationFailure ||= error;
    }
  };
  root.signal.addEventListener("abort", onAbort, { once: true });
  root.unsubscribeSignal = () => root.signal.removeEventListener("abort", onAbort);
  return root;
}
function prepareWorkflowInvocation(workflow, descriptors, requirements, schemas, options, entryMode) {
  let normalized;
  try {
    normalized = normalizeOptions(workflow, options);
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
  const root = createRoot(workflow, normalized);
  try {
    throwIfAborted(root.signal, workflow);
    root.capabilities = prepareCapabilities(
      workflow,
      descriptors,
      requirements,
      schemas,
      normalized.capabilities,
      root,
      entryMode
    );
    emitTrace(root, "run_start", {}, true);
    return root;
  } catch (cause) {
    root.unsubscribeSignal();
    throw ensureErrorLocation(cause, workflow, []);
  }
}
function assertWorkflowAbi(workflow) {
  if (workflow.abi_version !== VIBEFLOW_WORKFLOW_ABI) {
    throw vfError(
      "VF_INTERNAL",
      `generated workflow ABI '${workflow.abi_version}' is unsupported`,
      workflow
    );
  }
}
function createStaticWorkflowSync(workflowMetadata, capabilityDescriptors, capabilityRequirements, schemaCatalog, runtimePluginDescriptors, runtimePluginFactories, executeRoot) {
  const workflow = deepFreeze(workflowMetadata);
  const descriptors = deepFreeze(capabilityDescriptors);
  const requirements = deepFreeze(capabilityRequirements);
  const schemas = deepFreeze(schemaCatalog);
  const plugins = deepFreeze(runtimePluginDescriptors);
  assertWorkflowAbi(workflow);
  return function invokeWorkflow(inputs, options) {
    const root = prepareWorkflowInvocation(
      workflow,
      descriptors,
      requirements,
      schemas,
      options,
      "sync"
    );
    let failed = false;
    let primaryFailure;
    try {
      root.runtimePlugins = createRuntimePluginsSync(
        workflow,
        plugins,
        runtimePluginFactories,
        root
      );
      invokeRuntimeHookSync(root, "beforeRun", {
        inputKeys: Object.keys(inputs || {}).sort()
      });
      const result = executeRoot(inputs, root, []);
      throwIfAborted(root.signal, workflow);
      invokeRuntimeHookSync(root, "afterRun", {
        outputKeys: Object.keys(result.publicOutputs || {}).sort()
      });
      emitTrace(root, "run_end", {}, true);
      return result.publicOutputs;
    } catch (cause) {
      failed = true;
      const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
      primaryFailure = failure;
      if (failure.code !== "VF_TRACE_SINK_FAILED") {
        try {
          emitTrace(root, "run_failed", {
            code: failure.code,
            message: failure.message
          }, true);
        } catch {
        }
      }
      invokeRuntimeHookSync(root, "runFailed", {
        code: failure.code,
        message: failure.message
      }, true);
      throw ensureErrorLocation(failure, workflow, []);
    } finally {
      try {
        disposeRuntimePluginsSync(root, failed);
      } finally {
        if (primaryFailure && root.cleanupErrors?.length) (primaryFailure.cleanupErrors ||= []).push(...root.cleanupErrors);
        root.unsubscribeSignal();
      }
    }
  };
}
function __vfSnapshotInfo(info) {
  const active = /* @__PURE__ */ new Set();
  function copy(value) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || active.has(value)) throw new TypeError("run info must contain JSON values");
    const array = Array.isArray(value);
    if (!array && ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
      throw new TypeError("run info must contain plain JSON objects");
    }
    active.add(value);
    let result;
    if (array) {
      result = Array.from(value, (item) => copy(item));
    } else {
      result = Object.fromEntries(Object.entries(value).map(([key, item]) => [key, copy(item)]));
    }
    active.delete(value);
    return Object.freeze(result);
  }
  if (!Array.isArray(info) || info.some((item) => !item || typeof item !== "object" || Array.isArray(item))) {
    throw new TypeError("run info must be an array of JSON objects");
  }
  return copy(info);
}
function __vfObservation(options) {
  const raw = options ?? {};
  const interval = raw.statusIntervalMs ?? 6e4;
  if (!Number.isFinite(interval) || interval <= 0) throw new TypeError("statusIntervalMs must be positive finite milliseconds");
  if (raw.onStatus !== void 0 && typeof raw.onStatus !== "function") throw new TypeError("onStatus must be a function");
  let info = Object.freeze([]);
  let state = "starting";
  let error = null;
  let closed = false;
  let timer;
  let sink;
  const record = () => Object.freeze({ state, error, updated_at: (/* @__PURE__ */ new Date()).toISOString(), info });
  const publish = () => {
    const snapshot = record();
    sink?.publish(snapshot);
    raw.onStatus?.(snapshot);
  };
  const observer = {
    updateInfo(value) {
      if (closed) throw new Error("cannot update info after the run has finished");
      info = __vfSnapshotInfo(value);
      sink?.cache(record());
    },
    kernel(event) {
      sink?.kernel(JSON.stringify(event));
    },
    run(callback) {
      return sink ? sink.run(callback) : callback();
    },
    running() {
      if (state === "running" || closed) return;
      state = "running";
      publish();
    },
    stopping() {
      if (closed || state === "stopping") return;
      state = "stopping";
      publish();
    },
    start(running = true) {
      if (typeof __vfCreateFileObservation === "function") {
        sink = __vfCreateFileObservation(raw, record(), interval);
      }
      publish();
      if (running) observer.running();
      if (raw.onStatus) {
        timer = setInterval(() => {
          try {
            raw.onStatus(record());
          } catch (failure) {
            try {
              observer.finish(failure);
            } catch {
            }
            throw failure;
          }
        }, interval);
        timer.unref?.();
      }
    },
    finish(failure) {
      if (closed) return;
      if (timer) clearInterval(timer);
      state = failure ? "failed" : "succeeded";
      if (failure) {
        const messages = [];
        const seen = /* @__PURE__ */ new Set();
        for (let cause = failure; cause && !seen.has(cause); cause = cause.cause) {
          seen.add(cause);
          messages.push(String(cause.message || cause));
        }
        error = messages.join(": ");
      } else error = null;
      if (failure) sink?.kernel(String(failure.stack || failure));
      closed = true;
      try {
        sink?.finish(record());
        raw.onStatus?.(record());
      } catch (cause) {
        if (!failure) {
          state = "failed";
          error = String(cause?.message || cause);
          try {
            sink?.finish(record());
          } catch {
          }
        }
        throw cause;
      } finally {
        sink?.close();
      }
    }
  };
  return observer;
}
function __vfObservedOptions(options, observer) {
  return {
    ...options ?? {},
    __vfStatusUpdate: (info) => observer.updateInfo(info),
    __vfKernelLog: (event) => observer.kernel(event),
    __vfStatusStopping: () => observer.stopping()
  };
}
function __vfObserveSync(invoke, inputs, options) {
  if (options !== void 0 && (!options || typeof options !== "object" || Array.isArray(options))) return invoke(inputs, options);
  if (options?.__vfParentObservation) {
    const observer2 = options.__vfParentObservation;
    return observer2.run(() => invoke(inputs, __vfObservedOptions(options, observer2)));
  }
  const observer = __vfObservation(options);
  try {
    observer.start();
    const outputs = observer.run(() => invoke(inputs, __vfObservedOptions(options, observer)));
    observer.finish(null);
    return outputs;
  } catch (error) {
    try {
      observer.finish(error);
    } catch {
    }
    throw error;
  }
}
function taskErrorData(error, fallbackPath, seen = /* @__PURE__ */ new Set()) {
  if (error && typeof error === "object") {
    if (seen.has(error)) return {
      code: String(error.code || "VF_NODE_FAILED"),
      message: String(error.message || error),
      node_path: String(error.nodePath || fallbackPath),
      source_location: error.sourceLocation || {}
    };
    seen.add(error);
  }
  const cause = error?.cause;
  return {
    code: String(error?.code || "VF_NODE_FAILED"),
    message: String(cause?.message || error?.message || error),
    node_path: String(error?.nodePath || fallbackPath),
    source_location: error?.sourceLocation || {},
    exception_type: String(cause?.name || error?.name || typeof error),
    stack: String(cause?.stack || error?.stack || ""),
    ...cause !== void 0 ? { cause: taskErrorData(cause, fallbackPath, seen) } : {},
    ...Array.isArray(error?.errors) ? { errors: error.errors.map((item) => taskErrorData(item, fallbackPath, seen)) } : {},
    ...error?.taskErrors ? { task_errors: error.taskErrors } : {},
    ...error?.cleanupErrors?.length ? { cleanup_errors: error.cleanupErrors.map((item) => taskErrorData(item, fallbackPath, seen)) } : {}
  };
}
var TaskRegistry = class {
  constructor() {
    this.runId = globalThis.crypto?.randomUUID?.() || Array.from(
      globalThis.crypto?.getRandomValues(new Uint8Array(16)) || Uint8Array.from({ length: 16 }, () => Math.floor(Math.random() * 256)),
      (value) => value.toString(16).padStart(2, "0")
    ).join("");
    this.nextId = 0;
    this.nextExit = 0;
    this.closing = false;
    this.records = /* @__PURE__ */ new Map();
  }
  select(refs, workflow) {
    if (!Array.isArray(refs)) throw vfError("VF_TASK_REF_INVALID", "task references must be an array", workflow);
    const seen = /* @__PURE__ */ new Set();
    return refs.map((ref) => {
      if (!ref || ref.run_id !== this.runId || !this.records.has(ref.task_id))
        throw vfError("VF_TASK_REF_INVALID", "unknown, consumed or foreign workflow task reference", workflow);
      return this.records.get(ref.task_id);
    }).filter((record) => !seen.has(record.ref.task_id) && seen.add(record.ref.task_id));
  }
  stop(records, reason = "task stop requested") {
    return records.map((record) => {
      if (record.phase === "exited") return { task: record.ref, state: "already_exited" };
      record.phase = "stopping";
      record.controller.abort(reason);
      return { task: record.ref, state: "stop_requested" };
    });
  }
  async drain(parent, workflow) {
    const children = [...this.records.values()].filter((record) => record.parent === parent);
    this.stop(children);
    await Promise.allSettled(children.map((record) => record.promise));
    const failures = children.filter((record) => record.outcome.status === "failed" && !record.observed);
    const failed = failures[0];
    for (const record of children) {
      record.observed = true;
      this.records.delete(record.ref.task_id);
    }
    if (failed) {
      throw vfError(
        "VF_TASK_UNOBSERVED",
        failed.outcome.error.message,
        workflow,
        { nodePath: failed.outcome.error.node_path, taskErrors: failures.map((record) => record.outcome) }
      );
    }
  }
  deliver(records, workflow) {
    if (records.some((record) => this.records.get(record.ref.task_id) !== record))
      throw vfError("VF_TASK_REF_INVALID", "task result was already consumed", workflow);
    const outcomes = records.map((record) => record.outcome);
    for (const record of records) {
      record.observed = true;
      this.records.delete(record.ref.task_id);
    }
    return outcomes;
  }
  async finish(root) {
    this.closing = true;
    let statusFailure;
    if ([...this.records.values()].some((record) => !record.outcome)) {
      try {
        root.statusStopping?.();
      } catch (error) {
        statusFailure = error;
      }
    }
    await this.drain(null, root.workflow);
    if (statusFailure) throw statusFailure;
  }
  start(key, inputs, node, state) {
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    if (this.closing) throw vfError("VF_ABORTED", "workflow is stopping", state.workflow);
    const targets = state.taskExecutors[node.id];
    const execute = typeof key === "string" && targets && Object.hasOwn(targets, key) ? targets[key] : null;
    if (!execute) throw vfError("VF_TASK_TARGET_UNKNOWN", `undeclared task target '${key}'`, state.workflow);
    if (!inputs || typeof inputs !== "object" || Array.isArray(inputs)) throw vfError("VF_TASK_INPUT_INVALID", "task inputs must be an object", state.workflow);
    const controller = new AbortController();
    const parentSignal = state.root.signal;
    let record;
    const abort = () => {
      if (record && !record.outcome) record.phase = "stopping";
      controller.abort(parentSignal.reason);
    };
    parentSignal.addEventListener("abort", abort, { once: true });
    const ref = Object.freeze({ run_id: this.runId, task_id: String(++this.nextId) });
    record = {
      ref,
      controller,
      parent: state.root.currentTask?.ref.task_id ?? null,
      promise: null,
      outcome: null,
      observed: false,
      exitOrder: 0,
      phase: "running"
    };
    this.records.set(ref.task_id, record);
    record.promise = (async () => {
      let output;
      let failure;
      const root = { ...state.root, signal: controller.signal, currentTask: record };
      try {
        await Promise.resolve();
        throwIfAborted(controller.signal, state.workflow);
        const result = await execute(inputs, root, [...state.path, node.id, "tasks", key, `task_${ref.task_id}`]);
        output = result.publicOutputs;
      } catch (error) {
        failure = error;
      }
      try {
        await this.drain(ref.task_id, state.workflow);
      } catch (error) {
        if (failure) (failure.cleanupErrors ||= []).push(error);
        else failure = error;
      }
      parentSignal.removeEventListener("abort", abort);
      record.controller = null;
      record.phase = "exited";
      const status = failure ? failure.code === "VF_ABORTED" && !failure.cleanupErrors?.length ? "cancelled" : "failed" : "succeeded";
      let outcome = Object.freeze({
        task: ref,
        status,
        ...status === "succeeded" ? { outputs: output } : { error: taskErrorData(failure, nodePath(state, node.id)) }
      });
      record.exitOrder = ++this.nextExit;
      try {
        emitTrace(state.root, "task_exited", { task: ref, status, managerNode: node.id, nodePath: nodePath(state, node.id), blockPath: formatBlockPath(state.path) });
      } catch (error) {
        outcome = Object.freeze({ task: ref, status: "failed", error: {
          code: error.code,
          message: error.message,
          node_path: error.nodePath || nodePath(state, node.id)
        } });
      }
      record.outcome = outcome;
      return record.outcome;
    })();
    emitTrace(state.root, "task_started", { task: ref, managerNode: node.id, key, nodePath: nodePath(state, node.id), blockPath: formatBlockPath(state.path) });
    return ref;
  }
};
function taskController(node, state, execution) {
  const assertActive = (starting = false) => {
    if (execution && !execution.active) throw vfError("VF_TASK_CONTEXT_EXITED", "task controller's Node invocation has exited", state.workflow);
    if (starting && execution?.stopping) throw vfError("VF_ABORTED", "Node invocation is stopping", state.workflow);
  };
  const registry = state.root.taskRegistry;
  return Object.freeze({
    start: (key, inputs = {}) => {
      assertActive(true);
      return registry.start(key, inputs, node, state);
    },
    requestStop: (refs, reason) => {
      assertActive();
      return registry.stop(registry.select(refs, state.workflow), reason);
    },
    waitAny(refs) {
      assertActive();
      const waiting = (async () => {
        const records = registry.select(refs, state.workflow);
        if (!records.length) return null;
        const ready = records.filter((record2) => record2.outcome).sort((a, b) => a.exitOrder - b.exitOrder);
        const result = ready.length ? ready[0].outcome : await waitTaskNotification(
          Promise.race(records.map((record2) => record2.promise)),
          execution?.signal || state.root.signal,
          state.workflow
        );
        const record = records.find((record2) => record2.ref.task_id === result.task.task_id);
        return registry.deliver([record], state.workflow)[0];
      })();
      return execution ? execution.own(waiting) : waiting;
    },
    waitAllExited(refs) {
      assertActive();
      const waiting = (async () => {
        const records = registry.select(refs, state.workflow);
        await Promise.all(records.map((record) => record.promise));
        return registry.deliver(records, state.workflow);
      })();
      return execution ? execution.own(waiting) : waiting;
    }
  });
}
async function waitTaskNotification(value, signal, workflow) {
  throwIfAborted(signal, workflow);
  let onAbort;
  const cancelled = new Promise((_, reject) => {
    onAbort = () => reject(vfError("VF_ABORTED", "task observer cancelled", workflow));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([value, cancelled]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}
var NodeExecution = class {
  constructor(parentSignal) {
    this.controller = new AbortController();
    this.signal = this.controller.signal;
    this.operations = /* @__PURE__ */ new Set();
    this.active = true;
    this.stopping = false;
    this.parentSignal = parentSignal;
    this.abort = () => this.controller.abort(parentSignal.reason);
    parentSignal.addEventListener("abort", this.abort, { once: true });
    if (parentSignal.aborted) this.abort();
  }
  own(promise) {
    this.operations.add(promise);
    promise.then(() => this.operations.delete(promise), () => this.operations.delete(promise));
    return promise;
  }
  exitSync() {
    this.stopping = true;
    this.controller.abort("Node exiting");
    this.active = false;
    this.parentSignal.removeEventListener("abort", this.abort);
  }
  async exit() {
    this.stopping = true;
    this.controller.abort("Node exiting");
    const failures = [];
    try {
      while (this.operations.size) {
        const outcomes = await Promise.allSettled([...this.operations]);
        for (const outcome of outcomes) {
          if (outcome.status === "rejected" && (outcome.reason?.code !== "VF_ABORTED" || outcome.reason?.cleanupErrors?.length))
            failures.push(outcome.reason);
        }
      }
    } finally {
      this.active = false;
      this.parentSignal.removeEventListener("abort", this.abort);
      this.operations.clear();
    }
    if (failures.length) {
      const first = failures[0];
      if (failures.length > 1) (first.cleanupErrors ||= []).push(...failures.slice(1));
      throw first;
    }
  }
};
var __vfRuntimePluginDescriptors = [];
var __vfRuntimePluginFactories = [];
var __vf_workflow_2_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v6","entry_mode":"sync","inputs":[{"key":"sequence_state","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.expression.sequence.state"}],"kind":"loop","max_steps":8,"outputs":[{"as":"sequenceStateNext","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.expression.sequence.state"},{"as":"sequenceDone","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"type":"era.expression.sequence.done"},{"as":"operationExecutionResult","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.expression.execution.result"}],"schemas":{"era.expression.ast_frame.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.execution.result":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.acyclic_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.call_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.compiled":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.dependencies":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.function_library.purity":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operation.current":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operations.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.request":{"$schema":"https://json-schema.org/draft/2020-12/schema"},"era.expression.request.normalized":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"compactedOperations":{"type":"array"},"containsAutomaticRandom":{"type":"boolean"},"diagnostics":{"type":"array"},"finalState":{"type":"object"},"nextDrawOffset":{"minimum":0,"type":"integer"},"randomDrawsConsumed":{"minimum":0,"type":"integer"}},"required":["finalState","diagnostics","compactedOperations","randomDrawsConsumed","nextDrawOffset","containsAutomaticRandom"],"type":"object"},"era.expression.sequence.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.expression.sequence.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.symbolic.layer":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.value":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"task_input_cardinalities":{},"workflow_id":"era.expression.execute_layer.operation_loop"}'));
var __vf_w2_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"terminal","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts"},"type_used":"era.expression.terminal"}'));
var __vf_w2_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"select_next_operation","params":{"_global":{}},"provides":[{"key":"current_operation","type":"era.expression.operation.current"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.sequence.state"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/select_next_operation.ts"},"type_used":"era.expression.select_next_operation"}'));
var __vf_w2_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"initialize_ast_frames","params":{"_global":{}},"provides":[{"key":"ast_frame_state","type":"era.expression.ast_frame.state"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.operation.current"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/execution/initialize_ast_frames.ts"},"type_used":"era.expression.initialize_ast_frames"}'));
var __vf_w2_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"evaluate_ast","params":{"_global":{}},"provides":[{"key":"evaluated_expression","type":"era.expression.value"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.ast_frame.state"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/execution/evaluate_ast.ts"},"type_used":"era.expression.evaluate_ast"}'));
var __vf_w2_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"commit_operation_result","params":{"_global":{}},"provides":[{"key":"sequence_state_next","type":"era.expression.sequence.state"},{"key":"sequence_done","type":"era.expression.sequence.done"},{"key":"operation_execution_result","type":"era.expression.execution.result"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.operation.current"},{"cardinality":"exactly_one","type":"era.expression.value"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/execution/commit_operation_result.ts"},"type_used":"era.expression.commit_operation_result"}'));
var __vf_w2_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"terminal","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts"},"type_used":"era.expression.terminal"}'));
var __vf_workflow_1_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v6","entry_mode":"sync","inputs":[{"key":"expression_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema"},"type":"era.expression.request"}],"kind":"nodeset","max_steps":19,"outputs":[{"as":"expressionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"compactedOperations":{"type":"array"},"containsAutomaticRandom":{"type":"boolean"},"diagnostics":{"type":"array"},"finalState":{"type":"object"},"nextDrawOffset":{"minimum":0,"type":"integer"},"randomDrawsConsumed":{"minimum":0,"type":"integer"}},"required":["finalState","diagnostics","compactedOperations","randomDrawsConsumed","nextDrawOffset","containsAutomaticRandom"],"type":"object"},"type":"era.expression.response"}],"schemas":{"era.expression.ast_frame.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.execution.result":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.acyclic_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.call_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.compiled":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.dependencies":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.function_library.purity":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operation.current":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operations.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.request":{"$schema":"https://json-schema.org/draft/2020-12/schema"},"era.expression.request.normalized":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"compactedOperations":{"type":"array"},"containsAutomaticRandom":{"type":"boolean"},"diagnostics":{"type":"array"},"finalState":{"type":"object"},"nextDrawOffset":{"minimum":0,"type":"integer"},"randomDrawsConsumed":{"minimum":0,"type":"integer"}},"required":["finalState","diagnostics","compactedOperations","randomDrawsConsumed","nextDrawOffset","containsAutomaticRandom"],"type":"object"},"era.expression.sequence.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.expression.sequence.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.symbolic.layer":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.value":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"task_input_cardinalities":{},"workflow_id":"era.expression.execute_layer"}'));
var __vf_w1_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"terminal","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts"},"type_used":"era.expression.terminal"}'));
var __vf_w1_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"validate_request","params":{"_global":{}},"provides":[{"key":"normalized_expression_request","type":"era.expression.request.normalized"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.request"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/validate_request.ts"},"type_used":"era.expression.validate_request"}'));
var __vf_w1_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"validate_random_context","params":{"_global":{}},"provides":[{"key":"validated_random_request","type":"era.expression.request.normalized"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.request.normalized"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/validate_random_context.ts"},"type_used":"era.expression.validate_random_context"}'));
var __vf_w1_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"parse_function_definitions","params":{"_global":{}},"provides":[{"key":"parsed_function_library","type":"era.expression.function_library.parsed"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.request.normalized"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/parse_function_definitions.ts"},"type_used":"era.expression.parse_function_definitions"}'));
var __vf_w1_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"extract_function_dependencies","params":{"_global":{}},"provides":[{"key":"function_dependencies","type":"era.expression.function_library.dependencies"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.function_library.parsed"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/extract_function_dependencies.ts"},"type_used":"era.expression.extract_function_dependencies"}'));
var __vf_w1_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"validate_function_purity","params":{"_global":{}},"provides":[{"key":"function_purity_report","type":"era.expression.function_library.purity"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.function_library.parsed"},{"cardinality":"exactly_one","type":"era.expression.function_library.dependencies"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/validate_function_purity.ts"},"type_used":"era.expression.validate_function_purity"}'));
var __vf_w1_n6 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"build_function_call_graph","params":{"_global":{}},"provides":[{"key":"function_call_graph","type":"era.expression.function_library.call_graph"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.function_library.dependencies"},{"cardinality":"exactly_one","type":"era.expression.function_library.purity"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/build_function_call_graph.ts"},"type_used":"era.expression.build_function_call_graph"}'));
var __vf_w1_n7 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"reject_recursive_functions","params":{"_global":{}},"provides":[{"key":"acyclic_function_graph","type":"era.expression.function_library.acyclic_graph"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.function_library.call_graph"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/reject_recursive_functions.ts"},"type_used":"era.expression.reject_recursive_functions"}'));
var __vf_w1_n8 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"compile_callable_functions","params":{"_global":{}},"provides":[{"key":"compiled_function_library","type":"era.expression.function_library.compiled"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.function_library.parsed"},{"cardinality":"exactly_one","type":"era.expression.function_library.acyclic_graph"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/compile_callable_functions.ts"},"type_used":"era.expression.compile_callable_functions"}'));
var __vf_w1_n9 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"parse_operations","params":{"_global":{}},"provides":[{"key":"parsed_operations","type":"era.expression.operations.parsed"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.request.normalized"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/parse_operations.ts"},"type_used":"era.expression.parse_operations"}'));
var __vf_w1_n10 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"initialize_sequence_state","params":{"_global":{}},"provides":[{"key":"sequence_state","type":"era.expression.sequence.state"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.request.normalized"},{"cardinality":"exactly_one","type":"era.expression.function_library.compiled"},{"cardinality":"exactly_one","type":"era.expression.operations.parsed"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/initialize_random_sequence_state.ts"},"type_used":"era.expression.initialize_random_sequence_state"}'));
var __vf_w1_n11 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"predefined","id":"operation_loop","params":{},"provides":[{"key":"numeric_execution","type":"era.expression.execution.result"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.sequence.state"}],"schedule":"inline","source":{},"type_used":"vibeflow.loop.while"}'));
var __vf_w1_n12 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"derive_symbolic_layer","params":{"_global":{}},"provides":[{"key":"symbolic_layer","type":"era.expression.symbolic.layer"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.sequence.state"},{"cardinality":"exactly_one","type":"era.expression.execution.result"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/derive_symbolic_layer.ts"},"type_used":"era.expression.derive_symbolic_layer"}'));
var __vf_w1_n13 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"guard_random_compaction","params":{"_global":{}},"provides":[{"key":"random_guarded_symbolic_layer","type":"era.expression.symbolic.layer"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.symbolic.layer"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/guard_random_compaction.ts"},"type_used":"era.expression.guard_random_compaction"}'));
var __vf_w1_n14 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"process","id":"normalize_compaction","params":{"_global":{}},"provides":[{"key":"expression_response","type":"era.expression.response"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.sequence.state"},{"cardinality":"exactly_one","type":"era.expression.execution.result"},{"cardinality":"exactly_one","type":"era.expression.symbolic.layer"}],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/normalize_compaction.ts"},"type_used":"era.expression.normalize_compaction"}'));
var __vf_w1_n15 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"terminal","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts"},"type_used":"era.expression.terminal"}'));
var __vf_workflow_0_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v6","entry_mode":"sync","inputs":[{"key":"expression_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema"},"type":"era.expression.request"}],"kind":"workflow","max_steps":3,"outputs":[{"as":"expressionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"compactedOperations":{"type":"array"},"containsAutomaticRandom":{"type":"boolean"},"diagnostics":{"type":"array"},"finalState":{"type":"object"},"nextDrawOffset":{"minimum":0,"type":"integer"},"randomDrawsConsumed":{"minimum":0,"type":"integer"}},"required":["finalState","diagnostics","compactedOperations","randomDrawsConsumed","nextDrawOffset","containsAutomaticRandom"],"type":"object"},"type":"era.expression.response"}],"schemas":{"era.expression.ast_frame.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.execution.result":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.acyclic_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.call_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.compiled":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.dependencies":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.function_library.purity":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operation.current":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operations.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.request":{"$schema":"https://json-schema.org/draft/2020-12/schema"},"era.expression.request.normalized":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"compactedOperations":{"type":"array"},"containsAutomaticRandom":{"type":"boolean"},"diagnostics":{"type":"array"},"finalState":{"type":"object"},"nextDrawOffset":{"minimum":0,"type":"integer"},"randomDrawsConsumed":{"minimum":0,"type":"integer"}},"required":["finalState","diagnostics","compactedOperations","randomDrawsConsumed","nextDrawOffset","containsAutomaticRandom"],"type":"object"},"era.expression.sequence.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.expression.sequence.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.symbolic.layer":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.value":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"task_input_cardinalities":{},"workflow_id":"era.expression"}'));
var __vf_w0_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"terminal","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts"},"type_used":"era.expression.terminal"}'));
var __vf_w0_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"predefined","id":"execute_layer","params":{},"provides":[{"key":"expression_response","type":"era.expression.response"}],"requires":[{"cardinality":"exactly_one","type":"era.expression.request"}],"schedule":"inline","source":{},"type_used":"era.expression.execute_layer"}'));
var __vf_w0_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","flow_kind":"terminal","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","source":{"completion":"immediate","export":"run","language":"typescript","module":"/home/example/.codex/worktrees/era-native-resources/ERA-vibeFlow/javascript_project/expression/nodes/terminal.ts"},"type_used":"era.expression.terminal"}'));
var __vfCapabilityDescriptors = Object.freeze(JSON.parse("{}"));
var __vfCapabilityRequirements = Object.freeze(JSON.parse("{}"));
var __vfSchemaCatalog = Object.freeze(JSON.parse('{"era.expression.ast_frame.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.execution.result":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.acyclic_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.call_graph":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.compiled":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.dependencies":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.function_library.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.function_library.purity":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operation.current":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.operations.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","items":{"type":"object"},"type":"array"},"era.expression.request":{"$schema":"https://json-schema.org/draft/2020-12/schema"},"era.expression.request.normalized":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"compactedOperations":{"type":"array"},"containsAutomaticRandom":{"type":"boolean"},"diagnostics":{"type":"array"},"finalState":{"type":"object"},"nextDrawOffset":{"minimum":0,"type":"integer"},"randomDrawsConsumed":{"minimum":0,"type":"integer"}},"required":["finalState","diagnostics","compactedOperations","randomDrawsConsumed","nextDrawOffset","containsAutomaticRandom"],"type":"object"},"era.expression.sequence.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.expression.sequence.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.symbolic.layer":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.expression.value":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}}'));
function __vf_activate_w0_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("execute_layer");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0execute_layer");
  targets.push("execute_layer");
  emitTrace(state.root, "edge_activated", { source: "start", target: "execute_layer", path: state.path });
  deliverStatic(envelopes, state, "execute_layer", JSON.parse('["era.expression.request"]'));
  return targets;
}
function __vf_execute_w0_n0(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w0_n0, inputs, state);
}
function __vf_activate_w0_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("execute_layer\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "execute_layer", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w0_n1(inputs, state) {
  try {
    invokeRuntimeHookSync(state.root, "beforeNodeset", { nodeId: "execute_layer", nodePath: nodePath(state, "execute_layer"), blockPath: formatBlockPath(state.path) });
    emitTrace(state.root, "nodeset_enter", {
      nodeId: "execute_layer",
      nodePath: nodePath(state, "execute_layer")
    }, true);
    const initial = rawInputsForChild(__vf_workflow_1_metadata.inputs, inputs, state.workflow, "execute_layer");
    const child = __vf_workflow_1_execute(initial, state.root, [...state.path, "execute_layer"]);
    const outputs = outputsFromChild(__vf_w0_n1, JSON.parse('[{"alias":"expressionResponse","provider":"expression_response"}]'), child, state);
    emitTrace(state.root, "nodeset_exit", {
      nodeId: "execute_layer",
      nodePath: nodePath(state, "execute_layer")
    }, true);
    invokeRuntimeHookSync(state.root, "afterNodeset", { nodeId: "execute_layer", nodePath: nodePath(state, "execute_layer"), blockPath: formatBlockPath(state.path) });
    return outputs;
  } catch (cause) {
    const failure = ensureErrorLocation(cause, state.workflow, state.path, "execute_layer");
    invokeRuntimeHookSync(state.root, "nodesetFailed", { nodeId: "execute_layer", nodePath: nodePath(state, "execute_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w0_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w0_n2(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w0_n2, inputs, state);
}
function __vf_workflow_0_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_0_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "execute_layer");
    initializeInbox(state, "end");
    seedInbox(state, "execute_layer", JSON.parse('["era.expression.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_0_metadata);
      if (state.stepCount >= 3) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=3",
          __vf_workflow_0_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n0(inputs, state);
            finishStaticNode(__vf_w0_n0, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w0_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "execute_layer": {
          if (!state.inboxes["execute_layer"].some((item) => item.type === "era.expression.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "execute_layer", nodePath: nodePath(state, "execute_layer"), blockPath: formatBlockPath(state.path), type: "era.expression.execute_layer" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n1(inputs, state);
            finishStaticNode(__vf_w0_n1, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w0_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "execute_layer", nodePath: nodePath(state, "execute_layer"), blockPath: formatBlockPath(state.path), type: "era.expression.execute_layer", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "execute_layer");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "execute_layer", nodePath: nodePath(state, "execute_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n2(inputs, state);
            finishStaticNode(__vf_w0_n2, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w0_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    const publicOutputs = state.workflow.kind === "task" ? state.taskOutputs : finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w1_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("validate_request");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0validate_request");
  targets.push("validate_request");
  emitTrace(state.root, "edge_activated", { source: "start", target: "validate_request", path: state.path });
  deliverStatic(envelopes, state, "validate_request", JSON.parse('["era.expression.request"]'));
  return targets;
}
function __vf_execute_w1_n0(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w1_n0, inputs, state);
}
function __vf_activate_w1_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("validate_random_context");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("validate_request\0validate_random_context");
  targets.push("validate_random_context");
  emitTrace(state.root, "edge_activated", { source: "validate_request", target: "validate_random_context", path: state.path });
  deliverStatic(envelopes, state, "validate_random_context", JSON.parse('["era.expression.request.normalized"]'));
  return targets;
}
function __vf_execute_w1_n1(inputs, state) {
  return invokeStaticImplementationSync(validateRequestNode, __vf_w1_n1, inputs, state);
}
function __vf_activate_w1_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("parse_function_definitions");
    targets.push("parse_operations");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("validate_random_context\0parse_function_definitions");
  targets.push("parse_function_definitions");
  emitTrace(state.root, "edge_activated", { source: "validate_random_context", target: "parse_function_definitions", path: state.path });
  deliverStatic(envelopes, state, "parse_function_definitions", JSON.parse('["era.expression.request.normalized"]'));
  state.activeEdges.add("validate_random_context\0parse_operations");
  targets.push("parse_operations");
  emitTrace(state.root, "edge_activated", { source: "validate_random_context", target: "parse_operations", path: state.path });
  deliverStatic(envelopes, state, "parse_operations", JSON.parse('["era.expression.request.normalized"]'));
  deliverStatic(envelopes, state, "initialize_sequence_state", JSON.parse('["era.expression.request.normalized","era.expression.function_library.compiled","era.expression.operations.parsed"]'));
  return targets;
}
function __vf_execute_w1_n2(inputs, state) {
  return invokeStaticImplementationSync(validateRandomContextNode, __vf_w1_n2, inputs, state);
}
function __vf_activate_w1_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("extract_function_dependencies");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("parse_function_definitions\0extract_function_dependencies");
  targets.push("extract_function_dependencies");
  emitTrace(state.root, "edge_activated", { source: "parse_function_definitions", target: "extract_function_dependencies", path: state.path });
  deliverStatic(envelopes, state, "extract_function_dependencies", JSON.parse('["era.expression.function_library.parsed"]'));
  deliverStatic(envelopes, state, "validate_function_purity", JSON.parse('["era.expression.function_library.parsed","era.expression.function_library.dependencies"]'));
  deliverStatic(envelopes, state, "compile_callable_functions", JSON.parse('["era.expression.function_library.parsed","era.expression.function_library.acyclic_graph"]'));
  return targets;
}
function __vf_execute_w1_n3(inputs, state) {
  return invokeStaticImplementationSync(parseFunctionDefinitionsNode, __vf_w1_n3, inputs, state);
}
function __vf_activate_w1_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("validate_function_purity");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("extract_function_dependencies\0validate_function_purity");
  targets.push("validate_function_purity");
  emitTrace(state.root, "edge_activated", { source: "extract_function_dependencies", target: "validate_function_purity", path: state.path });
  deliverStatic(envelopes, state, "validate_function_purity", JSON.parse('["era.expression.function_library.parsed","era.expression.function_library.dependencies"]'));
  deliverStatic(envelopes, state, "build_function_call_graph", JSON.parse('["era.expression.function_library.dependencies","era.expression.function_library.purity"]'));
  return targets;
}
function __vf_execute_w1_n4(inputs, state) {
  return invokeStaticImplementationSync(extractFunctionDependenciesNode, __vf_w1_n4, inputs, state);
}
function __vf_activate_w1_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("build_function_call_graph");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("validate_function_purity\0build_function_call_graph");
  targets.push("build_function_call_graph");
  emitTrace(state.root, "edge_activated", { source: "validate_function_purity", target: "build_function_call_graph", path: state.path });
  deliverStatic(envelopes, state, "build_function_call_graph", JSON.parse('["era.expression.function_library.dependencies","era.expression.function_library.purity"]'));
  return targets;
}
function __vf_execute_w1_n5(inputs, state) {
  return invokeStaticImplementationSync(validateFunctionPurityNode, __vf_w1_n5, inputs, state);
}
function __vf_activate_w1_n6(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("reject_recursive_functions");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n6, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("build_function_call_graph\0reject_recursive_functions");
  targets.push("reject_recursive_functions");
  emitTrace(state.root, "edge_activated", { source: "build_function_call_graph", target: "reject_recursive_functions", path: state.path });
  deliverStatic(envelopes, state, "reject_recursive_functions", JSON.parse('["era.expression.function_library.call_graph"]'));
  return targets;
}
function __vf_execute_w1_n6(inputs, state) {
  return invokeStaticImplementationSync(buildFunctionCallGraphNode, __vf_w1_n6, inputs, state);
}
function __vf_activate_w1_n7(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("compile_callable_functions");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n7, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("reject_recursive_functions\0compile_callable_functions");
  targets.push("compile_callable_functions");
  emitTrace(state.root, "edge_activated", { source: "reject_recursive_functions", target: "compile_callable_functions", path: state.path });
  deliverStatic(envelopes, state, "compile_callable_functions", JSON.parse('["era.expression.function_library.parsed","era.expression.function_library.acyclic_graph"]'));
  return targets;
}
function __vf_execute_w1_n7(inputs, state) {
  return invokeStaticImplementationSync(rejectRecursiveFunctionsNode, __vf_w1_n7, inputs, state);
}
function __vf_activate_w1_n8(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("initialize_sequence_state");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n8, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("compile_callable_functions\0initialize_sequence_state");
  targets.push("initialize_sequence_state");
  emitTrace(state.root, "edge_activated", { source: "compile_callable_functions", target: "initialize_sequence_state", path: state.path });
  deliverStatic(envelopes, state, "initialize_sequence_state", JSON.parse('["era.expression.request.normalized","era.expression.function_library.compiled","era.expression.operations.parsed"]'));
  return targets;
}
function __vf_execute_w1_n8(inputs, state) {
  return invokeStaticImplementationSync(compileCallableFunctionsNode, __vf_w1_n8, inputs, state);
}
function __vf_activate_w1_n9(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("initialize_sequence_state");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n9, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("parse_operations\0initialize_sequence_state");
  targets.push("initialize_sequence_state");
  emitTrace(state.root, "edge_activated", { source: "parse_operations", target: "initialize_sequence_state", path: state.path });
  deliverStatic(envelopes, state, "initialize_sequence_state", JSON.parse('["era.expression.request.normalized","era.expression.function_library.compiled","era.expression.operations.parsed"]'));
  return targets;
}
function __vf_execute_w1_n9(inputs, state) {
  return invokeStaticImplementationSync(parseOperationsNode, __vf_w1_n9, inputs, state);
}
function __vf_activate_w1_n10(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("operation_loop");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n10, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("initialize_sequence_state\0operation_loop");
  targets.push("operation_loop");
  emitTrace(state.root, "edge_activated", { source: "initialize_sequence_state", target: "operation_loop", path: state.path });
  deliverStatic(envelopes, state, "operation_loop", JSON.parse('["era.expression.sequence.state"]'));
  deliverStatic(envelopes, state, "derive_symbolic_layer", JSON.parse('["era.expression.sequence.state","era.expression.execution.result"]'));
  deliverStatic(envelopes, state, "normalize_compaction", JSON.parse('["era.expression.sequence.state","era.expression.execution.result","era.expression.symbolic.layer"]'));
  return targets;
}
function __vf_execute_w1_n10(inputs, state) {
  return invokeStaticImplementationSync(initializeRandomSequenceStateNode, __vf_w1_n10, inputs, state);
}
function __vf_activate_w1_n11(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("derive_symbolic_layer");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n11, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("operation_loop\0derive_symbolic_layer");
  targets.push("derive_symbolic_layer");
  emitTrace(state.root, "edge_activated", { source: "operation_loop", target: "derive_symbolic_layer", path: state.path });
  deliverStatic(envelopes, state, "derive_symbolic_layer", JSON.parse('["era.expression.sequence.state","era.expression.execution.result"]'));
  deliverStatic(envelopes, state, "normalize_compaction", JSON.parse('["era.expression.sequence.state","era.expression.execution.result","era.expression.symbolic.layer"]'));
  return targets;
}
function __vf_execute_w1_n11(inputs, state) {
  emitTrace(state.root, "loop_enter", {
    nodeId: "operation_loop",
    nodePath: nodePath(state, "operation_loop")
  }, true);
  const values = dictionary();
  for (const [type, input] of Object.entries(inputs)) {
    setOwn(values, type, Array.isArray(input) ? input.map(valueFromEnvelope) : valueFromEnvelope(input));
    const items = Array.isArray(input) ? input : [input];
    for (const item of items) {
      if (item?.key) setOwn(values, item.key, item.value);
      if (item?.type) setOwn(values, item.type, item.value);
    }
  }
  if (!Object.prototype.hasOwnProperty.call(values, "era.expression.sequence.state")) {
    throw vfError("VF_INPUT_REQUIRED", "loop carry source 'era.expression.sequence.state' is unavailable", state.workflow, { nodePath: nodePath(state, "operation_loop") });
  }
  setOwn(values, "sequence_state", values["era.expression.sequence.state"]);
  let stopped = false;
  for (let iteration = 0; ; iteration += 1) {
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, "operation_loop"));
    const initial = dictionary();
    setOwn(initial, "sequence_state", values["sequence_state"]);
    emitTrace(state.root, "loop_iteration", {
      nodeId: "operation_loop",
      nodePath: nodePath(state, "operation_loop"),
      iteration
    });
    const child = __vf_workflow_2_execute(initial, state.root, [...state.path, "operation_loop", `iter_${iteration}`]);
    const childValues = resultValues(child);
    for (const [key, value] of Object.entries(childValues)) setOwn(values, key, value);
    if (!Object.prototype.hasOwnProperty.call(values, "sequenceStateNext")) {
      throw vfError("VF_OUTPUT_KEYS", "loop carry update 'sequenceStateNext' is unavailable", state.workflow, { nodePath: nodePath(state, "operation_loop") });
    }
    setOwn(values, "sequence_state", values["sequenceStateNext"]);
    const iterationCount = iteration + 1;
    setOwn(values, "loop.iterations", iterationCount);
    if (!Object.prototype.hasOwnProperty.call(values, "sequenceDone")) {
      throw vfError("VF_OUTPUT_KEYS", "loop stop source 'sequenceDone' is unavailable", state.workflow);
    }
    if (typeof values["sequenceDone"] !== "boolean") {
      throw vfError("VF_OUTPUT_SCHEMA", "loop stop source 'sequenceDone' must be boolean", state.workflow);
    }
    stopped = stopped || values["sequenceDone"] === true;
    if (stopped) break;
  }
  const outputs = dictionary();
  if (!Object.prototype.hasOwnProperty.call(values, "operationExecutionResult")) {
    throw vfError("VF_OUTPUT_KEYS", "loop output source 'operationExecutionResult' is unavailable", state.workflow);
  }
  setOwn(outputs, "numeric_execution", values["operationExecutionResult"]);
  emitTrace(state.root, "loop_exit", {
    nodeId: "operation_loop",
    nodePath: nodePath(state, "operation_loop")
  }, true);
  return validateNodeOutputs(__vf_w1_n11, outputs, state);
}
function __vf_activate_w1_n12(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("guard_random_compaction");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n12, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("derive_symbolic_layer\0guard_random_compaction");
  targets.push("guard_random_compaction");
  emitTrace(state.root, "edge_activated", { source: "derive_symbolic_layer", target: "guard_random_compaction", path: state.path });
  deliverStatic(envelopes, state, "guard_random_compaction", JSON.parse('["era.expression.symbolic.layer"]'));
  return targets;
}
function __vf_execute_w1_n12(inputs, state) {
  return invokeStaticImplementationSync(deriveSymbolicLayerNode, __vf_w1_n12, inputs, state);
}
function __vf_activate_w1_n13(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("normalize_compaction");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n13, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("guard_random_compaction\0normalize_compaction");
  targets.push("normalize_compaction");
  emitTrace(state.root, "edge_activated", { source: "guard_random_compaction", target: "normalize_compaction", path: state.path });
  deliverStatic(envelopes, state, "normalize_compaction", JSON.parse('["era.expression.sequence.state","era.expression.execution.result","era.expression.symbolic.layer"]'));
  return targets;
}
function __vf_execute_w1_n13(inputs, state) {
  return invokeStaticImplementationSync(guardRandomCompactionNode, __vf_w1_n13, inputs, state);
}
function __vf_activate_w1_n14(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n14, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("normalize_compaction\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "normalize_compaction", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w1_n14(inputs, state) {
  return invokeStaticImplementationSync(normalizeCompactionNode, __vf_w1_n14, inputs, state);
}
function __vf_activate_w1_n15(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n15, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w1_n15(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w1_n15, inputs, state);
}
function __vf_workflow_1_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_1_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "validate_request");
    initializeInbox(state, "validate_random_context");
    initializeInbox(state, "parse_function_definitions");
    initializeInbox(state, "extract_function_dependencies");
    initializeInbox(state, "validate_function_purity");
    initializeInbox(state, "build_function_call_graph");
    initializeInbox(state, "reject_recursive_functions");
    initializeInbox(state, "compile_callable_functions");
    initializeInbox(state, "parse_operations");
    initializeInbox(state, "initialize_sequence_state");
    initializeInbox(state, "operation_loop");
    initializeInbox(state, "derive_symbolic_layer");
    initializeInbox(state, "guard_random_compaction");
    initializeInbox(state, "normalize_compaction");
    initializeInbox(state, "end");
    seedInbox(state, "validate_request", JSON.parse('["era.expression.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_1_metadata);
      if (state.stepCount >= 19) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=19",
          __vf_workflow_1_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w1_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n0(inputs, state);
            finishStaticNode(__vf_w1_n0, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "validate_request": {
          if (!state.inboxes["validate_request"].some((item) => item.type === "era.expression.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "validate_request", nodePath: nodePath(state, "validate_request"), blockPath: formatBlockPath(state.path), type: "era.expression.validate_request" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n1(inputs, state);
            finishStaticNode(__vf_w1_n1, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "validate_request", nodePath: nodePath(state, "validate_request"), blockPath: formatBlockPath(state.path), type: "era.expression.validate_request", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "validate_request");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "validate_request", nodePath: nodePath(state, "validate_request"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "validate_random_context": {
          if (!state.inboxes["validate_random_context"].some((item) => item.type === "era.expression.request.normalized")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "validate_random_context", nodePath: nodePath(state, "validate_random_context"), blockPath: formatBlockPath(state.path), type: "era.expression.validate_random_context" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n2(inputs, state);
            finishStaticNode(__vf_w1_n2, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "validate_random_context", nodePath: nodePath(state, "validate_random_context"), blockPath: formatBlockPath(state.path), type: "era.expression.validate_random_context", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "validate_random_context");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "validate_random_context", nodePath: nodePath(state, "validate_random_context"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "parse_function_definitions": {
          if (!state.inboxes["parse_function_definitions"].some((item) => item.type === "era.expression.request.normalized")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "parse_function_definitions", nodePath: nodePath(state, "parse_function_definitions"), blockPath: formatBlockPath(state.path), type: "era.expression.parse_function_definitions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n3(inputs, state);
            finishStaticNode(__vf_w1_n3, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "parse_function_definitions", nodePath: nodePath(state, "parse_function_definitions"), blockPath: formatBlockPath(state.path), type: "era.expression.parse_function_definitions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "parse_function_definitions");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "parse_function_definitions", nodePath: nodePath(state, "parse_function_definitions"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "extract_function_dependencies": {
          if (!state.inboxes["extract_function_dependencies"].some((item) => item.type === "era.expression.function_library.parsed")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "extract_function_dependencies", nodePath: nodePath(state, "extract_function_dependencies"), blockPath: formatBlockPath(state.path), type: "era.expression.extract_function_dependencies" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n4(inputs, state);
            finishStaticNode(__vf_w1_n4, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "extract_function_dependencies", nodePath: nodePath(state, "extract_function_dependencies"), blockPath: formatBlockPath(state.path), type: "era.expression.extract_function_dependencies", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "extract_function_dependencies");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "extract_function_dependencies", nodePath: nodePath(state, "extract_function_dependencies"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "validate_function_purity": {
          if (!(state.inboxes["validate_function_purity"].some((item) => item.type === "era.expression.function_library.parsed") && state.inboxes["validate_function_purity"].some((item) => item.type === "era.expression.function_library.dependencies"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "validate_function_purity", nodePath: nodePath(state, "validate_function_purity"), blockPath: formatBlockPath(state.path), type: "era.expression.validate_function_purity" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n5(inputs, state);
            finishStaticNode(__vf_w1_n5, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "validate_function_purity", nodePath: nodePath(state, "validate_function_purity"), blockPath: formatBlockPath(state.path), type: "era.expression.validate_function_purity", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "validate_function_purity");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "validate_function_purity", nodePath: nodePath(state, "validate_function_purity"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "build_function_call_graph": {
          if (!(state.inboxes["build_function_call_graph"].some((item) => item.type === "era.expression.function_library.dependencies") && state.inboxes["build_function_call_graph"].some((item) => item.type === "era.expression.function_library.purity"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n6, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "build_function_call_graph", nodePath: nodePath(state, "build_function_call_graph"), blockPath: formatBlockPath(state.path), type: "era.expression.build_function_call_graph" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n6(inputs, state);
            finishStaticNode(__vf_w1_n6, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n6(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "build_function_call_graph", nodePath: nodePath(state, "build_function_call_graph"), blockPath: formatBlockPath(state.path), type: "era.expression.build_function_call_graph", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "build_function_call_graph");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "build_function_call_graph", nodePath: nodePath(state, "build_function_call_graph"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "reject_recursive_functions": {
          if (!state.inboxes["reject_recursive_functions"].some((item) => item.type === "era.expression.function_library.call_graph")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n7, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "reject_recursive_functions", nodePath: nodePath(state, "reject_recursive_functions"), blockPath: formatBlockPath(state.path), type: "era.expression.reject_recursive_functions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n7(inputs, state);
            finishStaticNode(__vf_w1_n7, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n7(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "reject_recursive_functions", nodePath: nodePath(state, "reject_recursive_functions"), blockPath: formatBlockPath(state.path), type: "era.expression.reject_recursive_functions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "reject_recursive_functions");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "reject_recursive_functions", nodePath: nodePath(state, "reject_recursive_functions"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "compile_callable_functions": {
          if (!(state.inboxes["compile_callable_functions"].some((item) => item.type === "era.expression.function_library.parsed") && state.inboxes["compile_callable_functions"].some((item) => item.type === "era.expression.function_library.acyclic_graph"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n8, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "compile_callable_functions", nodePath: nodePath(state, "compile_callable_functions"), blockPath: formatBlockPath(state.path), type: "era.expression.compile_callable_functions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n8(inputs, state);
            finishStaticNode(__vf_w1_n8, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n8(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "compile_callable_functions", nodePath: nodePath(state, "compile_callable_functions"), blockPath: formatBlockPath(state.path), type: "era.expression.compile_callable_functions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "compile_callable_functions");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "compile_callable_functions", nodePath: nodePath(state, "compile_callable_functions"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "parse_operations": {
          if (!state.inboxes["parse_operations"].some((item) => item.type === "era.expression.request.normalized")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n9, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "parse_operations", nodePath: nodePath(state, "parse_operations"), blockPath: formatBlockPath(state.path), type: "era.expression.parse_operations" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n9(inputs, state);
            finishStaticNode(__vf_w1_n9, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n9(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "parse_operations", nodePath: nodePath(state, "parse_operations"), blockPath: formatBlockPath(state.path), type: "era.expression.parse_operations", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "parse_operations");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "parse_operations", nodePath: nodePath(state, "parse_operations"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "initialize_sequence_state": {
          if (!(state.activeEdges.has("compile_callable_functions\0initialize_sequence_state") && state.activeEdges.has("parse_operations\0initialize_sequence_state") && state.inboxes["initialize_sequence_state"].some((item) => item.type === "era.expression.request.normalized") && state.inboxes["initialize_sequence_state"].some((item) => item.type === "era.expression.function_library.compiled") && state.inboxes["initialize_sequence_state"].some((item) => item.type === "era.expression.operations.parsed"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n10, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "initialize_sequence_state", nodePath: nodePath(state, "initialize_sequence_state"), blockPath: formatBlockPath(state.path), type: "era.expression.initialize_random_sequence_state" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n10(inputs, state);
            finishStaticNode(__vf_w1_n10, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n10(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "initialize_sequence_state", nodePath: nodePath(state, "initialize_sequence_state"), blockPath: formatBlockPath(state.path), type: "era.expression.initialize_random_sequence_state", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "initialize_sequence_state");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "initialize_sequence_state", nodePath: nodePath(state, "initialize_sequence_state"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "operation_loop": {
          if (!state.inboxes["operation_loop"].some((item) => item.type === "era.expression.sequence.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n11, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "operation_loop", nodePath: nodePath(state, "operation_loop"), blockPath: formatBlockPath(state.path), type: "vibeflow.loop.while" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n11(inputs, state);
            finishStaticNode(__vf_w1_n11, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n11(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "operation_loop", nodePath: nodePath(state, "operation_loop"), blockPath: formatBlockPath(state.path), type: "vibeflow.loop.while", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "operation_loop");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "operation_loop", nodePath: nodePath(state, "operation_loop"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "derive_symbolic_layer": {
          if (!(state.inboxes["derive_symbolic_layer"].some((item) => item.type === "era.expression.sequence.state") && state.inboxes["derive_symbolic_layer"].some((item) => item.type === "era.expression.execution.result"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n12, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "derive_symbolic_layer", nodePath: nodePath(state, "derive_symbolic_layer"), blockPath: formatBlockPath(state.path), type: "era.expression.derive_symbolic_layer" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n12(inputs, state);
            finishStaticNode(__vf_w1_n12, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n12(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "derive_symbolic_layer", nodePath: nodePath(state, "derive_symbolic_layer"), blockPath: formatBlockPath(state.path), type: "era.expression.derive_symbolic_layer", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "derive_symbolic_layer");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "derive_symbolic_layer", nodePath: nodePath(state, "derive_symbolic_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "guard_random_compaction": {
          if (!state.inboxes["guard_random_compaction"].some((item) => item.type === "era.expression.symbolic.layer")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n13, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "guard_random_compaction", nodePath: nodePath(state, "guard_random_compaction"), blockPath: formatBlockPath(state.path), type: "era.expression.guard_random_compaction" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n13(inputs, state);
            finishStaticNode(__vf_w1_n13, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n13(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "guard_random_compaction", nodePath: nodePath(state, "guard_random_compaction"), blockPath: formatBlockPath(state.path), type: "era.expression.guard_random_compaction", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "guard_random_compaction");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "guard_random_compaction", nodePath: nodePath(state, "guard_random_compaction"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "normalize_compaction": {
          if (!(state.inboxes["normalize_compaction"].some((item) => item.type === "era.expression.sequence.state") && state.inboxes["normalize_compaction"].some((item) => item.type === "era.expression.execution.result") && state.inboxes["normalize_compaction"].some((item) => item.type === "era.expression.symbolic.layer"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n14, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "normalize_compaction", nodePath: nodePath(state, "normalize_compaction"), blockPath: formatBlockPath(state.path), type: "era.expression.normalize_compaction" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n14(inputs, state);
            finishStaticNode(__vf_w1_n14, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n14(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "normalize_compaction", nodePath: nodePath(state, "normalize_compaction"), blockPath: formatBlockPath(state.path), type: "era.expression.normalize_compaction", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "normalize_compaction");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "normalize_compaction", nodePath: nodePath(state, "normalize_compaction"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w1_n15, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n15(inputs, state);
            finishStaticNode(__vf_w1_n15, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w1_n15(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    const publicOutputs = state.workflow.kind === "task" ? state.taskOutputs : finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w2_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("select_next_operation");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0select_next_operation");
  targets.push("select_next_operation");
  emitTrace(state.root, "edge_activated", { source: "start", target: "select_next_operation", path: state.path });
  deliverStatic(envelopes, state, "select_next_operation", JSON.parse('["era.expression.sequence.state"]'));
  return targets;
}
function __vf_execute_w2_n0(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w2_n0, inputs, state);
}
function __vf_activate_w2_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("initialize_ast_frames");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("select_next_operation\0initialize_ast_frames");
  targets.push("initialize_ast_frames");
  emitTrace(state.root, "edge_activated", { source: "select_next_operation", target: "initialize_ast_frames", path: state.path });
  deliverStatic(envelopes, state, "initialize_ast_frames", JSON.parse('["era.expression.operation.current"]'));
  deliverStatic(envelopes, state, "commit_operation_result", JSON.parse('["era.expression.operation.current","era.expression.value"]'));
  return targets;
}
function __vf_execute_w2_n1(inputs, state) {
  return invokeStaticImplementationSync(selectNextOperationNode, __vf_w2_n1, inputs, state);
}
function __vf_activate_w2_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("evaluate_ast");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("initialize_ast_frames\0evaluate_ast");
  targets.push("evaluate_ast");
  emitTrace(state.root, "edge_activated", { source: "initialize_ast_frames", target: "evaluate_ast", path: state.path });
  deliverStatic(envelopes, state, "evaluate_ast", JSON.parse('["era.expression.ast_frame.state"]'));
  return targets;
}
function __vf_execute_w2_n2(inputs, state) {
  return invokeStaticImplementationSync(initializeAstFramesNode, __vf_w2_n2, inputs, state);
}
function __vf_activate_w2_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("commit_operation_result");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("evaluate_ast\0commit_operation_result");
  targets.push("commit_operation_result");
  emitTrace(state.root, "edge_activated", { source: "evaluate_ast", target: "commit_operation_result", path: state.path });
  deliverStatic(envelopes, state, "commit_operation_result", JSON.parse('["era.expression.operation.current","era.expression.value"]'));
  return targets;
}
function __vf_execute_w2_n3(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w2_n3, inputs, state);
}
function __vf_activate_w2_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("commit_operation_result\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "commit_operation_result", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w2_n4(inputs, state) {
  return invokeStaticImplementationSync(commitOperationResultNode, __vf_w2_n4, inputs, state);
}
function __vf_activate_w2_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w2_n5(inputs, state) {
  return invokeStaticImplementationSync(terminalNode, __vf_w2_n5, inputs, state);
}
function __vf_workflow_2_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_2_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "select_next_operation");
    initializeInbox(state, "initialize_ast_frames");
    initializeInbox(state, "evaluate_ast");
    initializeInbox(state, "commit_operation_result");
    initializeInbox(state, "end");
    seedInbox(state, "select_next_operation", JSON.parse('["era.expression.sequence.state"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_2_metadata);
      if (state.stepCount >= 8) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=8",
          __vf_workflow_2_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w2_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n0(inputs, state);
            finishStaticNode(__vf_w2_n0, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w2_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "select_next_operation": {
          if (!state.inboxes["select_next_operation"].some((item) => item.type === "era.expression.sequence.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "select_next_operation", nodePath: nodePath(state, "select_next_operation"), blockPath: formatBlockPath(state.path), type: "era.expression.select_next_operation" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n1(inputs, state);
            finishStaticNode(__vf_w2_n1, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w2_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "select_next_operation", nodePath: nodePath(state, "select_next_operation"), blockPath: formatBlockPath(state.path), type: "era.expression.select_next_operation", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "select_next_operation");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "select_next_operation", nodePath: nodePath(state, "select_next_operation"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "initialize_ast_frames": {
          if (!state.inboxes["initialize_ast_frames"].some((item) => item.type === "era.expression.operation.current")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "initialize_ast_frames", nodePath: nodePath(state, "initialize_ast_frames"), blockPath: formatBlockPath(state.path), type: "era.expression.initialize_ast_frames" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n2(inputs, state);
            finishStaticNode(__vf_w2_n2, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w2_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "initialize_ast_frames", nodePath: nodePath(state, "initialize_ast_frames"), blockPath: formatBlockPath(state.path), type: "era.expression.initialize_ast_frames", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "initialize_ast_frames");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "initialize_ast_frames", nodePath: nodePath(state, "initialize_ast_frames"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "evaluate_ast": {
          if (!state.inboxes["evaluate_ast"].some((item) => item.type === "era.expression.ast_frame.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "evaluate_ast", nodePath: nodePath(state, "evaluate_ast"), blockPath: formatBlockPath(state.path), type: "era.expression.evaluate_ast" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n3(inputs, state);
            finishStaticNode(__vf_w2_n3, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w2_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "evaluate_ast", nodePath: nodePath(state, "evaluate_ast"), blockPath: formatBlockPath(state.path), type: "era.expression.evaluate_ast", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "evaluate_ast");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "evaluate_ast", nodePath: nodePath(state, "evaluate_ast"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "commit_operation_result": {
          if (!(state.inboxes["commit_operation_result"].some((item) => item.type === "era.expression.operation.current") && state.inboxes["commit_operation_result"].some((item) => item.type === "era.expression.value"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "commit_operation_result", nodePath: nodePath(state, "commit_operation_result"), blockPath: formatBlockPath(state.path), type: "era.expression.commit_operation_result" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n4(inputs, state);
            finishStaticNode(__vf_w2_n4, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w2_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "commit_operation_result", nodePath: nodePath(state, "commit_operation_result"), blockPath: formatBlockPath(state.path), type: "era.expression.commit_operation_result", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "commit_operation_result");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "commit_operation_result", nodePath: nodePath(state, "commit_operation_result"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w2_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n5(inputs, state);
            finishStaticNode(__vf_w2_n5, state);
            state.taskOutputs = outputs;
            state.stepCount += 1;
            const targets = __vf_activate_w2_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.expression.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    const publicOutputs = state.workflow.kind === "task" ? state.taskOutputs : finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
var __vfInvokeWorkflow = createStaticWorkflowSync(
  __vf_workflow_0_metadata,
  __vfCapabilityDescriptors,
  __vfCapabilityRequirements,
  __vfSchemaCatalog,
  __vfRuntimePluginDescriptors,
  __vfRuntimePluginFactories,
  __vf_workflow_0_execute
);
function runWorkflow(inputs, options) {
  return __vfObserveSync(__vfInvokeWorkflow, inputs, options);
}
export {
  VIBEFLOW_PLUGIN_ABI,
  VIBEFLOW_WORKFLOW_ABI,
  VibeFlowWorkflowError,
  runWorkflow
};
