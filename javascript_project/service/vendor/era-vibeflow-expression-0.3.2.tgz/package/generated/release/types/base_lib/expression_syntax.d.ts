import { Ast, Diagnostic, NormalizedRequest, ParsedOperation } from "./expression_types.ts";
export interface Token {
    readonly kind: "number" | "identifier" | "operator" | "punctuation" | "eof";
    readonly text: string;
    readonly position: number;
}
export declare function lex(source: string): Token[];
export declare class Parser {
    private readonly tokens;
    private readonly allowSnapshot;
    private index;
    constructor(tokens: readonly Token[], allowSnapshot: boolean);
    private current;
    private take;
    private matches;
    private expect;
    parse(): Ast;
    private additive;
    private multiplicative;
    private unary;
    private power;
    private primary;
}
export declare function parseExpression(source: string, allowSnapshot?: boolean): {
    readonly ast: Ast | null;
    readonly diagnostics: readonly Diagnostic[];
};
export declare function validatePath(value: string): readonly string[];
export declare function normaliseRequest(input: unknown): NormalizedRequest;
export declare function walk(ast: Ast, visitor: (item: Ast) => void): void;
export declare function parseOperations(request: NormalizedRequest): readonly ParsedOperation[];
