export declare function rejectRecursiveFunctionsNode(inputs: NodeInputs): any;
export { rejectRecursiveFunctionsNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
