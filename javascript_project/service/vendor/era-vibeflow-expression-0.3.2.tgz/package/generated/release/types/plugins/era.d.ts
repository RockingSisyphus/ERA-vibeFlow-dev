export declare const plugin: Readonly<{
    id: string;
    display_name: string;
    description: string;
    declaration_rulesets: string[];
    implementation_files: string[];
    resources: any[];
} & {
    abi: "vibeflow.plugin.v3";
}>;
