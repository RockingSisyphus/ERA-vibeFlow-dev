import { Ast, SequenceState, ExpressionResponse } from "./expression_types.ts";
export declare function substituteSymbolic(ast: Ast, state: Readonly<Record<string, Ast>>): Ast;
export declare function literal(value: number): Ast;
export declare function literalNumber(ast: Ast): number | undefined;
export declare function simplify(ast: Ast): Ast;
export declare function operatorPrecedence(op: Extract<Ast, {
    kind: "binary";
}>["op"]): number;
export declare function printAst(ast: Ast, parent?: number): string;
export declare function deriveSymbolicLayer(sequence: SequenceState): Readonly<Record<string, Ast>>;
export declare function normaliseCompaction(sequence: SequenceState, symbols: Readonly<Record<string, Ast>>): ExpressionResponse;
