export declare const schema0: import("@vibeflow/plugin").Resource;
export declare const schema1: import("@vibeflow/plugin").Resource;
export declare const schema2: import("@vibeflow/plugin").Resource;
export declare const schema3: import("@vibeflow/plugin").Resource;
export declare const schema4: import("@vibeflow/plugin").Resource;
export declare const schema5: import("@vibeflow/plugin").Resource;
export declare const schema6: import("@vibeflow/plugin").Resource;
export declare const schema7: import("@vibeflow/plugin").Resource;
