export declare function initializeRandomSequenceStateNode(inputs: NodeInputs): any;
export { initializeRandomSequenceStateNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
