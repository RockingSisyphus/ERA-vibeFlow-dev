export declare function terminalNode(): Record<string, never>;
export { terminalNode as run };
