export declare function extractFunctionDependenciesNode(inputs: NodeInputs): any;
export { extractFunctionDependenciesNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
