export declare function validateFunctionPurityNode(inputs: NodeInputs): any;
export { validateFunctionPurityNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
