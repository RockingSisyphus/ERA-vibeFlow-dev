import { Diagnostic, JsonValue, RandomContext } from "./expression_types.ts";
export declare function isBuiltin(name: string): boolean;
export declare function diagnostic(code: string, message: string, extra?: Partial<Diagnostic>): Diagnostic;
export declare function isRecord(value: unknown): value is Record<string, unknown>;
export declare function clone<T extends JsonValue>(value: T): T;
export declare function finite(value: number, code: string, message: string): number;
export declare class ExpressionFailure extends Error {
    readonly detail: Diagnostic;
    constructor(detail: Diagnostic);
}
export declare function getPath(root: JsonValue, path: readonly string[]): JsonValue | undefined;
export declare function setPath(root: JsonValue, path: readonly string[], value: JsonValue): JsonValue;
export declare const UINT64_MASK: bigint;
export declare const FNV64_OFFSET = 14695981039346656037n;
export declare const FNV64_PRIME = 1099511628211n;
export declare const SPLITMIX_GAMMA = 11400714819323198485n;
export declare const SPLITMIX_MUL_1 = 13787848793156543929n;
export declare const SPLITMIX_MUL_2 = 10723151780598845931n;
export declare const TWO_POW_53 = 9007199254740992;
export declare function fnv1a64(bytes: Uint8Array): bigint;
export declare function randomSeedHash(seed: string | number): bigint;
export declare function deterministicRandomUnit(seed: string | number, draw: number): number;
export declare function calculateRandom(args: readonly number[], context: RandomContext | null, automaticDraw: number): number;
export declare function calculateBuiltin(name: string, args: readonly number[]): number;
