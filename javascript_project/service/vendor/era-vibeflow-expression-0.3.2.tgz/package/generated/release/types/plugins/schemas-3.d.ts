export declare const schema16: import("@vibeflow/plugin").Resource;
export declare const schema17: import("@vibeflow/plugin").Resource;
export declare const schema18: import("@vibeflow/plugin").Resource;
export declare const schema19: import("@vibeflow/plugin").Resource;
export declare const schema20: import("@vibeflow/plugin").Resource;
