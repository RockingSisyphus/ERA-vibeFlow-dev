export declare function parseFunctionDefinitionsNode(inputs: NodeInputs): any;
export { parseFunctionDefinitionsNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
