export declare const resource19: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
export declare const resource20: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: string[];
    rulesets: string[];
}, "implementation">>;
export declare const resource21: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
export declare const resource22: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
export declare const resource23: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: string[];
    rulesets: string[];
}, "implementation">>;
export declare const resource24: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
export declare const resource25: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: string[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
export declare const resource26: import("@vibeflow/plugin").Resource & Readonly<Pick<{
    id: string;
    display_name: string;
    description: string;
    version: string;
    implementations: {
        language: string;
        targets: string[];
        source: {
            kind: string;
            ref: string;
        };
    }[];
    dependencies: never[];
    external_packages: never[];
    rulesets: string[];
}, "implementation">>;
