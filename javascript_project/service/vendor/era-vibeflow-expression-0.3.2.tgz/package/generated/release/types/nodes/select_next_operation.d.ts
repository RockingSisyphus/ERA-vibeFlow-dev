export declare function selectNextOperationNode(inputs: NodeInputs): any;
export { selectNextOperationNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
