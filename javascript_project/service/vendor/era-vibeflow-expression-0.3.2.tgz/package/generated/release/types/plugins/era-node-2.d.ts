export declare const resource12: any;
export declare const resource13: any;
export declare const resource14: any;
export declare const resource15: any;
export declare const resource16: any;
export declare const resource17: any;
export declare const resource18: any;
