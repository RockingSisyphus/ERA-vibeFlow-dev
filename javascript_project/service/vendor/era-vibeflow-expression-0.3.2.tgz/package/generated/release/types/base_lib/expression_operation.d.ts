import { type SequenceState, type AstFrameState, type JsonValue, type Diagnostic } from "./expression_types.ts";
export declare function runOperationStep(state: SequenceState): ReturnType<typeof commitOperationResult>;
export declare function commitOperationResult(state: SequenceState, value: number | null, evaluationDiagnostics: readonly Diagnostic[]): {
    readonly sequenceStateNext: SequenceState;
    readonly sequenceDone: boolean;
    readonly operationExecutionResult: {
        readonly finalState: JsonValue;
        readonly diagnostics: readonly Diagnostic[];
        readonly randomDrawsConsumed: number;
    };
};
/** Evaluate one initialized AST; operation ordering and state commits belong to the workflow. */
export declare function evaluateAst(state: AstFrameState): {
    readonly value: number | null;
    readonly diagnostics: readonly Diagnostic[];
};
