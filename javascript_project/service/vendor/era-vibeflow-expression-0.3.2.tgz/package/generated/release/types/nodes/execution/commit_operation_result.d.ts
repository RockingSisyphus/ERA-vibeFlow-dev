export declare function commitOperationResultNode(inputs: NodeInputs): any;
export { commitOperationResultNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
