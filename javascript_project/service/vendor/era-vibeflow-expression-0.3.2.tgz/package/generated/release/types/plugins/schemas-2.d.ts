export declare const schema8: import("@vibeflow/plugin").Resource;
export declare const schema9: import("@vibeflow/plugin").Resource;
export declare const schema10: import("@vibeflow/plugin").Resource;
export declare const schema11: import("@vibeflow/plugin").Resource;
export declare const schema12: import("@vibeflow/plugin").Resource;
export declare const schema13: import("@vibeflow/plugin").Resource;
export declare const schema14: import("@vibeflow/plugin").Resource;
export declare const schema15: import("@vibeflow/plugin").Resource;
