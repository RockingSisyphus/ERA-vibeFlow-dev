export declare function initializeAstFramesNode(inputs: NodeInputs): any;
export { initializeAstFramesNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
