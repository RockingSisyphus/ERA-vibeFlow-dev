export declare function initializeSequenceStateNode(inputs: NodeInputs): any;
export { initializeSequenceStateNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
