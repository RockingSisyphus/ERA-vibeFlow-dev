export declare function run(inputs: Readonly<Record<string, unknown>>): any;
