export declare function deriveSymbolicLayerNode(inputs: NodeInputs): any;
export { deriveSymbolicLayerNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
