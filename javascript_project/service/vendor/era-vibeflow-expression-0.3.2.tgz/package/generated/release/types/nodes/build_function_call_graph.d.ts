export declare function buildFunctionCallGraphNode(inputs: NodeInputs): any;
export { buildFunctionCallGraphNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
