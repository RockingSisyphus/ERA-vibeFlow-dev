export declare function validateRequestNode(inputs: NodeInputs): any;
export { validateRequestNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
