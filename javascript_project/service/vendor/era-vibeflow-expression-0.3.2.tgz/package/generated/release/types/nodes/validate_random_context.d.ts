export declare function validateRandomContextNode(inputs: NodeInputs): any;
export { validateRandomContextNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
