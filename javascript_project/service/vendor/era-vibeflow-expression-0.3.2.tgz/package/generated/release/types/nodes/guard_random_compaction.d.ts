export declare function guardRandomCompactionNode(inputs: NodeInputs): any;
export { guardRandomCompactionNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
