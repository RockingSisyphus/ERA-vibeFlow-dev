export declare function normalizeCompactionNode(inputs: NodeInputs): any;
export { normalizeCompactionNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
