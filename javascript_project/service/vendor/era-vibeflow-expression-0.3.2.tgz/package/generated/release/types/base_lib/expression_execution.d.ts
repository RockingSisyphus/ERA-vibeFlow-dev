import { CompiledLibrary, AstFrameState } from "./expression_types.ts";
import { astFrameRoute } from "./expression_execution_core.ts";
export { initializeSequenceState, createAstFrameState, refValue, popValues, inlineCustomAst, mathText, complete, astFrameRoute } from "./expression_execution_core.ts";
export declare function evaluateFunctionAt(library: CompiledLibrary, name: string, input: number): number;
export declare function calculateCalculus(name: "derivative" | "integral", target: string, args: readonly number[], library: CompiledLibrary): number;
export declare function advanceAstFrame(state: AstFrameState, expected?: ReturnType<typeof astFrameRoute>): AstFrameState;
/** Standalone operation API reuses the same evaluator and commit policy as Nodes. */
