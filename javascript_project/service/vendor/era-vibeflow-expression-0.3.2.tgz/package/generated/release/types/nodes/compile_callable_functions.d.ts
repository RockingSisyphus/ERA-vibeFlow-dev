export declare function compileCallableFunctionsNode(inputs: NodeInputs): any;
export { compileCallableFunctionsNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
