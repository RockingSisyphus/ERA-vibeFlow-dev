import { NormalizedRequest, CompiledLibrary, ParsedOperation, SequenceState, Ast, AstFrameState } from "./expression_types.ts";
export declare function initializeSequenceState(request: NormalizedRequest, compiled: CompiledLibrary, operations: readonly ParsedOperation[], snapshotCompiled?: CompiledLibrary): SequenceState;
export declare function refValue(ast: Extract<Ast, {
    kind: "ref";
}>, state: SequenceState, env: Readonly<Record<string, number>>, allowState: boolean): number;
export declare function popValues(values: readonly number[], count: number): {
    readonly values: readonly number[];
    readonly args: readonly number[];
};
export declare function inlineCustomAst(ast: Ast, bindings: Readonly<Record<string, Ast>>, library: CompiledLibrary): Ast;
export declare function mathText(ast: Ast): string;
export declare function createAstFrameState(sequence: SequenceState, ast: Ast, env?: Readonly<Record<string, number>>, allowState?: boolean, library?: CompiledLibrary): AstFrameState;
export declare function complete(state: Omit<AstFrameState, "done" | "result">): AstFrameState;
export declare function astFrameRoute(state: AstFrameState): "value" | "operator" | "builtin" | "random" | "custom" | "return";
