export declare function parseOperationsNode(inputs: NodeInputs): any;
export { parseOperationsNode as run };
type NodeInputs = Readonly<Record<string, unknown>>;
