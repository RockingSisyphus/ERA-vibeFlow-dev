import type { CommandCompactionResponse } from "./command_compaction_interpreter.ts";
import { type ParsedCommand, type ParsedLayer, type SemanticTrace, type Candidate } from "./command_compaction_interpreter.ts";
export * from "./command_compaction_interpreter.ts";
export declare function executeOriginalSemantics(parsed: ParsedLayer): SemanticTrace;
export declare function renderTag(tag: string, data: Record<string, unknown>): string;
declare function commandExpressionFacts(trace: SemanticTrace, command: ParsedCommand): {
    readonly automaticRandom: boolean;
    readonly paths: readonly string[];
    readonly refs: readonly string[];
    readonly flattenable: boolean;
};
export declare function candidateFor(analysis: DependencyAnalysis): Candidate;
export declare function render(trace: SemanticTrace, replacements: ReadonlyMap<number, string>): string;
export declare function equivalent(trace: SemanticTrace, content: string): boolean;
/** Facts used by rewriting are computed at the explicit analysis stage. */
export interface DependencyAnalysis {
    readonly [key: string]: unknown;
    readonly trace: SemanticTrace;
    readonly facts: Readonly<Record<number, ReturnType<typeof commandExpressionFacts>>>;
}
export declare function analyzeDependencies(trace: SemanticTrace): DependencyAnalysis;

export declare function compactCommandLayer(input: unknown): CommandCompactionResponse;
