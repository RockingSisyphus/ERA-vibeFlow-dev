// ../../../../../../tmp/era-compaction-package-sPM2qu/node/workflow.js
import * as __vfFs from "node:fs";
import * as __vfPath from "node:path";
import { randomUUID as __vfUuid } from "node:crypto";
import { AsyncLocalStorage as __vfAsyncLocalStorage } from "node:async_hooks";
import { Worker as __vfStatusWorker } from "node:worker_threads";
import {
  compileFunctionLibrary as compileFunctionLibrary2,
  countAutomaticRandomDraws as countAutomaticRandomDraws2,
  executeExpressionLayer as executeExpressionLayer2,
  parseExpression as parseExpression2
} from "@era/vibeflow-expression/engine";
import {
  executeExpressionLayer
} from "@era/vibeflow-expression/engine";
function run() {
  return {};
}
function tagInfo(value) {
  if (value === "variableinsert") return { kind: "insert", tag: "VariableInsert" };
  if (value === "variableedit") return { kind: "edit", tag: "VariableEdit" };
  if (value === "variabledelete") return { kind: "delete", tag: "VariableDelete" };
  if (value === "functioninsert") return { kind: "function-insert", tag: "FunctionInsert" };
  if (value === "functionedit") return { kind: "function-edit", tag: "FunctionEdit" };
  if (value === "functiondelete") return { kind: "function-delete", tag: "FunctionDelete" };
  return null;
}
function record(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function plain(value) {
  if (!record(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
function clone(value) {
  return structuredClone(value);
}
function equal(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}
function diagnostic(code, message, commandIndex, path) {
  return { code, message, ...commandIndex === void 0 ? {} : { commandIndex }, ...path === void 0 ? {} : { path } };
}
function stripFence(text) {
  const match = /^```(?:json)?\s*([\s\S]*?)\s*```$/iu.exec(text.trim());
  return match ? match[1] : text.trim();
}
function parseData(text, commandIndex) {
  try {
    const parsed = JSON.parse(stripFence(text));
    const values = Array.isArray(parsed) ? parsed : [parsed];
    if (!values.every(plain)) {
      return { data: [], diagnostic: diagnostic("ERA_COMPACT_COMMAND_DATA_INVALID", "\u6307\u4EE4\u5185\u5BB9\u5FC5\u987B\u662F JSON \u5BF9\u8C61\u6216\u5BF9\u8C61\u6570\u7EC4\u3002", commandIndex) };
    }
    return { data: values };
  } catch (error) {
    return { data: [], diagnostic: diagnostic("ERA_COMPACT_COMMAND_JSON_INVALID", `\u6307\u4EE4 JSON \u65E0\u6CD5\u89E3\u6790\uFF1A${error instanceof Error ? error.message : String(error)}`, commandIndex) };
  }
}
function parseCommandLayer(input) {
  const source = record(input) ? input : {};
  const request = {
    content: typeof source.content === "string" ? source.content : "",
    initialStatData: plain(source.initialStatData) ? clone(source.initialStatData) : {},
    initialStatFunc: plain(source.initialStatFunc) ? clone(source.initialStatFunc) : {},
    snapshotStatData: plain(source.snapshotStatData) ? clone(source.snapshotStatData) : plain(source.initialStatData) ? clone(source.initialStatData) : {},
    snapshotStatFunc: plain(source.snapshotStatFunc) ? clone(source.snapshotStatFunc) : plain(source.initialStatFunc) ? clone(source.initialStatFunc) : {},
    eraMeta: plain(source.eraMeta) ? clone(source.eraMeta) : {},
    templateContext: plain(source.templateContext) ? clone(source.templateContext) : {},
    randomContext: plain(source.randomContext) && typeof source.randomContext.sourceKey === "string" && source.randomContext.sourceKey.length > 0 && Number.isSafeInteger(source.randomContext.drawOffset) && source.randomContext.drawOffset >= 0 ? {
      sourceKey: source.randomContext.sourceKey,
      drawOffset: source.randomContext.drawOffset
    } : void 0
  };
  const commands = [];
  const diagnostics = [];
  const pattern = /<((?:Variable|Function)(?:Insert|Edit|Delete))>\s*([\s\S]*?)\s*<\/\1>/giu;
  let match;
  while ((match = pattern.exec(request.content)) !== null) {
    const info = tagInfo((match[1] ?? "").toLowerCase());
    if (!info) continue;
    const index = commands.length;
    const parsed = parseData(match[2] ?? "", index);
    if (parsed.diagnostic) diagnostics.push(parsed.diagnostic);
    commands.push({
      index,
      kind: info.kind,
      tag: info.tag,
      data: parsed.data,
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0]
    });
  }
  return { request, commands, diagnostics };
}
function getAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return void 0;
    cursor = cursor[segment];
  }
  return cursor;
}
function hasAt(root, segments) {
  let cursor = root;
  for (const segment of segments) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return false;
    cursor = cursor[segment];
  }
  return true;
}
function setAt(root, segments, value) {
  let cursor = root;
  for (let index = 0; index < segments.length - 1; index += 1) {
    const key = segments[index];
    if (!plain(cursor[key])) cursor[key] = {};
    cursor = cursor[key];
  }
  cursor[segments[segments.length - 1]] = clone(value);
}
function unsetAt(root, segments) {
  let cursor = root;
  for (const segment of segments.slice(0, -1)) {
    if (!record(cursor) || !Object.prototype.hasOwnProperty.call(cursor, segment)) return;
    cursor = cursor[segment];
  }
  if (record(cursor)) delete cursor[segments[segments.length - 1]];
}
function metaValue(value, key) {
  return plain(value) && plain(value.$meta) ? value.$meta[key] : void 0;
}
function merge(left, right) {
  if (!plain(left) || !plain(right)) return clone(right);
  const output = clone(left);
  for (const [key, value] of Object.entries(right)) {
    output[key] = Object.prototype.hasOwnProperty.call(output, key) ? merge(output[key], value) : clone(value);
  }
  return output;
}
function inheritedTemplateContent(parentTemplate, key) {
  if (!plain(parentTemplate)) return void 0;
  const general = parentTemplate.$template;
  const specific = parentTemplate[key];
  if (plain(general) && plain(specific)) return merge(general, specific);
  return plain(specific) ? specific : plain(general) ? general : void 0;
}
function resolvedTemplate(inherited, parentData) {
  const own = plain(parentData) ? parentData.$template : void 0;
  const result = merge(plain(inherited) ? inherited : {}, plain(own) ? own : {});
  return plain(result) && Object.keys(result).length > 0 ? result : void 0;
}
function applyTemplate(template, patch) {
  if (!plain(patch) || !plain(template)) return clone(patch);
  return Object.keys(patch).length === 0 ? clone(template) : merge(template, patch);
}
function applyInsertAt(stat, segments, patch, inheritedTemplate = void 0, parentData = void 0) {
  const current = getAt(stat, segments);
  const localTemplate = resolvedTemplate(inheritedTemplate, parentData);
  if (segments.length > 0 && current === void 0) {
    setAt(stat, segments, applyTemplate(localTemplate, patch));
    return;
  }
  if (!plain(current) || !plain(patch)) return;
  const protection = metaValue(current, "unInsertAble");
  const keys = Object.keys(patch);
  const metaOnly = keys.every((key) => key === "$meta");
  if (protection === "all" && keys.length > 0 && !metaOnly) return;
  for (const key of keys) {
    if (protection === "self" && key !== "$meta" && !Object.prototype.hasOwnProperty.call(current, key)) continue;
    applyInsertAt(
      stat,
      [...segments, key],
      patch[key],
      inheritedTemplateContent(localTemplate, key),
      current
    );
  }
}
function expressionValue(stat, layerStart, statFunc, startFunc, path, expr, randomCursor) {
  const request = {
    initialState: stat,
    snapshotState: layerStart,
    functionLibrary: statFunc,
    snapshotFunctionLibrary: startFunc,
    allowSnapshots: true,
    operations: [{ path: path.join("."), expr }],
    ...randomCursor ? { randomContext: randomCursor } : {}
  };
  const response = executeExpressionLayer(request);
  if (randomCursor) randomCursor.drawOffset = response.nextDrawOffset;
  const value = getAt(response.finalState, path);
  const issue = response.diagnostics[0];
  if (issue || typeof value !== "number" || !Number.isFinite(value)) {
    return { diagnostic: diagnostic(issue?.code ?? "ERA_COMPACT_EXPR_NON_FINITE", issue?.message ?? "$expr \u5FC5\u987B\u5F97\u5230\u6709\u9650\u6570\u503C\u3002", void 0, path.join(".")) };
  }
  return { value };
}
function applyEditAt(stat, layerStart, statFunc, startFunc, segments, patch, diagnostics, commandIndex, randomCursor) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  if (metaValue(current, "updatable") === false) {
    const unlock = plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true;
    if (!unlock) return;
  }
  if (plain(patch) && Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (segments.length === 0 || !hasAt(stat, segments)) return;
    const resolved = expressionValue(
      stat,
      layerStart,
      statFunc,
      startFunc,
      segments,
      patch.$expr,
      randomCursor
    );
    if (resolved.diagnostic) diagnostics.push({ ...resolved.diagnostic, commandIndex });
    else setAt(stat, segments, resolved.value);
    return;
  }
  if (!plain(patch)) {
    if (segments.length > 0 && hasAt(stat, segments)) setAt(stat, segments, patch);
    return;
  }
  for (const [key, value] of Object.entries(patch)) {
    applyEditAt(stat, layerStart, statFunc, startFunc, [...segments, key], value, diagnostics, commandIndex, randomCursor);
  }
}
function deleteBypass(patch) {
  return plain(patch) && plain(patch.$meta) && Object.prototype.hasOwnProperty.call(patch.$meta, "necessary");
}
function emptyRecord(value) {
  return plain(value) && Object.keys(value).length === 0;
}
function applyDeleteAt(stat, segments, patch) {
  const current = getAt(stat, segments);
  if (segments.length > 0 && current === void 0) return;
  const necessary = metaValue(current, "necessary");
  const bypass = deleteBypass(patch);
  if (plain(patch) && Object.keys(patch).length > 0) {
    if (necessary === "all" && !bypass) return;
    for (const [key, value] of Object.entries(patch)) {
      if (necessary === "children" && emptyRecord(value) && !(key === "$meta" && bypass)) continue;
      applyDeleteAt(stat, [...segments, key], value);
    }
    return;
  }
  if (segments.length === 0 || necessary === "self" || necessary === "all") return;
  unsetAt(stat, segments);
}
function functionDiagnostic(code, message, commandIndex, name) {
  return diagnostic(code, message, commandIndex, name);
}
function functionMetaInvalid(value) {
  const meta = plain(value) && plain(value.$meta) ? value.$meta : null;
  if (!meta) return null;
  if (Object.prototype.hasOwnProperty.call(meta, "unInsertAble")) return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.unInsertAble\u3002";
  if (meta.necessary === "children") return "\u51FD\u6570\u662F\u5E73\u9762\u5B9E\u4F53\uFF0C\u4E0D\u652F\u6301 $meta.necessary: children\u3002";
  return null;
}
function validateFunctions(library) {
  const result = executeExpressionLayer({ initialState: {}, functionLibrary: library, operations: [] });
  const issue = result.diagnostics[0];
  return issue ? diagnostic(issue.code, issue.message, void 0, "<library>") : null;
}
function editFunction(current, patch) {
  if (!plain(current) || !plain(patch)) return clone(patch);
  const patchMeta = plain(patch.$meta) ? patch.$meta : null;
  if (Object.keys(patch).length === 1 && patchMeta) {
    const next2 = clone(current);
    next2.$meta = merge(current.$meta, patchMeta);
    return next2;
  }
  const next = clone(patch);
  if (!Object.prototype.hasOwnProperty.call(patch, "$meta") && Object.prototype.hasOwnProperty.call(current, "$meta")) next.$meta = clone(current.$meta);
  else if (patchMeta) next.$meta = merge(current.$meta, patchMeta);
  return next;
}
function applyFunction(library, type, data, diagnostics, commandIndex) {
  let current = clone(library);
  for (const root of data) {
    if (Object.keys(root).length === 0) {
      diagnostics.push(functionDiagnostic("ERA_FUNCTION_COMMAND_INVALID", "\u51FD\u6570\u6307\u4EE4\u5FC5\u987B\u662F\u975E\u7A7A\u5BF9\u8C61\u3002", commandIndex));
      continue;
    }
    const candidate = clone(current);
    const issues = [];
    for (const [name, patch] of Object.entries(root)) {
      const exists = Object.prototype.hasOwnProperty.call(current, name);
      if (type === "function-insert") {
        if (exists) {
          issues.push(functionDiagnostic("ERA_FUNCTION_ALREADY_EXISTS", "FunctionInsert \u53EA\u80FD\u65B0\u589E\u4E0D\u5B58\u5728\u7684\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        const invalid2 = functionMetaInvalid(patch);
        if (invalid2) {
          issues.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = clone(patch);
      } else if (type === "function-edit") {
        if (!exists) {
          issues.push(functionDiagnostic("ERA_FUNCTION_NOT_FOUND", "FunctionEdit \u53EA\u80FD\u4FEE\u6539\u65E2\u6709\u51FD\u6570\u3002", commandIndex, name));
          continue;
        }
        if (metaValue(current[name], "updatable") === false && !(plain(patch) && plain(patch.$meta) && patch.$meta.updatable === true)) continue;
        const next = editFunction(current[name], patch);
        const invalid2 = functionMetaInvalid(next);
        if (invalid2) {
          issues.push(functionDiagnostic("ERA_FUNCTION_META_UNSUPPORTED", invalid2, commandIndex, name));
          continue;
        }
        candidate[name] = next;
      } else {
        if (!plain(patch)) {
          issues.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
          continue;
        }
        if (Object.keys(patch).length === 0) {
          if (exists && !["self", "all"].includes(String(metaValue(current[name], "necessary")))) delete candidate[name];
        } else if (Object.keys(patch).length === 1 && plain(patch.$meta) && exists) {
          const next = clone(current[name]);
          const metaPatch = patch.$meta;
          if (plain(next.$meta)) {
            for (const key of Object.keys(metaPatch)) delete next.$meta[key];
          }
          candidate[name] = next;
        } else issues.push(functionDiagnostic("ERA_FUNCTION_DELETE_INVALID", "FunctionDelete \u7684\u51FD\u6570\u503C\u5FC5\u987B\u662F\u7A7A\u5BF9\u8C61\u3002", commandIndex, name));
      }
    }
    if (issues.length > 0) {
      diagnostics.push(...issues);
      continue;
    }
    const invalid = validateFunctions(candidate);
    if (invalid) {
      diagnostics.push({ ...invalid, commandIndex });
      continue;
    }
    current = candidate;
  }
  return current;
}
function replayCommand(command, state) {
  if (command.kind === "insert") {
    for (const patch of command.data) applyInsertAt(state.stat, [], patch);
  } else if (command.kind === "edit") {
    for (const patch of command.data) applyEditAt(state.stat, state.start, state.functions, state.startFunctions, [], patch, state.diagnostics, command.index, state.randomCursor);
  } else if (command.kind === "delete") {
    for (const patch of command.data) applyDeleteAt(state.stat, [], patch);
  } else {
    return applyFunction(state.functions, command.kind, command.data, state.diagnostics, command.index);
  }
  return state.functions;
}
function executeOriginalSemantics(parsed) {
  const stat = clone(parsed.request.initialStatData);
  const start = clone(parsed.request.snapshotStatData ?? parsed.request.initialStatData);
  let functions = clone(parsed.request.initialStatFunc ?? {});
  const startFunctions = clone(parsed.request.snapshotStatFunc ?? parsed.request.initialStatFunc ?? {});
  const diagnostics = [...parsed.diagnostics];
  const randomCursor = parsed.request.randomContext ? { ...parsed.request.randomContext } : null;
  for (const command of parsed.commands) {
    if (command.data.length === 0) continue;
    functions = replayCommand(command, { stat, start, functions, startFunctions, diagnostics, randomCursor });
  }
  return {
    ...parsed,
    finalStatData: stat,
    finalStatFunc: functions,
    diagnostics,
    nextRandomDrawOffset: randomCursor?.drawOffset ?? parsed.request.randomContext?.drawOffset ?? 0
  };
}
function hasMeta(value) {
  if (!plain(value)) return false;
  if (Object.prototype.hasOwnProperty.call(value, "$meta") || Object.prototype.hasOwnProperty.call(value, "$template")) return true;
  return Object.values(value).some(hasMeta);
}
function flattenNumericEdits(patch, prefix = [], output = []) {
  if (!plain(patch)) return false;
  if (Object.prototype.hasOwnProperty.call(patch, "$meta") || Object.prototype.hasOwnProperty.call(patch, "$template")) return false;
  if (Object.keys(patch).length === 1 && typeof patch.$expr === "string") {
    if (prefix.length === 0) return false;
    output.push({ path: prefix.join("."), expr: patch.$expr, source: "expr" });
    return true;
  }
  for (const [key, value] of Object.entries(patch)) {
    if (plain(value)) {
      if (!flattenNumericEdits(value, [...prefix, key], output)) return false;
    } else if (typeof value === "number" && Number.isFinite(value)) output.push({ path: [...prefix, key].join("."), expr: JSON.stringify(value), source: "literal", literal: value });
    else return false;
  }
  return output.length > 0;
}
function nestingRecord(paths) {
  const result = {};
  for (const item of paths) {
    const parts = item.path.split(".");
    let cursor = result;
    for (const part of parts.slice(0, -1)) {
      if (Object.prototype.hasOwnProperty.call(cursor, part) && !plain(cursor[part])) return null;
      cursor[part] ??= {};
      cursor = cursor[part];
    }
    const leaf = parts[parts.length - 1];
    if (plain(cursor[leaf])) return null;
    cursor[leaf] = item.value;
  }
  return result;
}
function renderTag(tag, data) {
  return `<${tag}>
${JSON.stringify(data)}
</${tag}>`;
}
function mergeInsertPatch(left, right) {
  if (!plain(left) || !plain(right) || hasMeta(left) || hasMeta(right)) return null;
  const output = clone(left);
  for (const [key, value] of Object.entries(right)) {
    if (!Object.prototype.hasOwnProperty.call(output, key)) {
      output[key] = clone(value);
      continue;
    }
    if (!plain(value)) continue;
    if (!plain(output[key])) {
      return null;
    }
    const merged = mergeInsertPatch(output[key], value);
    if (merged === null) return null;
    output[key] = merged;
  }
  return output;
}
function allCommandData(command) {
  if (command.data.length !== 1) return null;
  return command.data[0] ?? null;
}
function renderCompactedEdits(operations, compacted) {
  const sourceByPath = /* @__PURE__ */ new Map();
  const lastLiteralByPath = /* @__PURE__ */ new Map();
  for (const operation of operations) {
    const prior = sourceByPath.get(operation.path);
    sourceByPath.set(operation.path, prior === void 0 || prior === operation.source ? operation.source : "mixed");
    if (operation.source === "literal") lastLiteralByPath.set(operation.path, operation.literal);
  }
  if ([...sourceByPath.values()].includes("mixed")) return null;
  const output = nestingRecord(compacted.map((item) => {
    const source = sourceByPath.get(item.path);
    return source === "literal" ? { path: item.path, value: lastLiteralByPath.get(item.path) } : { path: item.path, value: { $expr: item.value.$expr } };
  }));
  return output && Object.keys(output).length > 0 ? renderTag("VariableEdit", output) : "";
}
function compactEditRun(trace, commands) {
  const operations = [];
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data || !flattenNumericEdits(data, [], operations)) return null;
  }
  const response = executeExpressionLayer2({
    initialState: trace.request.initialStatData,
    snapshotState: trace.request.snapshotStatData ?? trace.request.initialStatData,
    functionLibrary: trace.request.initialStatFunc ?? {},
    snapshotFunctionLibrary: trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {},
    allowSnapshots: true,
    operations,
    ...trace.request.randomContext ? { randomContext: trace.request.randomContext } : {}
  });
  if (response.diagnostics.length > 0) return null;
  return renderCompactedEdits(operations, response.compactedOperations);
}
function pathConflict(left, right) {
  return left === right || left.startsWith(`${right}.`) || right.startsWith(`${left}.`);
}
function operationRefs(ast) {
  const refs = /* @__PURE__ */ new Set();
  const visit = (item) => {
    if (item.kind === "ref") {
      if (!item.snapshot) refs.add(item.path.join("."));
      return;
    }
    if (item.kind === "unary") visit(item.value);
    else if (item.kind === "binary") {
      visit(item.left);
      visit(item.right);
    } else if (item.kind === "call") for (const arg of item.args) visit(arg);
  };
  visit(ast);
  return [...refs];
}
function commandExpressionFacts(trace, command) {
  const operations = [];
  const data = allCommandData(command);
  if (!data || !flattenNumericEdits(data, [], operations))
    return { automaticRandom: false, paths: [], refs: [], flattenable: false };
  const current = compileFunctionLibrary2(trace.request.initialStatFunc ?? {});
  const snapshot = compileFunctionLibrary2(
    trace.request.snapshotStatFunc ?? trace.request.initialStatFunc ?? {}
  );
  const refs = /* @__PURE__ */ new Set();
  let automaticRandom = false;
  for (const operation of operations) {
    const parsed = parseExpression2(operation.expr, true);
    if (!parsed.ast) continue;
    if (countAutomaticRandomDraws2(parsed.ast, current, snapshot) > 0)
      automaticRandom = true;
    for (const ref of operationRefs(parsed.ast)) refs.add(ref);
  }
  return {
    automaticRandom,
    paths: operations.map((operation) => operation.path),
    refs: [...refs],
    flattenable: true
  };
}
function segmentDoesNotDependOnPriorChanges(facts, priorPaths) {
  return facts.every(
    (fact) => fact.refs.every(
      (ref) => ![...priorPaths].some((path) => pathConflict(ref, path))
    )
  );
}
function compactInsertRun(commands) {
  let merged = {};
  for (const command of commands) {
    const data = allCommandData(command);
    if (!data) return null;
    const next = mergeInsertPatch(merged, data);
    if (next === null) return null;
    merged = next;
  }
  return plain(merged) && Object.keys(merged).length > 0 ? renderTag("VariableInsert", merged) : null;
}
function candidateFor(analysis) {
  const { trace } = analysis;
  const replacements = /* @__PURE__ */ new Map();
  const reasons = [];
  if (trace.diagnostics.length > 0) return { ...trace, replacements, reasons: ["\u539F\u547D\u4EE4\u542B\u8BCA\u65AD\uFF0C\u4FDD\u7559\u5168\u90E8\u6807\u7B7E\u3002"] };
  let cursor = 0;
  while (cursor < trace.commands.length) {
    const kind = trace.commands[cursor].kind;
    let end = cursor + 1;
    while (end < trace.commands.length && trace.commands[end].kind === kind) end += 1;
    const run12 = trace.commands.slice(cursor, end);
    let replacement = null;
    if (kind === "edit") {
      if (cursor === 0) {
        const facts = run12.map((command) => analysis.facts[command.index]);
        const priorPaths = /* @__PURE__ */ new Set();
        let segmentStart = 0;
        const compactSegment = (segmentEnd) => {
          if (segmentEnd <= segmentStart) return;
          const segment = run12.slice(segmentStart, segmentEnd);
          const segmentFacts = facts.slice(segmentStart, segmentEnd);
          if (segmentFacts.every((fact) => fact.flattenable) && segmentDoesNotDependOnPriorChanges(segmentFacts, priorPaths)) {
            const compacted = compactEditRun(trace, segment);
            if (compacted !== null && (segment.length > 1 || compacted !== segment[0].raw)) {
              replacements.set(segment[0].index, compacted);
              for (const command of segment.slice(1))
                replacements.set(command.index, "");
            }
          } else {
            reasons.push(
              `${segment.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u4F9D\u8D56\u968F\u673A\u5C4F\u969C\u6216\u66F4\u65E9\u547D\u4EE4\u6539\u53D8\u7684\u8DEF\u5F84\u3002`
            );
          }
          for (const fact of segmentFacts)
            for (const path of fact.paths) priorPaths.add(path);
        };
        for (let index = 0; index < run12.length; index += 1) {
          if (!facts[index].automaticRandom) continue;
          compactSegment(index);
          for (const path of facts[index].paths) priorPaths.add(path);
          reasons.push(`${run12[index].tag} \u4FDD\u7559\uFF1A\u5305\u542B\u81EA\u52A8 random \u8C03\u7528\u3002`);
          segmentStart = index + 1;
        }
        compactSegment(run12.length);
        replacement = null;
      } else
        reasons.push(`${run12.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u524D\u5E8F\u547D\u4EE4\u4F1A\u6539\u53D8\u8BE5\u533A\u95F4\u7684\u5C42\u8D77\u59CB\u8BED\u4E49\u3002`);
    } else if (kind === "insert") replacement = compactInsertRun(run12);
    else reasons.push(`${run12.map((command) => command.tag).join("/")} \u4FDD\u7559\uFF1A\u5C1A\u65E0\u53EF\u8BC1\u660E\u7684\u901A\u7528\u91CD\u5199\u89C4\u5219\u3002`);
    if (replacement !== null && (run12.length > 1 || replacement !== run12[0].raw)) {
      replacements.set(run12[0].index, replacement);
      for (const command of run12.slice(1)) replacements.set(command.index, "");
    }
    cursor = end;
  }
  return { ...trace, replacements, reasons };
}
function render(trace, replacements) {
  let content = trace.request.content;
  for (const command of [...trace.commands].sort((left, right) => right.start - left.start)) {
    const replacement = replacements.get(command.index);
    if (replacement !== void 0) content = `${content.slice(0, command.start)}${replacement}${content.slice(command.end)}`;
  }
  return content;
}
function equivalent(trace, content) {
  const replay = executeOriginalSemantics(parseCommandLayer({ ...trace.request, content }));
  const sameDiagnostics = replay.diagnostics.length === trace.diagnostics.length && replay.diagnostics.every((issue, index) => {
    const expected = trace.diagnostics[index];
    return expected !== void 0 && issue.code === expected.code && issue.path === expected.path;
  });
  return sameDiagnostics && equal(replay.finalStatData, trace.finalStatData) && equal(replay.finalStatFunc, trace.finalStatFunc) && replay.nextRandomDrawOffset === trace.nextRandomDrawOffset;
}
function analyzeDependencies(trace) {
  const facts = {};
  if (trace.diagnostics.length === 0) {
    for (const command of trace.commands) {
      if (command.kind !== "edit") break;
      facts[command.index] = commandExpressionFacts(trace, command);
    }
  }
  return { trace, facts };
}
function scopedTransactions(content) {
  const result = [];
  const pattern = /<era_tx\b([^>]*)>([\s\S]*?)<\/era_tx>/giu;
  let match;
  while ((match = pattern.exec(content)) !== null) {
    const scopeMatch = /\bs\s*=\s*["']([^"']+)["']/iu.exec(match[1] ?? "");
    const rawScope = scopeMatch?.[1] ?? "";
    result.push({
      start: match.index,
      end: match.index + match[0].length,
      raw: match[0],
      body: match[2] ?? "",
      scope: rawScope === "m" || rawScope === "b" || rawScope === "a" ? rawScope : null
    });
  }
  return result;
}
function withStartState(request, content, statData, statFunc) {
  return {
    ...request,
    content,
    initialStatData: statData,
    initialStatFunc: statFunc
  };
}
function groupedTransaction(transactions, content, index) {
  const current = transactions[index];
  let endIndex = index;
  let text = current.body;
  let raw = current.raw;
  if (current.scope === null) return { endIndex, text, raw };
  while (endIndex + 1 < transactions.length) {
    const next = transactions[endIndex + 1];
    const between = content.slice(transactions[endIndex].end, next.start);
    if (next.scope !== current.scope || between.trim().length > 0) break;
    text += `${between}${next.body}`;
    raw += `${between}${next.raw}`;
    endIndex += 1;
  }
  return { endIndex, text, raw };
}
function parseLayer(input) {
  const parsed = parseCommandLayer(input);
  const transactions = scopedTransactions(parsed.request.content);
  if (transactions.length === 0)
    return {
      ...parsed,
      scoped: false,
      segments: [
        {
          text: parsed.request.content,
          raw: parsed.request.content,
          scope: null,
          allowRewrite: true
        }
      ]
    };
  const segments = [];
  let cursor = 0;
  for (let index = 0; index < transactions.length; ) {
    const current = transactions[index];
    const prefix = parsed.request.content.slice(cursor, current.start);
    segments.push({
      text: prefix,
      raw: prefix,
      scope: null,
      allowRewrite: true
    });
    const { endIndex, text, raw } = groupedTransaction(
      transactions,
      parsed.request.content,
      index
    );
    segments.push({
      text,
      raw,
      scope: current.scope,
      allowRewrite: current.scope !== null && endIndex > index
    });
    cursor = transactions[endIndex].end;
    index = endIndex + 1;
  }
  const tail = parsed.request.content.slice(cursor);
  segments.push({ text: tail, raw: tail, scope: null, allowRewrite: true });
  return { ...parsed, segments, scoped: true };
}
function initializeSegments(parsed) {
  return {
    cursor: 0,
    segments: parsed.segments,
    request: parsed.request,
    parsed,
    statData: clone(parsed.request.initialStatData),
    statFunc: clone(parsed.request.initialStatFunc ?? {}),
    drawOffset: parsed.request.randomContext?.drawOffset ?? 0,
    parts: [],
    diagnostics: [],
    reasons: [],
    changed: false,
    commandSegments: 0,
    rewrittenSegments: 0,
    lastResult: null
  };
}
function selectSegment(state) {
  const segment = state.segments[state.cursor];
  if (!state.parsed.scoped) return parseCommandLayer(state.request);
  const request = {
    ...state.request,
    ...state.request.randomContext ? {
      randomContext: {
        sourceKey: state.request.randomContext.sourceKey,
        drawOffset: state.drawOffset
      }
    } : {}
  };
  return parseCommandLayer(
    withStartState(request, segment.text, state.statData, state.statFunc)
  );
}
function rewriteSegment(analysis) {
  const candidate = candidateFor(analysis);
  return { ...candidate, replacements: [...candidate.replacements] };
}
function verifySegment(candidate) {
  const replacements = new Map(candidate.replacements);
  const base = {
    content: candidate.request.content,
    finalStatData: candidate.finalStatData,
    finalStatFunc: candidate.finalStatFunc,
    diagnostics: candidate.diagnostics,
    parsedCommands: candidate.commands,
    nextRandomDrawOffset: candidate.nextRandomDrawOffset
  };
  if (parseCommandLayer(candidate.request).diagnostics.length > 0)
    return {
      ...base,
      status: "invalid",
      reasons: ["\u6807\u7B7E JSON \u65E0\u6548\uFF0C\u672A\u6539\u5199\u6D88\u606F\u3002"]
    };
  if (replacements.size === 0)
    return {
      ...base,
      status: "unchanged",
      reasons: candidate.reasons.length ? candidate.reasons : ["\u6CA1\u6709\u53EF\u8BC1\u660E\u5B89\u5168\u7684\u7F29\u5199\u3002"]
    };
  const content = render(candidate, replacements);
  if (!equivalent(candidate, content))
    return {
      ...base,
      status: "unchanged",
      reasons: [
        ...candidate.reasons,
        "\u5019\u9009\u672A\u901A\u8FC7\u540C\u4E00\u8D77\u70B9\u771F\u5B9E\u91CD\u653E\uFF0C\u5DF2\u9000\u56DE\u539F\u547D\u4EE4\u3002"
      ]
    };
  return {
    ...base,
    content,
    status: candidate.commands.every(
      (command) => replacements.has(command.index)
    ) ? "compacted" : "partial",
    reasons: candidate.reasons
  };
}
function advanceSegment(state, result) {
  const segment = state.segments[state.cursor];
  const hasCommands = result.parsedCommands.length > 0;
  const changed = hasCommands && segment.allowRewrite && result.content !== segment.text && result.diagnostics.length === 0;
  const text = changed ? segment.scope === null ? result.content : `<era_tx s="${segment.scope}">${result.content}</era_tx>` : segment.raw;
  return {
    ...state,
    cursor: state.cursor + 1,
    statData: clone(result.finalStatData),
    statFunc: clone(result.finalStatFunc),
    drawOffset: result.nextRandomDrawOffset,
    parts: [...state.parts, text],
    diagnostics: [...state.diagnostics, ...result.diagnostics],
    reasons: [...state.reasons, ...result.reasons],
    changed: state.changed || changed,
    commandSegments: state.commandSegments + Number(hasCommands),
    rewrittenSegments: state.rewrittenSegments + Number(changed),
    lastResult: result
  };
}
function verifyLayer(state) {
  if (!state.parsed.scoped) return state.lastResult;
  const originalTrace = executeOriginalSemantics(state.parsed);
  const content = state.parts.join("");
  const replay = executeOriginalSemantics(
    parseCommandLayer({ ...state.request, content })
  );
  const equivalentResult = equal(originalTrace.finalStatData, replay.finalStatData) && equal(originalTrace.finalStatFunc, replay.finalStatFunc) && originalTrace.nextRandomDrawOffset === replay.nextRandomDrawOffset && originalTrace.diagnostics.length === replay.diagnostics.length && originalTrace.diagnostics.every(
    (issue, index) => issue.code === replay.diagnostics[index]?.code && issue.path === replay.diagnostics[index]?.path
  );
  const base = {
    finalStatData: originalTrace.finalStatData,
    finalStatFunc: originalTrace.finalStatFunc,
    diagnostics: originalTrace.diagnostics,
    parsedCommands: state.parsed.commands,
    nextRandomDrawOffset: originalTrace.nextRandomDrawOffset
  };
  if (!state.changed || !equivalentResult)
    return {
      ...base,
      status: state.diagnostics.length > 0 ? "invalid" : "unchanged",
      content: state.request.content,
      reasons: equivalentResult ? state.reasons : [
        ...state.reasons,
        "\u540C scope \u5206\u6BB5\u5019\u9009\u672A\u901A\u8FC7\u6574\u5C42\u771F\u5B9E\u91CD\u653E\uFF0C\u5DF2\u4FDD\u7559\u539F\u4E8B\u52A1\u3002"
      ]
    };
  return {
    ...base,
    status: state.rewrittenSegments === state.commandSegments ? "compacted" : "partial",
    content,
    reasons: state.reasons
  };
}
function run2(inputs) {
  return { parsed: parseLayer(inputs["era.command_compaction.request"].value) };
}
function run3(inputs) {
  return {
    segment_state: initializeSegments(
      inputs["era.command_compaction.parsed"].value
    )
  };
}
function run4(inputs) {
  const state = inputs["era.command_compaction.segment.state"].value;
  return { parsed: selectSegment(state), segment_state_before: state };
}
function run5(inputs) {
  return {
    trace: executeOriginalSemantics(
      inputs["era.command_compaction.parsed"].value
    )
  };
}
function run6(inputs) {
  return {
    symbols: analyzeDependencies(
      inputs["era.command_compaction.semantic_trace"].value
    )
  };
}
function run7(inputs) {
  return {
    candidate: rewriteSegment(
      inputs["era.command_compaction.symbols"].value
    )
  };
}
function run8(inputs) {
  return {
    verified: verifySegment(
      inputs["era.command_compaction.candidate"].value
    )
  };
}
function run9(inputs) {
  const next = advanceSegment(
    inputs["era.command_compaction.segment.state.before"].value,
    inputs["era.command_compaction.verified"].value
  );
  return {
    segment_state_next: next,
    segment_done: next.cursor >= next.segments.length
  };
}
function run10(inputs) {
  return {
    verified: verifyLayer(
      inputs["era.command_compaction.segment.state"].value
    )
  };
}
function run11(inputs) {
  return {
    compaction_response: inputs["era.command_compaction.verified"].value
  };
}
var __vfConsoleKey = /* @__PURE__ */ Symbol.for("vibeflow.console.observation.v1");
function __vfConsoleStorage() {
  if (!globalThis[__vfConsoleKey]) {
    const storage = new __vfAsyncLocalStorage();
    globalThis[__vfConsoleKey] = storage;
    for (const stream of [process.stdout, process.stderr]) {
      const original = stream.write;
      stream.write = function(chunk, ...args) {
        storage.getStore()?.business(chunk);
        return original.call(this, chunk, ...args);
      };
    }
  }
  return globalThis[__vfConsoleKey];
}
var __vfHeartbeatSource = `
const {workerData, parentPort} = require('node:worker_threads');
const fs = require('node:fs');
const flags = new Int32Array(workerData.flags);
let record = workerData.record;
parentPort.on('message', value => {record = value;});
const timer = setInterval(() => {
  if (Atomics.compareExchange(flags, 1, 0, 1) !== 0) return;
  try {
    if (Atomics.load(flags, 0)) {clearInterval(timer); return;}
    const temporary = workerData.file + '.heartbeat-' + process.pid;
    fs.writeFileSync(temporary, JSON.stringify({...record, updated_at: new Date().toISOString()}) + '\\n');
    fs.renameSync(temporary, workerData.file);
  } catch (error) {
    parentPort.postMessage({error: String(error)});
    clearInterval(timer);
  } finally {
    Atomics.store(flags, 1, 0); Atomics.notify(flags, 1);
  }
}, workerData.interval);
`;
function __vfCreateFileObservation(options, initial, interval) {
  const runDir = __vfPath.resolve(options.runDir ?? __vfPath.join("runs", (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-") + "_" + __vfUuid()));
  const file = __vfPath.resolve(options.statusFile ?? __vfPath.join(runDir, "status.json"));
  __vfFs.mkdirSync(runDir, { recursive: true });
  __vfFs.mkdirSync(__vfPath.dirname(file), { recursive: true });
  const businessFd = __vfFs.openSync(__vfPath.join(runDir, "business.log"), "w");
  const kernelFd = __vfFs.openSync(__vfPath.join(runDir, "vibeflow.log"), "w");
  const flags = new Int32Array(new SharedArrayBuffer(8));
  let worker;
  let heartbeatError;
  let closed = false;
  const storage = __vfConsoleStorage();
  function write(record2) {
    if (heartbeatError) throw heartbeatError;
    while (Atomics.compareExchange(flags, 1, 0, 1) !== 0) Atomics.wait(flags, 1, 1, 100);
    const temporary = file + ".main-" + process.pid + "-" + __vfUuid();
    try {
      __vfFs.writeFileSync(temporary, JSON.stringify(record2) + "\n");
      __vfFs.renameSync(temporary, file);
    } finally {
      if (__vfFs.existsSync(temporary)) __vfFs.unlinkSync(temporary);
      Atomics.store(flags, 1, 0);
      Atomics.notify(flags, 1);
    }
  }
  const sink = {
    business(chunk) {
      if (!closed) __vfFs.writeSync(businessFd, typeof chunk === "string" ? chunk : Buffer.from(chunk));
    },
    kernel(text) {
      if (!closed) __vfFs.writeSync(kernelFd, text + "\n");
    },
    run(callback) {
      return storage.run(sink, callback);
    },
    cache(record2) {
      worker?.postMessage(record2);
    },
    publish(record2) {
      sink.kernel("STATE " + record2.state);
      write(record2);
      worker?.postMessage(record2);
    },
    finish(record2) {
      Atomics.store(flags, 0, 1);
      sink.publish(record2);
    },
    close() {
      if (closed) return;
      closed = true;
      Atomics.store(flags, 0, 1);
      worker?.terminate();
      __vfFs.closeSync(businessFd);
      __vfFs.closeSync(kernelFd);
    }
  };
  try {
    write(initial);
    worker = new __vfStatusWorker(__vfHeartbeatSource, { eval: true, workerData: {
      record: initial,
      file,
      interval,
      flags: flags.buffer
    } });
    worker.on("message", (message) => {
      if (message.error) heartbeatError = new Error(message.error);
    });
    worker.on("error", (error) => {
      heartbeatError = error;
    });
    worker.unref();
    return sink;
  } catch (error) {
    sink.close();
    throw error;
  }
}
var VIBEFLOW_WORKFLOW_ABI = "vibeflow.workflow.v5";
var VIBEFLOW_PLUGIN_ABI = "vibeflow.plugin.v3";
var VibeFlowWorkflowError = class extends Error {
  constructor(code, message, details = {}) {
    const options = details.cause === void 0 ? void 0 : { cause: details.cause };
    super(message, options);
    this.name = "VibeFlowWorkflowError";
    this.code = code;
    this.workflowId = details.workflowId || "";
    this.nodePath = details.nodePath || "";
    this.blockPath = details.blockPath || "";
  }
};
function vfError(code, message, workflow, details = {}) {
  return new VibeFlowWorkflowError(code, message, {
    workflowId: workflow.workflow_id,
    ...details
  });
}
function throwIfAborted(signal, workflow, nodePath2 = "", blockPath = "") {
  if (!signal?.aborted) return;
  throw vfError("VF_ABORTED", "workflow execution was aborted", workflow, {
    nodePath: nodePath2,
    blockPath,
    cause: signal.reason
  });
}
async function awaitWithAbort(value, signal, workflow, nodePath2 = "", blockPath = "") {
  throwIfAborted(signal, workflow, nodePath2, blockPath);
  if (!signal) return await value;
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(vfError(
      "VF_ABORTED",
      "workflow execution was aborted",
      workflow,
      { nodePath: nodePath2, blockPath, cause: signal.reason }
    ));
    signal.addEventListener("abort", onAbort, { once: true });
  });
  try {
    return await Promise.race([Promise.resolve(value), aborted]);
  } finally {
    signal.removeEventListener("abort", onAbort);
  }
}
function assertObject(value, code, message, workflow) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw vfError(code, message, workflow);
  }
}
function dictionary() {
  return /* @__PURE__ */ Object.create(null);
}
function setOwn(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    enumerable: true,
    configurable: true,
    writable: true
  });
  return target;
}
function validateJsonSchema(value, schema, path = "$") {
  if (!schema || typeof schema !== "object") return "";
  if (Array.isArray(schema.enum) && !schema.enum.some((item) => jsonEquals(item, value))) {
    return `${path} is not one of the allowed values`;
  }
  if (Object.prototype.hasOwnProperty.call(schema, "const") && !jsonEquals(schema.const, value)) {
    return `${path} does not equal the required constant`;
  }
  if (Array.isArray(schema.allOf)) {
    for (const child of schema.allOf) {
      const failure = validateJsonSchema(value, child, path);
      if (failure) return failure;
    }
  }
  if (Array.isArray(schema.anyOf)) {
    if (!schema.anyOf.some((child) => !validateJsonSchema(value, child, path))) {
      return `${path} does not match any allowed schema`;
    }
  }
  if (Array.isArray(schema.oneOf)) {
    const matches = schema.oneOf.filter((child) => !validateJsonSchema(value, child, path)).length;
    if (matches !== 1) return `${path} must match exactly one allowed schema`;
  }
  const allowedTypes = Array.isArray(schema.type) ? schema.type : schema.type ? [schema.type] : [];
  if (allowedTypes.length && !allowedTypes.some((type) => jsonTypeMatches(value, type))) {
    return `${path} has type ${jsonType(value)}, expected ${allowedTypes.join(" or ")}`;
  }
  if (typeof value === "string") {
    const length = [...value].length;
    if (Number.isInteger(schema.minLength) && length < schema.minLength) {
      return `${path} is shorter than minLength=${schema.minLength}`;
    }
    if (Number.isInteger(schema.maxLength) && length > schema.maxLength) {
      return `${path} is longer than maxLength=${schema.maxLength}`;
    }
    if (typeof schema.pattern === "string" && !new RegExp(schema.pattern).test(value)) {
      return `${path} does not match pattern`;
    }
  }
  if (typeof value === "number") {
    if (typeof schema.minimum === "number" && value < schema.minimum) {
      return `${path} is less than minimum=${schema.minimum}`;
    }
    if (typeof schema.maximum === "number" && value > schema.maximum) {
      return `${path} is greater than maximum=${schema.maximum}`;
    }
  }
  if (Array.isArray(value)) {
    if (Number.isInteger(schema.minItems) && value.length < schema.minItems) {
      return `${path} has fewer than minItems=${schema.minItems}`;
    }
    if (Number.isInteger(schema.maxItems) && value.length > schema.maxItems) {
      return `${path} has more than maxItems=${schema.maxItems}`;
    }
    if (schema.items && typeof schema.items === "object") {
      for (let index = 0; index < value.length; index += 1) {
        const failure = validateJsonSchema(value[index], schema.items, `${path}[${index}]`);
        if (failure) return failure;
      }
    }
  }
  if (value !== null && typeof value === "object" && !Array.isArray(value)) {
    const properties = schema.properties && typeof schema.properties === "object" ? schema.properties : {};
    if (Array.isArray(schema.required)) {
      for (const key of schema.required) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) {
          return `${path}.${key} is required`;
        }
      }
    }
    for (const [key, childValue] of Object.entries(value)) {
      if (Object.prototype.hasOwnProperty.call(properties, key)) {
        const failure = validateJsonSchema(childValue, properties[key], `${path}.${key}`);
        if (failure) return failure;
      } else if (schema.additionalProperties === false) {
        return `${path}.${key} is not allowed`;
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        const failure = validateJsonSchema(childValue, schema.additionalProperties, `${path}.${key}`);
        if (failure) return failure;
      }
    }
  }
  return "";
}
function jsonEquals(left, right) {
  if (left === right) return true;
  if (left === null || right === null || typeof left !== typeof right) return false;
  if (Array.isArray(left) || Array.isArray(right)) {
    return Array.isArray(left) && Array.isArray(right) && left.length === right.length && left.every((item, index) => jsonEquals(item, right[index]));
  }
  if (typeof left !== "object") return false;
  const leftKeys = Object.keys(left).sort();
  const rightKeys = Object.keys(right).sort();
  return leftKeys.length === rightKeys.length && leftKeys.every(
    (key, index) => key === rightKeys[index] && jsonEquals(left[key], right[key])
  );
}
function jsonTypeMatches(value, expected) {
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "integer") return Number.isInteger(value);
  if (expected === "number") return typeof value === "number" && Number.isFinite(value);
  return typeof value === expected;
}
function jsonType(value) {
  if (value === null) return "null";
  if (Array.isArray(value)) return "array";
  if (Number.isInteger(value)) return "integer";
  return typeof value;
}
function formatBlockPath(path) {
  if (!path.length) return "/";
  const segments = path.map((item) => String(item).replaceAll("~", "~0").replaceAll("/", "~1"));
  return `/${segments.join("/")}`;
}
function nodePath(state, nodeId) {
  return [...state.path, nodeId].join(".");
}
function ensureErrorLocation(cause, workflow, path, nodeId = "") {
  const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
  if (!failure.nodePath && nodeId) failure.nodePath = [...path, nodeId].join(".");
  if (!failure.blockPath) failure.blockPath = formatBlockPath(path);
  return failure;
}
function emitTrace(root, kind, details = {}, boundary = false) {
  if (root.traceMode === "off") return;
  if (root.traceMode !== "full" && !boundary) return;
  const event = Object.freeze({
    kind,
    workflowId: root.workflowId,
    ...details
  });
  root.kernelLog?.(event);
  if (!root.onTrace) return;
  try {
    root.onTrace(event);
  } catch (cause) {
    throw vfError(
      "VF_TRACE_SINK_FAILED",
      `trace callback failed during '${kind}'`,
      root.workflow,
      { cause }
    );
  }
}
function normalizeOptions(workflow, options) {
  const raw = options === void 0 ? {} : options;
  assertObject(raw, "VF_INTERNAL", "workflow options must be an object", workflow);
  const traceMode = raw.trace ?? "boundary";
  if (!["off", "boundary", "full"].includes(traceMode)) {
    throw vfError("VF_INTERNAL", `unsupported trace mode '${String(traceMode)}'`, workflow);
  }
  if (raw.onTrace !== void 0 && typeof raw.onTrace !== "function") {
    throw vfError("VF_INTERNAL", "options.onTrace must be a function", workflow);
  }
  const detachedTimeoutMs = raw.detachedTimeoutMs ?? 5e3;
  if (!Number.isFinite(detachedTimeoutMs) || detachedTimeoutMs < 0) {
    throw vfError("VF_INTERNAL", "options.detachedTimeoutMs must be a non-negative number", workflow);
  }
  return {
    signal: raw.signal,
    traceMode,
    onTrace: raw.onTrace,
    statusUpdate: raw.__vfStatusUpdate,
    kernelLog: raw.__vfKernelLog,
    capabilities: raw.capabilities ?? {},
    detachedTimeoutMs
  };
}
function capabilityLocation(caller) {
  return {
    nodePath: typeof caller?.nodePath === "string" ? caller.nodePath : "",
    blockPath: typeof caller?.blockPath === "string" ? caller.blockPath : ""
  };
}
function validateCapabilityInput(workflow, schemas, capabilityId, operationName, operationDescriptor, input, location) {
  const failure = validateJsonSchema(
    input,
    operationDescriptor.input_type ? schemas[operationDescriptor.input_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_INPUT",
      `capability '${capabilityId}.${operationName}' input failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
}
function validateCapabilityOutput(workflow, schemas, capabilityId, operationName, operationDescriptor, output, location) {
  const failure = validateJsonSchema(
    output,
    operationDescriptor.output_type ? schemas[operationDescriptor.output_type] : void 0
  );
  if (failure) {
    throw vfError(
      "VF_CAPABILITY_OUTPUT",
      `capability '${capabilityId}.${operationName}' output failed schema validation: ${failure}`,
      workflow,
      location
    );
  }
  return output;
}
function wrapCapabilityFailure(cause, workflow, root, capabilityId, operationName, location) {
  if (cause instanceof VibeFlowWorkflowError) throw cause;
  if (root.signal?.aborted) {
    throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
  }
  throw vfError(
    "VF_CAPABILITY_FAILED",
    `capability '${capabilityId}.${operationName}' failed`,
    workflow,
    { ...location, cause }
  );
}
function prepareCapabilities(workflow, descriptors, requirements, schemas, supplied, root, entryMode) {
  assertObject(
    supplied,
    "VF_CAPABILITY_MISSING",
    "options.capabilities must be an object",
    workflow
  );
  const wrapped = dictionary();
  for (const [capabilityId, operationNames] of Object.entries(requirements)) {
    const implementation = Object.prototype.hasOwnProperty.call(supplied, capabilityId) ? supplied[capabilityId] : void 0;
    if (!implementation || typeof implementation !== "object") {
      throw vfError(
        "VF_CAPABILITY_MISSING",
        `required capability '${capabilityId}' was not supplied`,
        workflow
      );
    }
    const descriptor = descriptors[capabilityId] || {};
    const capability = dictionary();
    for (const operationName of operationNames) {
      const callable = implementation[operationName];
      if (typeof callable !== "function") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `capability '${capabilityId}' is missing operation '${operationName}'`,
          workflow
        );
      }
      const operationDescriptor = descriptor.operations?.[operationName] || {};
      const completion = operationDescriptor.completion || "immediate";
      if (entryMode === "sync" && completion === "suspend") {
        throw vfError(
          "VF_CAPABILITY_MISSING",
          `sync workflow cannot use suspending capability '${capabilityId}.${operationName}'`,
          workflow
        );
      }
      if (completion === "suspend") {
        setOwn(capability, operationName, async (input, caller = {}) => {
          const location = capabilityLocation(caller);
          throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input,
            location
          );
          try {
            const output = await awaitWithAbort(
              callable.call(implementation, input, { signal: root.signal }),
              root.signal,
              workflow,
              location.nodePath,
              location.blockPath
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      } else {
        setOwn(capability, operationName, (input, caller = {}) => {
          const location = capabilityLocation(caller);
          throwIfAborted(root.signal, workflow, location.nodePath, location.blockPath);
          validateCapabilityInput(
            workflow,
            schemas,
            capabilityId,
            operationName,
            operationDescriptor,
            input,
            location
          );
          try {
            const output = callable.call(
              implementation,
              input,
              { signal: root.signal }
            );
            return validateCapabilityOutput(
              workflow,
              schemas,
              capabilityId,
              operationName,
              operationDescriptor,
              output,
              location
            );
          } catch (cause) {
            return wrapCapabilityFailure(
              cause,
              workflow,
              root,
              capabilityId,
              operationName,
              location
            );
          }
        });
      }
    }
    setOwn(wrapped, capabilityId, Object.freeze(capability));
  }
  return Object.freeze(wrapped);
}
function validatePublicInputs(workflow, inputs) {
  assertObject(inputs, "VF_INPUT_SCHEMA", "workflow inputs must be an object", workflow);
  const known = new Set(workflow.inputs.map((item) => item.key));
  for (const key of Object.keys(inputs)) {
    if (!known.has(key)) {
      throw vfError("VF_INPUT_UNKNOWN", `unknown workflow input '${key}'`, workflow);
    }
  }
  for (const input of workflow.inputs) {
    const present = Object.prototype.hasOwnProperty.call(inputs, input.key);
    if (input.required && !present) {
      throw vfError("VF_INPUT_REQUIRED", `required workflow input '${input.key}' is missing`, workflow);
    }
    if (!present) continue;
    const failure = validateJsonSchema(
      inputs[input.key],
      input.schema || workflow.schemas?.[input.type]
    );
    if (failure) {
      throw vfError(
        "VF_INPUT_SCHEMA",
        `workflow input '${input.key}' failed schema validation: ${failure}`,
        workflow
      );
    }
  }
}
function createEnvelope(key, type, value, sourceNode) {
  return Object.freeze({ key, type, value, source_node: sourceNode });
}
function createStaticState(workflow, initial, root, path) {
  validatePublicInputs(workflow, initial);
  return {
    workflow,
    root,
    path,
    inboxes: dictionary(),
    candidates: /* @__PURE__ */ new Map(),
    activeEdges: /* @__PURE__ */ new Set(),
    lastInputs: /* @__PURE__ */ new Map(),
    pending: /* @__PURE__ */ new Map(),
    nodeRuns: /* @__PURE__ */ new Map(),
    stepCount: 0,
    initial
  };
}
function initializeInbox(state, nodeId) {
  setOwn(state.inboxes, nodeId, []);
}
function seedInbox(state, nodeId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const input of state.workflow.inputs) {
    if (!accepted.has(input.type)) continue;
    if (!Object.prototype.hasOwnProperty.call(state.initial, input.key)) continue;
    state.inboxes[nodeId].push(
      createEnvelope(input.key, input.type, state.initial[input.key], "pipeline.input")
    );
  }
}
function requirementsFromInbox(node, state) {
  const inputs = dictionary();
  for (const requirement of node.requires) {
    const matches = state.inboxes[node.id].filter((item) => item.type === requirement.type);
    if (requirement.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' exactly once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0]);
    } else if (requirement.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `node '${node.id}' requires type '${requirement.type}' at most once, got ${matches.length}`,
          state.workflow,
          { nodePath: nodePath(state, node.id) }
        );
      }
      setOwn(inputs, requirement.type, matches[0] ?? null);
    } else {
      setOwn(inputs, requirement.type, [...matches]);
    }
  }
  return inputs;
}
function conditionValues(inputs, outputs) {
  const values = dictionary();
  for (const value of Object.values(inputs)) {
    const items = Array.isArray(value) ? value : [value];
    for (const item of items) {
      if (item && typeof item === "object" && "key" in item) {
        setOwn(values, item.key, item.value);
      }
    }
  }
  for (const [key, value] of Object.entries(outputs)) setOwn(values, key, value);
  return values;
}
function recordCandidate(state, envelope) {
  if (!state.workflow.outputs.some((output) => output.type === envelope.type)) return;
  const candidates = state.candidates.get(envelope.type) || [];
  const index = candidates.findIndex(
    (item) => item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node
  );
  if (index >= 0) candidates[index] = envelope;
  else candidates.push(envelope);
  state.candidates.set(envelope.type, candidates);
}
function validateNodeOutputs(node, outputs, state) {
  if (!outputs || typeof outputs !== "object" || Array.isArray(outputs)) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' must return an object`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  const expected = node.provides.map((item) => item.key).sort();
  const actual = Object.keys(outputs).sort();
  if (expected.length !== actual.length || expected.some((key, index) => key !== actual[index])) {
    throw vfError(
      "VF_OUTPUT_KEYS",
      `node '${node.id}' output keys must exactly match provides: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  for (const provider of node.provides) {
    const schema = state.workflow.schemas?.[provider.type];
    const failure = validateJsonSchema(outputs[provider.key], schema);
    if (failure) {
      throw vfError(
        "VF_OUTPUT_SCHEMA",
        `node '${node.id}' output '${provider.key}' failed data type schema validation: ${failure}`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
  }
  return outputs;
}
function outputEnvelopes(node, outputs) {
  return node.provides.map(
    (provider) => createEnvelope(provider.key, provider.type, outputs[provider.key], node.id)
  );
}
function deliverStatic(envelopes, state, targetId, acceptedTypes) {
  const accepted = new Set(acceptedTypes);
  for (const envelope of envelopes) {
    if (!accepted.has(envelope.type)) continue;
    state.inboxes[targetId] = state.inboxes[targetId].filter(
      (item) => !(item.key === envelope.key && item.type === envelope.type && item.source_node === envelope.source_node)
    );
    state.inboxes[targetId].push(envelope);
  }
}
function nodeContext(node, state) {
  const allowed = dictionary();
  for (const requirement of node.capabilities || []) {
    const capability = state.root.capabilities[requirement.id];
    if (!capability) continue;
    const contextual = dictionary();
    const requested = new Set(requirement.operations || []);
    for (const [operationName, operation] of Object.entries(capability)) {
      if (requested.size && !requested.has(operationName)) continue;
      setOwn(contextual, operationName, (input) => operation(input, {
        nodePath: nodePath(state, node.id),
        blockPath: formatBlockPath(state.path)
      }));
    }
    setOwn(allowed, requirement.id, Object.freeze(contextual));
  }
  return Object.freeze({
    signal: state.root.signal,
    capabilities: Object.freeze(allowed),
    updateInfo(info) {
      state.root.statusUpdate?.(info);
    },
    trace(kind, details = {}) {
      emitTrace(state.root, "node_trace", {
        nodeId: node.id,
        nodePath: nodePath(state, node.id),
        event: String(kind),
        details
      });
    }
  });
}
function invokeStaticImplementationSync(implementation, node, inputs, state) {
  if (typeof implementation !== "function") {
    throw vfError(
      "VF_INTERNAL",
      `node '${node.id}' has no emitted implementation binding`,
      state.workflow,
      { nodePath: nodePath(state, node.id) }
    );
  }
  try {
    const outputs = implementation(inputs, node.params, nodeContext(node, state));
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    return validateNodeOutputs(node, outputs, state);
  } catch (cause) {
    if (cause instanceof VibeFlowWorkflowError) {
      throw ensureErrorLocation(cause, state.workflow, state.path, node.id);
    }
    if (state.root.signal?.aborted) {
      throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
    }
    throw vfError(
      "VF_NODE_FAILED",
      `node '${node.id}' failed`,
      state.workflow,
      { nodePath: nodePath(state, node.id), cause }
    );
  }
}
function prepareStaticNode(node, state) {
  throwIfAborted(state.root.signal, state.workflow, nodePath(state, node.id));
  const inputs = requirementsFromInbox(node, state);
  state.lastInputs.set(node.id, inputs);
  state.inboxes[node.id] = [];
  state.nodeRuns.set(node.id, (state.nodeRuns.get(node.id) || 0) + 1);
  emitTrace(state.root, "node_start", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
  return inputs;
}
function finishStaticNode(node, state) {
  emitTrace(state.root, "node_end", {
    nodeId: node.id,
    nodePath: nodePath(state, node.id),
    blockPath: formatBlockPath(state.path),
    type: node.type_used
  });
}
function enqueueStaticTargets(targets, ready, queued) {
  for (const target of targets) {
    if (queued.has(target)) continue;
    ready.push(target);
    queued.add(target);
  }
}
function rawInputsForChild(inputSpecs, inputs, workflow, nodeId) {
  const items = [];
  for (const value of Object.values(inputs)) {
    if (Array.isArray(value)) items.push(...value);
    else if (value) items.push(value);
  }
  const initial = dictionary();
  for (const input of inputSpecs) {
    const match = items.find((item) => item?.type === input.type);
    if (match) setOwn(initial, input.key, match.value);
    else if (input.required) {
      throw vfError(
        "VF_INPUT_REQUIRED",
        `composite node '${nodeId}' cannot supply required body input '${input.key}'`,
        workflow
      );
    }
  }
  return initial;
}
function outputsFromChild(node, mappings, childResult, state) {
  const outputs = dictionary();
  for (const mapping of mappings) {
    if (!Object.prototype.hasOwnProperty.call(childResult.publicOutputs, mapping.alias)) {
      throw vfError(
        "VF_OUTPUT_CARDINALITY",
        `composite node '${node.id}' body omitted optional output '${mapping.alias}' required by provider '${mapping.provider}'`,
        state.workflow,
        { nodePath: nodePath(state, node.id) }
      );
    }
    setOwn(outputs, mapping.provider, childResult.publicOutputs[mapping.alias]);
  }
  return validateNodeOutputs(node, outputs, state);
}
function valueFromEnvelope(value) {
  if (value && typeof value === "object" && "value" in value && "type" in value) {
    return value.value;
  }
  return value;
}
function resultValues(child) {
  const values = dictionary();
  for (const [key, value] of Object.entries(child.publicOutputs)) setOwn(values, key, value);
  for (const [type, candidates] of child.candidates) {
    if (candidates.length === 1) setOwn(values, type, candidates[0].value);
  }
  return values;
}
function finalizeOutputs(state) {
  const output = {};
  for (const spec of state.workflow.outputs) {
    const matches = state.candidates.get(spec.type) || [];
    if (spec.cardinality === "exactly_one") {
      if (matches.length !== 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected exactly one value, got ${matches.length}`,
          state.workflow
        );
      }
      setOwn(output, spec.as, matches[0].value);
    } else if (spec.cardinality === "optional_one") {
      if (matches.length > 1) {
        throw vfError(
          "VF_OUTPUT_CARDINALITY",
          `workflow output type '${spec.type}' expected at most one value, got ${matches.length}`,
          state.workflow
        );
      }
      if (matches.length) setOwn(output, spec.as, matches[0].value);
    } else {
      setOwn(output, spec.as, matches.map((item) => item.value));
    }
    const schema = spec.schema || state.workflow.schemas?.[spec.type];
    const values = spec.cardinality === "all" ? matches.map((item) => item.value) : Object.prototype.hasOwnProperty.call(output, spec.as) ? [output[spec.as]] : [];
    for (const value of values) {
      const failure = validateJsonSchema(value, schema);
      if (failure) {
        throw vfError(
          "VF_OUTPUT_SCHEMA",
          `workflow output '${spec.as}' failed schema validation: ${failure}`,
          state.workflow
        );
      }
    }
  }
  return output;
}
function abandonPending(state) {
  for (const [nodeId, promise] of state.pending) {
    promise.catch(() => {
    });
    emitTrace(state.root, "async_result_abandoned", {
      nodeId,
      nodePath: nodePath(state, nodeId),
      blockPath: formatBlockPath(state.path)
    });
  }
}
function deepFreeze(value) {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
function runtimePluginError(code, descriptor, hook, cause, workflow, location = {}) {
  const suffix = hook ? ` hook '${hook}'` : "";
  return vfError(
    code,
    `runtime plugin '${descriptor.id}'${suffix} failed`,
    workflow,
    {
      nodePath: location.nodePath || "",
      blockPath: location.blockPath || "/",
      cause
    }
  );
}
function runtimePluginContext(workflow, descriptor, root) {
  return Object.freeze({
    abiVersion: VIBEFLOW_PLUGIN_ABI,
    pluginId: descriptor.id,
    pluginType: "runtime",
    target: descriptor.target,
    workflowId: workflow.workflow_id,
    config: deepFreeze(descriptor.config || {}),
    signal: root.signal
  });
}
function runtimePluginSummary(root, details = {}) {
  return deepFreeze({
    workflowId: root.workflowId,
    entryMode: root.workflow.entry_mode,
    ...details
  });
}
function createRuntimePluginsSync(workflow, descriptors, factories, root) {
  const records = [];
  try {
    for (const descriptor of descriptors) {
      const factory = factories[descriptor.factory_index];
      if (typeof factory !== "function") {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("plugin module does not export createPlugin()"),
          workflow
        );
      }
      let instance;
      try {
        instance = factory(runtimePluginContext(workflow, descriptor, root));
      } catch (cause) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          cause,
          workflow
        );
      }
      if (!instance || typeof instance !== "object" || Array.isArray(instance)) {
        throw runtimePluginError(
          "VF_RUNTIME_PLUGIN_CREATE",
          descriptor,
          "createPlugin",
          new TypeError("createPlugin() must return a RuntimePlugin object"),
          workflow
        );
      }
      records.push({ descriptor, instance });
    }
    return records;
  } catch (failure) {
    for (let index = records.length - 1; index >= 0; index -= 1) {
      try {
        records[index].instance.dispose?.();
      } catch {
      }
    }
    throw failure;
  }
}
function invokeRuntimeHookSync(root, hook, details = {}, preserveFailure = false) {
  const summary = runtimePluginSummary(root, details);
  for (const record2 of root.runtimePlugins) {
    const callback = record2.instance[hook];
    if (typeof callback !== "function") continue;
    try {
      callback(summary);
    } catch (cause) {
      if (preserveFailure) continue;
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_HOOK",
        record2.descriptor,
        hook,
        cause,
        root.workflow,
        summary
      );
    }
  }
}
function disposeRuntimePluginsSync(root, preserveFailure = false) {
  for (let index = root.runtimePlugins.length - 1; index >= 0; index -= 1) {
    const record2 = root.runtimePlugins[index];
    if (typeof record2.instance.dispose !== "function") continue;
    try {
      record2.instance.dispose();
    } catch (cause) {
      if (preserveFailure) continue;
      throw runtimePluginError(
        "VF_RUNTIME_PLUGIN_DISPOSE",
        record2.descriptor,
        "dispose",
        cause,
        root.workflow
      );
    }
  }
  root.runtimePlugins.length = 0;
}
function createRoot(workflow, normalized) {
  return {
    workflow,
    workflowId: workflow.workflow_id,
    signal: normalized.signal || new AbortController().signal,
    traceMode: normalized.traceMode,
    onTrace: normalized.onTrace,
    statusUpdate: normalized.statusUpdate,
    kernelLog: normalized.kernelLog,
    detachedTimeoutMs: normalized.detachedTimeoutMs,
    detached: /* @__PURE__ */ new Set(),
    detachedFailure: null,
    capabilities: {},
    runtimePlugins: []
  };
}
function prepareWorkflowInvocation(workflow, descriptors, requirements, schemas, options, entryMode) {
  let normalized;
  try {
    normalized = normalizeOptions(workflow, options);
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
  const root = createRoot(workflow, normalized);
  try {
    throwIfAborted(root.signal, workflow);
    root.capabilities = prepareCapabilities(
      workflow,
      descriptors,
      requirements,
      schemas,
      normalized.capabilities,
      root,
      entryMode
    );
    emitTrace(root, "run_start", {}, true);
    return root;
  } catch (cause) {
    throw ensureErrorLocation(cause, workflow, []);
  }
}
function assertWorkflowAbi(workflow) {
  if (workflow.abi_version !== VIBEFLOW_WORKFLOW_ABI) {
    throw vfError(
      "VF_INTERNAL",
      `generated workflow ABI '${workflow.abi_version}' is unsupported`,
      workflow
    );
  }
}
function createStaticWorkflowSync(workflowMetadata, capabilityDescriptors, capabilityRequirements, schemaCatalog, runtimePluginDescriptors, runtimePluginFactories, executeRoot) {
  const workflow = deepFreeze(workflowMetadata);
  const descriptors = deepFreeze(capabilityDescriptors);
  const requirements = deepFreeze(capabilityRequirements);
  const schemas = deepFreeze(schemaCatalog);
  const plugins = deepFreeze(runtimePluginDescriptors);
  assertWorkflowAbi(workflow);
  return function invokeWorkflow(inputs, options) {
    const root = prepareWorkflowInvocation(
      workflow,
      descriptors,
      requirements,
      schemas,
      options,
      "sync"
    );
    root.runtimePlugins = createRuntimePluginsSync(
      workflow,
      plugins,
      runtimePluginFactories,
      root
    );
    let failed = false;
    try {
      invokeRuntimeHookSync(root, "beforeRun", {
        inputKeys: Object.keys(inputs || {}).sort()
      });
      const result = executeRoot(inputs, root, []);
      throwIfAborted(root.signal, workflow);
      invokeRuntimeHookSync(root, "afterRun", {
        outputKeys: Object.keys(result.publicOutputs || {}).sort()
      });
      emitTrace(root, "run_end", {}, true);
      return result.publicOutputs;
    } catch (cause) {
      failed = true;
      const failure = cause instanceof VibeFlowWorkflowError ? cause : vfError("VF_INTERNAL", "generated workflow failed internally", workflow, { cause });
      if (failure.code !== "VF_TRACE_SINK_FAILED") {
        try {
          emitTrace(root, "run_failed", {
            code: failure.code,
            message: failure.message
          }, true);
        } catch {
        }
      }
      invokeRuntimeHookSync(root, "runFailed", {
        code: failure.code,
        message: failure.message
      }, true);
      throw ensureErrorLocation(failure, workflow, []);
    } finally {
      disposeRuntimePluginsSync(root, failed);
    }
  };
}
function __vfSnapshotInfo(info) {
  const active = /* @__PURE__ */ new Set();
  function copy(value) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "object" || active.has(value)) throw new TypeError("run info must contain JSON values");
    const array = Array.isArray(value);
    if (!array && ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
      throw new TypeError("run info must contain plain JSON objects");
    }
    active.add(value);
    let result;
    if (array) {
      result = Array.from(value, (item) => copy(item));
    } else {
      result = Object.fromEntries(Object.entries(value).map(([key, item]) => [key, copy(item)]));
    }
    active.delete(value);
    return Object.freeze(result);
  }
  if (!Array.isArray(info) || info.some((item) => !item || typeof item !== "object" || Array.isArray(item))) {
    throw new TypeError("run info must be an array of JSON objects");
  }
  return copy(info);
}
function __vfObservation(options) {
  const raw = options ?? {};
  const interval = raw.statusIntervalMs ?? 6e4;
  if (!Number.isFinite(interval) || interval <= 0) throw new TypeError("statusIntervalMs must be positive finite milliseconds");
  if (raw.onStatus !== void 0 && typeof raw.onStatus !== "function") throw new TypeError("onStatus must be a function");
  let info = Object.freeze([]);
  let state = "starting";
  let error = null;
  let closed = false;
  let timer;
  let sink;
  const record2 = () => Object.freeze({ state, error, updated_at: (/* @__PURE__ */ new Date()).toISOString(), info });
  const publish = () => {
    const snapshot = record2();
    sink?.publish(snapshot);
    raw.onStatus?.(snapshot);
  };
  const observer = {
    updateInfo(value) {
      if (closed) throw new Error("cannot update info after the run has finished");
      info = __vfSnapshotInfo(value);
      sink?.cache(record2());
    },
    kernel(event) {
      sink?.kernel(JSON.stringify(event));
    },
    run(callback) {
      return sink ? sink.run(callback) : callback();
    },
    running() {
      if (state === "running" || closed) return;
      state = "running";
      publish();
    },
    start(running = true) {
      if (typeof __vfCreateFileObservation === "function") {
        sink = __vfCreateFileObservation(raw, record2(), interval);
      }
      publish();
      if (running) observer.running();
      if (raw.onStatus) {
        timer = setInterval(() => {
          try {
            raw.onStatus(record2());
          } catch (failure) {
            try {
              observer.finish(failure);
            } catch {
            }
            throw failure;
          }
        }, interval);
        timer.unref?.();
      }
    },
    finish(failure) {
      if (closed) return;
      if (timer) clearInterval(timer);
      state = failure ? "failed" : "succeeded";
      if (failure) {
        const messages = [];
        const seen = /* @__PURE__ */ new Set();
        for (let cause = failure; cause && !seen.has(cause); cause = cause.cause) {
          seen.add(cause);
          messages.push(String(cause.message || cause));
        }
        error = messages.join(": ");
      } else error = null;
      if (failure) sink?.kernel(String(failure.stack || failure));
      closed = true;
      try {
        sink?.finish(record2());
        raw.onStatus?.(record2());
      } catch (cause) {
        if (!failure) {
          state = "failed";
          error = String(cause?.message || cause);
          try {
            sink?.finish(record2());
          } catch {
          }
        }
        throw cause;
      } finally {
        sink?.close();
      }
    }
  };
  return observer;
}
function __vfObservedOptions(options, observer) {
  return {
    ...options ?? {},
    __vfStatusUpdate: (info) => observer.updateInfo(info),
    __vfKernelLog: (event) => observer.kernel(event)
  };
}
function __vfObserveSync(invoke, inputs, options) {
  if (options !== void 0 && (!options || typeof options !== "object" || Array.isArray(options))) return invoke(inputs, options);
  if (options?.__vfParentObservation) {
    const observer2 = options.__vfParentObservation;
    return observer2.run(() => invoke(inputs, __vfObservedOptions(options, observer2)));
  }
  const observer = __vfObservation(options);
  try {
    observer.start();
    const outputs = observer.run(() => invoke(inputs, __vfObservedOptions(options, observer)));
    observer.finish(null);
    return outputs;
  } catch (error) {
    try {
      observer.finish(error);
    } catch {
    }
    throw error;
  }
}
var __vfRuntimePluginDescriptors = [];
var __vfRuntimePluginFactories = [];
var __vf_workflow_2_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v5","entry_mode":"sync","inputs":[{"key":"segment_state","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"type":"era.command_compaction.segment.state"}],"max_steps":8,"outputs":[{"as":"segmentStateNext","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"type":"era.command_compaction.segment.state"},{"as":"segmentDone","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"type":"era.command_compaction.segment.done"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction.compact_layer.segment_loop"}'));
var __vf_w2_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w2_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"select_segment","params":{"_global":{}},"provides":[{"key":"parsed","type":"era.command_compaction.parsed"},{"key":"segment_state_before","type":"era.command_compaction.segment.state.before"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state"}],"schedule":"inline","type_used":"era.command_compaction.select_segment"}'));
var __vf_w2_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"execute","params":{"_global":{}},"provides":[{"key":"trace","type":"era.command_compaction.semantic_trace"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.parsed"}],"schedule":"inline","type_used":"era.command_compaction.execute_original_semantics"}'));
var __vf_w2_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"analyze_dependencies","params":{"_global":{}},"provides":[{"key":"symbols","type":"era.command_compaction.symbols"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.semantic_trace"}],"schedule":"inline","type_used":"era.command_compaction.analyze_dependencies"}'));
var __vf_w2_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"rewrite","params":{"_global":{}},"provides":[{"key":"candidate","type":"era.command_compaction.candidate"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.symbols"}],"schedule":"inline","type_used":"era.command_compaction.rewrite_safe_regions"}'));
var __vf_w2_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"verify","params":{"_global":{}},"provides":[{"key":"verified","type":"era.command_compaction.verified"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.candidate"}],"schedule":"inline","type_used":"era.command_compaction.verify_replay_equivalence"}'));
var __vf_w2_n6 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"advance_segment","params":{"_global":{}},"provides":[{"key":"segment_state_next","type":"era.command_compaction.segment.state"},{"key":"segment_done","type":"era.command_compaction.segment.done"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state.before"},{"cardinality":"exactly_one","type":"era.command_compaction.verified"}],"schedule":"inline","type_used":"era.command_compaction.advance_segment"}'));
var __vf_w2_n7 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_workflow_1_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v5","entry_mode":"sync","inputs":[{"key":"compaction_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.request"}],"max_steps":7,"outputs":[{"as":"compactionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.response"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction.compact_layer"}'));
var __vf_w1_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w1_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"parse","params":{"_global":{}},"provides":[{"key":"parsed","type":"era.command_compaction.parsed"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.request"}],"schedule":"inline","type_used":"era.command_compaction.parse_command_blocks"}'));
var __vf_w1_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"initialize_segments","params":{"_global":{}},"provides":[{"key":"segment_state","type":"era.command_compaction.segment.state"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.parsed"}],"schedule":"inline","type_used":"era.command_compaction.initialize_segments"}'));
var __vf_w1_n3 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"segment_loop","params":{},"provides":[{"key":"segment_state_final","type":"era.command_compaction.segment.state"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state"}],"schedule":"inline","type_used":"vibeflow.loop.while"}'));
var __vf_w1_n4 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"verify_layer","params":{"_global":{}},"provides":[{"key":"verified","type":"era.command_compaction.verified"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.segment.state"}],"schedule":"inline","type_used":"era.command_compaction.verify_layer"}'));
var __vf_w1_n5 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"render","params":{"_global":{}},"provides":[{"key":"compaction_response","type":"era.command_compaction.response"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.verified"}],"schedule":"inline","type_used":"era.command_compaction.render_compaction_result"}'));
var __vf_w1_n6 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_workflow_0_metadata = Object.freeze(JSON.parse('{"abi_version":"vibeflow.workflow.v5","entry_mode":"sync","inputs":[{"key":"compaction_request","required":true,"schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.request"}],"max_steps":1000,"outputs":[{"as":"compactionResponse","cardinality":"exactly_one","schema":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"type":"era.command_compaction.response"}],"schemas":{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}},"workflow_id":"era.command_compaction"}'));
var __vf_w0_n0 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"start","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vf_w0_n1 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"compact_layer","params":{},"provides":[{"key":"compaction_response","type":"era.command_compaction.response"}],"requires":[{"cardinality":"exactly_one","type":"era.command_compaction.request"}],"schedule":"inline","type_used":"era.command_compaction.compact_layer"}'));
var __vf_w0_n2 = Object.freeze(JSON.parse('{"capabilities":[],"completion":"immediate","executor":"current","id":"end","params":{"_global":{}},"provides":[],"requires":[],"schedule":"inline","type_used":"era.command_compaction.terminal"}'));
var __vfCapabilityDescriptors = Object.freeze(JSON.parse("{}"));
var __vfCapabilityRequirements = Object.freeze(JSON.parse("{}"));
var __vfSchemaCatalog = Object.freeze(JSON.parse('{"era.command_compaction.candidate":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.parsed":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.request":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.response":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.segment.done":{"$schema":"https://json-schema.org/draft/2020-12/schema","type":"boolean"},"era.command_compaction.segment.state":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.segment.state.before":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"properties":{"cursor":{"type":"integer"},"diagnostics":{"type":"array"},"drawOffset":{"type":"integer"},"parts":{"type":"array"},"reasons":{"type":"array"},"request":{"type":"object"},"segments":{"type":"array"},"statData":{"type":"object"},"statFunc":{"type":"object"}},"required":["cursor","segments","request","statData","statFunc","drawOffset","parts","diagnostics","reasons"],"type":"object"},"era.command_compaction.semantic_trace":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.symbols":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"},"era.command_compaction.verified":{"$schema":"https://json-schema.org/draft/2020-12/schema","additionalProperties":true,"type":"object"}}'));
function __vf_activate_w0_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("compact_layer");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0compact_layer");
  targets.push("compact_layer");
  emitTrace(state.root, "edge_activated", { source: "start", target: "compact_layer", path: state.path });
  deliverStatic(envelopes, state, "compact_layer", JSON.parse('["era.command_compaction.request"]'));
  return targets;
}
function __vf_execute_w0_n0(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w0_n0, inputs, state);
}
function __vf_activate_w0_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("compact_layer\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "compact_layer", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w0_n1(inputs, state) {
  try {
    invokeRuntimeHookSync(state.root, "beforeNodeset", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path) });
    emitTrace(state.root, "nodeset_enter", {
      nodeId: "compact_layer",
      nodePath: nodePath(state, "compact_layer")
    }, true);
    const initial = rawInputsForChild(__vf_workflow_1_metadata.inputs, inputs, state.workflow, "compact_layer");
    const child = __vf_workflow_1_execute(initial, state.root, [...state.path, "compact_layer"]);
    const outputs = outputsFromChild(__vf_w0_n1, JSON.parse('[{"alias":"compactionResponse","provider":"compaction_response"}]'), child, state);
    emitTrace(state.root, "nodeset_exit", {
      nodeId: "compact_layer",
      nodePath: nodePath(state, "compact_layer")
    }, true);
    invokeRuntimeHookSync(state.root, "afterNodeset", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path) });
    return outputs;
  } catch (cause) {
    const failure = ensureErrorLocation(cause, state.workflow, state.path, "compact_layer");
    invokeRuntimeHookSync(state.root, "nodesetFailed", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w0_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w0_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w0_n2(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w0_n2, inputs, state);
}
function __vf_workflow_0_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_0_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "compact_layer");
    initializeInbox(state, "end");
    seedInbox(state, "compact_layer", JSON.parse('["era.command_compaction.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_0_metadata);
      if (state.stepCount >= 1e3) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=1000",
          __vf_workflow_0_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n0(inputs, state);
            finishStaticNode(__vf_w0_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "compact_layer": {
          if (!state.inboxes["compact_layer"].some((item) => item.type === "era.command_compaction.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w0_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.compact_layer" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n1(inputs, state);
            finishStaticNode(__vf_w0_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.compact_layer", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "compact_layer");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "compact_layer", nodePath: nodePath(state, "compact_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w0_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w0_n2(inputs, state);
            finishStaticNode(__vf_w0_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w0_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_0_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w1_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("parse");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0parse");
  targets.push("parse");
  emitTrace(state.root, "edge_activated", { source: "start", target: "parse", path: state.path });
  deliverStatic(envelopes, state, "parse", JSON.parse('["era.command_compaction.request"]'));
  return targets;
}
function __vf_execute_w1_n0(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w1_n0, inputs, state);
}
function __vf_activate_w1_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("initialize_segments");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("parse\0initialize_segments");
  targets.push("initialize_segments");
  emitTrace(state.root, "edge_activated", { source: "parse", target: "initialize_segments", path: state.path });
  deliverStatic(envelopes, state, "initialize_segments", JSON.parse('["era.command_compaction.parsed"]'));
  return targets;
}
function __vf_execute_w1_n1(inputs, state) {
  return invokeStaticImplementationSync(run2, __vf_w1_n1, inputs, state);
}
function __vf_activate_w1_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("segment_loop");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("initialize_segments\0segment_loop");
  targets.push("segment_loop");
  emitTrace(state.root, "edge_activated", { source: "initialize_segments", target: "segment_loop", path: state.path });
  deliverStatic(envelopes, state, "segment_loop", JSON.parse('["era.command_compaction.segment.state"]'));
  return targets;
}
function __vf_execute_w1_n2(inputs, state) {
  return invokeStaticImplementationSync(run3, __vf_w1_n2, inputs, state);
}
function __vf_activate_w1_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("verify_layer");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("segment_loop\0verify_layer");
  targets.push("verify_layer");
  emitTrace(state.root, "edge_activated", { source: "segment_loop", target: "verify_layer", path: state.path });
  deliverStatic(envelopes, state, "verify_layer", JSON.parse('["era.command_compaction.segment.state"]'));
  return targets;
}
function __vf_execute_w1_n3(inputs, state) {
  emitTrace(state.root, "loop_enter", {
    nodeId: "segment_loop",
    nodePath: nodePath(state, "segment_loop")
  }, true);
  const values = dictionary();
  for (const [type, input] of Object.entries(inputs)) {
    setOwn(values, type, Array.isArray(input) ? input.map(valueFromEnvelope) : valueFromEnvelope(input));
    const items = Array.isArray(input) ? input : [input];
    for (const item of items) {
      if (item?.key) setOwn(values, item.key, item.value);
      if (item?.type) setOwn(values, item.type, item.value);
    }
  }
  if (!Object.prototype.hasOwnProperty.call(values, "era.command_compaction.segment.state")) {
    throw vfError("VF_INPUT_REQUIRED", "loop carry source 'era.command_compaction.segment.state' is unavailable", state.workflow, { nodePath: nodePath(state, "segment_loop") });
  }
  setOwn(values, "segment_state", values["era.command_compaction.segment.state"]);
  let stopped = false;
  for (let iteration = 0; ; iteration += 1) {
    throwIfAborted(state.root.signal, state.workflow, nodePath(state, "segment_loop"));
    const initial = dictionary();
    setOwn(initial, "segment_state", values["segment_state"]);
    emitTrace(state.root, "loop_iteration", {
      nodeId: "segment_loop",
      nodePath: nodePath(state, "segment_loop"),
      iteration
    });
    const child = __vf_workflow_2_execute(initial, state.root, [...state.path, "segment_loop", `iter_${iteration}`]);
    const childValues = resultValues(child);
    for (const [key, value] of Object.entries(childValues)) setOwn(values, key, value);
    if (!Object.prototype.hasOwnProperty.call(values, "segmentStateNext")) {
      throw vfError("VF_OUTPUT_KEYS", "loop carry update 'segmentStateNext' is unavailable", state.workflow, { nodePath: nodePath(state, "segment_loop") });
    }
    setOwn(values, "segment_state", values["segmentStateNext"]);
    const iterationCount = iteration + 1;
    setOwn(values, "loop.iterations", iterationCount);
    if (!Object.prototype.hasOwnProperty.call(values, "segmentDone")) {
      throw vfError("VF_OUTPUT_KEYS", "loop stop source 'segmentDone' is unavailable", state.workflow);
    }
    if (typeof values["segmentDone"] !== "boolean") {
      throw vfError("VF_OUTPUT_SCHEMA", "loop stop source 'segmentDone' must be boolean", state.workflow);
    }
    stopped = stopped || values["segmentDone"] === true;
    if (stopped) break;
  }
  const outputs = dictionary();
  if (!Object.prototype.hasOwnProperty.call(values, "segmentStateNext")) {
    throw vfError("VF_OUTPUT_KEYS", "loop output source 'segmentStateNext' is unavailable", state.workflow);
  }
  setOwn(outputs, "segment_state_final", values["segmentStateNext"]);
  emitTrace(state.root, "loop_exit", {
    nodeId: "segment_loop",
    nodePath: nodePath(state, "segment_loop")
  }, true);
  return validateNodeOutputs(__vf_w1_n3, outputs, state);
}
function __vf_activate_w1_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("render");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("verify_layer\0render");
  targets.push("render");
  emitTrace(state.root, "edge_activated", { source: "verify_layer", target: "render", path: state.path });
  deliverStatic(envelopes, state, "render", JSON.parse('["era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w1_n4(inputs, state) {
  return invokeStaticImplementationSync(run10, __vf_w1_n4, inputs, state);
}
function __vf_activate_w1_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("render\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "render", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w1_n5(inputs, state) {
  return invokeStaticImplementationSync(run11, __vf_w1_n5, inputs, state);
}
function __vf_activate_w1_n6(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w1_n6, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w1_n6(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w1_n6, inputs, state);
}
function __vf_workflow_1_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_1_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "parse");
    initializeInbox(state, "initialize_segments");
    initializeInbox(state, "segment_loop");
    initializeInbox(state, "verify_layer");
    initializeInbox(state, "render");
    initializeInbox(state, "end");
    seedInbox(state, "parse", JSON.parse('["era.command_compaction.request"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_1_metadata);
      if (state.stepCount >= 7) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=7",
          __vf_workflow_1_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w1_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n0(inputs, state);
            finishStaticNode(__vf_w1_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "parse": {
          if (!state.inboxes["parse"].some((item) => item.type === "era.command_compaction.request")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "parse", nodePath: nodePath(state, "parse"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.parse_command_blocks" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n1(inputs, state);
            finishStaticNode(__vf_w1_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "parse", nodePath: nodePath(state, "parse"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.parse_command_blocks", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "parse");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "parse", nodePath: nodePath(state, "parse"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "initialize_segments": {
          if (!state.inboxes["initialize_segments"].some((item) => item.type === "era.command_compaction.parsed")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "initialize_segments", nodePath: nodePath(state, "initialize_segments"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.initialize_segments" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n2(inputs, state);
            finishStaticNode(__vf_w1_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "initialize_segments", nodePath: nodePath(state, "initialize_segments"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.initialize_segments", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "initialize_segments");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "initialize_segments", nodePath: nodePath(state, "initialize_segments"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "segment_loop": {
          if (!state.inboxes["segment_loop"].some((item) => item.type === "era.command_compaction.segment.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "segment_loop", nodePath: nodePath(state, "segment_loop"), blockPath: formatBlockPath(state.path), type: "vibeflow.loop.while" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n3(inputs, state);
            finishStaticNode(__vf_w1_n3, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "segment_loop", nodePath: nodePath(state, "segment_loop"), blockPath: formatBlockPath(state.path), type: "vibeflow.loop.while", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "segment_loop");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "segment_loop", nodePath: nodePath(state, "segment_loop"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "verify_layer": {
          if (!state.inboxes["verify_layer"].some((item) => item.type === "era.command_compaction.segment.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "verify_layer", nodePath: nodePath(state, "verify_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_layer" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n4(inputs, state);
            finishStaticNode(__vf_w1_n4, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "verify_layer", nodePath: nodePath(state, "verify_layer"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_layer", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "verify_layer");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "verify_layer", nodePath: nodePath(state, "verify_layer"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "render": {
          if (!state.inboxes["render"].some((item) => item.type === "era.command_compaction.verified")) break;
          try {
            const inputs = prepareStaticNode(__vf_w1_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "render", nodePath: nodePath(state, "render"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.render_compaction_result" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n5(inputs, state);
            finishStaticNode(__vf_w1_n5, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "render", nodePath: nodePath(state, "render"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.render_compaction_result", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "render");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "render", nodePath: nodePath(state, "render"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w1_n6, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w1_n6(inputs, state);
            finishStaticNode(__vf_w1_n6, state);
            state.stepCount += 1;
            const targets = __vf_activate_w1_n6(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_1_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
function __vf_activate_w2_n0(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("select_segment");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n0, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("start\0select_segment");
  targets.push("select_segment");
  emitTrace(state.root, "edge_activated", { source: "start", target: "select_segment", path: state.path });
  deliverStatic(envelopes, state, "select_segment", JSON.parse('["era.command_compaction.segment.state"]'));
  return targets;
}
function __vf_execute_w2_n0(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w2_n0, inputs, state);
}
function __vf_activate_w2_n1(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("execute");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n1, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("select_segment\0execute");
  targets.push("execute");
  emitTrace(state.root, "edge_activated", { source: "select_segment", target: "execute", path: state.path });
  deliverStatic(envelopes, state, "execute", JSON.parse('["era.command_compaction.parsed"]'));
  deliverStatic(envelopes, state, "advance_segment", JSON.parse('["era.command_compaction.segment.state.before","era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w2_n1(inputs, state) {
  return invokeStaticImplementationSync(run4, __vf_w2_n1, inputs, state);
}
function __vf_activate_w2_n2(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("analyze_dependencies");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n2, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("execute\0analyze_dependencies");
  targets.push("analyze_dependencies");
  emitTrace(state.root, "edge_activated", { source: "execute", target: "analyze_dependencies", path: state.path });
  deliverStatic(envelopes, state, "analyze_dependencies", JSON.parse('["era.command_compaction.semantic_trace"]'));
  return targets;
}
function __vf_execute_w2_n2(inputs, state) {
  return invokeStaticImplementationSync(run5, __vf_w2_n2, inputs, state);
}
function __vf_activate_w2_n3(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("rewrite");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n3, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("analyze_dependencies\0rewrite");
  targets.push("rewrite");
  emitTrace(state.root, "edge_activated", { source: "analyze_dependencies", target: "rewrite", path: state.path });
  deliverStatic(envelopes, state, "rewrite", JSON.parse('["era.command_compaction.symbols"]'));
  return targets;
}
function __vf_execute_w2_n3(inputs, state) {
  return invokeStaticImplementationSync(run6, __vf_w2_n3, inputs, state);
}
function __vf_activate_w2_n4(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("verify");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n4, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("rewrite\0verify");
  targets.push("verify");
  emitTrace(state.root, "edge_activated", { source: "rewrite", target: "verify", path: state.path });
  deliverStatic(envelopes, state, "verify", JSON.parse('["era.command_compaction.candidate"]'));
  return targets;
}
function __vf_execute_w2_n4(inputs, state) {
  return invokeStaticImplementationSync(run7, __vf_w2_n4, inputs, state);
}
function __vf_activate_w2_n5(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("advance_segment");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n5, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("verify\0advance_segment");
  targets.push("advance_segment");
  emitTrace(state.root, "edge_activated", { source: "verify", target: "advance_segment", path: state.path });
  deliverStatic(envelopes, state, "advance_segment", JSON.parse('["era.command_compaction.segment.state.before","era.command_compaction.verified"]'));
  return targets;
}
function __vf_execute_w2_n5(inputs, state) {
  return invokeStaticImplementationSync(run8, __vf_w2_n5, inputs, state);
}
function __vf_activate_w2_n6(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) {
    targets.push("end");
    return targets;
  }
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n6, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  state.activeEdges.add("advance_segment\0end");
  targets.push("end");
  emitTrace(state.root, "edge_activated", { source: "advance_segment", target: "end", path: state.path });
  deliverStatic(envelopes, state, "end", JSON.parse("[]"));
  return targets;
}
function __vf_execute_w2_n6(inputs, state) {
  return invokeStaticImplementationSync(run9, __vf_w2_n6, inputs, state);
}
function __vf_activate_w2_n7(outputs, inputs, state, deferred = false) {
  const targets = [];
  if (deferred) return targets;
  const values = conditionValues(inputs, outputs);
  const envelopes = outputEnvelopes(__vf_w2_n7, outputs);
  for (const envelope of envelopes) recordCandidate(state, envelope);
  return targets;
}
function __vf_execute_w2_n7(inputs, state) {
  return invokeStaticImplementationSync(run, __vf_w2_n7, inputs, state);
}
function __vf_workflow_2_execute(initial, root, path) {
  try {
    invokeRuntimeHookSync(root, "beforeBlock", { blockPath: formatBlockPath(path), path: [...path] });
    const state = createStaticState(__vf_workflow_2_metadata, initial, root, path);
    initializeInbox(state, "start");
    initializeInbox(state, "select_segment");
    initializeInbox(state, "execute");
    initializeInbox(state, "analyze_dependencies");
    initializeInbox(state, "rewrite");
    initializeInbox(state, "verify");
    initializeInbox(state, "advance_segment");
    initializeInbox(state, "end");
    seedInbox(state, "select_segment", JSON.parse('["era.command_compaction.segment.state"]'));
    const ready = JSON.parse('["start"]');
    const queued = new Set(ready);
    let completed = false;
    while (ready.length) {
      throwIfAborted(root.signal, __vf_workflow_2_metadata);
      if (state.stepCount >= 8) {
        const nextNodeId = ready[0] || "";
        throw vfError(
          "VF_MAX_STEPS",
          "workflow exceeded max_steps=8",
          __vf_workflow_2_metadata,
          {
            nodePath: nextNodeId ? nodePath(state, nextNodeId) : "",
            blockPath: formatBlockPath(path)
          }
        );
      }
      const nodeId = ready.shift();
      queued.delete(nodeId);
      switch (nodeId) {
        case "start": {
          try {
            const inputs = prepareStaticNode(__vf_w2_n0, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n0(inputs, state);
            finishStaticNode(__vf_w2_n0, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n0(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "start");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "start", nodePath: nodePath(state, "start"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "select_segment": {
          if (!state.inboxes["select_segment"].some((item) => item.type === "era.command_compaction.segment.state")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n1, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "select_segment", nodePath: nodePath(state, "select_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.select_segment" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n1(inputs, state);
            finishStaticNode(__vf_w2_n1, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n1(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "select_segment", nodePath: nodePath(state, "select_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.select_segment", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "select_segment");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "select_segment", nodePath: nodePath(state, "select_segment"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "execute": {
          if (!state.inboxes["execute"].some((item) => item.type === "era.command_compaction.parsed")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n2, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "execute", nodePath: nodePath(state, "execute"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.execute_original_semantics" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n2(inputs, state);
            finishStaticNode(__vf_w2_n2, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n2(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "execute", nodePath: nodePath(state, "execute"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.execute_original_semantics", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "execute");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "execute", nodePath: nodePath(state, "execute"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "analyze_dependencies": {
          if (!state.inboxes["analyze_dependencies"].some((item) => item.type === "era.command_compaction.semantic_trace")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n3, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "analyze_dependencies", nodePath: nodePath(state, "analyze_dependencies"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.analyze_dependencies" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n3(inputs, state);
            finishStaticNode(__vf_w2_n3, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n3(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "analyze_dependencies", nodePath: nodePath(state, "analyze_dependencies"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.analyze_dependencies", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "analyze_dependencies");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "analyze_dependencies", nodePath: nodePath(state, "analyze_dependencies"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "rewrite": {
          if (!state.inboxes["rewrite"].some((item) => item.type === "era.command_compaction.symbols")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n4, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "rewrite", nodePath: nodePath(state, "rewrite"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.rewrite_safe_regions" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n4(inputs, state);
            finishStaticNode(__vf_w2_n4, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n4(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "rewrite", nodePath: nodePath(state, "rewrite"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.rewrite_safe_regions", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "rewrite");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "rewrite", nodePath: nodePath(state, "rewrite"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "verify": {
          if (!state.inboxes["verify"].some((item) => item.type === "era.command_compaction.candidate")) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n5, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "verify", nodePath: nodePath(state, "verify"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_replay_equivalence" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n5(inputs, state);
            finishStaticNode(__vf_w2_n5, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n5(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "verify", nodePath: nodePath(state, "verify"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.verify_replay_equivalence", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "verify");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "verify", nodePath: nodePath(state, "verify"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "advance_segment": {
          if (!(state.inboxes["advance_segment"].some((item) => item.type === "era.command_compaction.segment.state.before") && state.inboxes["advance_segment"].some((item) => item.type === "era.command_compaction.verified"))) break;
          try {
            const inputs = prepareStaticNode(__vf_w2_n6, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "advance_segment", nodePath: nodePath(state, "advance_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.advance_segment" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n6(inputs, state);
            finishStaticNode(__vf_w2_n6, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n6(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "advance_segment", nodePath: nodePath(state, "advance_segment"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.advance_segment", outputKeys: Object.keys(outputs || {}).sort() });
            enqueueStaticTargets(targets, ready, queued);
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "advance_segment");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "advance_segment", nodePath: nodePath(state, "advance_segment"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        case "end": {
          try {
            const inputs = prepareStaticNode(__vf_w2_n7, state);
            invokeRuntimeHookSync(state.root, "beforeNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal" });
            let outputs;
            let deferred = false;
            outputs = __vf_execute_w2_n7(inputs, state);
            finishStaticNode(__vf_w2_n7, state);
            state.stepCount += 1;
            const targets = __vf_activate_w2_n7(outputs, inputs, state, deferred);
            invokeRuntimeHookSync(state.root, "afterNode", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), type: "era.command_compaction.terminal", outputKeys: Object.keys(outputs || {}).sort() });
            completed = true;
            ready.length = 0;
          } catch (cause) {
            const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path, "end");
            invokeRuntimeHookSync(state.root, "nodeFailed", { nodeId: "end", nodePath: nodePath(state, "end"), blockPath: formatBlockPath(state.path), code: failure.code, message: failure.message }, true);
            throw failure;
          }
          break;
        }
        default:
          break;
      }
    }
    abandonPending(state);
    const publicOutputs = finalizeOutputs(state);
    invokeRuntimeHookSync(root, "afterBlock", { blockPath: formatBlockPath(path), path: [...path] });
    return { publicOutputs, candidates: state.candidates, completed };
  } catch (cause) {
    const failure = ensureErrorLocation(cause, __vf_workflow_2_metadata, path);
    invokeRuntimeHookSync(root, "blockFailed", { blockPath: formatBlockPath(path), path: [...path], code: failure.code, message: failure.message }, true);
    throw failure;
  }
}
var __vfInvokeWorkflow = createStaticWorkflowSync(
  __vf_workflow_0_metadata,
  __vfCapabilityDescriptors,
  __vfCapabilityRequirements,
  __vfSchemaCatalog,
  __vfRuntimePluginDescriptors,
  __vfRuntimePluginFactories,
  __vf_workflow_0_execute
);
function runWorkflow(inputs, options) {
  return __vfObserveSync(__vfInvokeWorkflow, inputs, options);
}
export {
  VIBEFLOW_PLUGIN_ABI,
  VIBEFLOW_WORKFLOW_ABI,
  VibeFlowWorkflowError,
  runWorkflow
};
